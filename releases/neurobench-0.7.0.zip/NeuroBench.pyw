"""NeuroBench (脑电实验台) launcher.

Picks the active version from <root>/versions/current.txt (installed by the updater) and falls back
to the bundled copy in <root>/app if that version is missing or fails to load.
Run with the OpenMuse venv:  pythonw NeuroBench.pyw [--demo]
"""

import os
import sys
import traceback
from pathlib import Path

LAUNCHER_VERSION = 1
HERE = Path(__file__).resolve().parent          # <root>/app
ROOT = HERE.parent
VERSIONS = ROOT / "versions"
os.environ.setdefault("NEUROBENCH_ROOT", str(ROOT))      # tests may point this at a scratch folder
os.environ["NEUROBENCH_LAUNCHER"] = str(Path(__file__).resolve())
os.environ["NEUROBENCH_LAUNCHER_VERSION"] = str(LAUNCHER_VERSION)


def _candidates():
    out = []
    cur = VERSIONS / "current.txt"
    if cur.exists():
        v = cur.read_text(encoding="utf-8").strip()
        d = VERSIONS / v
        if v and (d / "neurobench" / "__init__.py").exists() and not (d / "BAD").exists():
            out.append(d)
    out.append(HERE)          # bundled copy, always present
    return out


def _drop_modules():
    for m in list(sys.modules):
        if m in ("neurobench", "OpenMuse") or m.startswith(("neurobench.", "OpenMuse.")):
            del sys.modules[m]


def main():
    last = None
    for base in _candidates():
        added = [str(base)]
        if (base / "lib").is_dir():
            added.insert(0, str(base / "lib"))      # updated OpenMuse, ahead of site-packages
        for p in reversed(added):
            sys.path.insert(0, p)
        try:
            from neurobench.main import main as run
        except Exception:  # noqa: BLE001
            last = traceback.format_exc()
            if base != HERE:
                (base / "BAD").write_text(last, encoding="utf-8")   # never try this version again
            for p in added:
                while p in sys.path:
                    sys.path.remove(p)
            _drop_modules()
            continue
        os.environ["NEUROBENCH_ACTIVE"] = str(base)
        return run()
    raise SystemExit(last)


if __name__ == "__main__":
    sys.exit(main())
