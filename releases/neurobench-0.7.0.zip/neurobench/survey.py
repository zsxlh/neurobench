"""10-second self-report after each recording: links the physiology to how it felt."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QComboBox, QDialog, QDoubleSpinBox, QGridLayout, QHBoxLayout, QLineEdit, QPushButton, QSlider, QVBoxLayout,
)

from .widgets import label

SCALES = [  # key, label, low end, high end
    ("calm", "平静", "烦躁", "很平静"),
    ("focus", "专注", "很散", "很专注"),
    ("sleepy", "困倦", "很清醒", "很困"),
    ("mood", "心情", "很差", "很好"),
]
ACTIVITIES = ["睁眼看屏幕", "闭眼静坐", "冥想 / 打坐", "站桩 / 练功", "工作 / 学习", "说话 / 聊天", "听音乐", "运动后", "其他"]
SELF_REPORT_LABELS = {
    "sr_calm": "自评平静（1–10）",
    "sr_focus": "自评专注（1–10）",
    "sr_sleepy": "自评困倦（1–10）",
    "sr_mood": "自评心情（1–10）",
    "sr_sleep_h": "昨晚睡眠（小时）",
}


class SurveyDialog(QDialog):
    def __init__(self, parent=None, default_activity: str = ""):
        super().__init__(parent)
        self.setWindowTitle("刚才感觉怎么样")
        self.setMinimumWidth(520)
        self.result_data = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 20)
        lay.setSpacing(12)
        lay.addWidget(label("刚才这段感觉怎么样？", "h2"))
        lay.addWidget(label("十秒钟填完。以后可以拿它和脑电、心率对照，慢慢找出只属于你的规律。", "muted", wrap=True))
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        self.sliders = {}
        for r, (key, name, lo, hi) in enumerate(SCALES):
            grid.addWidget(label(name, ""), r, 0)
            grid.addWidget(label(lo, "faint"), r, 1)
            sl = QSlider(Qt.Orientation.Horizontal)
            sl.setRange(1, 10)
            sl.setValue(5)
            sl.setMinimumWidth(220)
            grid.addWidget(sl, r, 2)
            grid.addWidget(label(hi, "faint"), r, 3)
            val = label("5", "")
            sl.valueChanged.connect(lambda v, l=val: l.setText(str(v)))
            grid.addWidget(val, r, 4)
            self.sliders[key] = sl
        lay.addLayout(grid)
        row = QHBoxLayout()
        row.addWidget(label("刚才在做什么", ""))
        self.cb_act = QComboBox()
        self.cb_act.addItems(ACTIVITIES)
        if default_activity in ACTIVITIES:
            self.cb_act.setCurrentText(default_activity)
        row.addWidget(self.cb_act, 1)
        row.addSpacing(12)
        row.addWidget(label("昨晚睡了", ""))
        self.sp_sleep = QDoubleSpinBox()
        self.sp_sleep.setRange(0, 14)
        self.sp_sleep.setSingleStep(0.5)
        self.sp_sleep.setValue(7.0)
        self.sp_sleep.setSuffix(" 小时")
        row.addWidget(self.sp_sleep)
        lay.addLayout(row)
        self.e_note = QLineEdit()
        self.e_note.setPlaceholderText("备注（可不填）：比如喝了咖啡、练了哪个桩、有什么感觉")
        lay.addWidget(self.e_note)
        btns = QHBoxLayout()
        skip = QPushButton("跳过")
        skip.setObjectName("ghost")
        skip.clicked.connect(self.reject)
        ok = QPushButton("保存")
        ok.setObjectName("primary")
        ok.clicked.connect(self._save)
        btns.addStretch(1)
        btns.addWidget(skip)
        btns.addWidget(ok)
        lay.addLayout(btns)

    def _save(self):
        self.result_data = {
            **{f"sr_{k}": s.value() for k, s in self.sliders.items()},
            "sr_sleep_h": self.sp_sleep.value(),
            "activity": self.cb_act.currentText(),
            "note": self.e_note.text().strip(),
        }
        self.accept()
