"""Session recording to disk, loading, and per-segment analysis."""

from __future__ import annotations

import csv
import json
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import numpy as np

from . import dsp

from .paths import SESSIONS as ROOT  # <install root>/recordings/sessions, same for every app version
SENSOR_FILES = {"EEG": "eeg.f64", "OPTICS": "optics.f64", "ACCGYRO": "imu.f64", "BATTERY": "battery.f64"}


def safe_name(s: str) -> str:
    bad = '<>:"/\\|?*'
    s = "".join("_" if c in bad else c for c in s.strip())
    return s[:40] or "未命名"


# ============================================================================ recorder
class Recorder:
    """Streams decoded samples, raw BLE lines and markers to a session folder.

    Times stored in files are seconds since recording start.
    """

    def __init__(self, hub, name: str, protocol: str, notes: str = ""):
        self.hub = hub
        self.t_start = hub.now()
        self.started_at = datetime.now()
        stamp = self.started_at.strftime("%Y%m%d_%H%M%S")
        self.dir = ROOT / f"{stamp}_{safe_name(name)}"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.meta = {
            "app": "NeuroBench",
            "format": 1,
            "name": name,
            "protocol": protocol,
            "notes": notes,
            "started_at": self.started_at.isoformat(timespec="seconds"),
            "source": hub.info.source,
            "device": {"name": hub.info.name, "address": hub.info.address, "firmware": hub.info.firmware},
            "channels": {},
            "fs": {"EEG": 256.0, "OPTICS": 64.0, "ACCGYRO": 52.0},
            "duration": 0.0,
        }
        self.meta.update(_environment_info(hub))
        self._files = {}
        self._raw = open(self.dir / "raw_ble.txt", "w", encoding="utf-8") if hub.info.source in ("muse", "replay") else None
        self._metrics = None
        self.markers: list[dict] = []
        self._lock = threading.Lock()
        self._write_meta()

    # called by the live analyzer about twice a second: what the screen showed, plus a flush
    METRIC_FIELDS = ["t", "live", "battery",
                     "q_TP9", "q_AF7", "q_AF8", "q_TP10", "qtext_TP9", "qtext_AF7", "qtext_AF8", "qtext_TP10",
                     "delta", "theta", "alpha", "beta", "gamma", "emg", "hr", "hr_ok", "rmssd", "hrv_ok",
                     "blink_rate", "mains_uv", "motion", "ppg_channel"]

    def write_metrics(self, row: dict):
        with self._lock:
            if self._metrics is None:
                self._metrics = open(self.dir / "live_metrics.csv", "w", encoding="utf-8-sig", newline="")
                self._metrics_w = csv.DictWriter(self._metrics, fieldnames=self.METRIC_FIELDS, extrasaction="ignore")
                self._metrics_w.writeheader()
            row = dict(row, t=round(self.elapsed(), 3))
            self._metrics_w.writerow({k: (f"{v:.5g}" if isinstance(v, float) else v) for k, v in row.items()})
            self._metrics.flush()
        # keep data on disk if the program or the computer stops unexpectedly
        with self.hub.lock:
            for f in self._files.values():
                f.flush()
            if self._raw is not None:
                self._raw.flush()

    # called by the hub (inside its lock)
    def write_raw(self, line: str):
        if self._raw is not None:
            self._raw.write(line.rstrip("\n") + "\n")

    def write_rows(self, sensor: str, names: list, rows: np.ndarray):
        fname = SENSOR_FILES.get(sensor)
        if fname is None:
            return
        rows = rows[rows[:, 0] >= self.t_start]
        if len(rows) == 0:
            return
        f = self._files.get(sensor)
        if f is None:
            f = open(self.dir / fname, "ab")
            self._files[sensor] = f
            self.meta["channels"][sensor] = ["time", *names]
            self._write_meta()
        out = rows.copy()
        out[:, 0] -= self.t_start
        out.astype("<f8").tofile(f)

    def elapsed(self) -> float:
        return self.hub.now() - self.t_start

    def add_marker(self, label: str, kind: str = "event"):
        m = {"t": round(self.elapsed(), 3), "label": label, "kind": kind}
        with self._lock:
            self.markers.append(m)
            self._write_markers()
        return m

    def _write_markers(self):
        with open(self.dir / "markers.csv", "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["t", "label", "kind"])
            w.writeheader()
            w.writerows(self.markers)

    def _write_meta(self):
        with open(self.dir / "session.json", "w", encoding="utf-8") as f:
            json.dump(self.meta, f, ensure_ascii=False, indent=2)

    def close(self, notes: str | None = None):
        with self.hub.lock:
            if self.hub.recorder is self:
                self.hub.recorder = None
        self.meta["duration"] = round(self.elapsed(), 2)
        self.meta["ended_at"] = datetime.now().isoformat(timespec="seconds")
        self.meta["battery_end"] = _num(self.hub.info.battery)
        self.meta["device"]["firmware"] = self.hub.info.firmware or self.meta["device"].get("firmware", "")
        if notes is not None:
            self.meta["notes"] = notes
        self.add_marker("结束", "end")
        for f in self._files.values():
            f.close()
        if self._raw is not None:
            self._raw.close()
        with self._lock:
            if self._metrics is not None:
                self._metrics.close()
        self.meta["files"] = {p.name: p.stat().st_size for p in sorted(self.dir.iterdir()) if p.is_file()}
        self._write_meta()
        return self.dir


def _num(v):
    try:
        v = float(v)
        return None if v != v else round(v, 1)
    except (TypeError, ValueError):
        return None


def _environment_info(hub) -> dict:
    """Software and device context saved with every recording (no personal data)."""
    import platform
    try:
        from importlib.metadata import version
        om = version("OpenMuse")
    except Exception:  # noqa: BLE001
        om = ""
    try:
        from . import APP_VERSION
    except Exception:  # noqa: BLE001
        APP_VERSION = ""
    return {
        "software": {"neurobench": APP_VERSION, "openmuse": om, "python": platform.python_version(),
                     "os": f"{platform.system()} {platform.release()} ({platform.machine()})"},
        "preset": hub.info.extra.get("preset", ""),
        "battery_start": _num(hub.info.battery),
    }


# ============================================================================ loading
@dataclass
class Segment:
    label: str
    t0: float
    t1: float
    metrics: dict = field(default_factory=dict)


@dataclass
class Session:
    dir: Path
    meta: dict
    data: dict          # sensor -> (t, X, names)
    markers: list
    segments: list = field(default_factory=list)

    @property
    def title(self):
        return self.meta.get("name") or self.dir.name

    @property
    def started(self) -> datetime:
        try:
            return datetime.fromisoformat(self.meta["started_at"])
        except Exception:  # noqa: BLE001
            return datetime.fromtimestamp(self.dir.stat().st_mtime)


def list_sessions():
    if not ROOT.exists():
        return []
    out = []
    for d in sorted(ROOT.iterdir(), reverse=True):
        mf = d / "session.json"
        if d.is_dir() and mf.exists():
            try:
                meta = json.loads(mf.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                continue
            out.append((d, meta))
    return out


def list_all_sessions():
    """Local sessions as dicts: dir, meta."""
    return [{"dir": d, "meta": meta} for d, meta in list_sessions()]


def export_sessions(dirs, zip_path: Path):
    """Pack whole session folders into one .zip for copying to another computer."""
    import zipfile

    dirs = [Path(d) for d in dirs]
    zip_path = Path(zip_path)
    tmp = zip_path.with_name(zip_path.name + ".part")
    n = 0
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for d in dirs:
            for p in sorted(d.rglob("*")):
                if p.is_file() and not p.name.endswith(".part"):
                    z.write(p, f"{d.name}/{p.relative_to(d).as_posix()}")
            n += 1
    import os
    os.replace(tmp, zip_path)
    return n, zip_path.stat().st_size


def import_archive(src: Path, dest: Path | None = None):
    """Unpack sessions from an exported .zip (or copy a session folder) into the local store.

    Sessions whose folder name already exists are skipped. Returns (imported, skipped) name lists.
    """
    import os
    import shutil
    import zipfile

    dest = Path(dest or ROOT)
    dest.mkdir(parents=True, exist_ok=True)
    src = Path(src)
    imported, skipped = [], []
    if src.is_dir():
        groups = [src] if (src / "session.json").exists() else [d for d in src.iterdir() if (d / "session.json").exists()]
        for d in groups:
            if (dest / d.name).exists():
                skipped.append(d.name)
                continue
            shutil.copytree(d, dest / (d.name + ".importing"))
            os.replace(dest / (d.name + ".importing"), dest / d.name)
            imported.append(d.name)
        return imported, skipped
    with zipfile.ZipFile(src) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        tops = sorted({n.split("/", 1)[0] for n in names if "/" in n})
        tops = [t for t in tops if f"{t}/session.json" in names]
        for t in tops:
            if (dest / t).exists():
                skipped.append(t)
                continue
            tmp = dest / (t + ".importing")
            if tmp.exists():
                shutil.rmtree(tmp)
            root = tmp.resolve()
            for n in names:
                if not n.startswith(t + "/"):
                    continue
                target = (tmp / n.split("/", 1)[1]).resolve()
                if root not in target.parents:      # refuse paths that escape the folder
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(n) as fsrc, open(target, "wb") as fdst:
                    shutil.copyfileobj(fsrc, fdst)
            os.replace(tmp, dest / t)
            imported.append(t)
    return imported, skipped


def load_session(d: Path) -> Session:
    d = Path(d)
    meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
    data = {}
    for sensor, fname in SENSOR_FILES.items():
        p = d / fname
        cols = meta.get("channels", {}).get(sensor)
        if not p.exists() or not cols:
            continue
        arr = np.fromfile(p, dtype="<f8")
        n = len(cols)
        arr = arr[: (len(arr) // n) * n].reshape(-1, n)
        if len(arr):
            order = np.argsort(arr[:, 0], kind="stable")
            arr = arr[order]
        data[sensor] = (arr[:, 0], arr[:, 1:], cols[1:])
    markers = []
    mp = d / "markers.csv"
    if mp.exists():
        with open(mp, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                try:
                    markers.append({"t": float(r["t"]), "label": r["label"], "kind": r.get("kind", "event")})
                except (ValueError, KeyError):
                    pass
    s = Session(dir=d, meta=meta, data=data, markers=markers)
    s.segments = build_segments(s)
    for seg in s.segments:
        seg.metrics = segment_metrics(s, seg.t0, seg.t1)
    return s


def build_segments(s: Session):
    dur = float(s.meta.get("duration") or 0)
    if "EEG" in s.data and len(s.data["EEG"][0]):
        dur = max(dur, float(s.data["EEG"][0][-1]))
    starts = [m for m in s.markers if m["kind"] == "segment"]
    segs = []
    if not starts:
        return [Segment("全程", 0.0, dur)]
    if starts[0]["t"] > 5:
        segs.append(Segment("开始前", 0.0, starts[0]["t"]))
    ends = [m["t"] for m in starts[1:]] + [dur]
    for m, e in zip(starts, ends):
        if e - m["t"] >= 1.0:
            segs.append(Segment(m["label"], m["t"], e))
    return segs


# ============================================================================ metrics
EPOCH = 2.0
EMG_LIMIT = 0.30   # share of 30-100 Hz power above which an epoch counts as muscle-contaminated


def _slice(s: Session, sensor, t0, t1):
    if sensor not in s.data:
        return None, None, None
    t, X, names = s.data[sensor]
    m = (t >= t0) & (t < t1)
    return t[m], X[m], names


MOTION_LIMIT = 5.0  # deg/s; head movement above this spoils an epoch


def segment_metrics(s: Session, t0: float, t1: float) -> dict:
    """Per-segment summary. Every 2 s epoch is tagged blink / muscle / motion / contact; band powers
    use only clean epochs, so eye blinks and movement do not masquerade as slow brain waves."""
    out = {"duration": t1 - t0}
    t, X, names = _slice(s, "EEG", t0, t1)
    tg, G, _ = _slice(s, "ACCGYRO", t0, t1)
    if X is not None and len(X) > dsp.FS_EEG * 4 and all(n in names for n in dsp.EEG_NAMES):
        X = X[:, [names.index(n) for n in dsp.EEG_NAMES]]
        x = dsp.notch_only(X)
        pk, _ = dsp.detect_blinks(X)
        bm = dsp.blink_mask(len(X), pk)
        out["blinks"] = int(len(pk))
        out["blink_rate"] = float(len(pk) / max(1e-9, (t[-1] - t[0])) * 60.0)
        out["blink_times"] = t[pk].tolist()
        ep_s = EPOCH if (t[-1] - t[0]) < 1800 else 30.0   # long recordings (sleep): 30 s epochs keep loading fast
        W = int(ep_s * dsp.FS_EEG)
        n_ep = len(x) // W
        rels, emgs, tags = [], [], []
        for k in range(n_ep):
            sl = slice(k * W, (k + 1) * W)
            rel, _, emg = dsp.band_powers(x[sl])
            q = dsp.window_quality(X[sl], mask=bm[sl])
            good = [c for c, (lv, _) in enumerate(q) if lv > 0]
            use = good or list(range(4))
            rels.append(rel[use].mean(axis=0))
            emgs.append(float(emg[use].mean()))
            tag = ""
            if len(good) < 3:
                tag = "contact"
            elif bm[sl].mean() > 0.05:
                tag = "blink"
            elif emgs[-1] >= EMG_LIMIT:
                tag = "emg"
            elif G is not None and len(G) > 10:
                m = (tg >= t[sl][0]) & (tg < t[sl][-1])
                if m.sum() > 10 and dsp.motion_level(G[m, 3:6]) > MOTION_LIMIT:
                    tag = "motion"
            tags.append(tag)
        rels, emgs = np.array(rels), np.array(emgs)
        keep = np.array([tg_ == "" for tg_ in tags], bool)
        out["epochs"] = int(n_ep)
        out["clean_share"] = float(keep.mean()) if n_ep else float("nan")
        out["artifact_counts"] = {k: tags.count(k) for k in ("blink", "emg", "motion", "contact")}
        out["emg"] = float(np.mean(emgs)) if n_ep else float("nan")
        use = rels[keep] if keep.sum() >= 2 else rels
        for i, k in enumerate(dsp.BAND_KEYS):
            out[k] = float(use[:, i].mean()) if len(use) else float("nan")
        clean_samples = np.concatenate([np.arange(k * W, (k + 1) * W) for k in range(n_ep) if keep[k]]) if keep.any() else None
        xa = x[clean_samples] if clean_samples is not None and len(clean_samples) > dsp.FS_EEG * 8 else x
        out["iaf"] = dsp.alpha_peak(xa[:, [0, 3]])
        out["alpha_series"] = (t0 + ep_s * (np.arange(n_ep) + 0.5), rels[:, 2] if n_ep else np.array([]), keep)
        out["epoch_tags"] = tags
    t_o, O, onames = _slice(s, "OPTICS", t0, t1)
    if O is not None and len(O) > dsp.FS_OPT * 10:
        h = dsp.robust_heart(O, onames)
        out["hr"], out["rmssd"] = h["hr"], h["rmssd"]
        out["hr_ok"], out["hrv_ok"] = h["ok_hr"], h["ok_hrv"]
        if h["ch"] is not None:
            out["ppg_channel"] = onames[h["ch"]]
    if G is not None and len(G) > 10:
        out["motion"] = dsp.motion_level(G[:, 3:6])
    return out


def session_hb_series(s: Session, side: str = "L", step: float = 1.0):
    """dHbO/dHbR over the whole session relative to its first 30 s (outer channels)."""
    if "OPTICS" not in s.data:
        return None
    t, O, names = s.data["OPTICS"]
    try:
        i730 = O[:, names.index(f"OPTICS_{side}O_NIR")]
        i850 = O[:, names.index(f"OPTICS_{side}O_IR")]
    except ValueError:
        return None
    nb = int(min(len(t), 30 * dsp.FS_OPT))
    hbo, hbr = dsp.hb_changes(i730, i850, baseline_n=max(nb, 1))
    hbo, hbr = dsp.lowpass(hbo, dsp.FS_OPT, 0.1), dsp.lowpass(hbr, dsp.FS_OPT, 0.1)
    k = max(1, int(step * dsp.FS_OPT))
    return t[::k], hbo[::k], hbr[::k]


METRIC_LABELS = {
    "alpha": "α 相对功率",
    "blink_rate": "眨眼（次/分）",
    "theta": "θ 相对功率",
    "beta": "β 相对功率",
    "delta": "δ 相对功率",
    "iaf": "α 峰值频率 (Hz)",
    "hr": "心率 (次/分)",
    "rmssd": "心率变异 RMSSD (ms)",
    "emg": "肌电占比",
    "clean_share": "干净数据比例",
    "motion": "头部晃动 (°/s)",
}


def export_segments_csv(s: Session, path: Path):
    keys = ["duration", "alpha", "theta", "beta", "delta", "gamma", "iaf", "hr", "rmssd", "emg", "clean_share", "motion"]
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["段落", "开始(s)", "结束(s)", *keys])
        for seg in s.segments:
            w.writerow([seg.label, f"{seg.t0:.1f}", f"{seg.t1:.1f}",
                        *[("" if not isinstance(seg.metrics.get(k), (int, float)) else f"{seg.metrics[k]:.4f}") for k in keys]])
