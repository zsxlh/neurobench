"""个人 page: what has been learned from your own data, and what still needs more data."""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QHBoxLayout, QHeaderView, QProgressBar, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from . import theme as T
from .widgets import Card, label


def _fmt(v, nd=1, pct=False):
    if v is None:
        return "—"
    return f"{v * 100:.{nd}f}%" if pct else f"{v:.{nd}f}"


class PersonalPage(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)
        head = QHBoxLayout()
        head.addWidget(label("从你自己的数据里学到的", "h1"))
        head.addStretch(1)
        b = QPushButton("刷新")
        b.clicked.connect(self.refresh)
        head.addWidget(b)
        root.addLayout(head)
        root.addWidget(label("这里只用你自己的真实录制（不含模拟数据）。数据越多，分析越可靠；"
                             "不够的地方会直接告诉你还差多少，不出结论。", "muted", wrap=True))

        top = QHBoxLayout()
        top.setSpacing(14)
        self.c_unlock = Card("解锁进度")
        self.unlock_box = QVBoxLayout()
        self.c_unlock.add(self.unlock_box)
        top.addWidget(self.c_unlock, 1)
        self.c_model = Card("个人模型", "用生理数据预测你的自评")
        self.l_model = label("", "muted", wrap=True)
        self.c_model.add(self.l_model)
        self.l_switch = label("", "muted", wrap=True)
        self.c_model.add(self.l_switch)
        top.addWidget(self.c_model, 1)
        root.addLayout(top)

        cb = Card("个人基线", "同一种段落的平均值 ± 波动；满 5 次后，回看和报告里会说「比你平时高/低」")
        self.tbl = QTableWidget()
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        cb.add(self.tbl, 1)
        root.addWidget(cb, 1)
        self._loaded = False

    def showEvent(self, e):
        super().showEvent(e)
        if not self._loaded:
            self.refresh()

    def refresh(self):
        from . import baseline as B
        from . import training as TR
        self._loaded = True
        rows = B.session_rows()
        # unlock progress
        while self.unlock_box.count():
            it = self.unlock_box.takeAt(0)
            w = it.widget() or (it.layout() and None)
            if it.widget():
                it.widget().deleteLater()
        for name, have, need, note in B.unlock_progress(rows):
            r = QHBoxLayout()
            lab = label(f"{name}  {min(have, need)}/{need}" + ("  ✓ 已解锁" if have >= need else ""), "")
            lab.setMinimumWidth(220)
            bar = QProgressBar()
            bar.setRange(0, need)
            bar.setValue(min(have, need))
            bar.setTextVisible(False)
            bar.setFixedHeight(8)
            bar.setStyleSheet(f"QProgressBar {{ background: {T.SURFACE2}; border: none; border-radius: 4px; }}"
                              f"QProgressBar::chunk {{ background: {T.GOOD if have >= need else T.ACCENT}; border-radius: 4px; }}")
            w = QWidget()
            v = QVBoxLayout(w)
            v.setContentsMargins(0, 4, 0, 4)
            v.setSpacing(4)
            r.addWidget(lab)
            r.addWidget(bar, 1)
            v.addLayout(r)
            v.addWidget(label(note, "faint"))
            self.unlock_box.addWidget(w)
        # personal model
        res = B.personal_model(rows)
        lines = []
        for k, r in res.items():
            if not r["ready"]:
                lines.append(f"{r['name']}：有 {r['n']} 次带问卷的录制，满 20 次后开始建模。")
            elif r["usable"]:
                tops = "、".join(f"{n}{'↑' if w > 0 else '↓'}" for n, w in r["top"])
                lines.append(f"{r['name']}：能预测一部分（交叉验证 R²={r['r2']:.2f}）。最相关的是 {tops}。")
            else:
                lines.append(f"{r['name']}：目前生理指标预测不了你的自评（交叉验证 R²={r['r2']:.2f}），说明两者关系不稳定，继续积累。")
        self.l_model.setText("\n".join(lines))
        m = TR.load_model()
        self.l_switch.setText(f"想法开关：{TR.trial_count()} 轮训练，交叉验证准确率 "
                              f"{m['accuracy'] * 100:.0f}%（瞎猜 50%）。" if m else
                              f"想法开关：{TR.trial_count()} 轮训练，还没有模型（在「意念开关」页训练）。")
        # baseline table
        table = B.baseline_table(rows)
        cols = ["段落", "次数", *B.METRICS.values()]
        self.tbl.clear()
        self.tbl.setColumnCount(len(cols))
        self.tbl.setHorizontalHeaderLabels(cols)
        labs = sorted(table, key=lambda k: -table[k]["n"])
        self.tbl.setRowCount(len(labs))
        pct = {"alpha", "theta", "beta", "emg"}
        for r, lab in enumerate(labs):
            e = table[lab]
            vals = [lab, str(e["n"])]
            for k in B.METRICS:
                if k in e:
                    mu, sd, _ = e[k]
                    vals.append(f"{_fmt(mu, 0, True)} ± {_fmt(sd, 0, True)}" if k in pct else f"{mu:.1f} ± {sd:.1f}")
                else:
                    vals.append("—")
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignmentFlag.AlignCenter if c else Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
                if c == 1 and e["n"] >= B.MIN_BASELINE:
                    it.setForeground(Qt.GlobalColor.green)
                self.tbl.setItem(r, c, it)
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
