"""Automated walk-through with screenshots (used for testing): --demo --shots <dir>."""

from __future__ import annotations

import sys
import traceback
from pathlib import Path

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QApplication

from . import protocols


def run_shots(w, outdir: str, fast: bool = False):
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    log = open(out / "selftest.log", "w", encoding="utf-8")

    def hook(t, v, tb):
        log.write("".join(traceback.format_exception(t, v, tb)))
        log.flush()

    sys.excepthook = hook
    protocols.speak = lambda *_a, **_k: None
    protocols.chime = lambda *_a, **_k: None
    import neurobench.page_record as pr
    import neurobench.page_switch as ps
    pr.speak = pr.chime = ps.speak = ps.chime = lambda *_a, **_k: None

    def shot(name):
        w.grab().save(str(out / f"{name}.png"))
        log.write(f"shot {name}\n")
        log.flush()

    def start_record():
        w.go("record")
        w.p_record.chk_voice.setChecked(False)
        w.p_record.cb_proto.setCurrentText("睁眼闭眼测试")
        w.p_record.e_name.setText("自检")
        w.p_record.start()
        log.write(f"recording: {w.p_record.rec and w.p_record.rec.dir}\n")

    def mark():
        w.p_record.mark("眨眼")

    def review():
        w.go("review")

    def trends():
        w.p_trends.include_sim = True
        w.go("trends")

    def transfer():
        # export a session from another folder (env var) to a zip, then import it here, as the user would
        import os
        from . import session as S
        src = os.environ.get("NB_TEST_IMPORT_SRC")
        if not src:
            log.write("no NB_TEST_IMPORT_SRC; skip transfer\n")
            return
        z = out / "transfer_test.zip"
        n, size = S.export_sessions([Path(src)], z)
        log.write(f"exported {n} session(s), {size} bytes\n")
        w.go("review")
        w.p_review.import_paths([str(z)])
        log.write(f"import status: {w.p_review.l_xfer.text()}\n")

    def quick_check():
        import json, zipfile
        zs = sorted(out.glob("NeuroBench_*.zip"))
        log.write(f"quick zips: {[z.name for z in zs]}\n")
        if zs:
            with zipfile.ZipFile(zs[-1]) as zz:
                names = zz.namelist()
                log.write("zip files: " + ", ".join(sorted(n.split('/', 1)[1] for n in names)) + "\n")
                meta = json.loads(zz.read([n for n in names if n.endswith("session.json")][0]))
                log.write(f"meta mode={meta.get('mode')} software={meta.get('software')} preset={meta.get('preset')} "
                          f"battery={meta.get('battery_start')}->{meta.get('battery_end')} duration={meta.get('duration')}\n")
                mk = zz.read([n for n in names if n.endswith("markers.csv")][0]).decode("utf-8-sig")
                log.write("markers:\n" + mk + "\n")
                lm = zz.read([n for n in names if n.endswith("live_metrics.csv")][0]).decode("utf-8-sig").splitlines()
                log.write(f"live_metrics rows={len(lm) - 1}\nheader={lm[0]}\nlast={lm[-1]}\n")
        log.write(f"live bar: {w.p_live.l_rec.text()}\n")
        log.flush()

    if "--train" in sys.argv:
        import os
        os.environ.update(NB_MED_FAST="1", NB_MUTE="1", NB_NO_SURVEY="1", NB_NO_REVEAL="1")

        def tr_start():
            w.go("switch")
            w.p_switch.start_training()
            log.write(f"training: {bool(w.p_switch.train)}\n")

        def tr_check():
            from . import training as TR
            m = TR.load_model()
            log.write(f"trials stored: {TR.trial_count()} | model accuracy: {m and round(m['accuracy'], 2)}\n")
            log.write(f"status: {w.p_switch.l_train.text()}\n")

        steps = [(4000, tr_start), (30000, lambda: shot("t1_training")), (134000, tr_check),
                 (135000, lambda: w.go("personal")), (138000, lambda: shot("t2_personal")),
                 (139000, lambda: (log.write("done\n"), log.close(), QApplication.quit()))]
        for ms, fn in steps:
            QTimer.singleShot(ms, fn)
        return

    if "--meditate" in sys.argv:
        import os
        os.environ.update(NB_MED_FAST="1", NB_MUTE="1", NB_NO_SURVEY="1", NB_NO_REVEAL="1")
        def med_start():
            w.go("meditate")
            w.p_meditate.chk_voice.setChecked(False)
            if "--breath" in sys.argv:
                w.p_meditate.cb_mode.setCurrentIndex(3)
            w.p_meditate.start()
            log.write(f"meditate state: {w.p_meditate.state}\n")

        def med_check():
            import json
            d = w.p_meditate.rec.dir
            meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
            log.write(f"summary: {meta.get('meditation')}\nfiles: {sorted(p.name for p in d.iterdir())}\n")
            log.write(f"session dir: {d}\n")

        steps = [(5000, med_start), (12000, lambda: shot("m1_calibrate")), (40000, lambda: shot("m2_session")),
                 (62000, lambda: shot("m3_results")), (63000, med_check),
                 (64000, lambda: (log.write("done\n"), log.close(), QApplication.quit()))]
        for ms, fn in steps:
            QTimer.singleShot(ms, fn)
        return

    if fast:
        import os
        os.environ["NB_NO_REVEAL"] = "1"
        os.environ["NB_NO_SURVEY"] = "1"
        os.environ["NB_EXPORT_DIR"] = str(out)
        steps = [
            (8000, w.quick_record),
            (12000, lambda: w._mark("眨眼")),
            (15000, lambda: w._mark("入静")),
            (20000, lambda: shot("0_live_recording")),
            (27000, w.quick_record),
            (28500, quick_check),
            (31000, lambda: shot("1_live")),
            (32000, lambda: w.go("switch")),
            (36000, lambda: shot("3_switch")),
            (37000, review),
            (40000, lambda: shot("4_review")),
            (41000, trends),
            (44000, lambda: shot("5_trends")),
            (45000, transfer),
            (49000, lambda: shot("6_review_imported")),
            (49500, lambda: (w.disconnect(), w.go("live"))),
            (53000, lambda: shot("8_live_disconnected")),
            (54000, lambda: (log.write("done\n"), log.close(), QApplication.quit())),
        ]
        for ms, fn in steps:
            QTimer.singleShot(ms, fn)
        return

    steps = [
        (6000, start_record),
        (13000, lambda: shot("2_record")),
        (20000, mark),
        (22000, lambda: w.go("live")),
        (24000, lambda: shot("1_live")),
        (40000, lambda: w.go("switch")),
        (46000, lambda: shot("3_switch")),
        (50000, lambda: w.go("live")),
        (52000, lambda: shot("1b_live_closed")),
        (131000, review),
        (134000, lambda: shot("4_review")),
        (136000, trends),
        (139000, lambda: shot("5_trends")),
        (140000, lambda: (log.write("done\n"), log.close(), QApplication.quit())),
    ]
    for ms, fn in steps:
        QTimer.singleShot(ms, fn)
