"""Colours, fonts and the Qt style sheet."""

BG = "#0d1018"
SURFACE = "#151a26"
SURFACE2 = "#1c2231"
BORDER = "#262d40"
TEXT = "#e7e9f0"
MUTED = "#8b92a8"
FAINT = "#5b6278"
ACCENT = "#5eead4"
ACCENT2 = "#a78bfa"
GOOD = "#34d399"
WARN = "#fbbf24"
BAD = "#f87171"
GRID = "#222838"

QUALITY_COLORS = {2: GOOD, 1: WARN, 0: BAD}

FONT = "Microsoft YaHei UI"
NUM_FONT = "Segoe UI"

QSS = f"""
* {{ font-family: "{FONT}"; color: {TEXT}; }}
QMainWindow, QWidget#root {{ background: {BG}; }}
QWidget {{ background: transparent; font-size: 13px; }}
QToolTip {{ background: {SURFACE2}; color: {TEXT}; border: 1px solid {BORDER}; padding: 6px; }}

QFrame#card {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 14px; }}
QFrame#sidebar {{ background: #0a0d14; border-right: 1px solid {BORDER}; }}
QFrame#topbar {{ background: {BG}; border-bottom: 1px solid {BORDER}; }}

QLabel#h1 {{ font-size: 22px; font-weight: 600; }}
QLabel#h2 {{ font-size: 15px; font-weight: 600; }}
QLabel#cardTitle {{ font-size: 13px; font-weight: 600; color: {TEXT}; }}
QLabel#muted {{ color: {MUTED}; }}
QLabel#faint {{ color: {FAINT}; font-size: 12px; }}
QLabel#brand {{ font-family: "{NUM_FONT}"; font-size: 22px; font-weight: 700; color: {ACCENT}; letter-spacing: 0.5px; }}
QLabel#brandSub {{ color: {FAINT}; font-size: 11px; letter-spacing: 1px; }}

QPushButton {{
    background: {SURFACE2}; border: 1px solid {BORDER}; border-radius: 10px;
    padding: 8px 16px; font-size: 13px;
}}
QPushButton:hover {{ border-color: {ACCENT}; }}
QPushButton:pressed {{ background: {BORDER}; }}
QPushButton:disabled {{ color: {FAINT}; border-color: {BORDER}; }}
QPushButton#primary {{ background: {ACCENT}; color: #04211c; border: none; font-weight: 600; }}
QPushButton#primary:hover {{ background: #7ff3e0; }}
QPushButton#primary:disabled {{ background: {SURFACE2}; color: {FAINT}; }}
QPushButton#danger {{ background: {BAD}; color: #2a0707; border: none; font-weight: 600; }}
QPushButton#ghost {{ background: transparent; border: 1px solid {BORDER}; }}
QPushButton#marker {{ padding: 10px 8px; font-size: 13px; }}
QPushButton#marker:hover {{ border-color: {ACCENT2}; }}

QPushButton#nav {{
    text-align: left; padding: 11px 18px; border: none; border-radius: 10px;
    font-size: 14px; color: {MUTED}; background: transparent;
}}
QPushButton#nav:hover {{ color: {TEXT}; background: {SURFACE}; }}
QPushButton#nav:checked {{ color: {TEXT}; background: {SURFACE2}; border-left: 3px solid {ACCENT}; }}

QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QDoubleSpinBox, QSpinBox {{
    background: {SURFACE2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 6px 10px;
    selection-background-color: {ACCENT2};
}}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus {{ border-color: {ACCENT}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {SURFACE2}; border: 1px solid {BORDER}; selection-background-color: {BORDER}; }}

QListWidget {{ background: transparent; border: none; outline: none; }}
QListWidget::item {{ padding: 10px 10px; border-radius: 8px; margin: 2px 0; }}
QListWidget::item:selected {{ background: {SURFACE2}; color: {TEXT}; }}
QListWidget::item:hover {{ background: {SURFACE}; }}

QTableWidget {{ background: transparent; border: none; gridline-color: {GRID}; }}
QHeaderView::section {{ background: {SURFACE}; color: {MUTED}; border: none; border-bottom: 1px solid {BORDER}; padding: 6px; }}
QTableWidget::item {{ padding: 4px; }}
QTableWidget::item:selected {{ background: {SURFACE2}; }}

QScrollBar:vertical {{ background: transparent; width: 10px; }}
QScrollBar::handle:vertical {{ background: {BORDER}; border-radius: 5px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QScrollBar:horizontal {{ height: 0; }}

QSlider::groove:horizontal {{ height: 4px; background: {BORDER}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: {ACCENT}; width: 16px; height: 16px; margin: -6px 0; border-radius: 8px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT}; border-radius: 2px; }}

QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid {BORDER}; background: {SURFACE2}; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}

QDialog {{ background: {BG}; }}
QMessageBox {{ background: {BG}; }}
"""
