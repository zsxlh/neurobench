"""Where updates are published (public GitHub repository; jsDelivr mirrors it)."""

OWNER = "zsxlh"
REPO = "neurobench"
BRANCH = "main"
