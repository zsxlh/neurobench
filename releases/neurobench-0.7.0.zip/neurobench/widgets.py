"""Reusable visual building blocks."""

from __future__ import annotations

import math

import pyqtgraph as pg
from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen, QRadialGradient
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget

from . import theme as T

pg.setConfigOptions(antialias=True, background=None, foreground=T.MUTED)


def label(text="", name=None, wrap=False):
    l = QLabel(text)
    if name:
        l.setObjectName(name)
    l.setWordWrap(wrap)
    return l


class Card(QFrame):
    def __init__(self, title: str = "", subtitle: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(16, 14, 16, 14)
        self.lay.setSpacing(8)
        if title or subtitle:
            head = QHBoxLayout()
            head.setSpacing(8)
            self.title_label = label(title, "cardTitle")
            head.addWidget(self.title_label)
            head.addStretch(1)
            self.sub_label = label(subtitle, "faint")
            head.addWidget(self.sub_label)
            self.lay.addLayout(head)

    def add(self, w, stretch=0):
        if isinstance(w, QWidget):
            self.lay.addWidget(w, stretch)
        else:
            self.lay.addLayout(w, stretch)
        return w


class StatTile(QFrame):
    """Small card with a caption, a big number and a hint line."""

    def __init__(self, caption: str, unit: str = "", accent: str = T.ACCENT):
        super().__init__()
        self.setObjectName("card")
        self.accent = accent
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(2)
        self.cap = label(caption, "muted")
        row = QHBoxLayout()
        row.setSpacing(6)
        self.val = QLabel("—")
        f = QFont(T.NUM_FONT, 22)
        f.setWeight(QFont.Weight.DemiBold)
        self.val.setFont(f)
        self.unit = label(unit, "faint")
        row.addWidget(self.val)
        row.addWidget(self.unit, 0, Qt.AlignmentFlag.AlignBottom)
        row.addStretch(1)
        self.hint = label("", "faint")
        lay.addWidget(self.cap)
        lay.addLayout(row)
        lay.addWidget(self.hint)
        self.set_color(accent)

    def set_color(self, c):
        self.val.setStyleSheet(f"color: {c};")

    def set(self, value: str, hint: str = "", color: str | None = None):
        self.val.setText(value)
        self.hint.setText(hint)
        if color:
            self.set_color(color)


class HeadbandMap(QWidget):
    """Top view of the headband arc with four contact dots coloured by quality."""

    POS = {  # angle on the arc (degrees, 90 = front centre)
        "EEG_TP9": 192, "EEG_AF7": 126, "EEG_AF8": 54, "EEG_TP10": -12,
    }
    SHORT = {"EEG_TP9": "TP9", "EEG_AF7": "AF7", "EEG_AF8": "AF8", "EEG_TP10": "TP10"}
    SIDE = {"EEG_TP9": "左耳后", "EEG_AF7": "左前额", "EEG_AF8": "右前额", "EEG_TP10": "右耳后"}

    def __init__(self):
        super().__init__()
        self.q = {k: (0, "等待") for k in self.POS}
        self.setMinimumHeight(170)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_quality(self, q: dict):
        self.q = q
        self.update()

    # order of the text legend under the arc: left column, right column
    LEGEND = [("EEG_AF7", "EEG_AF8"), ("EEG_TP9", "EEG_TP10")]

    def paintEvent(self, _):
        """Arc with short codes next to the dots; full names and status in a 2x2 legend below.

        Nothing is centred on a dot any more, so labels cannot collide on narrow screens.
        """
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        # legend in two columns if they fit, otherwise one column of four rows
        p.setFont(QFont(T.FONT, 9))
        need = 18 + p.fontMetrics().horizontalAdvance("右耳后") + 6 + p.fontMetrics().horizontalAdvance("未贴合") + 6
        two_cols = (w - 8) / 2 >= need
        rows = [list(pair) for pair in self.LEGEND] if two_cols else [[k] for pair in self.LEGEND for k in pair]
        legend_h = 22 * len(rows) + 2
        area_h = max(60, h - legend_h - 8)
        r = max(28.0, min(w * 0.30, w / 2 - 60, area_h * 0.62))   # keep room for the codes at the sides
        cx, cy = w / 2, 14 + r
        # band arc
        pen = QPen(QColor(T.BORDER), 10, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        rect = QRectF(cx - r, cy - r, 2 * r, 2 * r)
        p.drawArc(rect, int(-20 * 16), int(220 * 16))
        p.setPen(QPen(QColor(T.FAINT), 1))
        p.setFont(QFont(T.FONT, 8))
        p.drawText(QRectF(cx - 40, cy - r + 16, 80, 16), Qt.AlignmentFlag.AlignCenter, "前额")
        for key, ang in self.POS.items():
            level, _ = self.q.get(key, (0, ""))
            col = QColor(T.QUALITY_COLORS.get(level, T.BAD))
            a = math.radians(ang)
            x, y = cx + r * math.cos(a), cy - r * math.sin(a)
            glow = QRadialGradient(QPointF(x, y), 20)
            gc = QColor(col)
            gc.setAlpha(110)
            glow.setColorAt(0, gc)
            gc.setAlpha(0)
            glow.setColorAt(1, gc)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(glow))
            p.drawEllipse(QPointF(x, y), 20, 20)
            p.setBrush(col)
            p.drawEllipse(QPointF(x, y), 7, 7)
            # short code just outside the dot, pointing away from the centre
            left = math.cos(a) < 0
            box = QRectF(x - 54, y - 9, 40, 18) if left else QRectF(x + 14, y - 9, 40, 18)
            if math.sin(a) > 0.6:
                box.translate(0, -14)
            box.moveLeft(min(max(box.left(), 2), w - 42))
            p.setPen(QColor(T.MUTED))
            p.setFont(QFont(T.NUM_FONT, 8, QFont.Weight.DemiBold))
            p.drawText(box, (Qt.AlignmentFlag.AlignRight if left else Qt.AlignmentFlag.AlignLeft) | Qt.AlignmentFlag.AlignVCenter,
                       self.SHORT[key])
        # legend: 2 x 2, left column = left side of the head
        top = h - legend_h
        colw = (w - 8) / 2 if two_cols else (w - 8)
        for row, pair in enumerate(rows):
            for c, key in enumerate(pair):
                level, text = self.q.get(key, (0, ""))
                col = QColor(T.QUALITY_COLORS.get(level, T.BAD))
                x0, y0 = 4 + c * colw, top + row * 22
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(col)
                p.drawEllipse(QPointF(x0 + 6, y0 + 10), 4, 4)
                p.setPen(QColor(T.TEXT))
                p.setFont(QFont(T.FONT, 9))
                fm = p.fontMetrics()
                name = self.SIDE[key]
                p.drawText(QRectF(x0 + 14, y0, colw - 14, 20), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, name)
                p.setPen(col)
                p.drawText(QRectF(x0 + 18 + fm.horizontalAdvance(name), y0, colw, 20),
                           Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, text)
        p.end()


class BandBars(QWidget):
    """Vertical bars for relative band power."""

    def __init__(self, bands):
        super().__init__()
        self.bands = bands  # list of (key, label, colour)
        self.values = {b[0]: 0.0 for b in bands}
        self.setMinimumHeight(150)

    def set_values(self, vals: dict):
        for k in self.values:
            v = vals.get(k, 0.0)
            self.values[k] = 0.0 if v is None or v != v else float(v)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        n = len(self.bands)
        gap = 12
        bw = (w - gap * (n + 1)) / n
        top, bottom = 22, h - 38
        vmax = max(0.5, max(self.values.values()) * 1.15)
        for i, (k, lab, col) in enumerate(self.bands):
            x = gap + i * (bw + gap)
            v = self.values[k]
            bh = (bottom - top) * min(1.0, v / vmax)
            track = QPainterPath()
            track.addRoundedRect(QRectF(x, top, bw, bottom - top), 8, 8)
            p.fillPath(track, QColor(T.SURFACE2))
            bar = QPainterPath()
            bar.addRoundedRect(QRectF(x, bottom - bh, bw, bh), 8, 8)
            c = QColor(col)
            p.fillPath(bar, c)
            p.setPen(QColor(T.TEXT))
            p.setFont(QFont(T.NUM_FONT, 10, QFont.Weight.DemiBold))
            p.drawText(QRectF(x - 6, bottom - bh - 20, bw + 12, 18), Qt.AlignmentFlag.AlignCenter, f"{v * 100:.0f}%")
            p.setPen(QColor(T.MUTED))
            p.setFont(QFont(T.FONT, 9))
            p.drawText(QRectF(x - 10, bottom + 6, bw + 20, 30), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, lab)
        p.end()


class Ring(QWidget):
    """Circular countdown / progress ring with text in the middle."""

    def __init__(self, size=220):
        super().__init__()
        self.frac = 0.0
        self.big = ""
        self.small = ""
        self.color = T.ACCENT
        self.setMinimumSize(size, size)

    def set(self, frac, big, small="", color=None):
        self.frac = max(0.0, min(1.0, frac))
        self.big, self.small = big, small
        if color:
            self.color = color
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        s = min(self.width(), self.height()) - 20
        rect = QRectF((self.width() - s) / 2, (self.height() - s) / 2, s, s)
        p.setPen(QPen(QColor(T.SURFACE2), 12, cap=Qt.PenCapStyle.RoundCap))
        p.drawArc(rect, 0, 360 * 16)
        p.setPen(QPen(QColor(self.color), 12, cap=Qt.PenCapStyle.RoundCap))
        p.drawArc(rect, 90 * 16, int(-self.frac * 360 * 16))
        p.setPen(QColor(T.TEXT))
        p.setFont(QFont(T.NUM_FONT, int(s / 7), QFont.Weight.DemiBold))
        p.drawText(rect.adjusted(0, -s * 0.08, 0, -s * 0.08), Qt.AlignmentFlag.AlignCenter, self.big)
        p.setPen(QColor(T.MUTED))
        p.setFont(QFont(T.FONT, max(9, int(s / 18))))
        p.drawText(rect.adjusted(0, s * 0.22, 0, s * 0.22), Qt.AlignmentFlag.AlignCenter, self.small)
        p.end()


class Orb(QWidget):
    """Glowing orb for the alpha switch: brightness follows a 0..1 level."""

    def __init__(self):
        super().__init__()
        self.level = 0.0
        self.on = False
        self.setMinimumSize(260, 260)

    def set(self, level, on):
        self.level = max(0.0, min(1.0, level))
        self.on = on
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        c = QPointF(w / 2, h / 2)
        r = min(w, h) * 0.42
        base = QColor("#fde68a") if self.on else QColor(T.ACCENT)
        glow = QRadialGradient(c, r * 1.15)
        g = QColor(base)
        g.setAlpha(int(40 + 180 * self.level) if self.on else int(20 + 90 * self.level))
        glow.setColorAt(0.0, g)
        g2 = QColor(base)
        g2.setAlpha(0)
        glow.setColorAt(1.0, g2)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(glow))
        p.drawEllipse(c, r * 1.15, r * 1.15)
        core = QRadialGradient(c, r * 0.55)
        cc = QColor(base)
        cc.setAlpha(255 if self.on else int(70 + 120 * self.level))
        core.setColorAt(0, QColor("#ffffff") if self.on else cc)
        core.setColorAt(0.5, cc)
        cc2 = QColor(T.SURFACE2)
        core.setColorAt(1, cc2)
        p.setBrush(QBrush(core))
        p.drawEllipse(c, r * 0.55, r * 0.55)
        p.setPen(QPen(QColor(T.BORDER), 2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(c, r * 0.56, r * 0.56)
        p.end()


def plot(title: str = "", left: str = "", bottom: str = "", height: int | None = None) -> pg.PlotWidget:
    w = pg.PlotWidget()
    w.setBackground(None)
    pi = w.getPlotItem()
    pi.showGrid(x=True, y=True, alpha=0.12)
    pi.setMenuEnabled(False)
    pi.hideButtons()
    for ax in ("left", "bottom"):
        a = pi.getAxis(ax)
        a.setPen(pg.mkPen(T.BORDER))
        a.setTextPen(pg.mkPen(T.MUTED))
        a.setStyle(tickFont=QFont(T.NUM_FONT, 8))
        a.enableAutoSIPrefix(False)
    if left:
        pi.setLabel("left", left, color=T.MUTED, size="9pt")
    if bottom:
        pi.setLabel("bottom", bottom, color=T.MUTED, size="9pt")
    if title:
        pi.setTitle(title, color=T.MUTED, size="10pt")
    w.setMouseEnabled(x=False, y=False)
    if height:
        w.setMinimumHeight(height)
    return w


def legend_row(items):
    """Horizontal legend: list of (text, colour)."""
    box = QHBoxLayout()
    box.setSpacing(0)
    html = "&nbsp;&nbsp;&nbsp;&nbsp;".join(
        f"<span style='color:{col}; font-size:11px;'>●</span>&nbsp;<span style='color:{T.MUTED};'>{text}</span>"
        for text, col in items)
    l = QLabel(html)
    l.setTextFormat(Qt.TextFormat.RichText)
    box.addWidget(l)
    box.addStretch(1)
    return box
