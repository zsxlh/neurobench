"""Data sources: real Muse S Athena over BLE, raw-file replay, and a simulator."""

from __future__ import annotations

import asyncio
import re
import threading
import time
from datetime import datetime

import numpy as np
from PyQt6.QtCore import QObject, pyqtSignal
from scipy.signal import lfilter

from OpenMuse.decode import select_optics_channels
from OpenMuse.muse import MuseS
from OpenMuse.utils import get_utc_timestamp

from .dsp import _EXT, ASSUMED_DISTANCE_CM, ASSUMED_DPF
from .hub import DataHub


class SourceSignals(QObject):
    status = pyqtSignal(str, str)        # state, message  (state: connecting/connected/stopped/error)
    scan_done = pyqtSignal(list, str)    # devices, error


# ============================================================================ scan
def scan_devices(signals: SourceSignals, timeout: float = 8.0):
    def run():
        try:
            import bleak

            async def go():
                return await bleak.BleakScanner.discover(timeout=timeout)

            devs = asyncio.run(go())
            muses = [
                {"name": d.name, "address": d.address}
                for d in devs
                if isinstance(d.name, str) and "muse" in d.name.lower()
            ]
            signals.scan_done.emit(muses, "")
        except Exception as e:  # noqa: BLE001
            signals.scan_done.emit([], f"{type(e).__name__}: {e}")

    threading.Thread(target=run, daemon=True, name="muse-scan").start()


# ============================================================================ base
class Source:
    kind = ""

    def __init__(self, hub: DataHub, signals: SourceSignals):
        self.hub = hub
        self.signals = signals
        self._stop = threading.Event()
        self.thread: threading.Thread | None = None

    def start(self):
        self._stop.clear()
        self.thread = threading.Thread(target=self._run_safe, daemon=True, name=f"src-{self.kind}")
        self.thread.start()

    def stop(self):
        self._stop.set()

    def _run_safe(self):
        try:
            self.run()
        except Exception as e:  # noqa: BLE001
            self.signals.status.emit("error", f"{type(e).__name__}: {e}")
            return
        self.signals.status.emit("stopped", "")

    def run(self):
        raise NotImplementedError


# ============================================================================ BLE
class MuseSource(Source):
    kind = "muse"

    def __init__(self, hub, signals, address: str, name: str = "", preset: str = "p1041"):
        super().__init__(hub, signals)
        self.address = address
        self.name = name
        self.preset = preset

    def run(self):
        asyncio.run(self._main())

    async def _main(self):
        import bleak

        hub = self.hub
        self.signals.status.emit("connecting", f"正在连接 {self.name or self.address} …")
        control_buf = ""

        def on_control(_, data: bytearray):
            nonlocal control_buf
            control_buf = (control_buf + data.decode("utf-8", errors="ignore"))[-4096:]
            fw = re.search(r'"fw"\s*:\s*"([^"]+)"', control_buf)
            bp = re.search(r'"bp"\s*:\s*([\d.]+)', control_buf)
            if fw:
                hub.info.firmware = fw.group(1)
            if bp:
                try:
                    hub.info.battery = float(bp.group(1))
                except ValueError:
                    pass

        def make_cb(uuid):
            def cb(_, data: bytearray):
                hub.ingest_message(f"{get_utc_timestamp()}\t{uuid}\t{data.hex()}")
            return cb

        async with bleak.BleakClient(self.address, timeout=20.0) as client:
            hub.info.source = "muse"
            hub.info.name = client.name or self.name or "Muse"
            hub.info.address = self.address
            hub.info.extra["preset"] = self.preset
            try:
                await client.start_notify(MuseS.CONTROL_UUID, on_control)
            except Exception:  # noqa: BLE001
                pass
            for uuid in MuseS.DATA_CHARACTERISTICS:
                await client.start_notify(uuid, make_cb(uuid))
            await MuseS.initialize_device(client, self.preset)
            self.signals.status.emit("connected", hub.info.name)
            while not self._stop.is_set():
                await asyncio.sleep(0.2)
                if not client.is_connected:
                    raise ConnectionError("头环断开了连接")
            await MuseS.stop_streaming(client)


# ============================================================================ replay
class ReplaySource(Source):
    """Feed a raw OpenMuse recording through the same decoder, in real time, looping."""

    kind = "replay"

    def __init__(self, hub, signals, path: str, speed: float = 1.0):
        super().__init__(hub, signals)
        self.path = path
        self.speed = speed

    def run(self):
        with open(self.path, "r", encoding="utf-8") as f:
            lines = [l for l in f.readlines() if l.strip()]
        stamps = []
        for l in lines:
            try:
                stamps.append(datetime.fromisoformat(l.split("\t", 1)[0].replace("Z", "+00:00")).timestamp())
            except ValueError:
                stamps.append(float("nan"))
        stamps = np.array(stamps)
        ok = np.isfinite(stamps)
        lines = [l for l, k in zip(lines, ok) if k]
        stamps = stamps[ok]
        if not lines:
            raise ValueError("文件里没有可读的数据行")
        self.hub.info.source = "replay"
        self.hub.info.name = "回放"
        self.signals.status.emit("connected", "回放")
        while not self._stop.is_set():
            t_start = time.perf_counter()
            s0 = stamps[0]
            for line, s in zip(lines, stamps):
                if self._stop.is_set():
                    return
                due = t_start + (s - s0) / self.speed
                wait = due - time.perf_counter()
                if wait > 0:
                    time.sleep(wait)
                self.hub.ingest_message(line)
            self.hub.reset_device_clocks()


# ============================================================================ simulator
class SimSource(Source):
    """Synthetic but physiologically shaped signals, for trying the app without a headband.

    Scenario (repeats every 60 s): 0-25 s eyes open (blinks), 25-55 s eyes closed
    (strong alpha, theta creeping up), 55-58 s jaw clench (muscle burst).
    Pulse ~64 bpm with breathing-linked variability, slow forehead oxygenation drift.
    """

    kind = "sim"
    EEG_NAMES = ["EEG_TP9", "EEG_AF7", "EEG_AF8", "EEG_TP10", "AUX_1", "AUX_2", "AUX_3", "AUX_4"]
    IMU_NAMES = ["ACC_X", "ACC_Y", "ACC_Z", "GYRO_X", "GYRO_Y", "GYRO_Z"]

    def phase(self, t):
        c = t % 60.0
        if c < 25:
            return "open"
        if c < 55:
            return "closed"
        if c < 58:
            return "clench"
        return "open"

    def run(self):
        rng = np.random.default_rng(7)
        hub = self.hub
        hub.info.source = "sim"
        hub.info.name = "模拟头环"
        hub.info.firmware = "sim"
        hub.info.extra["preset"] = "sim"
        hub.info.battery = 86.0
        opt_names = select_optics_channels(16)
        self.signals.status.emit("connected", "模拟头环")

        fs_e, fs_o, fs_i = 256.0, 64.0, 52.0
        n_e = n_o = n_i = 0
        # 1/f-like background per channel via AR(1)
        ar_zi = np.zeros((1, 8))
        phase_alpha = rng.uniform(0, 2 * np.pi, 8)
        phase_theta = rng.uniform(0, 2 * np.pi, 8)
        beat_phase = 0.0
        hb = np.zeros(2)  # dHbO, dHbR in uM
        t0 = time.perf_counter()

        while not self._stop.is_set():
            now = time.perf_counter() - t0
            # ---------------- EEG
            ne = int(now * fs_e) - n_e
            if ne > 0:
                t = (n_e + np.arange(ne)) / fs_e
                out, ar_zi = lfilter([1.0], [1.0, -0.97], rng.normal(0, 1.2, (ne, 8)), axis=0, zi=ar_zi)
                ph = np.array([self.phase(x) for x in t])
                closed = (ph == "closed").astype(float)
                # smooth eyes-closed envelope so alpha ramps instead of jumping
                ramp = np.clip(((t % 60) - 25) / 4.0, 0, 1) * closed
                a_amp = 3.0 + 9.0 * ramp
                th_amp = 2.0 + 3.0 * np.clip(((t % 60) - 25) / 30.0, 0, 1) * closed
                post = np.array([1.0, 0.55, 0.55, 1.0, 0.3, 0.3, 0.3, 0.3])
                for c in range(8):
                    out[:, c] += post[c] * a_amp * np.sin(2 * np.pi * 10.2 * t + phase_alpha[c] + 0.3 * np.sin(0.5 * t))
                    out[:, c] += th_amp * np.sin(2 * np.pi * 6.0 * t + phase_theta[c])
                    out[:, c] += 3.0 * np.sin(2 * np.pi * 20.0 * t + c)
                # blinks on frontal channels while eyes open (one every 4 s)
                blink = np.zeros(ne)
                cyc = t % 4.0
                is_open = ph == "open"
                blink[is_open] = np.exp(-((cyc[is_open] - 2.0) ** 2) / (2 * 0.06**2))
                # the reference sits above the eyes: blinks are small on AF7/AF8, large and negative on TP9/TP10
                out[:, 0] += -90.0 * blink
                out[:, 3] += -100.0 * blink
                out[:, 1] += -20.0 * blink
                out[:, 2] += -20.0 * blink
                # jaw clench: broadband muscle noise, strongest on temporal sites
                clench = (ph == "clench").astype(float)
                emg = rng.normal(0, 1, (ne, 8)) * 25.0
                emg[:, [1, 2]] *= 0.6
                out += emg * clench[:, None]
                out += 0.8 * np.sin(2 * np.pi * 60.0 * t)[:, None]  # mains hum
                out[:, :4] += 725.0
                out[:, 4:] += 725.0 + rng.normal(0, 30, (ne, 4))
                hub.ingest_arrays("EEG", self.EEG_NAMES, t, np.clip(out, 0, 1450))
                n_e += ne
            # ---------------- optics (PPG + slow haemodynamics)
            no = int(now * fs_o) - n_o
            if no > 0:
                t = (n_o + np.arange(no)) / fs_o
                hr = 64 + 5 * np.sin(2 * np.pi * 0.2 * t)  # breathing-linked variability
                phase = beat_phase + np.cumsum(hr / 60.0 / fs_o) * 2 * np.pi
                beat_phase = float(phase[-1])
                pulse = np.maximum(0, np.sin(phase)) ** 3 - 0.2
                # slow haemodynamics: HbO up / HbR down while eyes are closed (illustrative)
                target = np.array([0.6, -0.25]) if self.phase(t[-1]) == "closed" else np.zeros(2)
                hb += (target - hb) * min(1.0, (no / fs_o) / 8.0)
                path = ASSUMED_DISTANCE_CM * ASSUMED_DPF
                d_od = _EXT @ (hb * 1e-6) * path          # [730 nm, 850 nm]
                data = np.zeros((no, 16))
                base = np.array([4.8, 3.6, 0.10, 0.10, 11.5, 11.4, 13.6, 12.7, 2.6, 2.4, 9.5, 10.3, 2.8, 2.4, 6.2, 7.0])
                for c in range(16):
                    name = opt_names[c]
                    sig = base[c] * (1 + rng.normal(0, 0.0008, no))
                    if "AMB" in name:
                        data[:, c] = sig
                        continue
                    sig = sig * (1 - 0.01 * pulse)
                    if "NIR" in name:
                        sig = sig * 10 ** (-d_od[0])
                    elif "_IR" in name:
                        sig = sig * 10 ** (-d_od[1])
                    data[:, c] = sig
                hub.ingest_arrays("OPTICS", opt_names, t, data)
                n_o += no
            # ---------------- IMU
            ni = int(now * fs_i) - n_i
            if ni > 0:
                t = (n_i + np.arange(ni)) / fs_i
                acc = np.column_stack([np.full(ni, -0.14), np.full(ni, -0.03), np.full(ni, 0.985)])
                acc += rng.normal(0, 0.004, acc.shape)
                gyro = rng.normal(0, 0.6, (ni, 3))
                clench = np.array([self.phase(x) == "clench" for x in t])
                gyro[clench] += rng.normal(0, 4.0, (clench.sum(), 3))
                hub.ingest_arrays("ACCGYRO", self.IMU_NAMES, t, np.hstack([acc, gyro]))
                n_i += ni
            if int(now) % 5 == 0:
                hub.info.battery = max(5.0, 86.0 - now / 600.0)
            time.sleep(0.04)
