"""Crash logging, a one-click diagnostics pack, and the about / release-notes text."""

from __future__ import annotations

import json
import platform
import sys
import threading
import traceback
import zipfile
from datetime import datetime
from pathlib import Path

from . import APP_VERSION
from .paths import ROOT, SESSIONS, VERSIONS

LOGS = ROOT / "logs"
_listeners = []


def _write(kind: str, text: str):
    LOGS.mkdir(parents=True, exist_ok=True)
    p = LOGS / f"crash_{datetime.now():%Y%m%d}.log"
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n===== {datetime.now().isoformat(timespec='seconds')} · v{APP_VERSION} · {kind}\n{text}\n")
    for cb in list(_listeners):
        try:
            cb(text.strip().splitlines()[-1] if text.strip() else kind)
        except Exception:  # noqa: BLE001
            pass


def install(on_error=None):
    """Log uncaught exceptions from the main thread and worker threads instead of dying silently."""
    if on_error:
        _listeners.append(on_error)

    def hook(t, v, tb):
        _write("未处理的异常", "".join(traceback.format_exception(t, v, tb)))

    def thook(args):
        _write(f"线程 {args.thread.name if args.thread else ''} 异常",
               "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)))

    sys.excepthook = hook
    threading.excepthook = thook


def about_text() -> str:
    try:
        from importlib.metadata import version
        om = version("OpenMuse")
    except Exception:  # noqa: BLE001
        om = "?"
    lines = [f"NeuroBench 脑电实验台 v{APP_VERSION}",
             f"OpenMuse {om} · Python {platform.python_version()} · {platform.system()} {platform.release()}",
             f"安装位置：{ROOT}", "更新地址：https://github.com/zsxlh/neurobench", ""]
    notes = []
    if VERSIONS.exists():
        for d in VERSIONS.iterdir():
            r = d / "release.json"
            if r.exists():
                try:
                    m = json.loads(r.read_text(encoding="utf-8"))
                    notes.append((m.get("version", d.name), m.get("published", "")[:10], m.get("notes", "")))
                except Exception:  # noqa: BLE001
                    pass
    if notes:
        lines.append("更新记录：")
        for v, day, n in sorted(notes, key=lambda x: [int(p) if p.isdigit() else 0 for p in x[0].split(".")], reverse=True):
            lines.append(f"v{v}（{day}）：{n}")
    return "\n".join(lines)


def pack(out_dir: Path) -> Path:
    """Zip logs, update logs, version info and the metadata of the latest recordings (no signal data)."""
    out = Path(out_dir) / f"NeuroBench_诊断_{datetime.now():%Y%m%d_%H%M}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("about.txt", about_text())
        if LOGS.exists():
            for p in sorted(LOGS.glob("*.log"))[-10:]:
                z.write(p, f"logs/{p.name}")
        if VERSIONS.exists():
            for p in VERSIONS.glob("*.log"):
                z.write(p, f"update_logs/{p.name}")
            for p in VERSIONS.glob("*.txt"):
                z.write(p, f"versions/{p.name}")
            for p in VERSIONS.glob("*/BAD"):
                z.write(p, f"versions/{p.parent.name}_BAD.txt")
        if SESSIONS.exists():
            for d in sorted([d for d in SESSIONS.iterdir() if d.is_dir()], reverse=True)[:5]:
                for name in ("session.json", "markers.csv"):
                    if (d / name).exists():
                        z.write(d / name, f"recent_sessions/{d.name}/{name}")
    return out
