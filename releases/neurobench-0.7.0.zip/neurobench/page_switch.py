"""意念开关 page: an alpha-driven switch with calibration."""

from __future__ import annotations

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import QComboBox, QHBoxLayout, QPushButton, QSlider, QVBoxLayout, QWidget

from . import dsp
from . import theme as T
from .protocols import chime, speak
from .widgets import Card, Orb, label, plot

WINDOW_S = 2.0


class SwitchPage(QWidget):
    def __init__(self, hub, analyzer, record_page=None):
        super().__init__()
        self.hub, self.an, self.rp = hub, analyzer, record_page
        self.train = None          # dict while a thought-switch training run is going
        self.model = None
        self._p_t = -1e9
        self.threshold = 0.30
        self.on = False
        self.level = 0.0
        self.above_since = None
        self.below_since = None
        self.hist_t, self.hist_v = [], []
        self.calib = None      # dict during calibration
        self.count = 0

        root = QHBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        # ---------------- orb
        main = Card("闭眼开关", "闭上眼睛、放松 → α 波升高 → 灯亮")
        self.orb = Orb()
        main.add(self.orb, 1)
        self.l_state = label("关", "h1")
        self.l_state.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main.add(self.l_state)
        self.l_hint = label("先点右边「校准」，让程序认识你睁眼和闭眼时的样子。", "muted", wrap=True)
        self.l_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main.add(self.l_hint)
        root.addWidget(main, 3)

        # ---------------- controls
        side = QVBoxLayout()
        side.setSpacing(14)
        ctl = Card("设置")
        ctl.add(label("触发方式", "muted"))
        self.cb_mode = QComboBox()
        self.cb_mode.addItems(["按住：闭眼时亮，睁眼就灭", "切换：每闭眼 2 秒，开关翻转一次", "想法：心算时亮，放空时灭（需先训练）"])
        ctl.add(self.cb_mode)
        ctl.add(label("灵敏度（α 阈值）", "muted"))
        self.sl = QSlider(Qt.Orientation.Horizontal)
        self.sl.setRange(5, 80)
        self.sl.setValue(int(self.threshold * 100))
        self.sl.valueChanged.connect(self._slider)
        ctl.add(self.sl)
        self.l_thr = label("", "faint")
        ctl.add(self.l_thr)
        self.b_cal = QPushButton("校准（30 秒）")
        self.b_cal.setObjectName("primary")
        self.b_cal.clicked.connect(self.start_calibration)
        ctl.add(self.b_cal)
        self.l_cal = label("", "faint", wrap=True)
        ctl.add(self.l_cal)
        side.addWidget(ctl)
        th = Card("想法开关训练", "心算 vs 放空")
        self.l_train = label("", "faint", wrap=True)
        th.add(self.l_train)
        row = QHBoxLayout()
        self.b_train = QPushButton("开始训练（约 7 分钟）")
        self.b_train.clicked.connect(self.start_training)
        row.addWidget(self.b_train)
        self.b_train_stop = QPushButton("停止")
        self.b_train_stop.setObjectName("ghost")
        self.b_train_stop.clicked.connect(lambda: self.end_training(early=True))
        self.b_train_stop.setVisible(False)
        row.addWidget(self.b_train_stop)
        th.add(row)
        side.addWidget(th)

        tr = Card("α 水平", "最近 60 秒 · 耳后电极")
        self.p = plot(bottom="秒")
        self.curve = self.p.plot(pen=pg.mkPen(dsp.BAND_COLORS["alpha"], width=2),
                                 fillLevel=0, brush=pg.mkBrush(52, 211, 153, 40))
        self.thr_line = pg.InfiniteLine(angle=0, pen=pg.mkPen(T.WARN, width=1, style=Qt.PenStyle.DashLine))
        self.p.addItem(self.thr_line)
        self.p.setXRange(-60, 0)
        self.p.setYRange(0, 0.8)
        tr.add(self.p, 1)
        self.l_count = label("", "faint")
        tr.add(self.l_count)
        side.addWidget(tr, 1)
        sw = QWidget()
        sw.setLayout(side)
        sw.setFixedWidth(400)
        root.addWidget(sw)

        self._slider(self.sl.value())
        self.refresh_training()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(250)

    def _slider(self, v):
        self.threshold = v / 100.0
        self.thr_line.setValue(self.threshold)
        self.l_thr.setText(f"α 占比超过 {v}% 视为“闭眼放松”")

    # ------------------------------------------------------------------
    def current_alpha(self):
        eeg = self.hub.latest("EEG", WINDOW_S)
        names = self.hub.names("EEG")
        if len(eeg) < dsp.FS_EEG * WINDOW_S * 0.9 or not names:
            return None
        idx = [names.index(n) for n in ("EEG_TP9", "EEG_TP10") if n in names]
        X = dsp.notch_only(eeg[:, 1:][:, idx])
        rel, _, _ = dsp.band_powers(X)
        return float(rel[:, 2].mean())

    # ------------------------------------------------------------------ thought-switch training
    def refresh_training(self):
        from . import training as TR
        self.model = TR.load_model()
        n = TR.trial_count()
        if self.model:
            acc = self.model["accuracy"]
            verdict = "可以用来控制" if acc >= TR.TRUST else "还不够准，继续练（75% 以上才可靠）"
            self.l_train.setText(f"已有 {n} 轮训练。交叉验证准确率 {acc * 100:.0f}%（瞎猜是 50%，"
                                 f"p={self.model['p_value']:.3f}）：{verdict}。\n{self.model['how']}")
        else:
            self.l_train.setText(f"已有 {n} 轮训练。每次训练 20 轮：听提示心算（从 1000 起每次减 7）或放空，"
                                 "各 12 秒。闭着眼做最好。练完程序只用你自己的数据学会区分两种状态。")

    def start_training(self):
        from . import training as TR
        if self.train or self.rp is None:
            return
        if not self.hub.is_live():
            self.l_train.setText("还没有数据：先连接头环（或打开演示模式）。")
            return
        if self.rp.rec is not None:
            self.l_train.setText("正在录制别的内容，先停止那边的录制。")
            return
        from datetime import datetime
        if not self.rp.start_free(f"想法训练 {datetime.now():%m-%d %H%M}", mode="想法训练"):
            return
        import os
        n = 6 if os.environ.get("NB_MED_FAST") else TR.N_TRIALS
        self.train = {"labels": TR.schedule(n), "i": -1, "phase": "", "t0": self.hub.now(), "dir": self.rp.rec.dir}
        self.b_train.setVisible(False)
        self.b_train_stop.setVisible(True)
        speak("开始想法训练。请闭上眼睛，听到心算就从一千开始每次减七，听到放空就什么都不想。")
        self._next_trial()

    def _next_trial(self):
        from . import training as TR
        tr = self.train
        tr["i"] += 1
        if tr["i"] >= len(tr["labels"]):
            self.end_training()
            return
        tr["phase"], tr["t0"] = "cue", self.hub.now()
        lab = tr["labels"][tr["i"]]
        speak(TR.CLASSES[lab])
        self.l_state.setText(f"准备：{TR.CLASSES[lab]}")
        self.l_hint.setText(f"第 {tr['i'] + 1}/{len(tr['labels'])} 轮")

    def _train_tick(self):
        from . import training as TR
        tr = self.train
        if self.rp.rec is None:
            self.end_training(early=True)
            return
        el = self.hub.now() - tr["t0"]
        lab = tr["labels"][tr["i"]]
        if tr["phase"] == "cue" and el >= TR.CUE_S:
            tr["phase"], tr["t0"] = "task", self.hub.now()
            self.rp.rec.add_marker(f"{lab}·{TR.CLASSES[lab]}", "trial")
            chime()
            self.l_state.setText(TR.CLASSES[lab])
        elif tr["phase"] == "task":
            self.orb.set(el / TR.TASK_S, False)
            if el >= TR.TASK_S:
                tr["phase"], tr["t0"] = "rest", self.hub.now()
                self.l_state.setText("休息")
                chime()
        elif tr["phase"] == "rest" and el >= TR.REST_S:
            self._next_trial()

    def end_training(self, early=False):
        from . import training as TR
        tr, self.train = self.train, None
        self.b_train.setVisible(True)
        self.b_train_stop.setVisible(False)
        if tr is None:
            return
        if self.rp.rec is not None:
            self.rp.stop()
        n = TR.add_session(tr["dir"])
        res = TR.train()
        speak("训练结束。")
        self.l_state.setText("训练结束")
        self.l_hint.setText(f"这次收集到 {n} 轮。" + ("" if res.get("ok") else res.get("msg", "")))
        self.refresh_training()

    def _thought_tick(self):
        from . import training as TR
        if not self.model:
            self.l_hint.setText("还没有训练好的模型：先点右边「开始训练」。")
            return
        now = self.hub.now()
        if now - self._p_t < 1.0:
            return
        self._p_t = now
        p = TR.live_probability(self.hub, self.model)
        if p is None:
            self.l_hint.setText("数据还不够（需要约 15 秒连续数据）。")
            return
        self.level = 0.5 * self.level + 0.5 * p
        self.hist_t.append(now)
        self.hist_v.append(self.level)
        while self.hist_t and now - self.hist_t[0] > 60:
            self.hist_t.pop(0)
            self.hist_v.pop(0)
        self.curve.setData(np.array(self.hist_t) - now, np.array(self.hist_v))
        if self.level > 0.6:
            self._set(True)
        elif self.level < 0.4:
            self._set(False)
        self.orb.set(self.level, self.on)
        acc = self.model["accuracy"]
        self.l_hint.setText(f"心算的可能性 {self.level * 100:.0f}%（模型准确率 {acc * 100:.0f}%"
                            + ("" if acc >= TR.TRUST else "，还不够可靠") + "）")

    def tick(self):
        if self.train:
            self._train_tick()
            return
        if not self.isVisible() and self.calib is None:
            return
        if self.cb_mode.currentIndex() == 2 and self.calib is None:
            self._thought_tick()
            return
        a = self.current_alpha()
        if a is None:
            self.l_hint.setText("还没有数据：请先连接头环或打开演示。")
            return
        self.level = 0.6 * self.level + 0.4 * a
        now = self.hub.now()
        self.hist_t.append(now)
        self.hist_v.append(self.level)
        while self.hist_t and now - self.hist_t[0] > 60:
            self.hist_t.pop(0)
            self.hist_v.pop(0)
        self.curve.setData(np.array(self.hist_t) - now, np.array(self.hist_v))

        if self.calib is not None:
            self._calib_tick(now, a)
            return

        hi, lo = self.threshold, self.threshold * 0.85
        toggle_mode = self.cb_mode.currentIndex() == 1
        if self.level > hi:
            self.below_since = None
            if self.above_since is None:
                self.above_since = now
        elif self.level < lo:
            self.above_since = None
            if self.below_since is None:
                self.below_since = now
        if toggle_mode:
            if self.above_since is not None and now - self.above_since > 2.0 and not getattr(self, "_armed_used", False):
                self._set(not self.on)
                self._armed_used = True
            if self.below_since is not None:
                self._armed_used = False
        else:
            if self.above_since is not None and now - self.above_since > 0.5:
                self._set(True)
            elif self.below_since is not None and now - self.below_since > 0.5:
                self._set(False)
        frac = min(1.0, self.level / max(hi, 1e-3))
        self.orb.set(frac, self.on)
        self.l_hint.setText(f"当前 α {self.level * 100:.0f}%  ·  阈值 {hi * 100:.0f}%")

    def _set(self, on):
        if on != self.on:
            self.on = on
            if on:
                self.count += 1
            chime(1)
            self.l_state.setText("开" if on else "关")
            self.l_state.setStyleSheet(f"color: {'#fde68a' if on else T.TEXT};")
            self.l_count.setText(f"本次已触发 {self.count} 次")

    # ------------------------------------------------------------------ calibration
    def start_calibration(self):
        if not self.hub.is_live():
            self.l_cal.setText("请先连接头环或打开演示。")
            return
        self.calib = {"t0": self.hub.now(), "open": [], "closed": [], "stage": "open"}
        self.b_cal.setEnabled(False)
        self.l_cal.setText("第 1 步：睁眼看前方 15 秒…")
        speak("开始校准。请睁眼，看着前方。")

    def _calib_tick(self, now, a):
        c = self.calib
        el = now - c["t0"]
        if el < 15:
            if el > 3:
                c["open"].append(a)
            self.l_cal.setText(f"第 1 步：睁眼看前方 … {15 - el:.0f} 秒")
        elif el < 30:
            if c["stage"] == "open":
                c["stage"] = "closed"
                speak("请闭上眼睛，放松。")
            if el > 19:
                c["closed"].append(a)
            self.l_cal.setText(f"第 2 步：闭眼放松 … {30 - el:.0f} 秒")
        else:
            o, cl = np.median(c["open"] or [0]), np.median(c["closed"] or [0])
            self.calib = None
            self.b_cal.setEnabled(True)
            if cl > o * 1.2 and cl - o > 0.03:
                thr = o + 0.5 * (cl - o)
                self.sl.setValue(int(round(thr * 100)))
                self.l_cal.setText(f"校准完成：睁眼 α {o * 100:.0f}%，闭眼 α {cl * 100:.0f}%，阈值设为 {thr * 100:.0f}%。")
                speak("校准完成，可以睁开眼睛了。")
            else:
                self.l_cal.setText(f"闭眼时 α 没有明显升高（睁眼 {o * 100:.0f}%，闭眼 {cl * 100:.0f}%）。检查贴合后再试一次。")
                speak("校准没有成功，请检查头环贴合，再试一次。")
