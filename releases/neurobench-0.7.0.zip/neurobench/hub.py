"""Central data hub: ring buffers fed by a device/demo source, read by the UI."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from OpenMuse.decode import (
    ACCGYRO_CHANNELS,
    make_timestamps,
    parse_message,
    select_eeg_channels,
    select_optics_channels,
)

SENSORS = ("EEG", "OPTICS", "ACCGYRO", "BATTERY")
FS = {"EEG": 256.0, "OPTICS": 64.0, "ACCGYRO": 52.0, "BATTERY": 1.0}
KEEP_SECONDS = {"EEG": 120, "OPTICS": 400, "ACCGYRO": 120, "BATTERY": 3600}


class Ring:
    """Fixed-size ring buffer of rows [t, ch1, ch2, ...]."""

    def __init__(self, n_cols: int, capacity: int):
        self.buf = np.zeros((capacity, n_cols), dtype=np.float64)
        self.cap = capacity
        self.idx = 0
        self.count = 0

    def write(self, rows: np.ndarray):
        n = len(rows)
        if n == 0:
            return
        if n >= self.cap:
            self.buf[:] = rows[-self.cap:]
            self.idx, self.count = 0, self.cap
            return
        end = self.idx + n
        if end <= self.cap:
            self.buf[self.idx:end] = rows
        else:
            k = self.cap - self.idx
            self.buf[self.idx:] = rows[:k]
            self.buf[: n - k] = rows[k:]
        self.idx = end % self.cap
        self.count = min(self.cap, self.count + n)

    def latest(self, n: int) -> np.ndarray:
        n = min(n, self.count)
        if n == 0:
            return np.empty((0, self.buf.shape[1]))
        start = (self.idx - n) % self.cap
        if start + n <= self.cap:
            return self.buf[start:start + n].copy()
        return np.vstack([self.buf[start:], self.buf[: (start + n) % self.cap]])


@dataclass
class _SensorState:
    names: list
    ring: Ring
    base_time: Optional[float] = None
    wrap_offset: int = 0
    last_abs_tick: int = 0
    sample_counter: int = 0
    offset: Optional[float] = None
    last_t: float = -1e9
    lags: list = field(default_factory=list)


@dataclass
class DeviceInfo:
    source: str = ""          # "muse", "sim", "replay"
    name: str = ""
    address: str = ""
    firmware: str = ""
    battery: float = float("nan")
    extra: dict = field(default_factory=dict)


class DataHub:
    """Thread-safe store of the most recent samples of every sensor.

    Time axis: seconds on a session clock (time.perf_counter() - t0). Device
    timestamps are mapped onto it with one offset per sensor, fixed at the
    first packet, so all sensors share one axis to within BLE latency.
    """

    def __init__(self):
        self.lock = threading.RLock()
        self.t0 = time.perf_counter()
        self.sensors: dict[str, _SensorState] = {}
        self.info = DeviceInfo()
        self.recorder = None            # object with write_rows(sensor, rows) / write_raw(line)
        self.packets = 0
        self.last_packet_time = 0.0
        self.listeners: list[Callable[[str, np.ndarray], None]] = []

    # ------------------------------------------------------------------ clock
    def now(self) -> float:
        return time.perf_counter() - self.t0

    # ------------------------------------------------------------------ reset
    def clear(self):
        with self.lock:
            self.sensors.clear()
            self.packets = 0
            self.info = DeviceInfo()

    def reset_device_clocks(self):
        """Forget device clock state (e.g. when a replay file loops); keep buffers."""
        with self.lock:
            for s in self.sensors.values():
                s.base_time = None
                s.wrap_offset = 0
                s.last_abs_tick = 0
                s.sample_counter = 0
                s.offset = None

    # ------------------------------------------------------------------ ingest
    def _ensure(self, sensor: str, names: list) -> _SensorState:
        st = self.sensors.get(sensor)
        if st is None or len(st.names) != len(names):
            cap = int(FS[sensor] * KEEP_SECONDS[sensor])
            st = _SensorState(names=list(names), ring=Ring(len(names) + 1, cap))
            self.sensors[sensor] = st
        return st

    def ingest_message(self, line: str, arrival: Optional[float] = None):
        """Decode one raw BLE line ('iso_ts\\tuuid\\thex') and store it."""
        arrival = self.now() if arrival is None else arrival
        sub = parse_message(line)
        with self.lock:
            self.packets += 1
            self.last_packet_time = arrival
            if self.recorder is not None:
                self.recorder.write_raw(line)
            for sensor in SENSORS:
                pkts = sub.get(sensor) or []
                if not pkts:
                    continue
                n_ch = pkts[0].get("n_channels") or 1
                if sensor == "EEG":
                    names = select_eeg_channels(n_ch)
                elif sensor == "OPTICS":
                    names = select_optics_channels(n_ch)
                elif sensor == "ACCGYRO":
                    names = list(ACCGYRO_CHANNELS)
                else:
                    names = ["BATTERY_PERCENT"]
                st = self._ensure(sensor, names)
                arr, st.base_time, st.wrap_offset, st.last_abs_tick, st.sample_counter = make_timestamps(
                    pkts, st.base_time, st.wrap_offset, st.last_abs_tick, st.sample_counter
                )
                if arr.size == 0 or arr.shape[1] != len(names) + 1:
                    continue
                self._store(sensor, st, arr, arrival)

    def ingest_arrays(self, sensor: str, names: list, t_rel: np.ndarray, data: np.ndarray, arrival=None):
        """Store already-decoded samples (simulator). t_rel: device-relative seconds."""
        arrival = self.now() if arrival is None else arrival
        with self.lock:
            self.packets += 1
            self.last_packet_time = arrival
            st = self._ensure(sensor, names)
            arr = np.column_stack([t_rel, data])
            self._store(sensor, st, arr, arrival)

    def _store(self, sensor, st: _SensorState, arr: np.ndarray, arrival: float):
        if st.offset is None:
            st.offset = arrival - float(arr[-1, 0])
            st.lags = []
            if st.last_t > -1e8:
                # keep time monotonic after a clock reset
                st.offset = max(st.offset, st.last_t + 1.0 / FS[sensor] - float(arr[0, 0]))
        else:
            # Track clock drift between device and computer: follow the
            # minimum-latency envelope of (arrival - mapped time) slowly.
            raw_offset = arrival - float(arr[-1, 0])
            st.lags.append((arrival, raw_offset))
            while st.lags and arrival - st.lags[0][0] > 5.0:
                st.lags.pop(0)
            if len(st.lags) > 10:
                envelope = min(o for _, o in st.lags)
                st.offset += 0.02 * (envelope - st.offset)
        arr = arr.astype(np.float64, copy=True)
        arr[:, 0] += st.offset
        if arr[0, 0] <= st.last_t:
            arr[:, 0] += st.last_t + 1.0 / FS[sensor] - arr[0, 0]
        st.last_t = float(arr[-1, 0])
        st.ring.write(arr)
        if sensor == "BATTERY":
            self.info.battery = float(arr[-1, 1])
        if self.recorder is not None:
            self.recorder.write_rows(sensor, st.names, arr)

    # ------------------------------------------------------------------ read
    def names(self, sensor: str) -> list:
        with self.lock:
            st = self.sensors.get(sensor)
            return list(st.names) if st else []

    def latest(self, sensor: str, seconds: float) -> np.ndarray:
        with self.lock:
            st = self.sensors.get(sensor)
            if st is None:
                return np.empty((0, 0))
            return st.ring.latest(int(seconds * FS[sensor]))

    def is_live(self, within: float = 2.0) -> bool:
        return self.packets > 0 and (self.now() - self.last_packet_time) < within
