"""NeuroBench · 脑电实验台 (Muse S Athena)."""

APP_NAME = "NeuroBench"
APP_NAME_CN = "脑电实验台"
APP_VERSION = "0.7.0"
