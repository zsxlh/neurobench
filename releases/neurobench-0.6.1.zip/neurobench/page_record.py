"""录制 page: guided protocols, markers, saving sessions."""

from __future__ import annotations

import math

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QInputDialog, QLineEdit, QListWidget,
    QListWidgetItem, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget,
)

from . import dsp
from . import theme as T
from .protocols import EVENT_MARKERS, PROTOCOL_DESC, PROTOCOLS, chime, speak
from .session import Recorder
from .widgets import BandBars, Card, Ring, label


def mmss(s):
    s = max(0, int(round(s)))
    return f"{s // 60:02d}:{s % 60:02d}"


class RecordPage(QWidget):
    saved = pyqtSignal(str)

    def __init__(self, hub, analyzer):
        super().__init__()
        self.hub, self.an = hub, analyzer
        self.rec: Recorder | None = None
        self.steps = []
        self.step_i = -1
        self.step_t0 = 0.0

        root = QHBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        # ================= left: setup
        left = Card("录制设置")
        left.setFixedWidth(330)
        left.add(label("名称", "muted"))
        self.e_name = QLineEdit()
        self.e_name.setPlaceholderText("例如：马步 第3天")
        left.add(self.e_name)
        left.add(label("方案", "muted"))
        self.cb_proto = QComboBox()
        self.cb_proto.addItems(list(PROTOCOLS))
        self.cb_proto.setCurrentText("练功前后对比")
        left.add(self.cb_proto)
        self.l_desc = label("", "faint", wrap=True)
        left.add(self.l_desc)
        self.steps_list = QListWidget()
        self.steps_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        left.add(self.steps_list, 1)
        left.add(label("备注（今天状态、睡眠、咖啡等）", "muted"))
        self.e_notes = QPlainTextEdit()
        self.e_notes.setFixedHeight(70)
        left.add(self.e_notes)
        self.chk_voice = QCheckBox("语音提示（闭眼时也能听到下一步）")
        self.chk_voice.setChecked(True)
        left.add(self.chk_voice)
        root.addWidget(left)

        # ================= centre: guidance
        mid = Card()
        mid.lay.setSpacing(14)
        self.l_state = label("准备就绪", "muted")
        self.l_state.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mid.add(self.l_state)
        self.l_step = label("选好方案后点「开始录制」", "h1")
        self.l_step.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mid.add(self.l_step)
        self.ring = Ring(260)
        mid.add(self.ring, 1)
        self.l_tip = label("", "muted", wrap=True)
        self.l_tip.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.l_tip.setMinimumHeight(44)
        mid.add(self.l_tip)
        btns = QHBoxLayout()
        btns.addStretch(1)
        self.b_start = QPushButton("开始录制")
        self.b_start.setObjectName("primary")
        self.b_start.setMinimumWidth(150)
        self.b_next = QPushButton("下一步  (空格)")
        self.b_next.setMinimumWidth(150)
        self.b_stop = QPushButton("结束并保存")
        self.b_stop.setObjectName("danger")
        self.b_stop.setMinimumWidth(130)
        for b in (self.b_start, self.b_next, self.b_stop):
            btns.addWidget(b)
        btns.addStretch(1)
        mid.add(btns)
        self.l_saved = label("", "faint", wrap=True)
        self.l_saved.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mid.add(self.l_saved)
        root.addWidget(mid, 1)

        # ================= right: markers + live mini
        right = QVBoxLayout()
        right.setSpacing(14)
        mk = Card("事件标记", "按数字键也行")
        grid = QGridLayout()
        grid.setSpacing(8)
        self.marker_btns = []
        for i, (lab, key) in enumerate(EVENT_MARKERS):
            b = QPushButton(f"{lab}  ·{key}")
            b.setObjectName("marker")
            b.clicked.connect(lambda _=False, l=lab: self.mark(l))
            grid.addWidget(b, i // 2, i % 2)
            self.marker_btns.append(b)
            # number-key shortcuts live on the main window so they also work from the 实时 page
        b = QPushButton("自定义…")
        b.setObjectName("marker")
        b.clicked.connect(self.mark_custom)
        grid.addWidget(b, 3, 0, 1, 2)
        self.marker_btns.append(b)
        mk.add(grid)
        self.l_last = label("", "faint")
        mk.add(self.l_last)
        right.addWidget(mk)
        live = Card("此刻", "")
        self.bars = BandBars([(k, dsp.BAND_LABELS[k], dsp.BAND_COLORS[k]) for k in dsp.BAND_KEYS])
        live.add(self.bars, 1)
        self.l_live = label("", "muted")
        live.add(self.l_live)
        right.addWidget(live, 1)
        rw = QWidget()
        rw.setLayout(right)
        rw.setFixedWidth(330)
        root.addWidget(rw)

        # wiring
        self.cb_proto.currentTextChanged.connect(self.show_protocol)
        self.b_start.clicked.connect(self.start)
        self.b_next.clicked.connect(self.next_step)
        self.b_stop.clicked.connect(self.stop)
        QShortcut(QKeySequence(Qt.Key.Key_Space), self, activated=self.next_step)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(200)
        self.an.updated.connect(self.refresh_live)
        self.show_protocol(self.cb_proto.currentText())
        self.set_running(False)

    # ------------------------------------------------------------------ ui state
    def show_protocol(self, name):
        self.l_desc.setText(PROTOCOL_DESC.get(name, ""))
        self.steps_list.clear()
        steps = PROTOCOLS.get(name, [])
        if not steps:
            self.steps_list.addItem(QListWidgetItem("（无固定步骤）"))
        for i, s in enumerate(steps):
            dur = mmss(s.seconds) if s.seconds else "自定"
            self.steps_list.addItem(QListWidgetItem(f"{i + 1}. {s.label}   {dur}"))

    def set_running(self, on: bool):
        self.b_start.setVisible(not on)
        self.b_next.setVisible(on and bool(self.steps))
        self.b_stop.setVisible(on)
        for w in (self.e_name, self.cb_proto, self.chk_voice):
            w.setEnabled(not on)
        for b in self.marker_btns:
            b.setEnabled(on)

    def say(self, text):
        if self.chk_voice.isChecked():
            speak(text)
        else:
            chime()

    # ------------------------------------------------------------------ control
    def start_free(self, name: str, mode: str = "实时页一键录制") -> bool:
        """Free recording started from elsewhere (the 实时 page button). Returns True if it started."""
        if self.rec is not None:
            return False
        if not self.hub.is_live():
            return False
        self.cb_proto.setCurrentText("自由录制")
        self.e_name.setText(name)
        voice = self.chk_voice.isChecked()
        self.chk_voice.setChecked(False)      # quiet start: a single chime instead of speech
        self.start()
        self.chk_voice.setChecked(voice)
        if self.rec is None:
            return False
        self.rec.meta["mode"] = mode
        self.rec._write_meta()
        return True

    def start(self):
        if self.rec is not None:
            return
        if not self.hub.is_live():
            self.l_saved.setText("还没有数据：请先在右上角连接头环，或打开演示模式。")
            return
        name = self.e_name.text().strip() or self.cb_proto.currentText()
        self.rec = Recorder(self.hub, name, self.cb_proto.currentText(), self.e_notes.toPlainText())
        with self.hub.lock:
            self.hub.recorder = self.rec
        self.steps = list(PROTOCOLS.get(self.cb_proto.currentText(), []))
        self.step_i = -1
        self.l_saved.setText("")
        self.set_running(True)
        if self.steps:
            self.next_step()
        else:
            self.rec.add_marker("自由录制", "segment")
            self.l_step.setText("自由录制中")
            self.l_tip.setText("想标记的时候点右边按钮或按数字键。")
            self.say("开始录制")

    def next_step(self):
        if self.rec is None or not self.steps:
            return
        self.step_i += 1
        if self.step_i >= len(self.steps):
            self.say("全部完成，录制结束。")
            self.stop()
            return
        s = self.steps[self.step_i]
        self.step_t0 = self.rec.elapsed()
        self.rec.add_marker(s.label, "segment")
        self.l_step.setText(s.label)
        self.l_tip.setText(s.tip)
        for i in range(self.steps_list.count()):
            it = self.steps_list.item(i)
            txt = it.text().lstrip("✓▶ ")
            it.setText(("✓ " if i < self.step_i else ("▶ " if i == self.step_i else "")) + txt)
        self.steps_list.setCurrentRow(self.step_i)
        self.say(s.voice or s.label)

    def stop(self):
        if self.rec is None:
            return
        rec, self.rec = self.rec, None
        d = rec.close(self.e_notes.toPlainText())
        self.set_running(False)
        self.l_state.setText("已保存")
        self.l_step.setText("录制完成")
        self.l_tip.setText("可以到「回看」页查看每一段的结果。")
        self.ring.set(1.0, mmss(rec.meta["duration"]), "总时长", T.ACCENT)
        self.l_saved.setText(str(d))
        self.show_protocol(self.cb_proto.currentText())
        self.saved.emit(str(d))

    def mark(self, lab):
        if self.rec is None:
            return
        m = self.rec.add_marker(lab, "event")
        self.l_last.setText(f"已标记「{lab}」 @ {mmss(m['t'])}")

    def mark_custom(self):
        if self.rec is None:
            return
        text, ok = QInputDialog.getText(self, "自定义标记", "标记内容：")
        if ok and text.strip():
            self.mark(text.strip())

    # ------------------------------------------------------------------ timers
    def tick(self):
        if self.rec is None:
            if not self.hub.is_live():
                self.l_state.setText("未连接 · 请先连接头环或打开演示")
            elif self.l_state.text() != "已保存":
                self.l_state.setText("准备就绪")
            return
        el = self.rec.elapsed()
        self.l_state.setText(f"● 录制中  {mmss(el)}")
        self.l_state.setStyleSheet(f"color: {T.BAD};")
        if not self.steps:
            self.ring.set((el % 60) / 60, mmss(el), "已录制", T.ACCENT)
            return
        s = self.steps[self.step_i]
        in_step = el - self.step_t0
        if s.seconds:
            left = s.seconds - in_step
            self.ring.set(in_step / s.seconds, mmss(left), f"第 {self.step_i + 1}/{len(self.steps)} 步", T.ACCENT)
            if left <= 0:
                self.next_step()
        else:
            self.ring.set((in_step % 60) / 60, mmss(in_step), f"第 {self.step_i + 1}/{len(self.steps)} 步 · 按下一步结束", T.ACCENT2)

    def refresh_live(self):
        if not self.isVisible():
            return
        if self.rec is None:
            self.l_state.setStyleSheet("")
        self.bars.set_values(self.an.rel)
        hr = self.an.hr
        e = self.an.emg
        parts = []
        if hr == hr:
            parts.append(f"心率 {hr:.0f}")
        if e == e:
            parts.append(f"肌电 {e * 100:.0f}%" + ("  ⚠" if e > 0.3 else ""))
        good = sum(1 for v in self.an.quality.values() if v[0] == 2)
        parts.append(f"贴合 {good}/4")
        self.l_live.setText("   ·   ".join(parts))
