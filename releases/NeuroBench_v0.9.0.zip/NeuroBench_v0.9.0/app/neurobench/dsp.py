"""Signal processing shared by the live view and the offline review."""

from __future__ import annotations

import numpy as np
from scipy.signal import butter, find_peaks, iirnotch, sosfiltfilt, tf2sos, welch

FS_EEG = 256.0
FS_OPT = 64.0
FS_IMU = 52.0

EEG_NAMES = ["EEG_TP9", "EEG_AF7", "EEG_AF8", "EEG_TP10"]
EEG_LABELS = {
    "EEG_TP9": "左耳后 TP9",
    "EEG_AF7": "左前额 AF7",
    "EEG_AF8": "右前额 AF8",
    "EEG_TP10": "右耳后 TP10",
}
EEG_RAW_MAX = 1450.0  # decoder full scale (14-bit -> 0..1450 uV)

# key, Chinese label, low, high, colour
BANDS = [
    ("delta", "δ 慢波", 1.0, 4.0, "#818cf8"),
    ("theta", "θ 西塔", 4.0, 8.0, "#38bdf8"),
    ("alpha", "α 阿尔法", 8.0, 13.0, "#34d399"),
    ("beta", "β 贝塔", 13.0, 30.0, "#fbbf24"),
    ("gamma", "γ 伽马", 30.0, 45.0, "#f87171"),
]
BAND_KEYS = [b[0] for b in BANDS]
BAND_COLORS = {b[0]: b[4] for b in BANDS}
BAND_LABELS = {b[0]: b[1] for b in BANDS}


# --------------------------------------------------------------------------- filters
_SOS_CACHE: dict = {}


def _sos(kind: str, fs: float, *args):
    key = (kind, fs, args)
    if key not in _SOS_CACHE:
        if kind == "band":
            lo, hi, order = args
            _SOS_CACHE[key] = butter(order, [lo, hi], btype="band", fs=fs, output="sos")
        elif kind == "notch":
            f0, q = args
            b, a = iirnotch(f0, q, fs=fs)
            _SOS_CACHE[key] = tf2sos(b, a)
        elif kind == "low":
            hi, order = args
            _SOS_CACHE[key] = butter(order, hi, btype="low", fs=fs, output="sos")
    return _SOS_CACHE[key]


def _safe_filtfilt(sos, x, axis=0):
    padlen = 3 * (2 * len(sos) + 1)
    if x.shape[axis] <= padlen:
        return x - np.mean(x, axis=axis, keepdims=True)
    return sosfiltfilt(sos, x, axis=axis)


def clean_eeg(x: np.ndarray, fs: float = FS_EEG, lo: float = 1.0, hi: float = 40.0) -> np.ndarray:
    """Band-pass plus 50 and 60 Hz notches (works for China and the US). x: (n, ch)."""
    x = np.asarray(x, dtype=float)
    x = x - np.nanmean(x, axis=0, keepdims=True)
    x = np.nan_to_num(x)
    for f0 in (50.0, 60.0):
        x = _safe_filtfilt(_sos("notch", fs, f0, 25.0), x)
    return _safe_filtfilt(_sos("band", fs, lo, hi, 4), x)


def notch_only(x: np.ndarray, fs: float = FS_EEG) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    x = np.nan_to_num(x - np.nanmean(x, axis=0, keepdims=True))
    x = _safe_filtfilt(_sos("band", fs, 0.5, 120.0, 2), x)
    for f0 in (50.0, 60.0):
        x = _safe_filtfilt(_sos("notch", fs, f0, 25.0), x)
    return x


# --------------------------------------------------------------------------- spectra
def psd(x: np.ndarray, fs: float = FS_EEG, seg_s: float = 2.0):
    """Welch PSD along axis 0. Returns f, p with p shape (nf, ch)."""
    x = np.asarray(x, dtype=float)
    nper = int(min(len(x), seg_s * fs))
    f, p = welch(x, fs=fs, nperseg=nper, axis=0, detrend="constant")
    return f, p


def _band_sum(f, p, lo, hi):
    m = (f >= lo) & (f < hi)
    return p[m].sum(axis=0) * (f[1] - f[0])


# Narrow lines that are not brain or muscle: mains 50/60 Hz and harmonics (100/120 Hz), their folded
# 3rd harmonics at 256 Hz sampling (150 -> 106 Hz, 180 -> 76 Hz), and the optics sampling line at 64 Hz.
LINE_BANDS = ((46, 54), (56, 65), (74, 78), (96, 108), (116, 124))


def line_bins(f: np.ndarray) -> np.ndarray:
    m = np.zeros(len(f), bool)
    for lo, hi in LINE_BANDS:
        m |= (f > lo) & (f < hi)
    return m


def band_powers(x: np.ndarray, fs: float = FS_EEG):
    """Relative and absolute band power per channel.

    x: (n, ch) signal after notch (not band-limited).
    Returns rel (ch, 5), abs (ch, 5), emg (ch,) where emg is the share of
    30-100 Hz power (mains bands excluded) in 1-100 Hz total; on a forehead
    headband that range is dominated by muscle activity.
    """
    f, p = psd(x, fs)
    if p.ndim == 1:
        p = p[:, None]
    absp = np.stack([_band_sum(f, p, lo, hi) for _, _, lo, hi, _ in BANDS], axis=1)
    total = absp.sum(axis=1, keepdims=True)
    rel = absp / np.where(total > 0, total, 1.0)
    keep = ~line_bins(f)
    hf = _band_sum(f[keep], p[keep], 30.0, 100.0)
    tot = _band_sum(f[keep], p[keep], 1.0, 100.0)
    emg = hf / np.where(tot > 0, tot, 1.0)
    return rel, absp, emg


def alpha_peak(x: np.ndarray, fs: float = FS_EEG):
    """Individual alpha frequency (centre of gravity 7-13 Hz) from the mean spectrum."""
    f, p = psd(x, fs, seg_s=4.0)
    if p.ndim > 1:
        p = p.mean(axis=1)
    m = (f >= 7) & (f <= 13)
    if not m.any() or p[m].sum() <= 0:
        return float("nan")
    # remove 1/f trend before the centre of gravity
    lf, lp = np.log(f[(f >= 2) & (f <= 30)]), np.log(p[(f >= 2) & (f <= 30)] + 1e-12)
    slope, icpt = np.polyfit(lf, lp, 1)
    resid = p[m] - np.exp(icpt + slope * np.log(f[m]))
    resid = np.clip(resid, 0, None)
    if resid.sum() <= 0:
        return float("nan")
    return float((f[m] * resid).sum() / resid.sum())


# --------------------------------------------------------------------------- blinks
# The Muse reference electrode sits on the forehead, just above the eyes. A blink therefore shows
# up only weakly on AF7/AF8 (about -20 uV) but as a large negative wave on the ear sensors
# (TP9/TP10, about -100 uV). Calibrated on the user's first three real recordings (2026-11-27).
BLINK_HALF_S = 0.35      # samples within this distance of a blink peak are "blink" samples


def detect_blinks(X4: np.ndarray, fs: float = FS_EEG):
    """Blink peaks from raw [TP9, AF7, AF8, TP10]. Returns (indices, amplitude_uV)."""
    X4 = np.asarray(X4, float)
    if len(X4) < fs * 2:
        return np.array([], int), np.array([])
    lp = clean_eeg(X4, fs, 0.3, 15.0)
    tp = (lp[:, 0] + lp[:, 3]) / 2
    fr = (lp[:, 1] + lp[:, 2]) / 2
    pk, _ = find_peaks(-tp, height=20, distance=int(0.6 * fs), width=(0.05 * fs, 0.5 * fs))
    w1, w2, edge = int(0.1 * fs), int(0.2 * fs), int(0.5 * fs)
    keep = [i for i in pk
            if edge <= i < len(tp) - edge
            and lp[i - w1:i + w1, 0].min() < -10 and lp[i - w1:i + w1, 3].min() < -10
            and fr[i - w2:i + w2].min() < -3]
    keep = np.array(keep, int)
    return keep, (-tp[keep] if len(keep) else np.array([]))


def blink_mask(n: int, peaks, fs: float = FS_EEG):
    m = np.zeros(n, bool)
    h = int(BLINK_HALF_S * fs)
    for i in peaks:
        m[max(0, i - h):i + h] = True
    return m


# --------------------------------------------------------------------------- quality
def window_quality(raw: np.ndarray, fs: float = FS_EEG, mask=None):
    """Contact quality per channel for one ~2 s window, ignoring blink samples (mask=True).

    Returns list of (level, text): level 2 good, 1 fair, 0 poor. Thresholds from the real recordings:
    good channels stay below ~60 uV at the 99th percentile; loose ones exceed 100 uV or sit at the rails.
    """
    # v0.9: same features and classes as the live tracker (see window_features), without the hysteresis
    raw = np.asarray(raw, dtype=float)
    if len(raw) < fs:
        return [(0, "等待数据")] * raw.shape[1]
    out = []
    for ft in window_features(raw, fs, mask, span=None):
        k = classify_window(ft)
        # for analysis an excursion of >100 uV (or a clipped stretch) spoils the epoch: not usable, as in v0.8
        out.append((0, CLASS_TEXT[k]) if k == "artifact" else (CLASS_LEVEL[k], CLASS_TEXT[k]))
    return out


# --------------------------------------------------------------------------- quality v2 (v0.9)
# Built from the 7 real recordings of 2026-11-27 (see 改进计划.md, 第二版): a robust amplitude (MAD) instead of
# sd/p99 so 40-80 ms of spike no longer turns 2 s red; railed samples interpolated before filtering; mains
# pickup per electrode as a stand-in for contact resistance; short excursions labelled as movement, not as
# bad contact; and a tracker with hysteresis so the colour does not flicker.
RAIL_LO, RAIL_HI = 1.0, EEG_RAW_MAX - 1.0


_DFT_CACHE: dict = {}
LINE_N = 1024          # at most the last 4 s go into the line estimate (enough to resolve 0.25 Hz; keeps it cheap)


def _line_basis(n: int, fs: float, lo: float, hi: float, step: float):
    key = (n, fs, lo, hi, step)
    m = _DFT_CACHE.get(key)
    if m is None:
        if len(_DFT_CACHE) > 32:
            _DFT_CACHE.clear()
        w = np.hanning(n)
        fg = np.arange(lo, hi + step / 2, step)
        m = (fg, np.exp(-2j * np.pi * np.outer(fg, np.arange(n) / fs)) * w * (2 / w.sum()))
        _DFT_CACHE[key] = m
    return m


def line_amps(X: np.ndarray, fs: float = FS_EEG, lo: float = 49.0, hi: float = 51.0, step: float = 0.02):
    """Strongest narrow line in [lo, hi] Hz per channel, on a fine DFT grid (the mains drifts 49.6-50.0 Hz).
    X: (n, ch) raw samples, contiguous in time; uses the last LINE_N. Returns (uV RMS per ch, Hz per ch)."""
    X = np.asarray(X, float)
    if X.ndim == 1:
        X = X[:, None]
    X = X[-LINE_N:]
    n = len(X)
    if n < 64:
        return np.zeros(X.shape[1]), np.full(X.shape[1], (lo + hi) / 2)
    fg, B = _line_basis(n, fs, lo, hi, step)
    Z = np.abs(B @ (X - X.mean(axis=0)))               # (freqs, ch)
    k = np.argmax(Z, axis=0)
    cols = np.arange(X.shape[1])
    return Z[k, cols] / np.sqrt(2), fg[k]


def line_amp(x: np.ndarray, fs: float = FS_EEG, lo: float = 49.0, hi: float = 51.0, step: float = 0.02):
    """Single-channel version of line_amps: (uV RMS, Hz)."""
    a, f = line_amps(np.asarray(x, float)[:, None], fs, lo, hi, step)
    return float(a[0]), float(f[0])


def mains_pickup(raw: np.ndarray, fs: float = FS_EEG):
    """Per-channel mains pickup (uV RMS) at whichever of 50 / 60 Hz is stronger. Returns (hz, [uV per ch], f0).
    Raw samples are used as they are (clipped samples included): dropping them would splice the waveform."""
    raw = np.asarray(raw, float)
    a50, f50 = line_amps(raw, fs, 49.0, 51.0)
    a60, f60 = line_amps(raw, fs, 59.0, 61.0)
    if a60.max() > a50.max():
        return 60, a60.tolist(), float(np.median(f60))
    return 50, a50.tolist(), float(np.median(f50))


def window_features(raw: np.ndarray, fs: float = FS_EEG, mask=None, span: float | None = 2.0):
    """Per-channel features of the last `span` s of `raw` ((n, ch); live: ~4 s so filters settle).
    span=None uses the whole window (offline epochs)."""
    raw = np.asarray(raw, float)
    n2 = len(raw) if span is None else min(len(raw), int(span * fs))
    R = raw.copy()
    rail_all = (R <= RAIL_LO) | (R >= RAIL_HI)
    idx = np.arange(len(R))
    for c in range(R.shape[1]):                       # interpolate over clipped samples so the filters do not ring
        rail = rail_all[:, c]
        if rail.any() and (~rail).sum() > 10:
            R[rail, c] = np.interp(idx[rail], idx[~rail], R[~rail, c])
    F = clean_eeg(R, fs, 1.0, 40.0)[-n2:]
    SL = clean_eeg(R, fs, 0.3, 3.0)[-n2:]
    X2 = raw[-n2:]
    a50, _ = line_amps(X2, fs, 49.0, 51.0)
    a60, _ = line_amps(X2, fs, 59.0, 61.0)
    nb = np.ones(n2, bool) if mask is None else ~np.asarray(mask[-n2:], bool)   # blinks are not contact problems
    feats = []
    for c in range(raw.shape[1]):
        f = F[:, c]
        rl = rail_all[-n2:, c]
        keep = ~rl & nb
        if keep.sum() < fs * 0.5:
            keep = ~rl if (~rl).sum() >= fs * 0.5 else np.ones(n2, bool)
        fk = f[keep]
        rsd = 1.4826 * float(np.median(np.abs(fk - np.median(fk))))
        badm = rl | (np.abs(f) > 100)
        bad = float(np.mean(badm[nb])) if nb.sum() > fs * 0.5 else float(np.mean(badm))
        x2 = X2[:, c]
        two_rail = bool(np.mean(x2 <= RAIL_LO) > 0.02 and np.mean(x2 >= RAIL_HI) > 0.02)
        feats.append(dict(rail=float(rl.mean()), rsd=rsd, bad=bad, slow=float(np.std(SL[keep, c])),
                          line=float(max(a50[c], a60[c])), line50=float(a50[c]), line60=float(a60[c]),
                          two_rail=two_rail, flat=float(np.std(x2)) < 0.5))
    return feats


def classify_window(ft: dict, fair_rsd: float = 12.0) -> str:
    """'none' | 'float' (off the skin) | 'poor' | 'artifact' (brief excursion) | 'fair' | 'good'."""
    if ft["flat"]:
        return "none"
    if ft["line"] > 100 or (ft["two_rail"] and ft["rail"] > 0.2):
        return "float"
    if ft["rsd"] > 30 or ft["rail"] > 0.25 or ft["bad"] > 0.30:
        return "poor"
    if ft["bad"] > 0.005:
        return "artifact"
    if ft["rsd"] > fair_rsd or ft["slow"] > 30 or ft["line"] > 50:
        return "fair"
    return "good"


CLASS_LEVEL = {"none": 0, "float": 0, "poor": 0, "artifact": 1, "fair": 1, "good": 2}
CLASS_TEXT = {"none": "无信号", "float": "未贴合", "poor": "接触差", "artifact": "动作干扰", "fair": "一般", "good": "良好"}


class QualityTracker:
    """Hysteresis over checks made every `hop` s: red only for problems lasting ~4 s, green again after 2 s clean."""

    BAD = ("float", "poor", "none")

    def __init__(self, nch: int = 4, hop: float = 0.5, red_s: float = 4.0, green_s: float = 2.0):
        from collections import deque
        self.h = deque(maxlen=int(round(max(red_s, green_s) / hop)))
        self.nred = int(round(red_s / hop))
        self.ngreen = int(round(green_s / hop))
        self.state = [2] * nch
        self.nch = nch

    def update(self, classes):
        self.h.append(list(classes))
        H = list(self.h)
        out = []
        common = sum(c in ("artifact", "poor") for c in classes) >= 3    # whole headband moved
        for c in range(self.nch):
            seq = [x[c] for x in H]
            sev = sum(x in self.BAD for x in seq[-self.nred:])
            calm = len(seq) >= self.ngreen and not any(x in self.BAD for x in seq[-self.ngreen:])
            if seq[-1] in ("float", "none") and all(x in ("float", "none") for x in seq[-3:]):
                lv, txt = 0, CLASS_TEXT[seq[-1]]
            elif self.state[c] == 0 and not calm:
                lv, txt = 0, "接触差"
            elif len(seq) >= min(self.nred, 3) and sev >= 0.75 * min(len(seq), self.nred):
                lv, txt = 0, "接触差"
            elif seq[-1] in ("artifact", "poor"):
                lv, txt = 1, ("整体晃动" if common else "动作干扰")
            elif any(x in ("float", "none") for x in seq[-self.ngreen:]):
                lv, txt = 1, "接触不稳"                                  # touches the skin only part of the time
            elif sum(x == "fair" for x in seq[-self.ngreen:]) >= self.ngreen / 2:
                lv, txt = 1, "一般"
            else:
                lv, txt = 2, "良好"
            self.state[c] = lv
            out.append((lv, txt))
        return out


def channel_quality(raw: np.ndarray, fs: float = FS_EEG, mask=None):
    """Quality over a longer stretch: per channel, the median level of its 2 s windows."""
    raw = np.asarray(raw, dtype=float)
    W = int(2 * fs)
    if len(raw) < W:
        return window_quality(raw, fs, mask)
    wins = []
    for k in range(len(raw) // W):
        sl = slice(k * W, (k + 1) * W)
        wins.append(window_quality(raw[sl], fs, None if mask is None else mask[sl]))
    out = []
    for c in range(raw.shape[1]):
        levels = sorted(w[c] for w in wins)
        out.append(levels[len(levels) // 2] if len(levels) % 2 else levels[len(levels) // 2 - 1])
    return out


def mains_level(raw: np.ndarray, fs: float = FS_EEG):
    """RMS of the 50 Hz and 60 Hz mains components (uV), mean over channels. Returns (hz, uV)."""
    raw = np.asarray(raw, float)
    if len(raw) < fs * 2:
        return 0, 0.0
    f, p = welch(raw - raw.mean(axis=0), fs=fs, nperseg=int(2 * fs), axis=0)
    df = f[1] - f[0]
    best = (0, 0.0)
    for hz in (50.0, 60.0):
        m = np.abs(f - hz) <= 1.0
        rms = float(np.sqrt(p[m].sum(axis=0) * df).mean())
        if rms > best[1]:
            best = (int(hz), rms)
    return best


# --------------------------------------------------------------------------- heart
PPG_DEAD = ("_LI_NIR", "_RI_NIR", "_LI_IR", "_RI_IR")   # inner 730/850 nm channels are flat on this headband


def ppg_candidates(names: list[str]):
    """Red channels carry the clearest pulse on the Athena; fall back to other usable optics."""
    red = [i for i, n in enumerate(names) if n.endswith("_RED")]
    if red:
        return red
    return [i for i, n in enumerate(names) if "AMB" not in n and not n.endswith(PPG_DEAD)]


def ppg_scores(opt: np.ndarray, names: list[str], fs: float = FS_OPT):
    """[(channel index, cardiac share of power, spectral pulse rate in bpm)] for candidate channels."""
    out = []
    for i in ppg_candidates(names):
        x = np.asarray(opt[:, i], float)
        if np.std(x) <= 0:
            continue
        f, p = psd(x - x.mean(), fs, seg_s=8.0)
        tot = p[(f > 0.1) & (f < 8)].sum()
        if tot <= 0:
            continue
        score = float(p[(f > 0.8) & (f < 3.0)].sum() / tot)
        rate = pulse_rate_hz(-ppg_filter(x, fs), fs) * 60.0
        out.append((i, score, rate))
    return out


def consensus_rate(scores):
    rates = [r for _, sc, r in scores if sc > 0.15 and r == r]
    return float(np.median(rates)) if rates else float("nan")


def pick_ppg_channel(opt: np.ndarray, names: list[str], fs: float = FS_OPT, current=None):
    """Best pulse channel whose rate agrees with the consensus of all red channels.

    Sticky: keeps `current` unless another channel scores clearly (25 %) better or `current` disagrees.
    Returns (index, score).
    """
    sc = ppg_scores(opt, names, fs)
    if not sc:
        return None, -1.0
    cons = consensus_rate(sc)
    agree = [(i, s) for i, s, r in sc if cons != cons or (r == r and abs(r - cons) <= 8)] or [(i, s) for i, s, _ in sc]
    best_i, best_s = max(agree, key=lambda x: x[1])
    if current is not None:
        cur = [(i, s) for i, s in agree if i == current]
        if cur and best_s < cur[0][1] * 1.25:
            return cur[0]
    return best_i, best_s


def ppg_filter(x: np.ndarray, fs: float = FS_OPT):
    return _safe_filtfilt(_sos("band", fs, 0.7, 3.5, 2), np.asarray(x, float) - np.mean(x))


def pulse_rate_hz(y: np.ndarray, fs: float = FS_OPT):
    """Dominant frequency in 0.7-3.2 Hz (42-192 bpm) of a filtered PPG window."""
    if len(y) < 4 * fs:
        return float("nan")
    nfft = max(4096, len(y))
    f, p = welch(y, fs=fs, nperseg=min(len(y), int(8 * fs)), nfft=nfft)
    m = (f >= 0.7) & (f <= 3.2)
    if not m.any() or p[m].max() <= 0:
        return float("nan")
    fm, pm = f[m], p[m]
    k = int(np.argmax(pm))
    # if half the frequency also carries a strong peak, the true rate is the lower one
    half = np.abs(fm - fm[k] / 2) < 0.08
    if half.any() and pm[half].max() > 0.5 * pm[k]:
        k = int(np.flatnonzero(half)[np.argmax(pm[half])])
    return float(fm[k])


def ppg_beats(x: np.ndarray, fs: float = FS_OPT, t: np.ndarray | None = None):
    """Detect pulse peaks. Returns (peak_times, ibi_seconds)."""
    y = ppg_filter(x, fs)
    if len(y) < 3 * fs:
        return np.array([]), np.array([])
    # optical PPG pulses point down (more blood absorbs more light) -> use -y
    y = -y
    # dominant pulse rate from the spectrum guides the minimum peak spacing,
    # which stops the dicrotic notch from being counted as a second beat
    f0 = pulse_rate_hz(y, fs)
    min_gap = 0.6 / f0 if f0 == f0 else 0.33
    prom = 0.3 * np.std(y)
    peaks, _ = find_peaks(y, distance=max(1, int(min_gap * fs)), prominence=prom)
    if t is None:
        t = np.arange(len(y)) / fs
    pt = t[peaks]
    ibi = np.diff(pt)
    return pt, ibi


def clean_ibi(ibi: np.ndarray):
    ibi = ibi[(ibi > 0.33) & (ibi < 1.6)]
    if len(ibi) < 3:
        return ibi
    med = np.median(ibi)
    return ibi[np.abs(ibi - med) < 0.25 * med]


def heart_metrics(x: np.ndarray, fs: float = FS_OPT, min_beats: int = 4):
    """HR (bpm) and RMSSD (ms) from a PPG window."""
    _, ibi = ppg_beats(x, fs)
    ibi = clean_ibi(ibi)
    if len(ibi) < min_beats:
        return float("nan"), float("nan")
    hr = 60.0 / np.median(ibi)
    d = np.diff(ibi)
    rmssd = float(np.sqrt(np.mean(d**2)) * 1000.0) if len(d) >= 3 else float("nan")
    return float(hr), rmssd


def robust_heart(opt: np.ndarray, names: list[str], fs: float = FS_OPT, current=None):
    """Heart rate and RMSSD with agreement checks across red channels.

    Returns dict: ch, hr, rmssd, ok_hr, ok_hrv, consensus.
    HR is trusted when the chosen channel agrees with the spectral consensus (within 6 bpm);
    RMSSD is reported only if the two best channels agree within 30 % (beat jitter on a noisy channel
    inflates RMSSD, as seen in the real recordings: 31 ms on one channel, 108 ms on another).
    """
    sc = ppg_scores(opt, names, fs)
    cons = consensus_rate(sc)
    ch, _ = pick_ppg_channel(opt, names, fs, current)
    out = {"ch": ch, "hr": float("nan"), "rmssd": float("nan"), "ok_hr": False, "ok_hrv": False, "consensus": cons}
    if ch is None:
        return out
    hr, rm = heart_metrics(opt[:, ch], fs)
    if hr == hr and (cons != cons or abs(hr - cons) <= 6):
        out["hr"], out["ok_hr"] = hr, True
    elif cons == cons:
        out["hr"] = cons                    # fall back to the spectral rate, flagged as unsure
    ranked = sorted(sc, key=lambda x: -x[1])[:2]
    rms = [heart_metrics(opt[:, i], fs, min_beats=20)[1] for i, _, _ in ranked]
    rms = [r for r in rms if r == r]
    if len(rms) == 2 and max(rms) <= 1.3 * min(rms):
        out["rmssd"], out["ok_hrv"] = float(np.mean(rms)), True
    elif len(rms) == 1 and len(ranked) == 1:
        out["rmssd"], out["ok_hrv"] = rms[0], True
    return out


def breath_heart_coupling(opt: np.ndarray, names: list[str], t: np.ndarray, breaths_per_min: float, fs: float = FS_OPT):
    """How strongly heart rate follows a paced breathing rhythm (resonance breathing).

    Fits a sinusoid at the breathing frequency to the beat-to-beat heart rate.
    Returns dict: swing (peak-to-peak bpm), sync (R^2 of the fit, 0-1), rmssd (ms), beats.
    """
    h = robust_heart(opt, names, fs)
    out = {"swing": float("nan"), "sync": float("nan"), "rmssd": h["rmssd"], "beats": 0}
    if h["ch"] is None:
        return out
    pt, ibi = ppg_beats(opt[:, h["ch"]], fs, t=t)
    if len(ibi) < 10:
        return out
    tb = pt[1:]
    ok = (ibi > 0.33) & (ibi < 1.6)
    tb, hr = tb[ok], 60.0 / ibi[ok]
    med = np.median(hr)
    keep = np.abs(hr - med) < 25
    tb, hr = tb[keep], hr[keep]
    if len(hr) < 10:
        return out
    w = 2 * np.pi * breaths_per_min / 60.0
    A = np.column_stack([np.sin(w * tb), np.cos(w * tb), np.ones_like(tb)])
    coef, *_ = np.linalg.lstsq(A, hr, rcond=None)
    fit = A @ coef
    ss_res, ss_tot = np.sum((hr - fit) ** 2), np.sum((hr - hr.mean()) ** 2)
    out.update(swing=float(2 * np.hypot(coef[0], coef[1])), sync=float(1 - ss_res / ss_tot) if ss_tot > 0 else float("nan"),
               beats=int(len(hr)))
    return out


# --------------------------------------------------------------------------- fNIRS
# Molar extinction coefficients (cm^-1 / M, log10 base), Prahl's compilation.
#            HbO2      HbR
_EXT = np.array([[390.0, 1102.2],   # 730 nm (NIR channels)
                 [1058.0, 691.32]]) # 850 nm (IR channels)
_EXT_INV = np.linalg.inv(_EXT)
ASSUMED_DISTANCE_CM = 3.0
ASSUMED_DPF = 6.0


def hb_changes(i730: np.ndarray, i850: np.ndarray, baseline_n: int | None = None):
    """Modified Beer-Lambert: intensity series -> (dHbO, dHbR) in uM (assumed path length).

    Baseline is the mean of the first baseline_n samples (whole window if None).
    Values are rough: the source-detector distance and DPF are assumptions.
    """
    i730 = np.clip(np.asarray(i730, float), 1e-6, None)
    i850 = np.clip(np.asarray(i850, float), 1e-6, None)
    n = baseline_n or len(i730)
    od = np.vstack([-np.log10(i730 / np.mean(i730[:n])), -np.log10(i850 / np.mean(i850[:n]))])
    conc = _EXT_INV @ od / (ASSUMED_DISTANCE_CM * ASSUMED_DPF)  # mol/L
    return conc[0] * 1e6, conc[1] * 1e6


def lowpass(x: np.ndarray, fs: float, hi: float):
    return _safe_filtfilt(_sos("low", fs, hi, 2), np.asarray(x, float))


# --------------------------------------------------------------------------- motion
def motion_level(gyro: np.ndarray):
    """RMS angular speed (deg/s) after removing the offset."""
    g = np.asarray(gyro, float)
    if len(g) < 5:
        return float("nan")
    g = g - np.median(g, axis=0, keepdims=True)
    return float(np.sqrt(np.mean(np.sum(g**2, axis=1))))
