"""Thought-switch training: learn to tell "mental arithmetic" from "blank mind" in YOUR data.

Each training run records 20 trials (cue 3 s, task 12 s, rest 5 s). Features per trial (seconds 2-12
of the task): log relative band power for each electrode and band, forehead oxygenation change and
heart-rate change against the 3 s before the trial. Classifier: shrinkage LDA on standardized
features (numpy only). Accuracy is always cross-validated (leave one session out once there are two
or more sessions), and the switch is only trusted from 75 % upward.
"""

from __future__ import annotations

import json
import math
import random
from pathlib import Path

import numpy as np

from . import dsp
from .paths import ROOT

MODEL_DIR = ROOT / "models"
TRIALS = MODEL_DIR / "thought_trials.json"
MODEL = MODEL_DIR / "thought_switch.json"
CLASSES = {"A": "心算", "B": "放空"}
CUE_S, TASK_S, REST_S, N_TRIALS = 3, 12, 5, 20
WIN = (2.0, 12.0)                      # analysis window inside the task
TRUST = 0.75


def trusted(model) -> bool:
    """Good enough to control things: >= 75 % on at least 10 scored trials and unlikely to be luck."""
    return bool(model) and model.get("accuracy", 0) >= TRUST and model.get("n", 0) >= 10         and model.get("p_value", 1.0) < 0.05


def schedule(n=N_TRIALS, seed=None):
    lab = ["A", "B"] * (n // 2)
    random.Random(seed).shuffle(lab)
    return lab


# ------------------------------------------------------------------------------ features
def _eeg_feats(X4):
    pk, _ = dsp.detect_blinks(X4)
    keep = ~dsp.blink_mask(len(X4), pk)
    x = dsp.notch_only(X4)
    if keep.mean() > 0.4:
        x = x[keep]
    rel, _, _ = dsp.band_powers(x)
    out = {}
    for c, ch in enumerate(("TP9", "AF7", "AF8", "TP10")):
        for b, band in enumerate(dsp.BAND_KEYS):
            out[f"{ch}_{band}"] = float(np.log(rel[c, b] + 1e-6))
    return out


def _optic_feats(O, names, base_mask, win_mask, fs=dsp.FS_OPT):
    out = {}
    for side in ("L", "R"):
        try:
            a, b = names.index(f"OPTICS_{side}O_NIR"), names.index(f"OPTICS_{side}O_IR")
        except ValueError:
            continue
        if base_mask.sum() < fs or win_mask.sum() < fs * 3:
            continue
        sel = base_mask | win_mask
        hbo, hbr = dsp.hb_changes(O[sel, a], O[sel, b], baseline_n=int(base_mask.sum()))
        n0 = int(base_mask.sum())
        out[f"hbo_{side}"] = float(np.mean(hbo[n0:]))
        out[f"hbr_{side}"] = float(np.mean(hbr[n0:]))
    return out


def trial_features(eeg, eeg_t, eeg_names, opt, opt_t, opt_names, t_task):
    """Features for one trial starting (task phase) at t_task."""
    m = (eeg_t >= t_task + WIN[0]) & (eeg_t < t_task + WIN[1])
    if m.sum() < dsp.FS_EEG * 6 or not all(n in eeg_names for n in dsp.EEG_NAMES):
        return None
    X4 = eeg[m][:, [eeg_names.index(n) for n in dsp.EEG_NAMES]]
    f = _eeg_feats(X4)
    if opt is not None and len(opt):
        base = (opt_t >= t_task - 3) & (opt_t < t_task)
        win = (opt_t >= t_task + WIN[0]) & (opt_t < t_task + WIN[1])
        f.update(_optic_feats(opt, opt_names, base, win))
        h0 = dsp.robust_heart(opt[(opt_t >= t_task - 10) & (opt_t < t_task)], opt_names)["consensus"] if base.any() else float("nan")
        h1 = dsp.robust_heart(opt[win], opt_names)["consensus"] if win.any() else float("nan")
        if h0 == h0 and h1 == h1:
            f["hr_d"] = float(h1 - h0)
    return f


def add_session(session_dir: Path) -> int:
    """Extract trials from a finished training recording and append them to the trial store."""
    from .session import load_session
    s = load_session(Path(session_dir))
    if "EEG" not in s.data:
        return 0
    et, EX, en = s.data["EEG"]
    ot, OX, on = s.data.get("OPTICS", (None, None, []))
    new = []
    for mk in s.markers:
        if mk["kind"] != "trial":
            continue
        lab = mk["label"][:1]
        f = trial_features(EX, et, en, OX, ot, on, mk["t"])
        if f and lab in CLASSES:
            new.append({"session": Path(session_dir).name, "label": lab, "t": mk["t"], "features": f})
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    allt = load_trials()
    allt = [t for t in allt if t["session"] != Path(session_dir).name] + new
    TRIALS.write_text(json.dumps(allt, ensure_ascii=False), encoding="utf-8")
    return len(new)


def load_trials():
    try:
        return json.loads(TRIALS.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []


def trial_count():
    return len(load_trials())


# ------------------------------------------------------------------------------ classifier
def _fit(X, y, shrink=0.3):
    mu, sd = X.mean(0), X.std(0) + 1e-9
    Z = (X - mu) / sd
    m1, m0 = Z[y == 1].mean(0), Z[y == 0].mean(0)
    S = np.cov(Z.T) if Z.shape[1] > 1 else np.array([[np.var(Z)]])
    S = (1 - shrink) * S + shrink * np.eye(len(S)) * np.trace(S) / len(S)
    w = np.linalg.solve(S, m1 - m0)
    b = -w @ (m1 + m0) / 2
    return {"mu": mu.tolist(), "sd": sd.tolist(), "w": w.tolist(), "b": float(b)}


def _score(model, X):
    Z = (np.asarray(X) - np.array(model["mu"])) / np.array(model["sd"])
    return Z @ np.array(model["w"]) + model["b"]


def train():
    """Cross-validated accuracy, then a final model on all trials. Returns a result dict."""
    trials = load_trials()
    if len(trials) < 10:
        return {"ok": False, "n": len(trials), "msg": "至少要 10 轮训练数据"}
    feats = sorted(set.intersection(*(set(t["features"]) for t in trials)))
    X = np.array([[t["features"][k] for k in feats] for t in trials])
    y = np.array([1 if t["label"] == "A" else 0 for t in trials])
    sess = np.array([t["session"] for t in trials])
    groups = sorted(set(sess))
    def five_fold():
        idx = np.arange(len(y))
        rng = np.random.default_rng(0)
        rng.shuffle(idx)
        return [np.isin(np.arange(len(y)), idx[i::5]) for i in range(5)]

    def cross_validate(folds):
        pred = np.full(len(y), np.nan)      # folds that cannot be trained stay unscored (not counted as "B")
        for test in folds:
            if len(set(y[~test])) < 2:
                continue
            m = _fit(X[~test], y[~test])
            pred[test] = (_score(m, X[test]) > 0).astype(float)
        return pred

    if len(groups) >= 2:
        pred = cross_validate([sess == g for g in groups])
        how = f"留一次训练交叉验证（{len(groups)} 次训练）"
        if (~np.isnan(pred)).sum() < max(10, 0.8 * len(y)):      # too few trials could be scored that way
            pred = cross_validate(five_fold())
            how = "5 折交叉验证（有的训练只含一类，没法按次留出；结果偏乐观）"
    else:
        pred = cross_validate(five_fold())
        how = "5 折交叉验证（只有 1 次训练，结果偏乐观）"
    scored = ~np.isnan(pred)
    acc = float(np.mean(pred[scored] == y[scored])) if scored.any() else 0.0
    n = int(scored.sum())
    k = int(round(acc * n))
    p = sum(math.comb(n, i) for i in range(k, n + 1)) / 2 ** n       # one-sided binomial vs chance
    model = _fit(X, y)
    model.update(features=feats, accuracy=acc, n=n, sessions=len(groups), p_value=p, how=how)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    MODEL.write_text(json.dumps(model, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, **model}


def load_model():
    try:
        return json.loads(MODEL.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def live_probability(hub, model):
    """P(心算) for the last 10 s of live data, or None."""
    eeg = hub.latest("EEG", 14.0)
    names = hub.names("EEG")
    if len(eeg) < dsp.FS_EEG * 12:
        return None
    t_task = float(eeg[-1, 0]) - WIN[1]
    opt = hub.latest("OPTICS", 26.0)
    on = hub.names("OPTICS")
    f = trial_features(eeg[:, 1:], eeg[:, 0], names, opt[:, 1:] if len(opt) else None,
                       opt[:, 0] if len(opt) else None, on, t_task)
    if not f or any(k not in f for k in model["features"]):
        return None
    s = float(_score(model, [[f[k] for k in model["features"]]])[0])
    s = max(-50.0, min(50.0, s))              # a dead channel can give huge scores: no overflow
    return 1 / (1 + math.exp(-s))
