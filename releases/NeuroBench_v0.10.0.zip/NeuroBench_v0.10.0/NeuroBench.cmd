@echo off
start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0app\NeuroBench.pyw" %*
