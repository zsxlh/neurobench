﻿param([switch]$NoShortcut)
# NeuroBench 脑电实验台 - 安装脚本（在轻薄本上运行一次）
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host ''
Write-Host '==== NeuroBench 脑电实验台 安装 ====' -ForegroundColor Cyan
Write-Host "安装位置：$PSScriptRoot"
Write-Host '需要联网，第一次大约下载 200 MB，3-10 分钟。'
Write-Host ''

# 1. uv（Python 包管理器）
$uv = $null
$cmd = Get-Command uv -ErrorAction SilentlyContinue
if ($cmd) { $uv = $cmd.Source }
if (-not $uv) {
    $cand = Join-Path $env:USERPROFILE '.local\bin\uv.exe'
    if (-not (Test-Path $cand)) {
        Write-Host '[1/4] 下载 uv（官方安装脚本 astral.sh/uv）...' -ForegroundColor Yellow
        powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
    }
    $uv = $cand
}
if (-not (Test-Path $uv)) { throw "没找到 uv：$uv" }
Write-Host "[1/4] uv 就绪：$uv"

# 2. Python 3.12 虚拟环境
$py = '3.12'
if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') {
    $py = 'cpython-3.12-windows-x86_64-none'
    Write-Host '      检测到 ARM 处理器（骁龙）：使用 x64 版 Python，由 Windows 自动模拟运行。'
}
if (-not (Test-Path '.venv\Scripts\python.exe')) {
    Write-Host '[2/4] 创建 Python 3.12 环境...' -ForegroundColor Yellow
    & $uv venv --python $py .venv
    if ($LASTEXITCODE -ne 0) { throw '创建 Python 环境失败' }
} else {
    Write-Host '[2/4] Python 环境已存在，跳过'
}

# 3. 依赖（版本已锁定，和实验室那台一致）
Write-Host '[3/4] 安装依赖...' -ForegroundColor Yellow
$env:UV_HTTP_TIMEOUT = '120'
& $uv pip install --python .venv\Scripts\python.exe -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw '安装依赖失败（多半是网络问题，重新双击 Install.cmd 即可续装）' }
& $uv pip install --python .venv\Scripts\python.exe --no-deps .\vendor\OpenMuse
if ($LASTEXITCODE -ne 0) { throw '安装 OpenMuse 失败' }
& .venv\Scripts\python.exe -c "import OpenMuse, PyQt6.QtWidgets, pyqtgraph, scipy, bleak; print('      依赖检查通过')"
if ($LASTEXITCODE -ne 0) { throw '依赖检查没通过' }

# 4. 桌面快捷方式
if (-not $NoShortcut) {
    $desk = [Environment]::GetFolderPath('Desktop')
    $lnk = Join-Path $desk 'NeuroBench 脑电实验台.lnk'
    $ws = New-Object -ComObject WScript.Shell
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = (Join-Path $PSScriptRoot '.venv\Scripts\pythonw.exe')
    $s.Arguments = '"' + (Join-Path $PSScriptRoot 'app\NeuroBench.pyw') + '"'
    $s.WorkingDirectory = $PSScriptRoot
    $s.IconLocation = (Join-Path $PSScriptRoot 'app\neurobench.ico') + ',0'
    $s.Description = 'NeuroBench 脑电实验台 (Muse S Athena)'
    $s.Save()
    Write-Host "[4/4] 已在桌面创建快捷方式：$lnk"
} else {
    Write-Host '[4/4] 跳过快捷方式'
}
Write-Host ''
Write-Host '安装完成。双击桌面「NeuroBench 脑电实验台」打开。' -ForegroundColor Green
