"""Video / audio recorded together with the EEG (v0.9).

* Qt Multimedia (FFmpeg backend, bundled with PyQt6): H.264 + AAC in video.mp4, or AAC in audio.m4a.
* Sync: every durationChanged(ms) is paired with Recorder.elapsed(); the media clock is mapped to the EEG
  clock with t_eeg = a + b * t_media, where a is the lower envelope of (elapsed - media time) (frames arrive
  late, never early) and b is fitted when the recording is long. A chime + marker at start and end lets you
  check it by eye (and by ear in the audio track).
* Off by default. Media files are left out of the Desktop zip and the cloud upload unless the user opts in.
* PyQt6 6.12 cannot connect QMediaRecorder's enum signals, so state and errors are polled with a timer.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from PyQt6.QtCore import QEventLoop, QObject, QSettings, QTimer, QUrl, pyqtSignal

MEDIA_FILES = ("video.mp4", "audio.m4a")
SYNC_FILE = "av_sync.json"


def available() -> bool:
    try:
        import PyQt6.QtMultimedia  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def settings() -> dict:
    s = QSettings("NeuroBench", "NeuroBench")
    return {"video": s.value("av/video", False, type=bool), "audio": s.value("av/audio", False, type=bool),
            "camera": s.value("av/camera", "", type=str), "mic": s.value("av/mic", "", type=str)}


def save_settings(**kw):
    s = QSettings("NeuroBench", "NeuroBench")
    for k, v in kw.items():
        s.setValue(f"av/{k}", v)


def devices():
    """([(id, name)] cameras, [(id, name)] microphones); ids are the stable device ids as text."""
    from PyQt6.QtMultimedia import QMediaDevices
    cams = [(bytes(d.id()).decode("utf-8", "replace"), d.description()) for d in QMediaDevices.videoInputs()]
    mics = [(bytes(d.id()).decode("utf-8", "replace"), d.description()) for d in QMediaDevices.audioInputs()]
    return cams, mics


def _pick(devs, want: str, default):
    for d in devs:
        if bytes(d.id()).decode("utf-8", "replace") == want:
            return d
    return default


def _best_format(cam_dev):
    """1280x720 at <= 30 fps if offered (NV12/MJPEG preferred), else the largest format up to 720p."""
    fmts = list(cam_dev.videoFormats())
    if not fmts:
        return None

    def score(f):
        r = f.resolution()
        w, h = r.width(), r.height()
        fps = f.maxFrameRate()
        ok = h <= 720 and fps >= 15
        return (ok, h == 720, min(fps, 30), w * h if h <= 720 else 0)
    return max(fmts, key=score)


def fit_sync(pairs):
    """pairs: [(t_eeg, t_media)] -> (a, b, residual_ms). Lower envelope: media frames are stamped late."""
    if not pairs:
        return 0.0, 1.0, float("nan")
    import numpy as np
    p = np.array(pairs, float)
    lag = p[:, 0] - p[:, 1]
    b = 1.0
    span = p[-1, 1] - p[0, 1]
    if span > 120 and len(p) > 10:                       # long recording: fit drift on per-bin minima
        bins = np.linspace(p[0, 1], p[-1, 1], 8)
        xs, ys = [], []
        for lo, hi in zip(bins[:-1], bins[1:]):
            m = (p[:, 1] >= lo) & (p[:, 1] <= hi)
            if m.any():
                k = int(np.argmin(lag[m]))
                xs.append(p[m][k, 1])
                ys.append(lag[m][k])
        if len(xs) >= 3:
            slope = float(np.polyfit(xs, ys, 1)[0])
            if abs(slope) < 0.01:                         # anything bigger is not clock drift
                b = 1.0 + slope
    a = float(np.min(p[:, 0] - b * p[:, 1]))
    res = float(np.median(p[:, 0] - (a + b * p[:, 1])) * 1000)
    return a, b, res


class AVRecorder(QObject):
    """Records camera and/or microphone into the session folder while a Recorder runs."""

    message = pyqtSignal(str)

    def __init__(self, rec, video: bool, audio: bool, camera_id: str = "", mic_id: str = "", frame_input=None):
        super().__init__()
        self._frame_input = frame_input          # tests: a QVideoFrameInput instead of the camera
        self.rec, self.video, self.audio = rec, video, audio
        self.camera_id, self.mic_id = camera_id, mic_id
        self.pairs = []
        self.cues = []
        self.error = ""
        self.path = None
        self._last_pair = -1e9
        self._session = self._cam = self._mic = self._mr = None
        self._poll = QTimer(self)
        self._poll.timeout.connect(self._check)
        self.info = {}

    # ---------------------------------------------------------------- control
    def start(self) -> bool:
        from PyQt6.QtMultimedia import (QAudioInput, QCamera, QMediaCaptureSession, QMediaDevices, QMediaFormat,
                                        QMediaRecorder)
        try:
            self._session = QMediaCaptureSession()
            if self.video and self._frame_input is not None:
                self._session.setVideoFrameInput(self._frame_input)
                self.info["camera"] = "test frames"
            elif self.video:
                cams = QMediaDevices.videoInputs()
                if not cams:
                    self.video = False
                    self.message.emit("没有找到摄像头，只录音")
                else:
                    dev = _pick(cams, self.camera_id, QMediaDevices.defaultVideoInput())
                    self._cam = QCamera(dev)
                    fmt = _best_format(dev)
                    if fmt is not None:
                        self._cam.setCameraFormat(fmt)
                        r = fmt.resolution()
                        self.info["camera_format"] = f"{r.width()}x{r.height()}@{fmt.maxFrameRate():.0f}"
                    self.info["camera"] = dev.description()
                    self._session.setCamera(self._cam)
                    self._cam.start()
            if self.audio or self.video:
                mics = QMediaDevices.audioInputs()
                if mics and self.audio:
                    dev = _pick(mics, self.mic_id, QMediaDevices.defaultAudioInput())
                    self._mic = QAudioInput(dev)
                    self._session.setAudioInput(self._mic)
                    self.info["microphone"] = dev.description()
                elif self.audio:
                    self.audio = False
                    self.message.emit("没有找到麦克风")
            if not (self.video or self.audio):
                return False
            self._mr = QMediaRecorder()
            self._session.setRecorder(self._mr)
            mf = QMediaFormat()
            if self.video:
                mf.setFileFormat(QMediaFormat.FileFormat.MPEG4)
                mf.setVideoCodec(QMediaFormat.VideoCodec.H264)
                name = "video.mp4"
            else:
                mf.setFileFormat(QMediaFormat.FileFormat.Mpeg4Audio)
                name = "audio.m4a"
            if self.audio:
                mf.setAudioCodec(QMediaFormat.AudioCodec.AAC)
            self._mr.setMediaFormat(mf)
            self._mr.setQuality(QMediaRecorder.Quality.NormalQuality)
            self.path = Path(self.rec.dir) / name
            self._mr.setOutputLocation(QUrl.fromLocalFile(str(self.path)))
            self._mr.durationChanged.connect(self._on_duration)
            self.t_request = self.rec.elapsed()
            self.wall_request = time.time()
            self._mr.record()
            self._poll.start(100)
            self.cue("同步提示音（开始）")
            return True
        except Exception as e:  # noqa: BLE001
            self.error = f"{type(e).__name__}: {e}"
            self.message.emit(f"录像/录音没能启动：{self.error[:80]}")
            self._release()
            return False

    def cue(self, label: str):
        """Audible + logged sync point (also visible as a marker in 回看)."""
        from .protocols import chime
        chime()
        m = self.rec.add_marker(label, "system")
        self.cues.append(m["t"])

    def stop(self):
        if self._mr is None:
            return None
        from PyQt6.QtMultimedia import QMediaRecorder
        try:
            self.cue("同步提示音（结束）")
            loop = QEventLoop()
            QTimer.singleShot(300, loop.quit)             # let the end chime reach the microphone
            loop.exec()
            self._mr.stop()
            t0 = time.monotonic()
            while self._mr.recorderState() != QMediaRecorder.RecorderState.StoppedState and time.monotonic() - t0 < 6:
                loop = QEventLoop()
                QTimer.singleShot(50, loop.quit)
                loop.exec()
        finally:
            self._poll.stop()
            info = self._write_sync()
            self._release()
        return info

    # ---------------------------------------------------------------- internals
    def _on_duration(self, ms: int):
        te = self.rec.elapsed()
        # dense pairs in the first 30 s (they pin the offset), then one every 5 s
        if te < 30 or te - self._last_pair >= 5:
            self.pairs.append((te, ms / 1000.0))
            self._last_pair = te

    def _check(self):
        if self._mr is None:
            return
        from PyQt6.QtMultimedia import QMediaRecorder
        if self._mr.error() != QMediaRecorder.Error.NoError and not self.error:
            self.error = self._mr.errorString() or str(self._mr.error())
            self.message.emit(f"录像/录音出错：{self.error[:80]}")

    def _write_sync(self):
        a, b, res = fit_sync(self.pairs)
        size = self.path.stat().st_size if self.path is not None and self.path.exists() else 0
        info = {"file": self.path.name if self.path else None, "video": self.video, "audio": self.audio,
                "a": a, "b": b, "residual_ms": res, "pairs": self.pairs[:400], "cues": self.cues,
                "t_request": getattr(self, "t_request", None), "wall_request": getattr(self, "wall_request", None),
                "size": size, "error": self.error, **self.info}
        try:
            from PyQt6.QtCore import QT_VERSION_STR
            info["qt"] = QT_VERSION_STR
        except Exception:  # noqa: BLE001
            pass
        try:
            (Path(self.rec.dir) / SYNC_FILE).write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass
        self.rec.meta["av"] = {k: info[k] for k in ("file", "video", "audio", "size", "error")}
        return info

    def _release(self):
        for obj in (self._cam,):
            try:
                if obj is not None:
                    obj.stop()
            except Exception:  # noqa: BLE001
                pass
        self._mr = self._cam = self._mic = self._session = None


def load_sync(d: Path):
    p = Path(d) / SYNC_FILE
    if not p.exists():
        return None
    try:
        info = json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    f = info.get("file")
    if not f or not (Path(d) / f).exists():
        return None
    info["path"] = str(Path(d) / f)
    try:                                   # offset measured from the chimes in the audio, when available
        feat = json.loads((Path(d) / "av_features.json").read_text(encoding="utf-8"))
        if isinstance(feat.get("a_refined"), (int, float)):
            info["a_callback"], info["a"] = info["a"], float(feat["a_refined"])
    except Exception:  # noqa: BLE001
        pass
    return info
