"""冥想 page: calibrate on yourself, then hear your state as weather; results card at the end.

Like the official Muse "Mind" session, but with every number explainable:
  busy index = log( (beta + gamma power) / (alpha + theta power) ) on blink-free data,
  standardized against your own 1-minute calibration. Calm -> quiet rain and birds; busy -> heavy rain.
Heart and body (stillness) feedback use heart rate or head movement in the same way.
"""

from __future__ import annotations

import csv
import json
import math
import os
from datetime import date, datetime, timedelta

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QPushButton, QSlider, QVBoxLayout, QWidget

from . import dsp
from . import theme as T
from .protocols import speak
from .session import save_meta
from .widgets import Card, Ring, StatTile, label, plot

DURATIONS = [("3 分钟", 180), ("5 分钟", 300), ("10 分钟", 600), ("15 分钟", 900), ("20 分钟", 1200), ("30 分钟", 1800)]
MODES = [("脑电平静度（α、θ 对 β）", "brain"), ("心率（越慢越好）", "heart"), ("身体静止（越稳越好）", "body"),
         ("呼吸引导（共振呼吸）", "breath")]
BREATH_RATES = [4.5, 5.0, 5.5, 6.0, 6.5, 7.0]       # breaths per minute; ~6 is the usual resonance rate
INHALE_SHARE = 0.4                                   # 4 s in, 6 s out at 6 per minute
CALIB_S = 60
STATE_COL = {"calm": "#34d399", "neutral": "#94a3b8", "active": "#f59e0b"}
STATE_TXT = {"calm": "平静", "neutral": "中性", "active": "活跃", "skip": "肌肉干扰，跳过"}


def busy_raw(hub, mode: str, analyzer):
    """Raw activity value for the chosen feedback (higher = busier), or None if no data."""
    if mode == "heart":
        return analyzer.hr if analyzer.hr == analyzer.hr else None
    if mode == "body":
        imu = hub.latest("ACCGYRO", 2.0)
        return dsp.motion_level(imu[:, 4:7]) if len(imu) > 40 else None
    eeg = hub.latest("EEG", 3.0)
    names = hub.names("EEG")
    if len(eeg) < dsp.FS_EEG * 2.5 or not all(n in names for n in dsp.EEG_NAMES):
        return None
    X = eeg[:, 1:][:, [names.index(n) for n in dsp.EEG_NAMES]]
    pk, _ = dsp.detect_blinks(X)
    keep = ~dsp.blink_mask(len(X), pk)
    good = [i for i, n in enumerate(dsp.EEG_NAMES) if analyzer.quality.get(n, (2, ""))[0] > 0] or [0, 3]
    # v0.10: the ear sensors first (forehead contact varies, and the forehead picks up eyes and frowning);
    # gamma left out (on this headband it is mostly muscle); moments with strong muscle noise are skipped
    ear = [i for i in (0, 3) if i in good]
    use = ear if ear else good
    x = dsp.notch_only(X)[-int(2 * dsp.FS_EEG):]
    k = keep[-int(2 * dsp.FS_EEG):]
    if k.mean() < 0.5:
        return None                                  # mostly blink: skip this moment
    _, absp, emg = dsp.band_powers(x[k][:, use])
    if float(np.mean(emg)) > 0.35:
        return None                                  # jaw / frown: not a brain state
    a = absp.mean(axis=0)                            # delta theta alpha beta gamma
    return float(math.log((a[3] + 1e-9) / (a[1] + a[2] + 1e-9)))


def meditation_history():
    """(streak days, minutes this week, last sessions [(date, calm%)]) from saved recordings."""
    from .session import list_sessions
    days, week_min, last = set(), 0.0, []
    monday = date.today() - timedelta(days=date.today().weekday())
    for d, meta in list_sessions():
        med = meta.get("meditation")
        if not med or meta.get("source") == "sim":
            continue
        from .people import mine
        if not mine(meta):
            continue
        try:
            day = datetime.fromisoformat(meta["started_at"]).date()
        except Exception:  # noqa: BLE001
            continue
        days.add(day)
        if day >= monday:
            week_min += med.get("duration", 0) / 60
        if med.get("calm_pct") is not None:
            last.append((day, med.get("calm_pct", 0)))
    streak, day = 0, date.today()
    if day not in days:
        day -= timedelta(days=1)
    while day in days:
        streak += 1
        day -= timedelta(days=1)
    return streak, week_min, sorted(last)[-7:]


class MeditatePage(QWidget):
    def __init__(self, hub, analyzer, record_page):
        super().__init__()
        self.hub, self.an, self.rp = hub, analyzer, record_page
        self.state = "idle"
        self.sound = None
        root = QHBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        # ---------------- settings
        left = Card("冥想")
        left.setFixedWidth(330)
        self.l_streak = label("", "muted", wrap=True)
        left.add(self.l_streak)
        left.add(label("时长", "muted"))
        self.cb_dur = QComboBox()
        for t, s in DURATIONS:
            self.cb_dur.addItem(t, s)
        self.cb_dur.setCurrentIndex(1)
        left.add(self.cb_dur)
        left.add(label("反馈什么", "muted"))
        self.cb_mode = QComboBox()
        for t, k in MODES:
            self.cb_mode.addItem(t, k)
        left.add(self.cb_mode)
        self.l_rate = label("每分钟呼吸次数", "muted")
        left.add(self.l_rate)
        self.cb_rate = QComboBox()
        for r in BREATH_RATES:
            self.cb_rate.addItem(f"{r:g} 次（吸 {60 / r * INHALE_SHARE:.1f} 秒，呼 {60 / r * (1 - INHALE_SHARE):.1f} 秒）", r)
        self.cb_rate.setCurrentIndex(BREATH_RATES.index(6.0))
        left.add(self.cb_rate)
        self.cb_mode.currentIndexChanged.connect(self._mode_changed)
        self._mode_changed()
        left.add(label("音量", "muted"))
        self.sl_vol = QSlider(Qt.Orientation.Horizontal)
        self.sl_vol.setRange(0, 100)
        self.sl_vol.setValue(80)
        self.sl_vol.valueChanged.connect(self._vol)
        left.add(self.sl_vol)
        self.chk_voice = QCheckBox("语音引导")
        self.chk_voice.setChecked(True)
        left.add(self.chk_voice)
        left.add(label("怎么听：雨越小、越安静，说明越平静；保持平静一会儿会有鸟叫。"
                       "先校准 1 分钟（让思绪自然游走），之后的平静、活跃都是和你自己这一分钟比。", "faint", wrap=True))
        left.lay.addStretch(1)
        self.b_start = QPushButton("开始")
        self.b_start.setObjectName("primary")
        self.b_start.clicked.connect(self.start)
        left.add(self.b_start)
        self.b_stop = QPushButton("提前结束")
        self.b_stop.setObjectName("danger")
        self.b_stop.clicked.connect(lambda: self.finish(early=True))
        self.b_stop.setVisible(False)
        left.add(self.b_stop)
        root.addWidget(left)

        # ---------------- session view
        mid = QVBoxLayout()
        mid.setSpacing(14)
        main = Card()
        self.l_phase = label("准备好后点「开始」，然后闭上眼睛", "h1")
        self.l_phase.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main.add(self.l_phase)
        self.ring = Ring(280)
        main.add(self.ring, 1)
        self.l_hint = label("", "muted", wrap=True)
        self.l_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main.add(self.l_hint)
        mid.addWidget(main, 3)
        tl = Card("过程", "绿=平静 灰=中性 橙=活跃")
        self.c_tl = tl
        self.p_tl = plot(bottom="分钟")
        self.p_tl.setYRange(-3, 3)
        self.curve = self.p_tl.plot(pen=pg.mkPen(T.ACCENT, width=2))
        self.guides = [pg.InfiniteLine(pos=-0.5, angle=0, pen=pg.mkPen(STATE_COL["calm"], style=Qt.PenStyle.DashLine)),
                       pg.InfiniteLine(pos=0.5, angle=0, pen=pg.mkPen(STATE_COL["active"], style=Qt.PenStyle.DashLine))]
        for g in self.guides:
            self.p_tl.addItem(g)
        self.p_tl.getPlotItem().getAxis("left").setTicks([[(-2, "平静"), (0, "中性"), (2, "活跃")]])
        tl.add(self.p_tl, 1)
        mid.addWidget(tl, 2)
        mw = QWidget()
        mw.setLayout(mid)
        root.addWidget(mw, 1)

        # ---------------- results
        right = QVBoxLayout()
        right.setSpacing(12)
        self.t_calm = StatTile("平静", "%", STATE_COL["calm"])
        self.t_neutral = StatTile("中性", "%", STATE_COL["neutral"])
        self.t_active = StatTile("活跃", "%", STATE_COL["active"])
        self.t_birds = StatTile("鸟叫", "次", "#7dd3fc")
        self.t_back = StatTile("回到平静", "次", T.ACCENT2)
        self.t_hr = StatTile("心率 开始→结束", "", "#fb7185")
        for t in (self.t_calm, self.t_neutral, self.t_active, self.t_birds, self.t_back, self.t_hr):
            right.addWidget(t)
        right.addStretch(1)
        rw = QWidget()
        rw.setLayout(right)
        rw.setFixedWidth(260)
        root.addWidget(rw)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(500)
        self._reset_tiles()
        self.refresh_history()

    # ------------------------------------------------------------------
    def _vol(self, v):
        if self.sound:
            self.sound.master = v / 100
            self.sound.set_level(self.sound.level)

    def _mode_changed(self, *_):
        breath = self.cb_mode.currentData() == "breath"
        self.l_rate.setVisible(breath)
        self.cb_rate.setVisible(breath)
        if hasattr(self, "t_calm") and self.state in ("idle", "done"):
            self._reset_tiles()

    def _say(self, text):
        if self.chk_voice.isChecked():
            speak(text)

    def _reset_tiles(self):
        breath = self.cb_mode.currentData() == "breath"
        caps = (("心率随呼吸起伏", "同步度", "心率变异", "呼吸", "回到平静", "心率") if breath else
                ("平静", "中性", "活跃", "鸟叫", "回到平静", "心率 开始→结束"))
        units = (("次/分", "%", "ms", "次", "", "次/分") if breath else ("%", "%", "%", "次", "次", ""))
        for t, c, u in zip((self.t_calm, self.t_neutral, self.t_active, self.t_birds, self.t_back, self.t_hr), caps, units):
            t.cap.setText(c)
            t.unit.setText(u)
            t.set("—", "")
        self.t_back.setVisible(not breath)
        for g in self.guides:
            g.setVisible(not breath)
        self.c_tl.sub_label.setText("心率（次/分）" if breath else "绿=平静 灰=中性 橙=活跃")
        ax = self.p_tl.getPlotItem().getAxis("left")
        if breath:
            ax.setTicks(None)
            self.p_tl.enableAutoRange(axis="y")
        else:
            ax.setTicks([[(-2, "平静"), (0, "中性"), (2, "活跃")]])
            self.p_tl.setYRange(-3, 3)

    def refresh_history(self):
        streak, week, last = meditation_history()
        txt = f"连续 {streak} 天 · 本周 {week:.0f} 分钟"
        if last:
            txt += "\n最近几次平静占比：" + "、".join(f"{d.month}/{d.day} {p:.0f}%" for d, p in last[-5:])
        self.l_streak.setText(txt)

    # ------------------------------------------------------------------ flow
    def start(self):
        if self.state not in ("idle", "done"):
            return
        if not self.hub.is_live():
            self.l_hint.setText("还没有数据：先连接头环（或右上角「···」打开演示模式）。")
            return
        if self.rp.rec is not None:
            self.l_hint.setText("正在录制别的内容，先停止那边的录制。")
            return
        bad = [n for n, (lv, _) in self.an.quality.items() if lv == 0]
        if len(bad) >= 2 and self.cb_mode.currentData() == "brain":
            self.l_hint.setText("有两个以上电极没贴好（看「实时」页的电极图），先调整好再开始。")
            return
        self.mode = self.cb_mode.currentData()
        self.total = self.cb_dur.currentData()
        self.calib_s = CALIB_S
        if os.environ.get("NB_MED_FAST"):          # automated tests only
            self.calib_s, self.total = 15, 40
        if not self.rp.start_free(f"冥想 {datetime.now():%m-%d %H%M}", mode="冥想"):
            self.l_hint.setText("无法开始录制。")
            return
        self.rec = self.rp.rec
        from .sounds import Soundscape
        self.sound = Soundscape()
        self.sound.master = 0.0 if os.environ.get("NB_MUTE") else self.sl_vol.value() / 100
        if self.mode == "breath":
            self.timer.setInterval(100)              # smooth pacer animation
            self.rate = self.cb_rate.currentData()
            self.rec.add_marker("呼吸引导", "segment")
            self.rows, self.inhaling, self.breaths = [], None, 0
            self.hr_start = self.an.hr
            self.t_phase0 = self.hub.now()
            self.state = "session"
            self.b_start.setVisible(False)
            self.b_stop.setVisible(True)
            for w in (self.cb_dur, self.cb_mode, self.cb_rate):
                w.setEnabled(False)
            self._reset_tiles()
            self.curve.setData([], [])
            self.sound.start()
            self.sound.set_level(0.0)
            self.l_phase.setText(f"呼吸引导 · 每分钟 {self.rate:g} 次")
            self.l_hint.setText("跟着光圈：变大时用鼻子慢慢吸气，变小时缓缓呼气。不用憋气，舒服就好。")
            self._say(f"开始呼吸引导，每分钟{self.rate:g}次。跟着提示音，吸气，呼气。")
            return
        self.rec.add_marker("校准", "segment")
        self.calib, self.rows = [], []
        self.z = 0.0
        self.calm_run, self.birds, self.backs, self.was_active = 0.0, 0, 0, False
        self.hr_start = self.an.hr
        self.t_phase0 = self.hub.now()
        self.state = "calibrate"
        self.b_start.setVisible(False)
        self.b_stop.setVisible(True)
        for w in (self.cb_dur, self.cb_mode):
            w.setEnabled(False)
        self._reset_tiles()
        self.curve.setData([], [])
        self.l_phase.setText("校准中：闭上眼睛，让思绪自然游走")
        self.l_hint.setText("这一分钟不用刻意做什么，程序在认识你平时的样子。")
        self._say("开始校准。请闭上眼睛，让思绪自然游走，一分钟。")

    def tick(self):
        if self.state not in ("calibrate", "session"):
            return
        if self.rp.rec is None:                        # recording stopped elsewhere (disconnect, battery)
            self.finish(early=True)
            return
        now = self.hub.now()
        el = now - self.t_phase0
        if self.mode == "breath":
            self._tick_breath(el)
            return
        v = busy_raw(self.hub, self.mode, self.an)
        if self.state == "calibrate":
            if v is not None:
                self.calib.append(v)
            self.ring.set(el / self.calib_s, f"{max(0, self.calib_s - el):.0f}", "校准（秒）", T.ACCENT2)
            if el >= self.calib_s:
                if len(self.calib) < min(20, self.calib_s):
                    self.l_hint.setText("校准时有效数据太少（电极没贴好或一直在动），再校准一分钟。")
                    self.t_phase0, self.calib = now, []
                    return
                self.mu = float(np.median(self.calib))
                self.sd = max(float(np.std(self.calib)), {"brain": 0.15, "heart": 2.0, "body": 0.5}[self.mode])
                self.state = "session"
                self.t_phase0 = now
                self.rec.add_marker("冥想", "segment")
                self.hr_start = self.an.hr
                self.sound.start()
                self.sound.ring()
                self.l_phase.setText("冥想中")
                self.l_hint.setText("听雨声：雨小了、有鸟叫，说明你静下来了。走神了就轻轻回到呼吸上。")
                self._say("校准完成，开始冥想。")
            return
        # session
        if v is not None:
            zz = (v - self.mu) / self.sd
            self.z = 0.7 * self.z + 0.3 * zz
            st = "calm" if self.z < -0.5 else ("active" if self.z > 0.5 else "neutral")
            busy = 1 / (1 + math.exp(-1.5 * self.z))
            self.sound.set_level(busy)
        else:
            st = "skip"                      # jaw / frown / blink: no reading -> not counted, no reward
        if st == "skip":
            pass
        elif st == "calm":
            self.calm_run += 0.5
            if self.was_active:
                self.backs += 1
                self.was_active = False
            if self.calm_run >= 8:
                self.sound.chirp()
                self.birds += 1
                self.calm_run = 0
        else:
            self.calm_run = 0
            if st == "active":
                self.was_active = True
        self.rows.append({"t": round(el, 1), "z": round(self.z, 3), "state": st, "raw": v,
                          "hr": self.an.hr, "motion": self.an.motion})
        n = max(1, sum(1 for r in self.rows if r["state"] in STATE_COL))
        cnt = {k: sum(1 for r in self.rows if r["state"] == k) / n * 100 for k in STATE_COL}
        self.t_calm.set(f"{cnt['calm']:.0f}", "")
        self.t_neutral.set(f"{cnt['neutral']:.0f}", "")
        self.t_active.set(f"{cnt['active']:.0f}", "")
        self.t_birds.set(str(self.birds), "")
        self.t_back.set(str(self.backs), "走神后又静下来")
        self.ring.set(el / self.total, f"{int(self.total - el) // 60:02d}:{int(self.total - el) % 60:02d}",
                      STATE_TXT[st], STATE_COL.get(st, "#64748b"))
        if n % 2 == 0:
            tt = np.array([r["t"] for r in self.rows]) / 60
            self.curve.setData(tt, np.clip([r["z"] for r in self.rows], -3, 3))
        if el >= self.total:
            self.finish()

    # ------------------------------------------------------------------ breathing pacer
    def _tick_breath(self, el):
        period = 60.0 / self.rate
        ph = (el % period) / period
        inh = ph < INHALE_SHARE
        if inh != self.inhaling:
            self.sound.breath(inh)
            if inh:
                self.breaths += 1
            self.inhaling = inh
        frac = ph / INHALE_SHARE if inh else 1 - (ph - INHALE_SHARE) / (1 - INHALE_SHARE)
        left = max(0, self.total - el)
        self.ring.set(frac, "吸气" if inh else "呼气", f"剩余 {int(left) // 60:02d}:{int(left) % 60:02d}",
                      T.ACCENT if inh else T.ACCENT2)
        if not self.rows or el - self.rows[-1]["t"] >= 1.0:
            self.rows.append({"t": round(el, 1), "z": "", "state": "inhale" if inh else "exhale", "raw": "",
                              "hr": self.an.hr, "motion": self.an.motion})
            hrs = [(r["t"] / 60, r["hr"]) for r in self.rows if r["hr"] == r["hr"]]
            if hrs:
                self.curve.setData([h[0] for h in hrs], [h[1] for h in hrs])
            self.t_hr.set(f"{self.an.hr:.0f}" if self.an.hr == self.an.hr else "—", "当前心率")
            self.t_birds.set(str(self.breaths), "")
        if el >= self.total:
            self.finish()

    def _finish_breath(self, early, rec):
        if rec is not None:
            self.rp.stop()
        d = self.rec.dir
        res = {}
        try:
            from .session import load_session
            s = load_session(d)
            seg = next((g for g in s.segments if g.label == "呼吸引导"), None)
            if seg and "OPTICS" in s.data:
                t, O, names = s.data["OPTICS"]
                m = (t >= seg.t0) & (t < seg.t1)
                res = dsp.breath_heart_coupling(O[m], names, t[m], self.rate)
        except Exception:  # noqa: BLE001
            res = {}
        dur = self.rows[-1]["t"] if self.rows else 0
        summary = {"mode": "breath", "rate": self.rate, "duration": round(dur, 1), "planned": self.total,
                   "breaths": self.breaths, "early": early,
                   "hr_swing": res.get("swing"), "sync": res.get("sync"), "rmssd": res.get("rmssd"),
                   "hr_start": None if self.hr_start != self.hr_start else round(self.hr_start, 1),
                   "hr_end": None if self.an.hr != self.an.hr else round(self.an.hr, 1)}
        try:
            with open(d / "meditation.csv", "w", encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=["t", "z", "state", "raw", "hr", "motion"])
                w.writeheader()
                w.writerows(self.rows)
            p = d / "session.json"
            meta = json.loads(p.read_text(encoding="utf-8"))
            meta["meditation"] = summary
            save_meta(p.parent, meta)
        except Exception:  # noqa: BLE001
            pass
        ok = lambda v: isinstance(v, (int, float)) and v == v  # noqa: E731
        self.t_calm.cap.setText("心率随呼吸起伏")
        self.t_calm.set(f"{summary['hr_swing']:.1f}" if ok(summary["hr_swing"]) else "—", "次/分（越大越好）")
        self.t_neutral.cap.setText("同步度")
        self.t_neutral.set(f"{summary['sync'] * 100:.0f}" if ok(summary["sync"]) else "—", "心率跟着呼吸走的程度")
        self.t_active.cap.setText("心率变异")
        self.t_active.set(f"{summary['rmssd']:.0f}" if ok(summary["rmssd"]) else "—", "ms")
        self.t_birds.cap.setText("呼吸")
        self.t_back.set("—", "")
        hs, he = summary["hr_start"], summary["hr_end"]
        self.t_hr.set(f"{hs or '—'}→{he or '—'}", "次/分")
        self.l_phase.setText("完成")
        self.l_hint.setText("心率随呼吸起伏越大、同步度越高，说明这个呼吸节奏越接近你的共振频率。"
                            "可以换不同的次数各练几次，在「趋势」里比较。" if ok(summary["hr_swing"]) else
                            "脉搏数据不够，算不出心率起伏（省电模式没有心率）。")
        self.ring.set(1.0, f"{summary['sync'] * 100:.0f}%" if ok(summary["sync"]) else "完成", "同步度", T.ACCENT)
        self._say("呼吸练习结束。")
        self.b_start.setVisible(True)
        self.b_start.setText("再来一次")
        self.b_stop.setVisible(False)
        for w in (self.cb_dur, self.cb_mode, self.cb_rate):
            w.setEnabled(True)
        self.refresh_history()

    def finish(self, early=False):
        if self.state not in ("calibrate", "session"):
            return
        was_session = self.state == "session"
        self.state = "done"
        if self.sound:
            self.sound.ring()
            self.sound.stop()
        self._say("冥想结束。" if not early else "冥想结束。")
        rec = self.rp.rec
        summary = None
        if self.mode == "breath":
            self.timer.setInterval(500)
            self._finish_breath(early, rec)
            return
        if was_session and self.rows:
            n = max(1, sum(1 for r in self.rows if r["state"] in STATE_COL))
            pct = {k: sum(1 for r in self.rows if r["state"] == k) / n * 100 for k in STATE_COL}
            summary = {"mode": self.mode, "duration": round(self.rows[-1]["t"], 1), "planned": self.total,
                       "calm_pct": round(pct["calm"], 1), "neutral_pct": round(pct["neutral"], 1),
                       "active_pct": round(pct["active"], 1), "birds": self.birds, "recoveries": self.backs,
                       "calibration": {"median": self.mu, "sd": self.sd, "n": len(self.calib)},
                       "hr_start": None if self.hr_start != self.hr_start else round(self.hr_start, 1),
                       "hr_end": None if self.an.hr != self.an.hr else round(self.an.hr, 1), "early": early}
            hs, he = summary["hr_start"], summary["hr_end"]
            self.t_hr.set(f"{hs or '—'}→{he or '—'}", "次/分")
        if rec is not None:
            self.rp.stop()
        # write the results into the session folder (also when the recording was stopped by a disconnect)
        d = getattr(self, "rec", None) and self.rec.dir
        if d and summary:
            with open(d / "meditation.csv", "w", encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=["t", "z", "state", "raw", "hr", "motion"])
                w.writeheader()
                w.writerows(self.rows)
            p = d / "session.json"
            try:
                meta = json.loads(p.read_text(encoding="utf-8"))
                meta["meditation"] = summary
                save_meta(p.parent, meta)
            except Exception:  # noqa: BLE001
                pass
        self.b_start.setVisible(True)
        self.b_start.setText("再来一次")
        self.b_stop.setVisible(False)
        for w in (self.cb_dur, self.cb_mode):
            w.setEnabled(True)
        if summary:
            self.l_phase.setText("完成")
            self.l_hint.setText(f"平静 {summary['calm_pct']:.0f}% · 鸟叫 {self.birds} 次 · 回到平静 {self.backs} 次。"
                                "结果已保存，在「回看」「趋势」里也能看到。")
            self.ring.set(1.0, f"{summary['calm_pct']:.0f}%", "平静", STATE_COL["calm"])
        else:
            self.l_phase.setText("已结束")
            self.l_hint.setText("校准还没完成就结束了，这次不计成绩。")
        self.refresh_history()
