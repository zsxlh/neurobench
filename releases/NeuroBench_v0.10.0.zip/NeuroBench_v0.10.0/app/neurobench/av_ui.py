"""Widgets for video/audio: the device dialog (with preview) and the synced player on the 回看 page."""

from __future__ import annotations

from PyQt6.QtCore import Qt, QUrl, pyqtSignal
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QDialog, QGridLayout, QHBoxLayout, QPushButton, QSlider,
                             QVBoxLayout, QWidget)

from . import av as AV
from .widgets import label


class AVDialog(QDialog):
    """Choose whether to record video / audio and which camera / microphone; live preview of the camera."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("录像和录音")
        self.setMinimumWidth(560)
        st = AV.settings()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 20)
        lay.setSpacing(10)
        lay.addWidget(label("录制脑电时同时录像 / 录音", "h2"))
        lay.addWidget(label(
            "视频和声音存进这次录制的文件夹（video.mp4 或 audio.m4a），和脑电对齐，在「回看」里可以边看视频边看脑电。"
            "默认关闭；录制时 Windows 会亮起摄像头灯。录像约 10–30 MB/分钟，只录音约 0.5 MB/分钟。"
            "桌面打包和云端上传默认不带音视频。过夜睡眠只录音、不录像。", "muted", wrap=True))
        self.c_video = QCheckBox("录像（摄像头，含声音）")
        self.c_video.setChecked(st["video"])
        self.c_audio = QCheckBox("录音（麦克风）")
        self.c_audio.setChecked(st["audio"])
        lay.addWidget(self.c_video)
        lay.addWidget(self.c_audio)
        grid = QGridLayout()
        grid.addWidget(label("摄像头", ""), 0, 0)
        self.cb_cam = QComboBox()
        grid.addWidget(self.cb_cam, 0, 1)
        grid.addWidget(label("麦克风", ""), 1, 0)
        self.cb_mic = QComboBox()
        grid.addWidget(self.cb_mic, 1, 1)
        lay.addLayout(grid)
        self.preview = None
        self._cam = self._session = None
        try:
            cams, mics = AV.devices()
        except Exception:  # noqa: BLE001
            cams, mics = [], []
        for i, n in cams:
            self.cb_cam.addItem(n, i)
        for i, n in mics:
            self.cb_mic.addItem(n, i)
        for cb, want in ((self.cb_cam, st["camera"]), (self.cb_mic, st["mic"])):
            k = cb.findData(want)
            if k >= 0:
                cb.setCurrentIndex(k)
        if not cams:
            self.c_video.setEnabled(False)
            self.c_video.setChecked(False)
            self.cb_cam.addItem("（没有找到摄像头）", "")
        if not mics:
            self.c_audio.setEnabled(False)
            self.c_audio.setChecked(False)
            self.cb_mic.addItem("（没有找到麦克风）", "")
        if cams:
            b = QPushButton("预览摄像头")
            b.setObjectName("ghost")
            b.clicked.connect(self._preview)
            lay.addWidget(b)
            self.v_holder = QVBoxLayout()
            lay.addLayout(self.v_holder)
        self.l_msg = label("", "faint", wrap=True)
        lay.addWidget(self.l_msg)
        btns = QHBoxLayout()
        btns.addStretch(1)
        cancel = QPushButton("取消")
        cancel.setObjectName("ghost")
        cancel.clicked.connect(self.reject)
        ok = QPushButton("保存")
        ok.setObjectName("primary")
        ok.clicked.connect(self._save)
        btns.addWidget(cancel)
        btns.addWidget(ok)
        lay.addLayout(btns)

    def _preview(self):
        try:
            from PyQt6.QtMultimedia import QCamera, QMediaCaptureSession, QMediaDevices
            from PyQt6.QtMultimediaWidgets import QVideoWidget
            if self.preview is None:
                self.preview = QVideoWidget()
                self.preview.setMinimumHeight(260)
                self.v_holder.addWidget(self.preview)
            if self._cam is not None:
                self._cam.stop()
            dev = AV._pick(QMediaDevices.videoInputs(), self.cb_cam.currentData() or "", QMediaDevices.defaultVideoInput())
            self._cam = QCamera(dev)
            self._session = QMediaCaptureSession()
            self._session.setCamera(self._cam)
            self._session.setVideoOutput(self.preview)
            self._cam.start()
        except Exception as e:  # noqa: BLE001
            self.l_msg.setText(f"预览失败：{e}")

    def _stop_preview(self):
        if self._cam is not None:
            try:
                self._cam.stop()
            except Exception:  # noqa: BLE001
                pass
        self._cam = self._session = None

    def _save(self):
        AV.save_settings(video=self.c_video.isChecked(), audio=self.c_audio.isChecked(),
                         camera=self.cb_cam.currentData() or "", mic=self.cb_mic.currentData() or "")
        self._stop_preview()
        self.accept()

    def reject(self):
        self._stop_preview()
        super().reject()


class AVPanel(QWidget):
    """Player for a session's video/audio. Emits `moved(t_eeg_s)` while playing or after a seek."""

    moved = pyqtSignal(float)

    def __init__(self):
        super().__init__()
        self.info = None
        self.player = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.video_box = QVBoxLayout()
        lay.addLayout(self.video_box)
        row = QHBoxLayout()
        self.b_play = QPushButton("播放")
        self.b_play.setFixedWidth(80)
        self.b_play.clicked.connect(self.toggle)
        row.addWidget(self.b_play)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.sliderMoved.connect(self._slid)
        row.addWidget(self.slider, 1)
        self.l_time = label("", "faint")
        row.addWidget(self.l_time)
        lay.addLayout(row)
        self.vw = None

    def load(self, info: dict | None):
        self.stop()
        self.info = info
        if not info:
            if self.player is not None:
                self.player.setSource(QUrl())          # release the file (Windows keeps it locked otherwise)
            self.setVisible(False)
            return
        from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer
        if self.player is None:
            self.player = QMediaPlayer(self)
            self.audio_out = QAudioOutput(self)
            self.player.setAudioOutput(self.audio_out)
            self.player.positionChanged.connect(self._pos)
            self.player.durationChanged.connect(lambda d: self.slider.setRange(0, int(d)))
        if info.get("video"):
            if self.vw is None:
                from PyQt6.QtMultimediaWidgets import QVideoWidget
                self.vw = QVideoWidget()
                self.vw.setMinimumHeight(180)
                self.video_box.addWidget(self.vw)
            self.player.setVideoOutput(self.vw)
            self.vw.setVisible(True)
        elif self.vw is not None:
            self.vw.setVisible(False)
        self.player.setSource(QUrl.fromLocalFile(info["path"]))
        self.setVisible(True)

    def media_to_eeg(self, t_media: float) -> float:
        return self.info["a"] + self.info["b"] * t_media

    def eeg_to_media(self, t_eeg: float) -> float:
        return (t_eeg - self.info["a"]) / self.info["b"]

    def seek_eeg(self, t_eeg: float):
        if self.player is None or not self.info:
            return
        self.player.setPosition(max(0, int(self.eeg_to_media(t_eeg) * 1000)))

    def toggle(self):
        if self.player is None:
            return
        from PyQt6.QtMultimedia import QMediaPlayer
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
            self.b_play.setText("播放")
        else:
            self.player.play()
            self.b_play.setText("暂停")

    def stop(self):
        if self.player is not None:
            self.player.stop()
            self.b_play.setText("播放")

    def _slid(self, ms):
        if self.player is not None:
            self.player.setPosition(ms)

    def _pos(self, ms):
        self.slider.blockSignals(True)
        self.slider.setValue(int(ms))
        self.slider.blockSignals(False)
        if self.info:
            te = self.media_to_eeg(ms / 1000.0)
            self.l_time.setText(f"{int(te) // 60:02d}:{int(te) % 60:02d}")
            self.moved.emit(te)
