"""「云端上传设置」: paste the GitHub token once; recordings then upload themselves to the private repo."""

from __future__ import annotations

import re
import threading
import webbrowser

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtWidgets import QCheckBox, QDialog, QGridLayout, QHBoxLayout, QLineEdit, QPushButton, QVBoxLayout

from . import cloud as C
from .widgets import label


class _Relay(QObject):
    done = pyqtSignal(str)


class CloudDialog(QDialog):
    def __init__(self, parent=None, uploader=None):
        super().__init__(parent)
        self.uploader = uploader
        self.setWindowTitle("云端上传设置")
        self.setMinimumWidth(600)
        cfg = C.load_config()
        has_token = bool(C.load_token())
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 20)
        lay.setSpacing(12)
        lay.addWidget(label("录完自动上传到你自己的私有 GitHub 仓库", "h2"))
        lay.addWidget(label(
            "每次录制保存后，这台电脑会把它打成一个 .zip，上传到下面这个私有仓库；Claude 在实验室那台电脑上直接读取，"
            "不用再手动拷文件。仓库必须是私有的，否则程序拒绝上传。令牌只存在这台电脑的 Windows 凭据管理器里。"
            "演示、回放、从别处导入的录制不会上传。", "muted", wrap=True))

        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(8)
        grid.addWidget(label("私有仓库", ""), 0, 0)
        self.e_repo = QLineEdit(cfg.get("repo", C.DEFAULT_REPO))
        grid.addWidget(self.e_repo, 0, 1, 1, 2)

        grid.addWidget(label("访问令牌", ""), 1, 0)
        self.e_token = QLineEdit()
        self.e_token.setEchoMode(QLineEdit.EchoMode.Password)
        self.e_token.setPlaceholderText("已保存（要换就粘贴新的）" if has_token else "粘贴 github_pat_ 开头的令牌")
        grid.addWidget(self.e_token, 1, 1)
        b_page = QPushButton("去 GitHub 生成…")
        b_page.setObjectName("ghost")
        b_page.clicked.connect(lambda: webbrowser.open(C.TOKEN_PAGE))
        grid.addWidget(b_page, 1, 2)

        # v0.10: each recording carries its wearer (top bar 「佩戴者」); the old per-computer code is kept hidden
        self.e_person = QLineEdit(cfg.get("person", "me"))
        self.e_person.setVisible(False)
        grid.addWidget(label("按人分开", ""), 2, 0)
        grid.addWidget(label("每条录制按录制时顶栏「佩戴者」分开存放（别人的数据要先征得本人同意）；"
                             "旧版本录的算作「我」。", "faint", wrap=True), 2, 1, 1, 2)
        lay.addLayout(grid)

        self.c_auto = QCheckBox("录完自动上传（失败会自动重试，录制中不上传）")
        self.c_auto.setChecked(bool(cfg.get("auto", True)))
        lay.addWidget(self.c_auto)
        self.c_media = QCheckBox("同时上传录像/录音（文件大，默认不传；单个录制打包后超过 1.9 GB 会被跳过）")
        self.c_media.setChecked(bool(cfg.get("upload_media", False)))
        lay.addWidget(self.c_media)

        lay.addWidget(label(
            "生成令牌：点「去 GitHub 生成…」→ Token name 填 NeuroBench → Expiration 选 1 年 → Repository access 选 "
            "Only select repositories 并只勾 neurobench-data → Permissions 里 Contents 选 Read and write → Generate token，"
            "复制后粘贴到上面。", "faint", wrap=True))

        self.l_result = label("", "muted", wrap=True)
        lay.addWidget(self.l_result)

        btns = QHBoxLayout()
        b_del = QPushButton("删除已存令牌")
        b_del.setObjectName("ghost")
        b_del.setEnabled(has_token)
        b_del.clicked.connect(self._delete)
        btns.addWidget(b_del)
        btns.addStretch(1)
        self.b_test = QPushButton("测试连接")
        self.b_test.setObjectName("ghost")
        self.b_test.clicked.connect(self._test)
        btns.addWidget(self.b_test)
        self._relay = _Relay()
        self._relay.done.connect(self._tested)
        b_cancel = QPushButton("取消")
        b_cancel.setObjectName("ghost")
        b_cancel.clicked.connect(self.reject)
        btns.addWidget(b_cancel)
        b_ok = QPushButton("保存")
        b_ok.setObjectName("primary")
        b_ok.clicked.connect(self._save)
        btns.addWidget(b_ok)
        lay.addLayout(btns)

    def _values(self):
        repo = self.e_repo.text().strip()
        person = self.e_person.text().strip().lower()
        token = self.e_token.text().strip()
        if not C.valid_repo(repo):
            return None, "仓库名格式应为「用户名/仓库名」，比如 zsxlh/neurobench-data"
        if not C.valid_person(person):
            return None, "代号只能用小写字母、数字、- 或 _，最多 20 个字符"
        if token and not re.fullmatch(r"(github_pat_|ghp_)[A-Za-z0-9_]{20,250}", token):
            return None, "这看起来不像 GitHub 令牌（应以 github_pat_ 开头，只含字母、数字和下划线）"
        return (repo, person, token), ""

    def _test(self):
        vals, err = self._values()
        if err:
            self.l_result.setText(err)
            return
        repo, _, token = vals
        token = token or C.load_token()
        if not token:
            self.l_result.setText("还没有令牌：先粘贴一个。")
            return
        self.l_result.setText("正在测试…（只读，不上传任何东西）")
        self.b_test.setEnabled(False)
        # network check off the GUI thread: the window (and a running recording) must not freeze
        threading.Thread(target=lambda: self._relay.done.emit(C.test_connection(repo, token)), daemon=True).start()

    def _tested(self, text: str):
        self.b_test.setEnabled(True)
        self.l_result.setText(text)

    def _delete(self):
        C.delete_token()
        self.e_token.setPlaceholderText("粘贴 github_pat_ 开头的令牌")
        self.l_result.setText("令牌已从这台电脑删除，不会再上传。")

    def _save(self):
        vals, err = self._values()
        if err:
            self.l_result.setText(err)
            return
        repo, person, token = vals
        try:
            if token:
                C.save_token(token)
            C.save_config({"repo": repo, "person": person, "auto": self.c_auto.isChecked(),
                           "upload_media": self.c_media.isChecked()})
        except Exception as e:  # noqa: BLE001
            self.l_result.setText(f"保存失败：{e}")
            return
        if self.uploader is not None:
            self.uploader.kick()
        self.accept()
