"""What a switch does when it flips (v0.10): press a key, a media key, or call a web address.

Keys go through the Windows keybd_event API (they reach whichever window has focus, e.g. a slideshow or a
music player). Web addresses are fetched with a plain GET in a background thread, so a smart plug or a home
automation hook can be switched; only http/https is allowed.
"""

from __future__ import annotations

import sys
import threading
import urllib.parse
import urllib.request

from PyQt6.QtCore import QSettings

ACTIONS = [("none", "不接任何动作"), ("key", "按一个键"), ("playpause", "播放 / 暂停（媒体键）"),
           ("next", "下一首（媒体键）"), ("url", "打开网址（开 / 关各一个）")]

VK = {"space": 0x20, "enter": 0x0D, "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28, "pageup": 0x21,
      "pagedown": 0x22, "esc": 0x1B, "tab": 0x09, "backspace": 0x08, "home": 0x24, "end": 0x23,
      **{f"f{i}": 0x6F + i for i in range(1, 13)},
      **{chr(c): c - 32 for c in range(ord("a"), ord("z") + 1)}, **{str(i): 0x30 + i for i in range(10)}}
VK_PLAY_PAUSE, VK_NEXT = 0xB3, 0xB0
KEYEVENTF_KEYUP = 0x0002


def settings() -> dict:
    s = QSettings("NeuroBench", "NeuroBench")
    return {"action": s.value("switch/action", "none", type=str), "key": s.value("switch/key", "space", type=str),
            "url_on": s.value("switch/url_on", "", type=str), "url_off": s.value("switch/url_off", "", type=str)}


def save(**kw):
    s = QSettings("NeuroBench", "NeuroBench")
    for k, v in kw.items():
        s.setValue(f"switch/{k}", v)


def _press(vk: int):
    if sys.platform != "win32":
        return
    import ctypes
    u = ctypes.windll.user32
    u.keybd_event(vk, 0, 0, 0)
    u.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


def valid_url(url: str) -> bool:
    try:
        p = urllib.parse.urlparse(url.strip())
    except ValueError:
        return False
    return p.scheme in ("http", "https") and bool(p.netloc)


def _get(url: str, log):
    def run():
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "NeuroBench"}), timeout=5) as r:
                log(f"网址返回 {r.status}")
        except Exception as e:  # noqa: BLE001
            log(f"网址没打开：{type(e).__name__}")
    threading.Thread(target=run, daemon=True).start()


def fire(on: bool, log=lambda _m: None) -> str:
    """Run the configured action for a switch flip. Returns a short description of what happened."""
    st = settings()
    a = st["action"]
    if a == "key":
        vk = VK.get(st["key"].strip().lower())
        if vk is None:
            return f"不认识的键名「{st['key']}」"
        try:
            from PyQt6.QtWidgets import QApplication
            if QApplication.activeWindow() is not None:
                return "NeuroBench 自己在最前面，没发按键（先切到要控制的窗口）"
        except Exception:  # noqa: BLE001
            pass
        _press(vk)
        return f"按了 {st['key']}"
    if a == "playpause":
        _press(VK_PLAY_PAUSE)
        return "播放/暂停"
    if a == "next":
        _press(VK_NEXT)
        return "下一首"
    if a == "url":
        url = st["url_on"] if on else st["url_off"]
        if url and valid_url(url):
            _get(url.strip(), log)
            return "打开网址"
        return "没设置网址" if not url else "网址格式不对（要以 http:// 或 https:// 开头）"
    return ""
