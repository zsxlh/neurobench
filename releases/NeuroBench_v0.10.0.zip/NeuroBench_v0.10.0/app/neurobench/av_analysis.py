"""Video / audio analysis (v0.10), all with the Qt Multimedia that ships with PyQt6 (no ffmpeg needed).

* Audio: decoded to 16 kHz mono and processed as it streams in (memory stays small even for a whole night):
  loudness every 0.1 s and talking spans (loud + voice band dominant + not the sync chime). Raw audio is only
  kept for 3 s around each expected sync chime.
* Sync refinement: the start / end chimes (880 Hz) are found in the audio track; their onsets give a measured
  offset that replaces the duration-callback estimate when it agrees within 0.5 s.
* Video: frames are pulled at 8x speed, shrunk to 64 x 36 grey, and the mean absolute change between frames
  gives the amount of movement in the picture.
* Nothing is saved unless every part ran to the end (closing the window or a timeout leaves no half result).
Results go to <session>/av_features.json on the EEG clock (seconds since the recording started).
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PyQt6.QtCore import QEventLoop, QObject, QTimer, QUrl

from . import av as AV

FEATURES = "av_features.json"
SR = 16000
HOP = 1600         # 0.1 s
WIN = 3200         # 0.2 s


class Incomplete(RuntimeError):
    pass


class _AudioStream:
    """Per-frame loudness / voice / chime-tone features, computed as buffers arrive."""

    def __init__(self, cue_media_times):
        self.buf = np.zeros(0, np.float32)
        self.pos = 0                       # sample index of buf[0]
        self.db, self.voice, self.tone = [], [], []
        self.cues = [(t - 1.5, t + 1.5) for t in cue_media_times]
        self.cue_audio = {i: [] for i in range(len(self.cues))}
        w = np.hanning(WIN).astype(np.float32)
        self.w = w
        f = np.fft.rfftfreq(WIN, 1 / SR)
        self.m_voice = (f >= 250) & (f <= 3400)
        self.m_tone = (f >= 850) & (f <= 910)
        self.m_ref = (f >= 300) & (f <= 4000)

    def feed(self, start_s: float, x: np.ndarray):
        i0 = int(round(start_s * SR))
        expect = self.pos + len(self.buf)
        if i0 > expect:                                     # a hole in the stream: pad with silence
            x = np.concatenate([np.zeros(i0 - expect, np.float32), x])
        elif i0 < expect:
            x = x[expect - i0:]
        for k, (a, b) in enumerate(self.cues):              # keep raw audio only around the chimes
            s0 = expect / SR
            s1 = (expect + len(x)) / SR
            if s1 > a and s0 < b:
                self.cue_audio[k].append((s0, x.copy()))
        self.buf = np.concatenate([self.buf, x])
        n = (len(self.buf) - WIN) // HOP + 1
        if n <= 0:
            return
        idx = np.arange(n)[:, None] * HOP + np.arange(WIN)[None, :]
        F = np.abs(np.fft.rfft(self.buf[idx] * self.w, axis=1)) ** 2
        tot = F.sum(axis=1) + 1e-12
        self.db += (10 * np.log10(tot)).tolist()
        self.voice += (F[:, self.m_voice].sum(axis=1) / tot).tolist()
        self.tone += (F[:, self.m_tone].sum(axis=1) / (F[:, self.m_ref].sum(axis=1) + 1e-12)).tolist()
        cut = n * HOP
        self.buf = self.buf[cut:]
        self.pos += cut

    def result(self):
        if len(self.db) < 10:
            return None
        db, voice, tone = np.array(self.db), np.array(self.voice), np.array(self.tone)
        t = (np.arange(len(db)) * HOP + WIN / 2) / SR
        floor = float(np.percentile(db, 20))
        talk = (db > floor + 12) & (voice > 0.6) & (tone < 0.5)     # the sync chimes are not talking
        talk = _min_run(_bridge(talk, 4), 3)
        return {"t": t.tolist(), "db": db.tolist(), "talk": talk.astype(int).tolist(), "floor_db": floor}

    def chime_onsets(self):
        """Onset (media seconds) of the 880 Hz chime inside each cue window, at 10 ms resolution."""
        out = {}
        h = SR // 100
        for k, parts in self.cue_audio.items():
            if not parts:
                continue
            s0 = parts[0][0]
            x = np.concatenate([p for _, p in parts])
            if len(x) < 8 * h:
                continue
            n = (len(x) - 4 * h) // h + 1
            idx = np.arange(n)[:, None] * h + np.arange(4 * h)[None, :]
            F = np.abs(np.fft.rfft(x[idx] * np.hanning(4 * h), axis=1)) ** 2
            f = np.fft.rfftfreq(4 * h, 1 / SR)
            r = F[:, (f >= 850) & (f <= 910)].sum(axis=1) / (F[:, (f >= 300) & (f <= 4000)].sum(axis=1) + 1e-12)
            on = np.flatnonzero(r > max(0.3, 0.5 * r.max()))
            if len(on) and r.max() > 0.3:
                out[k] = s0 + (on[0] * h + 2 * h) / SR
        return out


def _bridge(x, k):
    x = x.copy()
    idx = np.flatnonzero(x)
    for a, b in zip(idx[:-1], idx[1:]):
        if 1 < b - a <= k:
            x[a:b] = True
    return x


def _min_run(x, k):
    x = x.copy()
    i = 0
    while i < len(x):
        if x[i]:
            j = i
            while j < len(x) and x[j]:
                j += 1
            if j - i < k:
                x[i:j] = False
            i = j
        else:
            i += 1
    return x


def analyse_audio(path: str, cue_media_times, timeout_s: float):
    """Stream-decode the audio track. Returns (_AudioStream, finished_ok)."""
    from PyQt6.QtMultimedia import QAudioDecoder, QAudioFormat
    dec = QAudioDecoder()
    fmt = QAudioFormat()
    fmt.setSampleRate(SR)
    fmt.setChannelCount(1)
    fmt.setSampleFormat(QAudioFormat.SampleFormat.Int16)
    dec.setAudioFormat(fmt)
    dec.setSource(QUrl.fromLocalFile(path))
    st = _AudioStream(cue_media_times)
    state = {"done": False, "error": ""}

    def ready():
        b = dec.read()
        if b.isValid():
            x = np.frombuffer(b.constData().asstring(b.byteCount()), dtype=np.int16).astype(np.float32) / 32768.0
            st.feed(b.startTime() / 1e6, x)

    loop = QEventLoop()

    def finished():
        state["done"] = True
        loop.quit()

    def failed(*_a):
        state["error"] = dec.errorString() or "decode error"
        loop.quit()

    dec.bufferReady.connect(ready)
    dec.finished.connect(finished)
    try:
        dec.error.connect(failed)          # may not connect on some PyQt6 builds (enum signal)
    except Exception:  # noqa: BLE001
        pass
    QTimer.singleShot(int(timeout_s * 1000), loop.quit)
    dec.start()
    loop.exec()
    dec.stop()
    return st, state["done"] and not state["error"]


class _FrameGrabber(QObject):
    def __init__(self, path: str, rate: float = 8.0):
        super().__init__()
        from PyQt6.QtMultimedia import QMediaPlayer, QVideoSink
        self.player = QMediaPlayer(self)
        self.sink = QVideoSink(self)
        self.player.setVideoSink(self.sink)
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.setPlaybackRate(rate)
        self.sink.videoFrameChanged.connect(self._frame)
        self.times, self.motion = [], []
        self._prev = None
        self.ended = False

    def _frame(self, fr):
        try:
            img = fr.toImage()
            if img.isNull():
                return
            from PyQt6.QtCore import Qt
            from PyQt6.QtGui import QImage
            small = img.convertToFormat(QImage.Format.Format_Grayscale8).scaled(
                64, 36, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.FastTransformation)
            ptr = small.constBits()
            ptr.setsize(small.sizeInBytes())
            a = np.frombuffer(ptr, np.uint8).reshape(36, small.bytesPerLine())[:, :64].astype(np.float32)
            if self._prev is not None:
                self.times.append(fr.startTime() / 1e6)
                self.motion.append(float(np.mean(np.abs(a - self._prev))))
            self._prev = a
        except Exception:  # noqa: BLE001
            pass

    def run(self, timeout_s: float):
        from PyQt6.QtMultimedia import QMediaPlayer
        loop = QEventLoop()

        def status(stt):
            if stt == QMediaPlayer.MediaStatus.EndOfMedia:
                self.ended = True
                loop.quit()
            elif stt == QMediaPlayer.MediaStatus.InvalidMedia:
                loop.quit()

        self.player.mediaStatusChanged.connect(status)
        QTimer.singleShot(int(timeout_s * 1000), loop.quit)
        self.player.play()
        loop.exec()
        self.player.stop()


def _media_duration(info: dict, d: Path) -> float:
    try:
        meta = json.loads((Path(d) / "session.json").read_text(encoding="utf-8"))
        return float(meta.get("duration") or 0) or 3600.0
    except Exception:  # noqa: BLE001
        return 3600.0


def analyse(d: Path, progress=None) -> dict | None:
    """Compute and save av_features.json for a session folder; returns the features (or None: no media).
    Raises Incomplete if a part did not run to the end (nothing is written then)."""
    d = Path(d)
    info = AV.load_sync(d)
    if info is None:
        return None
    say = progress or (lambda _m: None)
    a0 = float(info.get("a_callback", info["a"]))          # always start from the recorder's own estimate
    b = float(info["b"])
    dur = _media_duration(info, d)
    out = {"file": info["file"], "a_callback": a0, "b": b}
    a = a0
    if info.get("audio"):
        say("正在解码声音…")
        cue_media = [(c - a0) / b for c in info.get("cues") or []]
        st, ok = analyse_audio(info["path"], cue_media, timeout_s=max(60.0, dur / 4 + 60))
        if not ok:
            raise Incomplete("声音没有读完（被中断或超时），结果没有保存")
        af = st.result()
        if af:
            onsets = st.chime_onsets()
            offs = [info["cues"][k] - b * t for k, t in onsets.items()]
            if offs and abs(float(np.median(offs)) - a0) <= 0.5:
                a = float(np.median(offs))
                out.update(a_refined=a, cues_found=len(offs),
                           cue_spread_ms=float((max(offs) - min(offs)) * 1000) if len(offs) > 1 else 0.0)
            out["audio"] = {"t": [a + b * x for x in af["t"]], "db": af["db"], "talk": af["talk"],
                            "floor_db": af["floor_db"]}
            out["talk_share"] = float(np.mean(af["talk"])) if af["talk"] else 0.0
    if info.get("video"):
        say("正在分析画面（按 8 倍速读取）…")
        g = _FrameGrabber(info["path"])
        g.run(timeout_s=dur / 8 * 1.5 + 30)
        if not g.ended:
            raise Incomplete("画面没有读完（被中断或超时），结果没有保存")
        if g.times:
            out["video"] = {"t": [a + b * x for x in g.times], "motion": g.motion}
    out["a"] = a
    tmp = d / (FEATURES + ".part")
    tmp.write_text(json.dumps(out), encoding="utf-8")
    tmp.replace(d / FEATURES)
    return out


def load(d: Path) -> dict | None:
    p = Path(d) / FEATURES
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
    except Exception:  # noqa: BLE001
        return None
