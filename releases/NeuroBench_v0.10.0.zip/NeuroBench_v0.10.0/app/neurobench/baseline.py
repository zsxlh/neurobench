"""Personal baselines and the personal model: everything learned from your own recordings.

- Baseline library: per condition (segment label or self-reported activity), your mean and spread
  of each metric, so any new value can be read as "higher / lower than your usual".
- Unlock progress: how much data each analysis needs and how much you have.
- Personal model: predicts your own self-ratings (calm, focus, sleepiness) from physiology with
  leave-one-out cross-validation; reported honestly, including when it does not work.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from .paths import ROOT
from .people import current, mine, person_of
from .session import list_sessions, load_session

METRICS = {"alpha": "α 占比", "alpha_ear": "耳后 α 占比", "theta": "θ 占比", "beta": "β 占比", "iaf": "α 峰值频率",
           "hr": "心率", "rmssd": "心率变异", "blink_rate": "眨眼/分", "emg": "肌电"}
CACHE = ROOT / "cache" / "baseline_rows.json"
MIN_BASELINE = 5


def _num(v):
    return isinstance(v, (int, float)) and v == v


def session_rows(refresh: bool = False):
    """One row per (real session, segment) with metrics; cached by folder name + file size."""
    try:
        cache = json.loads(CACHE.read_text(encoding="utf-8")) if CACHE.exists() and not refresh else {}
    except Exception:  # noqa: BLE001
        cache = {}
    out, keep = [], {}
    who = current()
    for d, meta in list_sessions():
        if meta.get("source") == "sim":
            continue
        try:
            key = f"v2|{d.name}|{(d / "eeg.f64").stat().st_size}|{(d / 'session.json').stat().st_mtime_ns}"
        except OSError:
            continue
        rows = cache.get(key)
        if rows is None:
            try:
                s = load_session(d)
            except Exception:  # noqa: BLE001
                continue
            sr = meta.get("self_report") or {}
            rows = []
            for g in s.segments:
                m = g.metrics
                row = {"session": d.name, "person": person_of(meta), "date": meta.get("started_at", "")[:10], "label": g.label,
                       "activity": sr.get("activity", ""), "duration": m.get("duration", 0),
                       "clean": m.get("clean_share", float("nan"))}
                for k in METRICS:
                    v = m.get(k)
                    if k == "rmssd" and not m.get("hrv_ok", True):
                        v = None
                    row[k] = float(v) if _num(v) else None
                for k, v in sr.items():
                    if k.startswith("sr_") and _num(v):
                        row[k] = float(v)
                rows.append(row)
        keep[key] = rows
        out += [r for r in rows if r.get("person", "me") == who]
    try:
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_text(json.dumps(keep, ensure_ascii=False), encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass
    return out


def conditions(rows):
    """Group rows by segment label; usable segments only (at least half clean data, 30 s or longer)."""
    g = defaultdict(list)
    for r in rows:
        if (r.get("clean") or 0) >= 0.5 and (r.get("duration") or 0) >= 30:
            g[r["label"]].append(r)
    return g


def baseline_table(rows):
    """{label: {"n": sessions, metric: (mean, sd, n)}}"""
    out = {}
    for lab, rs in conditions(rows).items():
        entry = {"n": len({r["session"] for r in rs})}
        for k in METRICS:
            vals = [r[k] for r in rs if r.get(k) is not None]
            if vals:
                entry[k] = (float(np.mean(vals)), float(np.std(vals)), len(vals))
        out[lab] = entry
    return out


def versus_usual(value, label, metric, table):
    e = table.get(label, {})
    if metric not in e or e["n"] < MIN_BASELINE or value is None:
        return None
    mu, sd, n = e[metric]
    z = (value - mu) / (sd or 1e-9)
    return {"z": z, "mean": mu, "n": n, "text": "和你平时差不多" if abs(z) < 1 else ("比你平时高" if z > 0 else "比你平时低")}


def unlock_progress(rows):
    """[(analysis, have, need, note)]"""
    cond = conditions(rows)
    best = max((len({r["session"] for r in rs}) for rs in cond.values()), default=0)
    with_sr = len({r["session"] for r in rows if any(k.startswith("sr_") for k in r)})
    from .training import trial_count
    trials = trial_count()
    practice = sum(1 for d, m in list_sessions() if m.get("protocol") == "练功前后对比" and m.get("source") != "sim"
                   and mine(m))
    rest_days = sum(1 for d, m in list_sessions() if (m.get("self_report") or {}).get("activity") in ("闭眼静坐", "睁眼看屏幕")
                    and m.get("source") != "sim" and mine(m))
    return [
        ("和自己平时比", best, MIN_BASELINE, "同一种段落（比如「闭眼静坐」）录满 5 次"),
        ("想法开关", trials, 60, "想法开关训练累计 60 轮（约 3 次训练）"),
        ("练功效果", practice, 10, f"「练功前后对比」满 10 次，另有不练功的对照日 {rest_days} 次"),
        ("用生理数据预测你的自评", with_sr, 20, "录完填问卷的录制满 20 次"),
    ]


# ------------------------------------------------------------------------------ personal model
FEATURES = ["alpha", "theta", "beta", "hr", "rmssd", "blink_rate", "emg"]
TARGETS = {"sr_calm": "自评平静", "sr_focus": "自评专注", "sr_sleepy": "自评困倦", "sr_mood": "自评心情"}


def session_features(rows):
    """Duration-weighted session averages of usable segments, plus the session's self-report."""
    by = defaultdict(list)
    for r in rows:
        by[r["session"]].append(r)
    out = []
    for sid, rs in by.items():
        good = [r for r in rs if (r.get("clean") or 0) >= 0.4] or rs
        feat = {}
        for k in FEATURES:
            vals = [(r[k], r.get("duration") or 1) for r in good if r.get(k) is not None]
            if vals:
                w = sum(d for _, d in vals)
                feat[k] = sum(v * d for v, d in vals) / w
        tg = {k: rs[0][k] for k in TARGETS if k in rs[0]}
        if tg:
            out.append((sid, feat, tg))
    return out


def personal_model(rows, min_sessions=20, lam=1.0):
    """Ridge regression per self-rating with leave-one-out CV. Returns {target: result dict}."""
    data = session_features(rows)
    results = {}
    for tk, tname in TARGETS.items():
        sub = [(f, t[tk]) for _, f, t in data if tk in t and all(k in f for k in FEATURES if k != "rmssd")]
        n = len(sub)
        if n < min_sessions:
            results[tk] = {"name": tname, "n": n, "ready": False}
            continue
        feats = [k for k in FEATURES if sum(k in f for f, _ in sub) == n]
        X = np.array([[f[k] for k in feats] for f, _ in sub])
        y = np.array([v for _, v in sub], float)
        mu, sd = X.mean(0), X.std(0) + 1e-9
        Z = (X - mu) / sd
        pred = np.zeros(n)
        for i in range(n):
            m = np.arange(n) != i
            A, b = Z[m], y[m] - y[m].mean()
            w = np.linalg.solve(A.T @ A + lam * np.eye(len(feats)), A.T @ b)
            pred[i] = y[m].mean() + Z[i] @ w
        ss_res, ss_tot = np.sum((y - pred) ** 2), np.sum((y - y.mean()) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
        w_all = np.linalg.solve(Z.T @ Z + lam * np.eye(len(feats)), Z.T @ (y - y.mean()))
        top = sorted(zip(feats, w_all), key=lambda x: -abs(x[1]))[:3]
        results[tk] = {"name": tname, "n": n, "ready": True, "r2": float(r2), "r": float(np.corrcoef(y, pred)[0, 1]),
                       "top": [(METRICS.get(k, k), float(v)) for k, v in top],
                       "usable": bool(r2 == r2 and r2 > 0.15)}
    return results
