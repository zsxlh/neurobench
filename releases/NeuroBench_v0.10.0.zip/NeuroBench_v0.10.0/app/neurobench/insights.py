"""Summaries that answer questions (v0.10): the 「今天」 page, α peak frequency against your own baseline split by
time of day, the before/after practice report, and event-locked averages around your own markers.

Everything is computed per person (people.py) from cached segment metrics, so pages open quickly.
"""

from __future__ import annotations

import html
import json
import math
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np

from . import dsp
from . import people as P
from . import session as S

PERIODS = (("夜里", 0, 5), ("早上", 5, 12), ("下午", 12, 18), ("晚上", 18, 24))
MIN_BASE = 3          # earlier recordings needed before saying "higher / lower than usual"


def period_of(hour: int) -> str:
    for name, lo, hi in PERIODS:
        if lo <= hour < hi:
            return name
    return "夜里"


def _wmean(segs, key, min_clean=0.1):
    flag = {"hr": "hr_ok", "rmssd": "hrv_ok"}.get(key)
    vals = [(g["metrics"].get(key), g["metrics"].get("duration", 1.0)) for g in segs
            if isinstance(g["metrics"].get(key), (int, float)) and g["metrics"][key] == g["metrics"][key]
            and g["metrics"].get("clean_share", 1.0) >= min_clean
            and (flag is None or g["metrics"].get(flag, True))]
    if not vals:
        return None
    w = sum(x[1] for x in vals) or 1.0
    return float(sum(v * wt for v, wt in vals) / w)


def recording_summary(d: Path, meta: dict) -> dict | None:
    """One row per real recording: when, who, and the headline numbers."""
    if meta.get("source") == "sim":
        return None
    try:
        when = datetime.fromisoformat(meta["started_at"])
    except Exception:  # noqa: BLE001
        return None
    try:
        segs = S.segments_cached(d, meta)
    except Exception:  # noqa: BLE001
        segs = []
    row = {"dir": str(d), "name": meta.get("name") or d.name, "protocol": meta.get("protocol", ""),
           "when": when, "day": when.date(), "period": period_of(when.hour), "person": P.person_of(meta),
           "duration": meta.get("duration", 0)}
    for k in ("iaf", "alpha", "alpha_ear", "theta", "hr", "rmssd", "emg", "blink_rate", "faa"):
        row[k] = _wmean(segs, k)
    med = meta.get("meditation") or {}
    row["calm_pct"] = med.get("calm_pct")
    row["sleep"] = meta.get("sleep")
    row["self_report"] = meta.get("self_report") or {}
    return row


def all_rows(person: str | None = None) -> list:
    who = person or P.current()
    out = []
    for d, meta in S.list_sessions():
        if P.person_of(meta) != who:
            continue
        r = recording_summary(d, meta)
        if r:
            out.append(r)
    return sorted(out, key=lambda r: r["when"])


def versus(value, history) -> dict | None:
    """Compare with earlier values: z score and a plain-language verdict."""
    h = [v for v in history if isinstance(v, (int, float)) and v == v]
    if value is None or len(h) < MIN_BASE:
        return None
    mu, sd = float(np.mean(h)), float(np.std(h, ddof=1)) if len(h) > 1 else 0.0
    sd = max(sd, 1e-9, abs(mu) * 0.02)
    z = (value - mu) / sd
    txt = "和你平时差不多" if abs(z) < 1 else ("比你平时高" if z > 0 else "比你平时低")
    return {"z": z, "mean": mu, "sd": sd, "n": len(h), "text": txt}


METRIC_NAMES = {"iaf": ("α 峰值频率", "Hz", 2), "alpha_ear": ("耳后 α 占比", "%", 0), "hr": ("心率", "次/分", 0),
                "rmssd": ("心率变异", "ms", 0), "calm_pct": ("冥想平静占比", "%", 0), "blink_rate": ("眨眼", "次/分", 0)}


def day_summary(day: date, person: str | None = None) -> dict:
    """Everything recorded on `day` by the person, each number next to their own usual value.
    The α peak frequency is compared with the same time of day (it is lower right after waking)."""
    rows = all_rows(person)
    today = [r for r in rows if r["day"] == day]
    before = [r for r in rows if r["day"] < day]
    items = []
    for r in today:
        cmp_ = {}
        for k in METRIC_NAMES:
            v = r.get(k)
            if v is None:
                continue
            hist = [b[k] for b in before if (b["period"] == r["period"] if k == "iaf" else True)]
            cmp_[k] = versus(v, hist)
        items.append({**r, "cmp": cmp_})
    # last night's sleep: a sleep recording that ended on this day
    sleep = None
    for r in rows:
        if r["protocol"] == "过夜睡眠" and r["sleep"] and (r["when"] + timedelta(seconds=r["duration"] or 0)).date() == day:
            sleep = r
    iaf_by_period = {}
    for r in today:
        if r.get("iaf"):
            iaf_by_period.setdefault(r["period"], []).append(r["iaf"])
    return {"day": day, "items": items, "sleep": sleep,
            "iaf_by_period": {k: float(np.mean(v)) for k, v in iaf_by_period.items()},
            "n_days": len({r["day"] for r in before})}


def fmt_value(k, v):
    name, unit, nd = METRIC_NAMES[k]
    if v is None:
        return "—"
    if unit == "%":
        v = v * 100 if v <= 1.0 and k != "calm_pct" else v
    return f"{v:.{nd}f} {unit}"


# ------------------------------------------------------------------ before / after practice (练功前后对比)
PRE, POST, LATER = "练前·闭眼静坐", "练后·闭眼静坐", "十分钟后·闭眼静坐"
PRACTICE_KEYS = (("alpha_ear", "耳后 α 占比", 100, "%"), ("theta", "θ 占比", 100, "%"), ("iaf", "α 峰值频率", 1, "Hz"),
                 ("hr", "心率", 1, "次/分"), ("rmssd", "心率变异 RMSSD", 1, "ms"), ("emg", "肌电占比", 100, "%"))


def practice_changes(d: Path, meta: dict) -> dict | None:
    segs = {g["label"]: g["metrics"] for g in S.segments_cached(d, meta)}
    if PRE not in segs or POST not in segs:
        return None
    out = {}
    for k, *_ in PRACTICE_KEYS:
        flag = {"hr": "hr_ok", "rmssd": "hrv_ok"}.get(k)
        if flag and not (segs[PRE].get(flag, True) and segs[POST].get(flag, True)):
            continue                                   # pulse not reliable in one of the two: no comparison
        a, b, c = segs[PRE].get(k), segs[POST].get(k), (segs.get(LATER) or {}).get(k)
        if flag and c is not None and not (segs.get(LATER) or {}).get(flag, True):
            c = None
        if isinstance(a, (int, float)) and isinstance(b, (int, float)) and a == a and b == b:
            out[k] = {"pre": a, "post": b, "delta": b - a,
                      "later": c if isinstance(c, (int, float)) and c == c else None}
    return out


def build_practice_report(d: Path) -> Path | None:
    """HTML report for one 练功前后对比 recording: what changed, and whether the change is bigger than the
    day-to-day wobble seen in your earlier practice sessions."""
    d = Path(d)
    meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
    ch = practice_changes(d, meta)
    if not ch:
        return None
    who = P.person_of(meta)
    hist = []
    for dd, mm in S.list_sessions():
        if dd == d or mm.get("protocol") != "练功前后对比" or mm.get("source") == "sim" or P.person_of(mm) != who:
            continue
        c = practice_changes(dd, mm)
        if c:
            hist.append(c)
    rows = []
    for k, name, scale, unit in PRACTICE_KEYS:
        if k not in ch:
            continue
        c = ch[k]
        deltas = [h[k]["delta"] for h in hist if k in h]
        cmp_ = versus(c["delta"], deltas)
        if len(deltas) >= MIN_BASE:
            lo, hi = np.percentile(deltas, [10, 90])
            usual = f"你以往练功的变化通常在 {lo * scale:+.1f} 到 {hi * scale:+.1f} {unit} 之间（{len(deltas)} 次）；这次{cmp_['text'].replace('你平时', '平时')}"
        else:
            usual = f"以往同类录制只有 {len(deltas)} 次，满 {MIN_BASE} 次后才能判断这次变化算不算大"
        later = "" if c["later"] is None else f"{c['later'] * scale:.1f}"
        rows.append(f"<tr><td>{name}</td><td>{c['pre'] * scale:.1f}</td><td>{c['post'] * scale:.1f}</td>"
                    f"<td><b>{c['delta'] * scale:+.1f}</b> {unit}</td><td>{later}</td><td>{html.escape(usual)}</td></tr>")
    notes = []
    if "alpha_ear" in ch and ch["alpha_ear"]["delta"] > 0.02:
        notes.append("练后闭眼时耳后 α 升高：常见于放松、内收注意的状态。")
    if "hr" in ch and ch["hr"]["delta"] > 5:
        notes.append("练后心率明显高于练前：身体还没完全恢复，「十分钟后」那段更能代表练功的余效。")
    if "emg" in ch and ch["emg"]["delta"] > 0.05:
        notes.append("练后肌电升高：面部或下巴没放松，会让 α、θ 的数值不太准。")
    started = html.escape(meta.get("started_at", "")[:16].replace("T", " "))
    page = f"""<!doctype html><html lang=zh><meta charset=utf-8><title>练功前后对比</title>
<style>body{{font-family:"Microsoft YaHei",sans-serif;max-width:900px;margin:24px auto;padding:0 16px;color:#1f2937}}
td,th{{border-bottom:1px solid #e5e7eb;padding:7px 8px;text-align:left}}table{{border-collapse:collapse;width:100%}}
.note{{background:#f0fdf4;border-left:4px solid #22c55e;padding:8px 14px}}.warn{{background:#fffbeb;border-left:4px solid #f59e0b;padding:8px 14px}}</style>
<h1>练功前后对比</h1><p>{started} · {html.escape(meta.get('name', ''))} · {html.escape(P.name_of(who))}</p>
<table><tr><th>指标</th><th>练前</th><th>练后</th><th>变化</th><th>十分钟后</th><th>和你以往比</th></tr>{''.join(rows)}</table>
{''.join(f'<p class=note>{html.escape(n)}</p>' for n in notes)}
<p class=warn>一次的变化可能来自当天的状态、贴合和肌肉紧张。要判断练功有没有效果，需要多次练功前后对比，
并且最好有不练功、只静坐两次的对照日。数值都只用了贴合良好的电极。</p></html>"""
    out = d / "practice_report.html"
    out.write_text(page, encoding="utf-8")
    meta["practice"] = {k: {kk: (round(vv, 5) if isinstance(vv, float) else vv) for kk, vv in v.items()} for k, v in ch.items()}
    S.save_meta(d, meta)
    return out


# ------------------------------------------------------------------ event-locked averages (事件前后)
def event_locked(s, label: str, pre: float = 10.0, post: float = 10.0, step: float = 0.5):
    """Average ear α share, heart rate and head motion around every marker called `label`.
    Returns {t, alpha, hr, motion, n} with mean values per time bin (NaN where nothing was available)."""
    marks = [m["t"] for m in s.markers if m["label"] == label]
    grid = np.arange(-pre, post + 1e-9, step)
    out = {"t": grid, "n": len(marks)}
    if not marks:
        return out
    alpha_rows, hr_rows, mot_rows = [], [], []
    if "EEG" in s.data:
        t, X, names = s.data["EEG"]
        idx = [names.index(n) for n in ("EEG_TP9", "EEG_TP10") if n in names]
        W = int(2 * dsp.FS_EEG)
        for m in marks:
            row = []
            for g in grid:
                c = np.searchsorted(t, m + g)
                sl = slice(max(0, c - W // 2), c + W // 2)
                if c - W // 2 < 0 or c + W // 2 > len(t) or not idx:
                    row.append(np.nan)
                    continue
                rel, _, _ = dsp.band_powers(dsp.notch_only(X[sl][:, idx]))
                row.append(float(rel[:, dsp.BAND_KEYS.index("alpha")].mean()))
            alpha_rows.append(row)
    if "OPTICS" in s.data:
        to, O, on = s.data["OPTICS"]
        for m in marks:
            sel = (to >= m - pre - 10) & (to <= m + post + 10)
            if sel.sum() < dsp.FS_OPT * 10:
                continue
            h = dsp.robust_heart(O[sel], on)
            ch = h.get("ch")
            if ch is None:
                continue
            bt, ibi = dsp.ppg_beats(O[sel][:, ch], t=to[sel])      # beat times (s), intervals
            if len(bt) < 4:
                continue
            ok = (ibi > 0.33) & (ibi < 2.0)
            if ok.sum() < 3:
                continue
            hr_t, hr_v = bt[1:][ok] - m, 60.0 / ibi[ok]
            hr_rows.append(np.interp(grid, hr_t, hr_v, left=np.nan, right=np.nan))
    if "ACCGYRO" in s.data:
        tg, G, _ = s.data["ACCGYRO"]
        for m in marks:
            row = []
            for g in grid:
                sel = (tg >= m + g - step / 2) & (tg < m + g + step / 2)
                row.append(dsp.motion_level(G[sel, 3:6]) if sel.sum() > 5 else np.nan)
            mot_rows.append(row)
    for key, rows in (("alpha", alpha_rows), ("hr", hr_rows), ("motion", mot_rows)):
        if rows:
            A = np.array(rows, float)
            with np.errstate(all="ignore"):
                out[key] = np.nanmean(A, axis=0)
                out[key + "_n"] = int(np.sum(~np.all(np.isnan(A), axis=1)))
    return out


def marker_labels(s) -> list:
    """Marker labels that occur in a recording (events the user pressed, not segment names)."""
    seen = []
    for m in s.markers:
        if m.get("kind") in ("event",) and m["label"] not in seen:
            seen.append(m["label"])
    return seen


def _nan(x):
    return x is None or (isinstance(x, float) and math.isnan(x))
