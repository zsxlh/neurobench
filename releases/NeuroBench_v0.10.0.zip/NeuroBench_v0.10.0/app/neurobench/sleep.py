"""Rough overnight sleep staging from the headband (unvalidated; clearly labelled as such).

Per 30 s epoch, from the ear and forehead electrodes, the IMU and (if present) heart rate:
  wake  : head movement, strong muscle activity, or alpha clearly above the night's own median
  deep  : the night's top slow-wave (0.5-2 Hz) power, with little muscle activity and no movement
  REM   : lowest muscle activity of the night, no movement, eye movements present, little alpha
  light : everything else (N1/N2)
Thresholds are relative to the same night, so they adapt to the person and the headband fit.
A consumer 4-electrode band cannot do clinical staging; treat stage percentages as a rough guide and
compare nights with each other rather than with lab norms.
"""

from __future__ import annotations

import base64
import html
import io
import json
from pathlib import Path

import numpy as np

from . import dsp
from .session import save_meta

EPOCH = 30.0
STAGES = ["清醒", "REM", "浅睡", "深睡"]          # plotting order, top to bottom
STAGE_COL = {"清醒": "#f59e0b", "REM": "#a78bfa", "浅睡": "#60a5fa", "深睡": "#1d4ed8"}


def _band(f, p, lo, hi):
    m = (f >= lo) & (f < hi)
    return p[m].sum() * (f[1] - f[0])


def epoch_features(s):
    t, X, names = s.data["EEG"]
    X4 = X[:, [names.index(n) for n in dsp.EEG_NAMES]]
    fs = dsp.FS_EEG
    W = int(EPOCH * fs)
    n = len(X4) // W
    tg, G = (s.data["ACCGYRO"][0], s.data["ACCGYRO"][1]) if "ACCGYRO" in s.data else (None, None)
    from scipy.signal import welch
    rows = []
    for k in range(n):
        sl = slice(k * W, (k + 1) * W)
        x = X4[sl]
        q = dsp.window_quality(x)
        good = [c for c, (lv, _) in enumerate(q) if lv > 0] or [0, 3]
        xx = x[:, good] - x[:, good].mean(axis=0)
        f, p = welch(xx, fs=fs, nperseg=int(4 * fs), axis=0)
        p = p.mean(axis=1)
        tot = _band(f, p, 0.5, 30) or 1e-9
        keepf = ~dsp.line_bins(f)
        emg = _band(f[keepf], p[keepf], 30, 100) / (_band(f[keepf], p[keepf], 0.5, 100) or 1e-9)
        fr = dsp.clean_eeg(x[:, [1, 2]], fs, 0.3, 5)
        okL, okR = q[1][0] > 0, q[2][0] > 0
        if okL and okR:
            heog, thr, src = fr[:, 0] - fr[:, 1], 8.0, "both"   # left minus right: sideways eye movements add up
        elif okL or okR:                                         # one forehead only: about half the swing
            heog, thr, src = fr[:, 0 if okL else 1], 4.0, ("AF7" if okL else "AF8")
        else:
            heog, thr, src = None, 0.0, "none"
        eye = float(np.mean(np.abs(np.diff(heog[:: int(fs / 8)])) > thr)) if heog is not None else float("nan")
        mot = float("nan")
        if G is not None:
            m = (tg >= t[sl][0]) & (tg < t[sl][-1])
            if m.sum() > 20:
                mot = dsp.motion_level(G[m, 3:6])
        rows.append({"t": float(t[sl][0]), "slow": np.log(_band(f, p, 0.5, 2) + 1e-9),
                     "delta": _band(f, p, 0.5, 4) / tot, "theta": _band(f, p, 4, 8) / tot,
                     "alpha": _band(f, p, 8, 12) / tot, "sigma": _band(f, p, 11, 16) / tot,
                     "beta": _band(f, p, 16, 30) / tot, "emg": emg, "eye": eye, "eye_src": src, "motion": mot,
                     "bad": len(good) < 2})
    return rows


def stage(rows):
    if not rows:
        return []
    a = lambda k: np.array([r[k] for r in rows], float)  # noqa: E731
    slow, alpha, emg, eye, mot, theta = a("slow"), a("alpha"), a("emg"), a("eye"), a("motion"), a("theta")
    mot = np.nan_to_num(mot, nan=0.0)
    q = lambda v, p: float(np.nanpercentile(v, p))  # noqa: E731
    out = []
    for i in range(len(rows)):
        if rows[i]["bad"]:
            out.append("清醒" if mot[i] > 3 else (out[-1] if out else "清醒"))
            continue
        if mot[i] > 3 or emg[i] > max(0.3, q(emg, 85)) or alpha[i] > 1.5 * q(alpha, 50) and alpha[i] > 0.15:
            out.append("清醒")
        elif slow[i] >= q(slow, 80) and emg[i] <= q(emg, 60) and mot[i] < 1.5:
            out.append("深睡")
        elif emg[i] <= q(emg, 40) and mot[i] < 1.0 and eye[i] >= max(0.02, q(eye, 70)) and alpha[i] <= q(alpha, 60):
            out.append("REM")
        else:
            out.append("浅睡")
    # smoothing: a single epoch that differs from both neighbours takes their stage
    sm = out[:]
    for i in range(1, len(out) - 1):
        if out[i - 1] == out[i + 1] != out[i]:
            sm[i] = out[i - 1]
    return sm


def summary(stages):
    n = len(stages)
    if n == 0:
        return {}
    mins = lambda k: sum(1 for x in stages if x == k) * EPOCH / 60  # noqa: E731
    asleep = [i for i, x in enumerate(stages) if x != "清醒"]
    onset = asleep[0] * EPOCH / 60 if asleep else None
    last = asleep[-1] if asleep else None
    waso = sum(1 for x in stages[asleep[0]:last + 1] if x == "清醒") * EPOCH / 60 if asleep else None
    awakenings = sum(1 for i in range(1, len(stages)) if stages[i] == "清醒" and stages[i - 1] != "清醒" and asleep and i > asleep[0])
    tst = sum(mins(k) for k in ("REM", "浅睡", "深睡"))
    return {"in_bed_min": n * EPOCH / 60, "sleep_min": tst, "onset_min": onset, "waso_min": waso,
            "awakenings": awakenings, "efficiency": tst / (n * EPOCH / 60) if n else None,
            **{f"{k}_min": mins(k) for k in STAGES}}


def build_sleep_report(d: Path):
    from .session import load_session
    d = Path(d)
    s = load_session(d)
    rows = epoch_features(s)
    st = stage(rows)
    sm = summary(st)
    meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
    meta["sleep"] = {k: (round(v, 1) if isinstance(v, float) else v) for k, v in sm.items()}
    save_meta(d, meta)
    with open(d / "sleep_stages.csv", "w", encoding="utf-8-sig") as f:
        f.write("t_s,stage,delta,theta,alpha,sigma,emg,eye,motion\n")
        for r, x in zip(rows, st):
            f.write(f"{r['t']:.0f},{x},{r['delta']:.4f},{r['theta']:.4f},{r['alpha']:.4f},{r['sigma']:.4f},"
                    f"{r['emg']:.4f},{r['eye']:.3f},{r['motion']:.2f}\n")
    img = ""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
        fig, ax = plt.subplots(figsize=(10, 2.8))
        y = [STAGES.index(x) for x in st]
        tt = [r["t"] / 3600 for r in rows]
        ax.step(tt, y, where="post", color="#334155", lw=1)
        for k in STAGES:
            m = [i for i, x in enumerate(st) if x == k]
            ax.scatter([tt[i] for i in m], [STAGES.index(k)] * len(m), s=6, color=STAGE_COL[k])
        ax.set_yticks(range(len(STAGES)))
        ax.set_yticklabels(STAGES)
        ax.invert_yaxis()
        ax.set_xlabel("小时")
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=110)
        plt.close(fig)
        img = f"<img src='data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}' style='width:100%'>"
    except Exception:  # noqa: BLE001
        pass
    f = lambda v, unit="分钟": "—" if v is None else f"{v:.0f} {unit}"  # noqa: E731
    sm_rows = "".join(f"<tr><td>{a}</td><td>{b}</td></tr>" for a, b in (
        ("躺下时长", f(sm.get("in_bed_min"))), ("估计睡着的时长", f(sm.get("sleep_min"))),
        ("入睡用时", f(sm.get("onset_min"))), ("睡着后醒着的时间", f(sm.get("waso_min"))),
        ("醒来次数", f(sm.get("awakenings"), "次")),
        ("睡眠效率", "—" if sm.get("efficiency") is None else f"{sm['efficiency'] * 100:.0f}%"),
        ("浅睡", f(sm.get("浅睡_min"))), ("深睡", f(sm.get("深睡_min"))), ("REM（可能）", f(sm.get("REM_min")))))
    srcs = [r.get("eye_src", "both") for r in rows]
    eye_note = ""
    if srcs:
        single = sum(x in ("AF7", "AF8") for x in srcs) / len(srcs)
        none = srcs.count("none") / len(srcs)
        if single + none > 0.2:
            eye_note = (f"<p class=warn>这一晚有 {single * 100:.0f}% 的时间只有一侧前额电极贴合良好、{none * 100:.0f}% 的时间两侧都不好，"
                        "眼动（判断 REM 的主要依据）只能用单侧估计或估计不了，<b>REM 的时长可信度较低</b>。</p>")
    page = f"""<!doctype html><html lang=zh><meta charset=utf-8><title>睡眠报告</title>
<style>body{{font-family:"Microsoft YaHei",sans-serif;max-width:860px;margin:24px auto;padding:0 16px;color:#1f2937}}
td{{border-bottom:1px solid #e5e7eb;padding:7px 8px}}table{{border-collapse:collapse;width:100%}}
.warn{{background:#fffbeb;border-left:4px solid #f59e0b;padding:8px 14px}}</style>
<h1>睡眠报告（粗略估计）</h1><p>{html.escape(meta.get('started_at', '')[:16].replace('T', ' '))}</p>
<p class=warn>这是根据头环的 4 个电极、运动传感器按规则估算的结果，<b>没有经过和医院睡眠监测的对照验证</b>。
适合同一个人不同晚上互相比较，不适合判断有没有睡眠疾病。</p>
{eye_note}{img}<table>{sm_rows}</table>
<p>每 30 秒的分期和用到的指标保存在 sleep_stages.csv。</p></html>"""
    (d / "sleep_report.html").write_text(page, encoding="utf-8")
    return sm
