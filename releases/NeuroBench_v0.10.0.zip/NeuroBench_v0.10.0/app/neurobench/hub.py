"""Central data hub: ring buffers fed by a device/demo source, read by the UI."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np

from OpenMuse.decode import (
    ACCGYRO_CHANNELS,
    make_timestamps,
    parse_message,
    select_eeg_channels,
    select_optics_channels,
)

SENSORS = ("EEG", "OPTICS", "ACCGYRO", "BATTERY")
FS = {"EEG": 256.0, "OPTICS": 64.0, "ACCGYRO": 52.0, "BATTERY": 1.0}
KEEP_SECONDS = {"EEG": 120, "OPTICS": 400, "ACCGYRO": 120, "BATTERY": 3600}


class Ring:
    """Fixed-size ring buffer of rows [t, ch1, ch2, ...]."""

    def __init__(self, n_cols: int, capacity: int):
        self.buf = np.zeros((capacity, n_cols), dtype=np.float64)
        self.cap = capacity
        self.idx = 0
        self.count = 0

    def write(self, rows: np.ndarray):
        n = len(rows)
        if n == 0:
            return
        if n >= self.cap:
            self.buf[:] = rows[-self.cap:]
            self.idx, self.count = 0, self.cap
            return
        end = self.idx + n
        if end <= self.cap:
            self.buf[self.idx:end] = rows
        else:
            k = self.cap - self.idx
            self.buf[self.idx:] = rows[:k]
            self.buf[: n - k] = rows[k:]
        self.idx = end % self.cap
        self.count = min(self.cap, self.count + n)

    def latest(self, n: int) -> np.ndarray:
        n = min(n, self.count)
        if n == 0:
            return np.empty((0, self.buf.shape[1]))
        start = (self.idx - n) % self.cap
        if start + n <= self.cap:
            return self.buf[start:start + n].copy()
        return np.vstack([self.buf[start:], self.buf[: (start + n) % self.cap]])


@dataclass
class _SensorState:
    names: list
    ring: Ring
    base_time: Optional[float] = None
    wrap_offset: int = 0
    last_abs_tick: int = 0
    sample_counter: int = 0
    offset: Optional[float] = None
    last_t: float = -1e9
    lags: list = field(default_factory=list)
    last_idx: Optional[int] = None          # sequence number of the last subpacket (EEG gap filling)
    run: int = 0                            # running subpacket number (does not wrap at 256)
    last_row: Optional[np.ndarray] = None
    filled: int = 0                         # samples interpolated over subpackets the headband skipped


@dataclass
class DeviceInfo:
    source: str = ""          # "muse", "sim", "replay"
    name: str = ""
    address: str = ""
    firmware: str = ""
    battery: float = float("nan")
    extra: dict = field(default_factory=dict)
    batt_recent: list = field(default_factory=list)   # last valid raw readings (both sources)
    batt_rejected: int = 0

    def set_battery(self, value) -> bool:
        """Accept a battery reading only if it is a number in 0-100; show the median of the last five
        accepted readings so a single wrong reading (wrong packet, other firmware) cannot move it."""
        try:
            v = float(value)
        except (TypeError, ValueError):
            v = float("nan")
        if not (v == v and 0.0 <= v <= 100.0):
            self.batt_rejected += 1
            return False
        self.batt_recent = (self.batt_recent + [v])[-5:]
        self.battery = float(sorted(self.batt_recent)[len(self.batt_recent) // 2])
        return True


MAX_FILL = 16     # subpackets; a longer hole is a real dropout (reconnect), left to the clock tracking


def _fill_gaps(st: "_SensorState", pkts: list) -> list:
    """Firmware 3.1.31 skips ~0.2-0.9 % of EEG subpackets (their sequence numbers are missing; Bluetooth
    loses nothing). Joining the neighbours squeezes the time axis by ~1 % and shifts every frequency, so the
    missing subpackets are filled with a straight line between the samples on either side (16 ms each).

    Every EEG subpacket also gets a running number that keeps counting past 255 (stored in subpkt_index),
    because make_timestamps orders subpackets of one packet by that number: the raw 0-255 value would put
    [255, 0] in the wrong order. Untagged first subpackets carry no number and count as the next one."""
    out = []
    for sp in pkts:
        idx = sp.get("subpkt_index")
        data = np.asarray(sp.get("data"))
        step = 1
        if idx is not None and st.last_idx is not None:
            step = (idx - st.last_idx) % 256 or 1            # 0 would be a repeat: treat as the next one
        run = st.run + step
        g = step - 1
        if 0 < g <= MAX_FILL and st.last_row is not None and data.ndim == 2 and len(data)                 and data.shape[1] == len(st.last_row):
            n = data.shape[0]
            total = g * n
            prev, nxt = st.last_row.astype(float), data[0].astype(float)
            for j in range(g):
                frac = (np.arange(j * n + 1, j * n + n + 1) / (total + 1))[:, None]
                syn = dict(sp)
                syn["data"] = (prev + (nxt - prev) * frac).astype(data.dtype)
                syn["subpkt_index"] = st.run + 1 + j                 # between the neighbours
                syn["filled"] = True
                out.append(syn)
            st.filled += total
        sp = dict(sp)
        sp["subpkt_index"] = run
        out.append(sp)
        st.run = run
        st.last_idx = idx if idx is not None else (None if st.last_idx is None else (st.last_idx + 1) % 256)
        if data.ndim == 2 and len(data):
            st.last_row = data[-1]
    return out


class DataHub:
    """Thread-safe store of the most recent samples of every sensor.

    Time axis: seconds on a session clock (time.perf_counter() - t0). Device
    timestamps are mapped onto it with one offset per sensor, fixed at the
    first packet, so all sensors share one axis to within BLE latency.
    """

    def __init__(self):
        self.lock = threading.RLock()
        self.t0 = time.perf_counter()
        self.sensors: dict[str, _SensorState] = {}
        self.info = DeviceInfo()
        self.recorder = None            # object with write_rows(sensor, rows) / write_raw(line)
        self.packets = 0
        self.last_packet_time = 0.0
        self.listeners: list[Callable[[str, np.ndarray], None]] = []

    # ------------------------------------------------------------------ clock
    def now(self) -> float:
        return time.perf_counter() - self.t0

    # ------------------------------------------------------------------ reset
    def clear(self):
        with self.lock:
            self.sensors.clear()
            self.packets = 0
            self.info = DeviceInfo()

    def reset_device_clocks(self):
        """Forget device clock state (e.g. when a replay file loops); keep buffers."""
        with self.lock:
            for s in self.sensors.values():
                s.base_time = None
                s.wrap_offset = 0
                s.last_abs_tick = 0
                s.sample_counter = 0
                s.offset = None
                s.last_idx, s.last_row = None, None          # a looping replay is not a gap

    # ------------------------------------------------------------------ ingest
    def _ensure(self, sensor: str, names: list) -> _SensorState:
        st = self.sensors.get(sensor)
        if st is None or len(st.names) != len(names):
            cap = int(FS[sensor] * KEEP_SECONDS[sensor])
            st = _SensorState(names=list(names), ring=Ring(len(names) + 1, cap))
            self.sensors[sensor] = st
        return st

    def ingest_message(self, line: str, arrival: Optional[float] = None):
        """Decode one raw BLE line ('iso_ts\\tuuid\\thex') and store it."""
        arrival = self.now() if arrival is None else arrival
        sub = parse_message(line)
        with self.lock:
            self.packets += 1
            self.last_packet_time = arrival
            if self.recorder is not None:
                self.recorder.write_raw(line)
            for sensor in SENSORS:
                pkts = sub.get(sensor) or []
                if not pkts:
                    continue
                n_ch = pkts[0].get("n_channels") or 1
                if sensor == "EEG":
                    names = select_eeg_channels(n_ch)
                elif sensor == "OPTICS":
                    names = select_optics_channels(n_ch)
                elif sensor == "ACCGYRO":
                    names = list(ACCGYRO_CHANNELS)
                else:
                    names = ["BATTERY_PERCENT"]
                st = self._ensure(sensor, names)
                if sensor == "EEG":
                    pkts = _fill_gaps(st, pkts)
                arr, st.base_time, st.wrap_offset, st.last_abs_tick, st.sample_counter = make_timestamps(
                    pkts, st.base_time, st.wrap_offset, st.last_abs_tick, st.sample_counter
                )
                if arr.size == 0 or arr.shape[1] != len(names) + 1:
                    continue
                self._store(sensor, st, arr, arrival)

    def ingest_arrays(self, sensor: str, names: list, t_rel: np.ndarray, data: np.ndarray, arrival=None):
        """Store already-decoded samples (simulator). t_rel: device-relative seconds."""
        arrival = self.now() if arrival is None else arrival
        with self.lock:
            self.packets += 1
            self.last_packet_time = arrival
            st = self._ensure(sensor, names)
            arr = np.column_stack([t_rel, data])
            self._store(sensor, st, arr, arrival)

    def _store(self, sensor, st: _SensorState, arr: np.ndarray, arrival: float):
        if sensor == "BATTERY":
            # Battery records come at a firmware-dependent rate (status packets ~0.2/s plus embedded
            # records ~1/s), so device-derived timestamps drift; the arrival time is accurate enough.
            arr = arr.astype(np.float64, copy=True)
            arr[:, 0] = arrival
            if arr[0, 0] <= st.last_t:
                arr[:, 0] = st.last_t + 1e-3
            st.last_t = float(arr[-1, 0])
            st.ring.write(arr)
            self.info.set_battery(arr[-1, 1])
            if self.recorder is not None:
                self.recorder.write_rows(sensor, st.names, arr)
            return
        if st.offset is None:
            st.offset = arrival - float(arr[-1, 0])
            st.lags = []
            if st.last_t > -1e8:
                # keep time monotonic after a clock reset
                st.offset = max(st.offset, st.last_t + 1.0 / FS[sensor] - float(arr[0, 0]))
        else:
            # Track clock drift between device and computer: follow the
            # minimum-latency envelope of (arrival - mapped time) slowly.
            raw_offset = arrival - float(arr[-1, 0])
            st.lags.append((arrival, raw_offset))
            while st.lags and arrival - st.lags[0][0] > 5.0:
                st.lags.pop(0)
            if len(st.lags) > 10:
                envelope = min(o for _, o in st.lags)
                st.offset += 0.02 * (envelope - st.offset)
        arr = arr.astype(np.float64, copy=True)
        arr[:, 0] += st.offset
        if arr[0, 0] <= st.last_t:
            arr[:, 0] += st.last_t + 1.0 / FS[sensor] - arr[0, 0]
        st.last_t = float(arr[-1, 0])
        st.ring.write(arr)
        if self.recorder is not None:
            self.recorder.write_rows(sensor, st.names, arr)

    # ------------------------------------------------------------------ read
    def names(self, sensor: str) -> list:
        with self.lock:
            st = self.sensors.get(sensor)
            return list(st.names) if st else []

    def latest(self, sensor: str, seconds: float) -> np.ndarray:
        with self.lock:
            st = self.sensors.get(sensor)
            if st is None:
                return np.empty((0, 0))
            return st.ring.latest(int(seconds * FS[sensor]))

    def is_live(self, within: float = 2.0) -> bool:
        return self.packets > 0 and (self.now() - self.last_packet_time) < within
