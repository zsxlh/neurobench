"""One-click research export (v0.10): CSV per sensor, an EDF file of the EEG, the events, the per-segment table,
and a ready-to-run Jupyter notebook that loads all of it.

EDF is the format most EEG tools open (EDFbrowser, MNE, EEGLAB). It is written here directly (no extra
package): 1 s data records, 16-bit samples, physical range 0..1450 uV (the headband's full scale).
"""

from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path

import numpy as np

from . import session as S

EEG_PHYS = (0.0, 1450.0)


def _write_csv(path: Path, header, t, X):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        for i in range(len(t)):
            w.writerow([f"{t[i]:.5f}", *(f"{v:.3f}" for v in X[i])])


def write_edf(path: Path, X: np.ndarray, names: list, fs: int, start: datetime, patient: str = "X",
              recording: str = "NeuroBench"):
    """Minimal EDF (not EDF+): continuous signal, all channels at the same rate. NaN -> 0."""
    X = np.nan_to_num(np.asarray(X, float))
    n_rec = int(len(X) // fs)
    X = X[: n_rec * fs]
    ns = X.shape[1]
    pmin, pmax = EEG_PHYS
    dmin, dmax = -32768, 32767
    scale = (dmax - dmin) / (pmax - pmin)
    D = np.clip(np.round((X - pmin) * scale + dmin), dmin, dmax).astype("<i2")

    def field(s, n):
        return str(s)[:n].ljust(n).encode("ascii", "replace")

    hdr = b"".join([
        field("0", 8), field(patient, 80), field(recording, 80),
        field(start.strftime("%d.%m.%y"), 8), field(start.strftime("%H.%M.%S"), 8),
        field(256 * (ns + 1), 8), field("", 44), field(n_rec, 8), field(1, 8), field(ns, 4)])
    for key, n in (("label", 16), ("transducer", 80), ("dim", 8), ("pmin", 8), ("pmax", 8), ("dmin", 8),
                   ("dmax", 8), ("prefilter", 80), ("ns", 8), ("reserved", 32)):
        for nm in names:
            v = {"label": nm, "transducer": "Muse dry electrode", "dim": "uV", "pmin": f"{pmin:g}", "pmax": f"{pmax:g}",
                 "dmin": dmin, "dmax": dmax, "prefilter": "none (raw)", "ns": fs, "reserved": ""}[key]
            hdr += field(v, n)
    with open(path, "wb") as f:
        f.write(hdr)
        for r in range(n_rec):
            f.write(D[r * fs:(r + 1) * fs].T.tobytes())      # per record: channel by channel
    return n_rec


NOTEBOOK_CELLS = [
    ("markdown", "# {title}\n\n录制：{started} · {person} · 方案：{protocol}\n\n"
                 "这个笔记本读取同一文件夹里导出的数据。需要 numpy、pandas、scipy、matplotlib；"
                 "装了 MNE 的话也可以直接读 EDF。\n\n- `eeg.csv`：时间（秒）+ TP9 AF7 AF8 TP10（µV，原始值，中心约 725）\n"
                 "- `optics.csv`、`imu.csv`：光学（PPG/血氧）和运动传感器\n- `events.csv`：标记和段落\n"
                 "- `segments.csv`：程序算好的每段指标\n- `eeg.edf`：同样的脑电，EDF 格式"),
    ("code", "import numpy as np, pandas as pd, matplotlib.pyplot as plt\nfrom scipy.signal import welch, iirnotch, butter, sosfiltfilt, tf2sos\n"
             "eeg = pd.read_csv('eeg.csv'); ev = pd.read_csv('events.csv'); seg = pd.read_csv('segments.csv')\n"
             "fs = 256\nprint(eeg.shape, 'samples;', len(ev), 'events'); seg"),
    ("code", "# 1–40 Hz 滤波并去掉 50/60 Hz，画前 30 秒\nx = eeg[['TP9','AF7','AF8','TP10']].to_numpy(float)\n"
             "x = x - x.mean(0)\nsos = butter(4, [1, 40], btype='band', fs=fs, output='sos')\ny = sosfiltfilt(sos, x, axis=0)\n"
             "for f0 in (50, 60):\n    y = sosfiltfilt(tf2sos(*iirnotch(f0, 25, fs=fs)), y, axis=0)\n"
             "t = eeg['time'].to_numpy()\nm = t < t[0] + 30\nfig, ax = plt.subplots(figsize=(12, 5))\n"
             "for i, c in enumerate(['TP9','AF7','AF8','TP10']):\n    ax.plot(t[m], y[m, i] - i * 80, lw=0.6, label=c)\n"
             "ax.legend(); ax.set_xlabel('s'); plt.show()"),
    ("code", "# 每段的频谱（用 events.csv 里的段落）\nsegs = ev[ev.kind == 'segment'].reset_index(drop=True)\n"
             "ends = list(segs.t[1:]) + [t[-1]]\nfig, ax = plt.subplots(figsize=(8, 4))\n"
             "for (_, r), t1 in zip(segs.iterrows(), ends):\n    mm = (t >= r.t) & (t < t1)\n"
             "    if mm.sum() < fs * 8: continue\n    f, p = welch(y[mm][:, [0, 3]], fs=fs, nperseg=fs * 4, axis=0)\n"
             "    k = (f >= 1) & (f <= 40); ax.semilogy(f[k], p[k].mean(1), label=r.label)\n"
             "ax.legend(); ax.set_xlabel('Hz'); ax.set_title('耳后电极平均频谱'); plt.show()"),
    ("code", "# 用 MNE 读 EDF（可选）\ntry:\n    import mne\n    raw = mne.io.read_raw_edf('eeg.edf', preload=True)\n"
             "    raw.notch_filter([50, 60]).filter(1, 40)\n    raw.plot(duration=20)\nexcept ImportError:\n    print('没装 MNE：pip install mne')"),
]


def write_notebook(path: Path, meta: dict):
    fill = {"title": meta.get("name", "录制"), "started": meta.get("started_at", "")[:16].replace("T", " "),
            "person": meta.get("person_name") or meta.get("person") or "我", "protocol": meta.get("protocol", "")}
    cells = []
    for kind, src in NOTEBOOK_CELLS:
        src = src.format(**fill) if kind == "markdown" else src
        c = {"cell_type": kind, "metadata": {}, "source": src.splitlines(keepends=True)}
        if kind == "code":
            c.update(execution_count=None, outputs=[])
        cells.append(c)
    nb = {"cells": cells, "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"}},
          "nbformat": 4, "nbformat_minor": 5}
    path.write_text(json.dumps(nb, ensure_ascii=False, indent=1), encoding="utf-8")


def export_research(d: Path, out_root: Path) -> Path:
    """Write the research bundle into out_root/<session folder name>/ and return that folder."""
    d = Path(d)
    s = S.load_session(d)
    out = Path(out_root) / d.name
    out.mkdir(parents=True, exist_ok=True)
    meta = s.meta
    if "EEG" in s.data:
        t, X, names = s.data["EEG"]
        idx = [names.index(n) for n in ("EEG_TP9", "EEG_AF7", "EEG_AF8", "EEG_TP10") if n in names]
        cols = [names[i].replace("EEG_", "") for i in idx]
        _write_csv(out / "eeg.csv", ["time", *cols], t, X[:, idx])
        try:
            from datetime import timedelta
            start = datetime.fromisoformat(meta["started_at"]) + timedelta(seconds=float(t[0]))   # first sample
        except Exception:  # noqa: BLE001
            start = datetime.now()
        write_edf(out / "eeg.edf", X[:, idx], cols, 256, start, patient=meta.get("person", "X"),
                  recording=f"NeuroBench {meta.get('protocol', '')}")
    for sensor, fname in (("OPTICS", "optics.csv"), ("ACCGYRO", "imu.csv")):
        if sensor in s.data:
            t, X, names = s.data[sensor]
            _write_csv(out / fname, ["time", *names], t, X)
    with open(out / "events.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t", "label", "kind"])
        for m in s.markers:
            w.writerow([f"{m['t']:.3f}", m["label"], m.get("kind", "")])
    S.export_segments_csv(s, out / "segments.csv")
    share = {k: meta.get(k) for k in ("name", "protocol", "started_at", "duration", "preset", "fs", "channels",
                                       "eeg_filled", "person_name") if k in meta}
    share["firmware"] = (meta.get("device") or {}).get("firmware")      # no headband address, notes or self-report
    (out / "recording.json").write_text(json.dumps(share, ensure_ascii=False, indent=2), encoding="utf-8")
    write_notebook(out / "analysis.ipynb", meta)
    return out
