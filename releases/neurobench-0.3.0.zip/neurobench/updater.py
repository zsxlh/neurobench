"""Update check, download and install.

Manifest (update.json) and packages are served from a public GitHub repository, with jsDelivr as a
mirror that also works from mainland China. A package is installed side by side in
<root>/versions/<version>/ and becomes active at the next start; the previous version stays for rollback.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import urllib.request
import zipfile
from pathlib import Path

from PyQt6.QtCore import QObject, pyqtSignal

from . import APP_VERSION
from .paths import ROOT, VERSIONS
from .update_config import BRANCH, OWNER, REPO

CHECK_EVERY_S = 6 * 3600
_UA = {"User-Agent": "NeuroBench-updater"}


def vtuple(v: str):
    out = []
    for part in str(v).strip().lstrip("v").split("."):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return tuple(out)


def manifest_urls():
    return [
        f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{BRANCH}/update.json",
        f"https://cdn.jsdelivr.net/gh/{OWNER}/{REPO}@{BRANCH}/update.json",
    ]


def package_urls(manifest: dict):
    """Packages are addressed by tag, so mirrors never serve a stale file."""
    tag, path = manifest["tag"], manifest["package"]["path"]
    return [
        f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{tag}/{path}",
        f"https://cdn.jsdelivr.net/gh/{OWNER}/{REPO}@{tag}/{path}",
    ]


def _get(url: str, timeout: float = 15.0) -> bytes:
    req = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:   # noqa: S310 (https only, fixed hosts)
        return r.read()


def active_version() -> str:
    return APP_VERSION


def installed_versions():
    if not VERSIONS.exists():
        return []
    return sorted([d.name for d in VERSIONS.iterdir()
                   if d.is_dir() and (d / "neurobench" / "__init__.py").exists() and not (d / "BAD").exists()],
                  key=vtuple)


def previous_version():
    p = VERSIONS / "previous.txt"
    if p.exists():
        v = p.read_text(encoding="utf-8").strip()
        if v == "bundled" or (VERSIONS / v / "neurobench").exists():
            return v
    return None


def set_current(version: str):
    VERSIONS.mkdir(parents=True, exist_ok=True)
    cur = VERSIONS / "current.txt"
    old = cur.read_text(encoding="utf-8").strip() if cur.exists() else "bundled"
    if old != version:
        (VERSIONS / "previous.txt").write_text(old, encoding="utf-8")
    if version == "bundled":
        if cur.exists():
            cur.unlink()
    else:
        cur.write_text(version, encoding="utf-8")


def _requirements_file() -> Path:
    return ROOT / "requirements.txt"


def _sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _install_requirements(req: Path, log) -> None:
    """Install changed dependencies into the app's venv (uv if available, else pip); PyPI first, then a China mirror."""
    py = Path(sys.executable)
    if py.name.lower() == "pythonw.exe":
        py = py.with_name("python.exe")
    uv = shutil.which("uv") or str(Path.home() / ".local" / "bin" / "uv.exe")
    indexes = [None, "https://pypi.tuna.tsinghua.edu.cn/simple"]
    flags = 0x08000000 if sys.platform == "win32" else 0      # no console window
    last = ""
    for idx in indexes:
        if Path(uv).exists():
            cmd = [uv, "pip", "install", "--python", str(py), "-r", str(req)]
            if idx:
                cmd += ["--index-url", idx]
        else:
            cmd = [str(py), "-m", "pip", "install", "-r", str(req)]
            if idx:
                cmd += ["-i", idx]
        env = dict(os.environ, UV_HTTP_TIMEOUT="120")
        r = subprocess.run(cmd, capture_output=True, text=True, env=env, creationflags=flags)
        log(f"$ {' '.join(cmd)}\n{r.stdout[-4000:]}\n{r.stderr[-4000:]}\n")
        if r.returncode == 0:
            return
        last = r.stderr[-500:]
    raise RuntimeError(f"安装依赖失败：{last}")


class Updater(QObject):
    available = pyqtSignal(dict)       # manifest of a newer version
    up_to_date = pyqtSignal(str)       # message
    progress = pyqtSignal(str)
    ready = pyqtSignal(str)            # version installed, restart to use
    failed = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.busy = False
        self.latest = None

    # ------------------------------------------------------------------ check
    def check(self, manual: bool = False):
        if OWNER.startswith("<"):
            if manual:
                self.failed.emit("还没有配置更新地址")
            return

        def run():
            errs = []
            for url in manifest_urls():
                try:
                    m = json.loads(_get(url, 10).decode("utf-8"))
                    break
                except Exception as e:  # noqa: BLE001
                    errs.append(f"{url.split('/')[2]}: {type(e).__name__}")
            else:
                if manual:
                    self.failed.emit("连不上更新服务器（" + "；".join(errs) + "）")
                return
            self.latest = m
            if vtuple(m.get("version", "0")) > vtuple(APP_VERSION):
                if m["version"] in installed_versions() and (VERSIONS / "current.txt").exists() and \
                        (VERSIONS / "current.txt").read_text(encoding="utf-8").strip() == m["version"]:
                    self.ready.emit(m["version"])       # already installed, waiting for restart
                else:
                    self.available.emit(m)
            elif manual:
                self.up_to_date.emit(f"已是最新版本 v{APP_VERSION}")

        threading.Thread(target=run, daemon=True, name="update-check").start()

    # ------------------------------------------------------------------ install
    def install(self, manifest: dict):
        if self.busy:
            return
        self.busy = True

        def run():
            try:
                self._install(manifest)
                self.ready.emit(manifest["version"])
            except Exception as e:  # noqa: BLE001
                self.failed.emit(f"更新失败：{e}")
            finally:
                self.busy = False

        threading.Thread(target=run, daemon=True, name="update-install").start()

    def _install(self, m: dict):
        ver = m["version"]
        VERSIONS.mkdir(parents=True, exist_ok=True)
        log_path = VERSIONS / f"update_{ver}.log"
        logf = open(log_path, "w", encoding="utf-8")
        log = logf.write
        try:
            want, size = m["package"]["sha256"], m["package"].get("size")
            data, errs = None, []
            for url in package_urls(m):
                self.progress.emit(f"正在下载 v{ver}（{url.split('/')[2]}）…")
                try:
                    b = _get(url, 60)
                except Exception as e:  # noqa: BLE001
                    errs.append(f"{url.split('/')[2]}: {type(e).__name__}")
                    continue
                if _sha256(b) != want or (size and len(b) != size):
                    errs.append(f"{url.split('/')[2]}: 校验不一致")
                    continue
                data = b
                break
            if data is None:
                raise RuntimeError("下载失败：" + "；".join(errs))
            log(f"downloaded {len(data)} bytes, sha256 ok\n")
            self.progress.emit("正在解压…")
            staging = VERSIONS / f"{ver}.staging"
            if staging.exists():
                shutil.rmtree(staging)
            staging.mkdir(parents=True)
            zp = VERSIONS / f"{ver}.zip"
            zp.write_bytes(data)
            root = staging.resolve()
            with zipfile.ZipFile(zp) as z:
                for n in z.namelist():
                    if n.endswith("/"):
                        continue
                    target = (staging / n).resolve()
                    if root not in target.parents:       # refuse paths outside the folder
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(n) as src, open(target, "wb") as dst:
                        shutil.copyfileobj(src, dst)
            zp.unlink()
            init = (staging / "neurobench" / "__init__.py").read_text(encoding="utf-8")
            if f'APP_VERSION = "{ver}"' not in init:
                raise RuntimeError("安装包内容和版本号对不上")
            # dependencies
            new_req = staging / "requirements.txt"
            old_req = _requirements_file()
            if new_req.exists() and (not old_req.exists() or new_req.read_bytes() != old_req.read_bytes()):
                self.progress.emit("正在安装新的依赖（可能要几分钟）…")
                _install_requirements(new_req, log)
                shutil.copy2(new_req, old_req)
            # launcher (only replaced when the package carries a newer one)
            nl = staging / "NeuroBench.pyw"
            launcher = Path(os.environ.get("NEUROBENCH_LAUNCHER", ROOT / "app" / "NeuroBench.pyw"))
            if nl.exists() and m.get("launcher", 1) > int(os.environ.get("NEUROBENCH_LAUNCHER_VERSION", "1")):
                shutil.copy2(nl, launcher)
                log("launcher replaced\n")
            final = VERSIONS / ver
            if final.exists():
                shutil.rmtree(final)
            os.replace(staging, final)
            (final / "release.json").write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
            set_current(ver)
            log("installed and set as current\n")
        finally:
            logf.close()


def restart_app():
    """Start a fresh copy through the launcher, then the caller quits."""
    launcher = os.environ.get("NEUROBENCH_LAUNCHER") or str(ROOT / "app" / "NeuroBench.pyw")
    py = Path(sys.executable)
    pyw = py.with_name("pythonw.exe") if py.with_name("pythonw.exe").exists() else py
    subprocess.Popen([str(pyw), launcher], cwd=str(ROOT), close_fds=True)
