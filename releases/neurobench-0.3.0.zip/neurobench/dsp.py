"""Signal processing shared by the live view and the offline review."""

from __future__ import annotations

import numpy as np
from scipy.signal import butter, find_peaks, iirnotch, sosfiltfilt, tf2sos, welch

FS_EEG = 256.0
FS_OPT = 64.0
FS_IMU = 52.0

EEG_NAMES = ["EEG_TP9", "EEG_AF7", "EEG_AF8", "EEG_TP10"]
EEG_LABELS = {
    "EEG_TP9": "左耳后 TP9",
    "EEG_AF7": "左前额 AF7",
    "EEG_AF8": "右前额 AF8",
    "EEG_TP10": "右耳后 TP10",
}
EEG_RAW_MAX = 1450.0  # decoder full scale (14-bit -> 0..1450 uV)

# key, Chinese label, low, high, colour
BANDS = [
    ("delta", "δ 慢波", 1.0, 4.0, "#818cf8"),
    ("theta", "θ 西塔", 4.0, 8.0, "#38bdf8"),
    ("alpha", "α 阿尔法", 8.0, 13.0, "#34d399"),
    ("beta", "β 贝塔", 13.0, 30.0, "#fbbf24"),
    ("gamma", "γ 伽马", 30.0, 45.0, "#f87171"),
]
BAND_KEYS = [b[0] for b in BANDS]
BAND_COLORS = {b[0]: b[4] for b in BANDS}
BAND_LABELS = {b[0]: b[1] for b in BANDS}


# --------------------------------------------------------------------------- filters
_SOS_CACHE: dict = {}


def _sos(kind: str, fs: float, *args):
    key = (kind, fs, args)
    if key not in _SOS_CACHE:
        if kind == "band":
            lo, hi, order = args
            _SOS_CACHE[key] = butter(order, [lo, hi], btype="band", fs=fs, output="sos")
        elif kind == "notch":
            f0, q = args
            b, a = iirnotch(f0, q, fs=fs)
            _SOS_CACHE[key] = tf2sos(b, a)
        elif kind == "low":
            hi, order = args
            _SOS_CACHE[key] = butter(order, hi, btype="low", fs=fs, output="sos")
    return _SOS_CACHE[key]


def _safe_filtfilt(sos, x, axis=0):
    padlen = 3 * (2 * len(sos) + 1)
    if x.shape[axis] <= padlen:
        return x - np.mean(x, axis=axis, keepdims=True)
    return sosfiltfilt(sos, x, axis=axis)


def clean_eeg(x: np.ndarray, fs: float = FS_EEG, lo: float = 1.0, hi: float = 40.0) -> np.ndarray:
    """Band-pass plus 50 and 60 Hz notches (works for China and the US). x: (n, ch)."""
    x = np.asarray(x, dtype=float)
    x = x - np.nanmean(x, axis=0, keepdims=True)
    x = np.nan_to_num(x)
    for f0 in (50.0, 60.0):
        x = _safe_filtfilt(_sos("notch", fs, f0, 25.0), x)
    return _safe_filtfilt(_sos("band", fs, lo, hi, 4), x)


def notch_only(x: np.ndarray, fs: float = FS_EEG) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    x = np.nan_to_num(x - np.nanmean(x, axis=0, keepdims=True))
    x = _safe_filtfilt(_sos("band", fs, 0.5, 120.0, 2), x)
    for f0 in (50.0, 60.0):
        x = _safe_filtfilt(_sos("notch", fs, f0, 25.0), x)
    return x


# --------------------------------------------------------------------------- spectra
def psd(x: np.ndarray, fs: float = FS_EEG, seg_s: float = 2.0):
    """Welch PSD along axis 0. Returns f, p with p shape (nf, ch)."""
    x = np.asarray(x, dtype=float)
    nper = int(min(len(x), seg_s * fs))
    f, p = welch(x, fs=fs, nperseg=nper, axis=0, detrend="constant")
    return f, p


def _band_sum(f, p, lo, hi):
    m = (f >= lo) & (f < hi)
    return p[m].sum(axis=0) * (f[1] - f[0])


def band_powers(x: np.ndarray, fs: float = FS_EEG):
    """Relative and absolute band power per channel.

    x: (n, ch) signal after notch (not band-limited).
    Returns rel (ch, 5), abs (ch, 5), emg (ch,) where emg is the share of
    30-100 Hz power (mains bands excluded) in 1-100 Hz total; on a forehead
    headband that range is dominated by muscle activity.
    """
    f, p = psd(x, fs)
    if p.ndim == 1:
        p = p[:, None]
    absp = np.stack([_band_sum(f, p, lo, hi) for _, _, lo, hi, _ in BANDS], axis=1)
    total = absp.sum(axis=1, keepdims=True)
    rel = absp / np.where(total > 0, total, 1.0)
    keep = ~(((f > 46) & (f < 54)) | ((f > 56) & (f < 64)))
    hf = _band_sum(f[keep], p[keep], 30.0, 100.0)
    tot = _band_sum(f[keep], p[keep], 1.0, 100.0)
    emg = hf / np.where(tot > 0, tot, 1.0)
    return rel, absp, emg


def alpha_peak(x: np.ndarray, fs: float = FS_EEG):
    """Individual alpha frequency (centre of gravity 7-13 Hz) from the mean spectrum."""
    f, p = psd(x, fs, seg_s=4.0)
    if p.ndim > 1:
        p = p.mean(axis=1)
    m = (f >= 7) & (f <= 13)
    if not m.any() or p[m].sum() <= 0:
        return float("nan")
    # remove 1/f trend before the centre of gravity
    lf, lp = np.log(f[(f >= 2) & (f <= 30)]), np.log(p[(f >= 2) & (f <= 30)] + 1e-12)
    slope, icpt = np.polyfit(lf, lp, 1)
    resid = p[m] - np.exp(icpt + slope * np.log(f[m]))
    resid = np.clip(resid, 0, None)
    if resid.sum() <= 0:
        return float("nan")
    return float((f[m] * resid).sum() / resid.sum())


# --------------------------------------------------------------------------- quality
def channel_quality(raw: np.ndarray, fs: float = FS_EEG):
    """Per-channel contact quality from the last ~2 s of raw data.

    Returns list of (level, text): level 2 good, 1 fair, 0 poor.
    """
    out = []
    raw = np.asarray(raw, dtype=float)
    if len(raw) < fs:
        return [(0, "等待数据")] * raw.shape[1]
    filt = clean_eeg(raw, fs, 1.0, 40.0)
    for i in range(raw.shape[1]):
        r = raw[:, i]
        railed = np.mean((r <= 1.0) | (r >= EEG_RAW_MAX - 1.0))
        sd = float(np.std(filt[:, i]))
        if np.std(r) < 0.5:
            out.append((0, "无信号"))
        elif railed > 0.02:
            out.append((0, "未贴合"))
        elif sd > 120:
            out.append((0, "噪声大"))
        elif sd > 45 or sd < 2:
            out.append((1, "一般"))
        else:
            out.append((2, "良好"))
    return out


# --------------------------------------------------------------------------- heart
def pick_ppg_channel(opt: np.ndarray, names: list[str], fs: float = FS_OPT):
    """Choose the optical channel with the strongest cardiac rhythm."""
    best, best_score = None, -1.0
    for i, n in enumerate(names):
        if "AMB" in n:
            continue
        x = opt[:, i]
        if np.std(x) <= 0:
            continue
        f, p = psd(x, fs, seg_s=8.0)
        tot = p[(f > 0.1) & (f < 8)].sum()
        if tot <= 0:
            continue
        score = p[(f > 0.8) & (f < 3.0)].sum() / tot
        if score > best_score:
            best, best_score = i, score
    return best, best_score


def ppg_filter(x: np.ndarray, fs: float = FS_OPT):
    return _safe_filtfilt(_sos("band", fs, 0.7, 3.5, 2), np.asarray(x, float) - np.mean(x))


def pulse_rate_hz(y: np.ndarray, fs: float = FS_OPT):
    """Dominant frequency in 0.7-3.2 Hz (42-192 bpm) of a filtered PPG window."""
    if len(y) < 4 * fs:
        return float("nan")
    nfft = max(4096, len(y))
    f, p = welch(y, fs=fs, nperseg=min(len(y), int(8 * fs)), nfft=nfft)
    m = (f >= 0.7) & (f <= 3.2)
    if not m.any() or p[m].max() <= 0:
        return float("nan")
    fm, pm = f[m], p[m]
    k = int(np.argmax(pm))
    # if half the frequency also carries a strong peak, the true rate is the lower one
    half = np.abs(fm - fm[k] / 2) < 0.08
    if half.any() and pm[half].max() > 0.5 * pm[k]:
        k = int(np.flatnonzero(half)[np.argmax(pm[half])])
    return float(fm[k])


def ppg_beats(x: np.ndarray, fs: float = FS_OPT, t: np.ndarray | None = None):
    """Detect pulse peaks. Returns (peak_times, ibi_seconds)."""
    y = ppg_filter(x, fs)
    if len(y) < 3 * fs:
        return np.array([]), np.array([])
    # optical PPG pulses point down (more blood absorbs more light) -> use -y
    y = -y
    # dominant pulse rate from the spectrum guides the minimum peak spacing,
    # which stops the dicrotic notch from being counted as a second beat
    f0 = pulse_rate_hz(y, fs)
    min_gap = 0.6 / f0 if f0 == f0 else 0.33
    prom = 0.3 * np.std(y)
    peaks, _ = find_peaks(y, distance=max(1, int(min_gap * fs)), prominence=prom)
    if t is None:
        t = np.arange(len(y)) / fs
    pt = t[peaks]
    ibi = np.diff(pt)
    return pt, ibi


def clean_ibi(ibi: np.ndarray):
    ibi = ibi[(ibi > 0.33) & (ibi < 1.6)]
    if len(ibi) < 3:
        return ibi
    med = np.median(ibi)
    return ibi[np.abs(ibi - med) < 0.25 * med]


def heart_metrics(x: np.ndarray, fs: float = FS_OPT):
    """HR (bpm) and RMSSD (ms) from a PPG window."""
    _, ibi = ppg_beats(x, fs)
    ibi = clean_ibi(ibi)
    if len(ibi) < 4:
        return float("nan"), float("nan")
    hr = 60.0 / np.median(ibi)
    d = np.diff(ibi)
    rmssd = float(np.sqrt(np.mean(d**2)) * 1000.0) if len(d) >= 3 else float("nan")
    return float(hr), rmssd


# --------------------------------------------------------------------------- fNIRS
# Molar extinction coefficients (cm^-1 / M, log10 base), Prahl's compilation.
#            HbO2      HbR
_EXT = np.array([[390.0, 1102.2],   # 730 nm (NIR channels)
                 [1058.0, 691.32]]) # 850 nm (IR channels)
_EXT_INV = np.linalg.inv(_EXT)
ASSUMED_DISTANCE_CM = 3.0
ASSUMED_DPF = 6.0


def hb_changes(i730: np.ndarray, i850: np.ndarray, baseline_n: int | None = None):
    """Modified Beer-Lambert: intensity series -> (dHbO, dHbR) in uM (assumed path length).

    Baseline is the mean of the first baseline_n samples (whole window if None).
    Values are rough: the source-detector distance and DPF are assumptions.
    """
    i730 = np.clip(np.asarray(i730, float), 1e-6, None)
    i850 = np.clip(np.asarray(i850, float), 1e-6, None)
    n = baseline_n or len(i730)
    od = np.vstack([-np.log10(i730 / np.mean(i730[:n])), -np.log10(i850 / np.mean(i850[:n]))])
    conc = _EXT_INV @ od / (ASSUMED_DISTANCE_CM * ASSUMED_DPF)  # mol/L
    return conc[0] * 1e6, conc[1] * 1e6


def lowpass(x: np.ndarray, fs: float, hi: float):
    return _safe_filtfilt(_sos("low", fs, hi, 2), np.asarray(x, float))


# --------------------------------------------------------------------------- motion
def motion_level(gyro: np.ndarray):
    """RMS angular speed (deg/s) after removing the offset."""
    g = np.asarray(gyro, float)
    if len(g) < 5:
        return float("nan")
    g = g - np.median(g, axis=0, keepdims=True)
    return float(np.sqrt(np.mean(np.sum(g**2, axis=1))))
