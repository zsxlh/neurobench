"""Periodic live metrics computed from the hub, shared by all pages."""

from __future__ import annotations

from collections import deque

import numpy as np
from PyQt6.QtCore import QObject, QTimer, pyqtSignal

from . import dsp
from .hub import DataHub


class LiveAnalyzer(QObject):
    updated = pyqtSignal()

    HISTORY_S = 600

    def __init__(self, hub: DataHub, period_ms: int = 500):
        super().__init__()
        self.hub = hub
        self.reset()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(period_ms)

    def reset(self):
        self.quality = {n: (0, "等待数据") for n in dsp.EEG_NAMES}
        self.rel = {k: float("nan") for k in dsp.BAND_KEYS}
        self.rel_ch = None
        self.emg = float("nan")
        self.hr = float("nan")
        self.rmssd = float("nan")
        self.motion = float("nan")
        self.ppg_ch = None
        self.ppg_name = ""
        self._ppg_pick_t = -1e9
        self.history = deque(maxlen=int(self.HISTORY_S * 2))   # (t, rel[5], emg)
        self.opt_baseline = None
        self.hb = None   # (t, hboL, hbrL, hboR, hbrR)
        self.live = False

    def set_opt_baseline(self):
        o = self.hub.latest("OPTICS", 10)
        if len(o) > dsp.FS_OPT * 3:
            self.opt_baseline = o[:, 1:].mean(axis=0)

    # ------------------------------------------------------------------
    def tick(self):
        hub = self.hub
        self.live = hub.is_live()
        now = hub.now()
        # ---------------- EEG
        eeg = hub.latest("EEG", 4.0)
        names = hub.names("EEG")
        if len(eeg) > dsp.FS_EEG * 2 and names:
            idx = [names.index(n) for n in dsp.EEG_NAMES if n in names]
            X = eeg[:, 1:][:, idx]
            q = dsp.channel_quality(X[-int(2 * dsp.FS_EEG):])
            self.quality = {dsp.EEG_NAMES[i]: q[i] for i in range(len(idx))}
            rel, _, emg = dsp.band_powers(dsp.notch_only(X))
            good = [i for i, (lv, _) in enumerate(q) if lv > 0] or list(range(len(idx)))
            self.rel_ch = rel
            avg = rel[good].mean(axis=0)
            self.rel = {k: float(avg[i]) for i, k in enumerate(dsp.BAND_KEYS)}
            self.emg = float(np.mean(emg[good]))
            self.history.append((float(eeg[-1, 0]), avg.copy(), self.emg))
        # ---------------- heart
        opt = hub.latest("OPTICS", 60.0)
        onames = hub.names("OPTICS")
        if len(opt) > dsp.FS_OPT * 8 and onames:
            if now - self._ppg_pick_t > 10 or self.ppg_ch is None:
                ch, _ = dsp.pick_ppg_channel(opt[-int(20 * dsp.FS_OPT):, 1:], onames)
                if ch is not None:
                    self.ppg_ch, self.ppg_name = ch, onames[ch]
                self._ppg_pick_t = now
            if self.ppg_ch is not None:
                x = opt[:, 1 + self.ppg_ch]
                hr, _ = dsp.heart_metrics(x[-int(15 * dsp.FS_OPT):])
                _, rmssd = dsp.heart_metrics(x)
                # hold the last valid value for up to 10 s instead of flashing "—"
                if hr == hr:
                    self.hr, self._hr_t = hr, now
                elif now - getattr(self, "_hr_t", -1e9) > 10:
                    self.hr = hr
                if rmssd == rmssd:
                    self.rmssd, self._rmssd_t = rmssd, now
                elif now - getattr(self, "_rmssd_t", -1e9) > 10:
                    self.rmssd = rmssd
            # ---------------- fNIRS
            if self.opt_baseline is None and len(hub.latest("OPTICS", 30)) > dsp.FS_OPT * 15:
                self.set_opt_baseline()
            if self.opt_baseline is not None:
                self._update_hb(onames)
        # ---------------- motion
        imu = hub.latest("ACCGYRO", 2.0)
        if len(imu) > 20:
            self.motion = dsp.motion_level(imu[:, 4:7])
        rec = hub.recorder
        if rec is not None:
            row = {"live": int(self.live), "battery": hub.info.battery, "emg": self.emg, "hr": self.hr,
                   "rmssd": self.rmssd, "motion": self.motion, "ppg_channel": self.ppg_name, **self.rel}
            for name, (lv, txt) in self.quality.items():
                short = name.replace("EEG_", "")
                row[f"q_{short}"], row[f"qtext_{short}"] = lv, txt
            try:
                rec.write_metrics(row)
            except Exception:  # noqa: BLE001  (never let logging break the live view)
                pass
        self.updated.emit()

    def _update_hb(self, onames):
        o = self.hub.latest("OPTICS", 180.0)
        if len(o) < dsp.FS_OPT * 4:
            return
        t = o[:, 0]
        out = [t]
        for side in ("L", "R"):
            try:
                a = onames.index(f"OPTICS_{side}O_NIR")
                b = onames.index(f"OPTICS_{side}O_IR")
            except ValueError:
                self.hb = None
                return
            b730, b850 = self.opt_baseline[a], self.opt_baseline[b]
            i730 = np.clip(o[:, 1 + a], 1e-6, None)
            i850 = np.clip(o[:, 1 + b], 1e-6, None)
            od = np.vstack([-np.log10(i730 / b730), -np.log10(i850 / b850)])
            conc = dsp._EXT_INV @ od / (dsp.ASSUMED_DISTANCE_CM * dsp.ASSUMED_DPF) * 1e6
            out += [dsp.lowpass(conc[0], dsp.FS_OPT, 0.1), dsp.lowpass(conc[1], dsp.FS_OPT, 0.1)]
        k = 8
        self.hb = tuple(x[::k] for x in out)

    def ppg_wave(self, seconds=8.0):
        if self.ppg_ch is None:
            return None, None
        o = self.hub.latest("OPTICS", seconds + 4)
        if len(o) < dsp.FS_OPT * 3:
            return None, None
        y = -dsp.ppg_filter(o[:, 1 + self.ppg_ch])
        n = int(seconds * dsp.FS_OPT)
        return o[-n:, 0], y[-n:]
