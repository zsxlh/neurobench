"""实时 page: waveforms, contact quality, band power, heart, oxygenation."""

from __future__ import annotations

import math

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import QTimer, pyqtSignal
from PyQt6.QtWidgets import QGridLayout, QHBoxLayout, QPushButton, QVBoxLayout, QWidget

from . import dsp
from . import theme as T
from .protocols import EVENT_MARKERS
from .widgets import BandBars, Card, HeadbandMap, StatTile, label, legend_row, plot

LANE = 120.0  # uV between stacked traces
TRACE_COLORS = ["#7dd3fc", "#a78bfa", "#f0abfc", "#5eead4"]


def fmt(v, nd=0, dash="—"):
    return dash if v is None or (isinstance(v, float) and math.isnan(v)) else f"{v:.{nd}f}"


class LivePage(QWidget):
    record_toggle = pyqtSignal()
    mark = pyqtSignal(str)

    def set_recording(self, elapsed: float | None, note: str = ""):
        """elapsed=None: idle; otherwise recording for `elapsed` seconds."""
        rec = elapsed is not None
        if rec:
            s = int(elapsed)
            self.b_rec.setText(f"■  停止  {s // 60:02d}:{s % 60:02d}")
            self.b_rec.setObjectName("danger")
            self.l_rec.setText("录制中 · 打标记：")
        else:
            self.b_rec.setText("●  录制")
            self.b_rec.setObjectName("primary")
            if note:
                self.l_rec.setText(note)
        self.b_rec.style().unpolish(self.b_rec)
        self.b_rec.style().polish(self.b_rec)
        for b in self.mark_btns:
            b.setVisible(rec)

    def __init__(self, hub, analyzer):
        super().__init__()
        self.hub, self.an = hub, analyzer
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        # ---------------- tiles
        tiles = QHBoxLayout()
        tiles.setSpacing(12)
        self.t_quality = StatTile("佩戴", "", T.GOOD)
        self.t_alpha = StatTile("α 放松度", "%", dsp.BAND_COLORS["alpha"])
        self.t_hr = StatTile("心率", "次/分", "#fb7185")
        self.t_hrv = StatTile("心率变异", "ms", T.ACCENT2)
        self.t_emg = StatTile("肌电干扰", "%", T.GOOD)
        self.t_motion = StatTile("头部晃动", "°/s", T.ACCENT)
        for t in (self.t_quality, self.t_alpha, self.t_hr, self.t_hrv, self.t_emg, self.t_motion):
            tiles.addWidget(t)
        root.addLayout(tiles)

        # ---------------- one-click recording bar
        bar = QHBoxLayout()
        bar.setSpacing(8)
        self.b_rec = QPushButton("●  录制")
        self.b_rec.setObjectName("primary")
        self.b_rec.setMinimumWidth(150)
        self.b_rec.setToolTip("一键录下全部数据（脑电、光学、运动、原始蓝牙包、屏幕上的指标和事件）；停止后自动打包到桌面")
        self.b_rec.clicked.connect(self.record_toggle.emit)
        bar.addWidget(self.b_rec)
        self.l_rec = label("一键录下这里看到的一切，停止后自动打包到桌面，直接发给 Claude。", "muted")
        bar.addWidget(self.l_rec, 1)
        self.mark_btns = []
        for lab, key in EVENT_MARKERS:
            b = QPushButton(f"{lab} ·{key}")
            b.setObjectName("marker")
            b.clicked.connect(lambda _=False, l=lab: self.mark.emit(l))
            b.setVisible(False)
            bar.addWidget(b)
            self.mark_btns.append(b)
        root.addLayout(bar)

        grid = QGridLayout()
        grid.setSpacing(14)
        root.addLayout(grid, 1)

        # ---------------- EEG waves
        self.c_wave = Card("脑电波形", "1–40 Hz 滤波 · 最近 8 秒")
        self.p_wave = plot(bottom="秒")
        self.p_wave.getPlotItem().getAxis("left").setTicks([[(-i * LANE, n) for i, n in enumerate(["TP9", "AF7", "AF8", "TP10"])]])
        self.curves = [self.p_wave.plot(pen=pg.mkPen(c, width=1.3)) for c in TRACE_COLORS]
        self.p_wave.setYRange(-3.6 * LANE, 0.6 * LANE, padding=0)
        self.c_wave.add(self.p_wave, 1)
        grid.addWidget(self.c_wave, 0, 0, 1, 2)

        # ---------------- contact map
        self.c_map = Card("电极贴合", "绿色=良好")
        self.map = HeadbandMap()
        self.c_map.add(self.map, 1)
        grid.addWidget(self.c_map, 0, 2)

        # ---------------- band bars
        self.c_bands = Card("各频段占比", "最近 4 秒 · 贴合电极平均")
        self.bars = BandBars([(k, dsp.BAND_LABELS[k], dsp.BAND_COLORS[k]) for k in dsp.BAND_KEYS])
        self.c_bands.add(self.bars, 1)
        grid.addWidget(self.c_bands, 0, 3)

        # ---------------- trend
        self.c_trend = Card("脑波趋势", "最近 5 分钟")
        self.p_trend = plot(bottom="分钟前")
        self.trend_curves = {}
        for k in ("theta", "alpha", "beta"):
            self.trend_curves[k] = self.p_trend.plot(pen=pg.mkPen(dsp.BAND_COLORS[k], width=2))
        self.emg_curve = self.p_trend.plot(pen=pg.mkPen(T.BAD, width=1, style=pg.QtCore.Qt.PenStyle.DotLine))
        self.p_trend.setYRange(0, 0.6)
        self.p_trend.setXRange(-5, 0)
        self.c_trend.add(self.p_trend, 1)
        self.c_trend.add(legend_row([("θ", dsp.BAND_COLORS["theta"]), ("α", dsp.BAND_COLORS["alpha"]),
                                     ("β", dsp.BAND_COLORS["beta"]), ("肌电", T.BAD)]))
        grid.addWidget(self.c_trend, 1, 0, 1, 2)

        # ---------------- pulse
        self.c_ppg = Card("脉搏", "")
        self.p_ppg = plot()
        self.p_ppg.getPlotItem().hideAxis("left")
        self.ppg_curve = self.p_ppg.plot(pen=pg.mkPen("#fb7185", width=2))
        self.c_ppg.add(self.p_ppg, 1)
        grid.addWidget(self.c_ppg, 1, 2)

        # ---------------- oxygenation
        self.c_hb = Card("前额血氧变化", "探索性 · 估算值")
        self.p_hb = plot(left="μM", bottom="分钟前")
        self.hb_curves = [
            self.p_hb.plot(pen=pg.mkPen("#f43f5e", width=2)),
            self.p_hb.plot(pen=pg.mkPen("#60a5fa", width=2)),
            self.p_hb.plot(pen=pg.mkPen("#f43f5e", width=1.2, style=pg.QtCore.Qt.PenStyle.DashLine)),
            self.p_hb.plot(pen=pg.mkPen("#60a5fa", width=1.2, style=pg.QtCore.Qt.PenStyle.DashLine)),
        ]
        self.p_hb.setXRange(-3, 0)
        self.c_hb.add(self.p_hb, 1)
        row = legend_row([("含氧 左", "#f43f5e"), ("脱氧 左", "#60a5fa"), ("虚线=右", T.FAINT)])
        b = QPushButton("重设基线")
        b.setObjectName("ghost")
        b.setToolTip("以最近 10 秒为零点重新计算")
        b.clicked.connect(self.an.set_opt_baseline)
        row.addWidget(b)
        self.c_hb.add(row)
        grid.addWidget(self.c_hb, 1, 3)

        # small screens: the waveform card gives up width first, the electrode / band cards keep enough to stay legible
        for c in (self.c_map, self.c_ppg):
            c.setMinimumWidth(250)
        for c in (self.c_bands, self.c_hb):
            c.setMinimumWidth(270)
        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 2)
        grid.setColumnStretch(2, 2)
        grid.setColumnStretch(3, 2)
        grid.setRowStretch(0, 3)
        grid.setRowStretch(1, 2)

        self.wave_timer = QTimer(self)
        self.wave_timer.timeout.connect(self.refresh_waves)
        self.wave_timer.start(40)
        self.an.updated.connect(self.refresh_metrics)

    # ------------------------------------------------------------------
    def refresh_waves(self):
        if not self.isVisible():
            return
        eeg = self.hub.latest("EEG", 9.0)
        names = self.hub.names("EEG")
        if len(eeg) < 64 or not names:
            return
        idx = [names.index(n) for n in dsp.EEG_NAMES if n in names]
        X = dsp.clean_eeg(eeg[:, 1:][:, idx])
        n = int(8 * dsp.FS_EEG)
        t = eeg[-n:, 0] - eeg[-1, 0]
        X = X[-n:]
        for i, c in enumerate(self.curves[: X.shape[1]]):
            c.setData(t, np.clip(X[:, i], -LANE * 0.55, LANE * 0.55) - i * LANE)
        self.p_wave.setXRange(-8, 0, padding=0)
        tt, y = self.an.ppg_wave(6.0)
        if tt is not None:
            self.ppg_curve.setData(tt - tt[-1], y)
            self.p_ppg.setXRange(-6, 0, padding=0)

    def refresh_metrics(self):
        an = self.an
        if not self.isVisible():
            return
        # tiles
        lv = [v[0] for v in an.quality.values()]
        good = sum(1 for v in lv if v == 2)
        bat = self.hub.info.battery
        if not an.live:
            # disconnected: do not leave the last numbers on screen as if they were current
            had_data = self.hub.packets > 0
            self.t_quality.set("—", "已断开 · 下面是断开前的画面" if had_data else "未连接", T.FAINT)
            for t in (self.t_alpha, self.t_hr, self.t_hrv, self.t_emg, self.t_motion):
                t.set("—", "", T.FAINT)
            if had_data and bat == bat and bat < 10:
                self.t_quality.set("—", f"已断开 · 电量只剩 {bat:.0f}%，先充电", T.BAD)
            return
        else:
            col = T.GOOD if good >= 3 else (T.WARN if good >= 1 else T.BAD)
            self.t_quality.set(f"{good}/4", "电极贴合良好" if good == 4 else "调整头环或润湿电极", col)
        a = an.rel.get("alpha", float("nan"))
        self.t_alpha.set(fmt(a * 100 if a == a else a), "闭眼放松时会升高")
        self.t_hr.set(fmt(an.hr), an.ppg_name.replace("OPTICS_", "光学 ") if an.ppg_name else "等待脉搏")
        self.t_hrv.set(fmt(an.rmssd), "近 1 分钟 RMSSD")
        e = an.emg
        if e == e:
            col = T.GOOD if e < 0.15 else (T.WARN if e < 0.30 else T.BAD)
            hint = "安静" if e < 0.15 else ("有些用力" if e < 0.30 else "咬牙/皱眉/说话")
            self.t_emg.set(f"{e * 100:.0f}", hint, col)
        m = an.motion
        if m == m:
            self.t_motion.set(f"{m:.1f}", "稳定" if m < 3 else ("轻微晃动" if m < 10 else "明显晃动"),
                              T.ACCENT if m < 3 else (T.WARN if m < 10 else T.BAD))
        low = bat == bat and bat < 15
        self.c_wave.sub_label.setText(f"1–40 Hz 滤波 · 最近 8 秒 · 电量 {fmt(bat)}%" + ("  ⚠ 电量低" if low else ""))
        self.c_wave.sub_label.setStyleSheet(f"color: {T.BAD};" if low else "")
        self.map.set_quality(an.quality)
        # dim traces from electrodes that are not making contact, so noise does not look like brain activity
        for i, name in enumerate(dsp.EEG_NAMES):
            if i < len(self.curves):
                level = an.quality.get(name, (2, ""))[0]
                col = pg.mkColor(TRACE_COLORS[i])
                col.setAlpha(255 if level > 0 else 70)
                self.curves[i].setPen(pg.mkPen(col, width=1.3))
        self.bars.set_values(an.rel)
        self.c_ppg.sub_label.setText(f"{fmt(an.hr)} 次/分" if an.hr == an.hr else "")
        # trend
        if an.history:
            h = list(an.history)
            t = np.array([x[0] for x in h])
            rel = np.array([x[1] for x in h])
            emg = np.array([x[2] for x in h])
            tm = (t - t[-1]) / 60.0
            for k, c in self.trend_curves.items():
                c.setData(tm, _smooth(rel[:, dsp.BAND_KEYS.index(k)]))
            self.emg_curve.setData(tm, _smooth(emg))
        if an.hb is not None:
            t = an.hb[0]
            tm = (t - t[-1]) / 60.0
            for c, y in zip(self.hb_curves, an.hb[1:]):
                c.setData(tm, y)


def _smooth(y, k=5):
    if len(y) < k:
        return y
    kern = np.ones(k) / k
    pad = np.concatenate([np.full(k - 1, y[0]), y])
    return np.convolve(pad, kern, mode="valid")
