"""神经反馈训练 page: calibrate a brain metric on yourself, then raise a lantern over a night lake with it.

Protocols (Muse S Athena has TP9/AF7/AF8/TP10 only, so no SMR: that needs central electrodes C3/Cz/C4):
  alpha : alpha share = alpha / (theta + alpha + beta) on the ear sensors (TP9, TP10); higher is better.
  tbr   : log(theta / beta) on forehead + ear sensors; lower is better (sign flipped, so higher z = better).
Flow: calibration (1 min) -> N training blocks with rests -> results.
z = (value - calibration mean) / calibration sd, smoothed; the target line adapts so ~60-70 % of scored time
is above it. Moments with poor contact, muscle tension (dsp.emg_rms), head movement or blinks are not scored.
"""

from __future__ import annotations

import csv
import json
import math
import os
from datetime import datetime

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap,
                         QRadialGradient)
from PyQt6.QtWidgets import QCheckBox, QComboBox, QHBoxLayout, QPushButton, QSizePolicy, QSlider, QVBoxLayout, QWidget

from . import dsp
from . import theme as T
from .widgets import Card, StatTile, label, plot

# ----------------------------------------------------------------------------- protocol definitions
PROTOCOLS = {
    "alpha": {"name": "α 上调（放松）", "short": "α 上调", "chans": [0, 3], "min_ch": 1, "sign": 1.0,
              "sd_floor": 0.02, "metric": "alpha_share"},
    "tbr": {"name": "θ/β 降低（专注）", "short": "θ/β 降低", "chans": [0, 1, 2, 3], "min_ch": 2, "sign": -1.0,
            "sd_floor": 0.08, "metric": "log_theta_beta"},
}
PROTO_HELP = {
    "alpha": "耳后电极的 α 波占比升高时，灯笼往上飘。α 多见于放松、不用力、不追着念头走的时候。"
             "闭眼练时看不到画面，就听：雨声变小、听到清脆的“叮”说明做对了。",
    "tbr": "额头和耳后的 θ/β 比值降低时，灯笼往上飘。θ/β 低通常对应清醒、专注。"
           "睁眼看着灯笼，平静地专注（比如在心里慢慢数呼吸），不要皱眉、咬牙。",
}
SMR_NOTE = ("为什么没有 SMR 训练：SMR（12–15 Hz 感觉运动节律）要在头顶中央（C3、Cz、C4）测，"
            "Muse 只有额头和耳后的电极，测不到，所以不提供。")
EYES = [("闭眼（靠声音反馈）", "closed"), ("睁眼（看灯笼）", "open")]
PLANS = [("3 组 × 3 分钟", (3, 180)), ("2 组 × 3 分钟", (2, 180)), ("4 组 × 3 分钟", (4, 180)),
         ("3 组 × 5 分钟", (3, 300)), ("5 组 × 2 分钟", (5, 120))]
CALIB_S, REST_S, ADAPT_S = 60.0, 30.0, 30.0
CALIB_TRIES = 3                    # calibration attempts before giving up
TICK_MS, ANIM_MS = 500, 60
SMOOTH = 0.3                       # EMA weight of a new z value per tick (~1.5 s time constant)
TARGET_LO, TARGET_HI = 0.60, 0.70  # wanted share of scored time above the target line
THR_STEP = 0.02                    # z units per tick
REWARD_S = 2.0                     # seconds above the line for one reward
EMG_ABS = 10.0                     # uV rms (30-100 Hz) before calibration; relaxed is ~1-3 uV
MOTION_LIMIT = 12.0                # deg/s
SIDE = {0: "左耳后", 1: "左前额", 2: "右前额", 3: "右耳后"}
FIELDS = ["t", "phase", "block", "raw", "z", "zs", "thr", "above", "skip"]


def _fast() -> bool:
    return bool(os.environ.get("NB_TRAIN_FAST"))


def _muted() -> bool:
    return bool(os.environ.get("NB_MUTE"))


def level_of(z: float) -> float:
    """Screen height 0..1 for a z value (z = 0 -> middle)."""
    return 1.0 / (1.0 + math.exp(-1.1 * float(np.clip(z, -6, 6))))


def nf_metric(hub, analyzer, proto: str, chans: list, emg_limit: float = EMG_ABS):
    """One reading of the training metric from the last ~2 s.

    Returns (value, emg_rms_max, reason). value is None when the moment must not be scored; reason says why.
    When the stream has stopped (BLE drop), hub.latest still returns the last buffer; it must not be scored.
    """
    live = getattr(hub, "is_live", None)
    if callable(live) and not live():
        return None, None, "数据中断"
    eeg = hub.latest("EEG", 3.0)
    names = hub.names("EEG")
    if len(eeg) < dsp.FS_EEG * 2.5 or not all(n in names for n in dsp.EEG_NAMES):
        return None, None, "等待数据"
    bad = [c for c in chans if analyzer.quality.get(dsp.EEG_NAMES[c], (0, ""))[0] == 0]
    if bad:
        return None, None, "、".join(SIDE[c] for c in bad) + "接触不好"
    mot = getattr(analyzer, "motion", float("nan"))
    if mot == mot and mot > MOTION_LIMIT:
        return None, None, "头在动"
    X = eeg[:, 1:][:, [names.index(n) for n in dsp.EEG_NAMES]]
    pk, _ = dsp.detect_blinks(X)
    keep = ~dsp.blink_mask(len(X), pk)
    n2 = int(2 * dsp.FS_EEG)
    x = dsp.notch_only(X)[-n2:][:, chans]
    k = keep[-n2:]
    if k.mean() < 0.5:
        return None, None, "眨眼"
    rms = dsp.emg_rms(x[-int(dsp.FS_EEG):])
    emg = float(np.max(rms))
    if emg > emg_limit:
        return None, emg, "肌肉紧张（咬牙、皱眉）"
    _, absp, _ = dsp.band_powers(x[k])
    a = absp.mean(axis=0)                     # delta theta alpha beta gamma
    if proto == "alpha":
        v = a[2] / (a[1] + a[2] + a[3] + 1e-12)
    else:
        v = math.log((a[1] + 1e-12) / (a[3] + 1e-12))
    return float(v), emg, ""


def display_value(proto: str, v) -> str:
    if v is None or v != v:
        return "—"
    return f"α 占比 {v * 100:.0f}%" if proto == "alpha" else f"θ/β {math.exp(v):.2f}"


def training_history(pid: str | None = None, protocol: str | None = None, include_sim: bool = False) -> list:
    """Past training sessions of a person, oldest first: [{date, protocol, mean_z, success_pct, minutes, dir, ...}]."""
    from .people import mine
    from .session import list_sessions
    out = []
    for d, meta in list_sessions():
        nf = meta.get("neurofeedback")
        if not isinstance(nf, dict) or (meta.get("source") == "sim" and not include_sim):
            continue
        if not mine(meta, pid):
            continue
        if protocol and nf.get("protocol") != protocol:
            continue
        try:
            day = datetime.fromisoformat(meta["started_at"])
        except Exception:  # noqa: BLE001
            continue
        out.append({"date": day, "protocol": nf.get("protocol"), "mean_z": nf.get("mean_z"),
                    "success_pct": nf.get("success_pct"), "minutes": nf.get("minutes"),
                    "calib_mean": (nf.get("calibration") or {}).get("mean"), "dir": str(d)})
    return sorted(out, key=lambda r: r["date"])


# ----------------------------------------------------------------------------- sounds
def ensure_nf_sounds() -> dict:
    """Soft reward chime (generated once, next to the meditation sounds)."""
    from . import sounds as S
    S.CACHE.mkdir(parents=True, exist_ok=True)
    p = S.CACHE / "nf_reward_v1.wav"
    if not p.exists():
        t = np.arange(int(1.4 * S.SR)) / S.SR
        x = np.zeros_like(t)
        for f, a, t0 in ((659.3, 1.0, 0.0), (987.8, 0.8, 0.12)):     # E5 then B5, a gentle fifth
            tt = np.clip(t - t0, 0, None)
            env = (1 - np.exp(-tt / 0.012)) * np.exp(-tt * 3.2) * (t >= t0)
            x += a * env * (np.sin(2 * np.pi * f * tt) + 0.25 * np.sin(4 * np.pi * f * tt))
        S._write(p, 0.32 * x / np.max(np.abs(x)))
    return {"reward": p, "bell": S.ensure_sounds()["bell"]}


class NfSound:
    """Reward chime, start/end bell and (optionally) the rain bed from sounds.Soundscape.

    With NB_MUTE set nothing is created or played."""

    def __init__(self, reward: bool, rain: bool, volume: float):
        self.ok = False
        self.reward_on = reward
        self.scape = None
        self.n_rewards = 0
        if _muted():
            return
        try:
            from PyQt6.QtCore import QUrl
            from PyQt6.QtMultimedia import QSoundEffect
            files = ensure_nf_sounds()
            self.fx = {}
            for k, pth in files.items():
                e = QSoundEffect()
                e.setSource(QUrl.fromLocalFile(str(pth)))
                e.setVolume(0.0)
                self.fx[k] = e
            if rain:
                from .sounds import Soundscape
                self.scape = Soundscape()
            self.ok = True
            self.set_volume(volume)
        except Exception:  # noqa: BLE001
            self.ok = False

    def set_volume(self, v: float):
        self.volume = float(v)
        if self.scape is not None:
            self.scape.master = self.volume
            self.scape.set_level(self.scape.level)

    def start(self):
        if self.ok and self.scape is not None:
            self.scape.start()

    def level(self, good: float):
        """good 0..1: the rain gets quieter as the metric rises."""
        if self.ok and self.scape is not None:
            self.scape.set_level(1.0 - good)

    def reward(self):
        self.n_rewards += 1
        if self.ok and self.reward_on:
            e = self.fx["reward"]
            e.setVolume(0.5 * self.volume)
            e.play()

    def bell(self):
        if self.ok:
            e = self.fx["bell"]
            e.setVolume(0.6 * self.volume)
            e.play()

    def stop(self):
        if self.ok and self.scape is not None:
            self.scape.stop()


# ----------------------------------------------------------------------------- the visual game
class LanternLake(QWidget):
    """A paper lantern over a night lake; its height follows the smoothed z, a dashed line marks the target.

    Each reward lights one more star in the sky. The static scenery is cached in a pixmap; only the lantern,
    reflection, stars and sparks are drawn per frame, and the animation timer runs only during a session."""

    def __init__(self):
        super().__init__()
        self.setMinimumSize(360, 280)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.target = 0.0          # 0..1 wanted height
        self.shown = 0.0           # eased height on screen
        self.thr = None            # 0..1 height of the target line (None = hidden)
        self.above = False
        self.dim = False           # artifact: grey lantern
        self.banner = ""
        self.stars = 0
        self.sparks: list = []
        self.phase = 0.0
        self._bg = None
        rng = np.random.default_rng(5)
        self._star_pos = rng.uniform(0, 1, (80, 2))
        self._dust = rng.uniform(0, 1, (70, 3))
        self.anim = QTimer(self)
        self.anim.timeout.connect(self._step)

    # state from the page
    def set_state(self, target=None, thr=None, above=None, dim=None, banner=None):
        if target is not None:
            self.target = float(np.clip(target, 0, 1))
        if thr is not None:
            self.thr = None if thr is False else float(np.clip(thr, 0, 1))
        if above is not None:
            self.above = bool(above)
        if dim is not None:
            self.dim = bool(dim)
        if banner is not None:
            self.banner = banner
        if not self.anim.isActive():
            self.update()

    def reward(self):
        self.stars += 1
        cx, cy = self._lantern_xy()
        rng = np.random.default_rng(self.stars)
        for _ in range(16):
            a = rng.uniform(-math.pi, 0)
            s = rng.uniform(1.5, 4.0)
            self.sparks.append([cx, cy, s * math.cos(a), s * math.sin(a), 1.0])
        if not self.anim.isActive():
            self.update()

    def run(self, on: bool):
        if on and not self.anim.isActive():
            self.anim.start(ANIM_MS)
        elif not on:
            self.anim.stop()
            self.shown = self.target
            self.sparks.clear()
            self.update()

    def _step(self):
        self.phase += ANIM_MS / 1000.0
        self.shown += (self.target - self.shown) * 0.08
        for s in self.sparks:
            s[0] += s[2]
            s[1] += s[3]
            s[3] += 0.12
            s[4] -= 0.035
        self.sparks = [s for s in self.sparks if s[4] > 0]
        self.update()

    # geometry
    def _water(self):
        return self.height() * 0.74

    def _lantern_size(self):
        lw = max(26.0, min(self.width(), self.height()) * 0.085)
        return lw, lw * 1.3

    def _y_of(self, level):
        lw, lh = self._lantern_size()
        bottom = self._water() - lh * 0.55
        top = 52 + lh * 0.6                    # keep clear of the banner
        return bottom - level * (bottom - top)

    def _lantern_xy(self):
        return self.width() / 2 + 6 * math.sin(self.phase * 0.7), self._y_of(self.shown) + 2 * math.sin(self.phase * 1.3)

    def resizeEvent(self, e):
        self._bg = None
        super().resizeEvent(e)

    def _background(self):
        w, h = max(1, self.width()), max(1, self.height())
        pm = QPixmap(w, h)
        pm.fill(QColor(T.SURFACE))
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        wl = self._water()
        clip = QPainterPath()
        clip.addRoundedRect(QRectF(0, 0, w, h), 12, 12)
        p.setClipPath(clip)
        sky = QLinearGradient(0, 0, 0, wl)
        sky.setColorAt(0, QColor("#070b18"))
        sky.setColorAt(0.7, QColor("#141d3a"))
        sky.setColorAt(1, QColor("#243055"))
        p.fillRect(QRectF(0, 0, w, wl + 1), QBrush(sky))
        # faint background stars
        p.setPen(Qt.PenStyle.NoPen)
        for x, y, b in self._dust:
            c = QColor("#cbd5f5")
            c.setAlpha(int(30 + 70 * b))
            p.setBrush(c)
            p.drawEllipse(QPointF(x * w, y * wl * 0.75), 0.8 + b * 0.6, 0.8 + b * 0.6)
        # moon
        mc = QPointF(w * 0.82, wl * 0.2)
        glow = QRadialGradient(mc, 70)
        glow.setColorAt(0, QColor(255, 244, 214, 70))
        glow.setColorAt(1, QColor(255, 244, 214, 0))
        p.setBrush(QBrush(glow))
        p.drawEllipse(mc, 70, 70)
        p.setBrush(QColor("#f5ecd4"))
        p.drawEllipse(mc, 16, 16)
        # two mountain layers
        for k, (col, base, amp, f1, f2, ph) in enumerate((("#1a2342", 0.62, 0.22, 0.006, 0.017, 0.4),
                                                          ("#10172c", 0.78, 0.16, 0.011, 0.023, 2.1))):
            path = QPainterPath(QPointF(0, wl))
            for x in range(0, w + 9, 8):
                y = wl * base - wl * amp * (0.55 + 0.3 * math.sin(x * f1 + ph) + 0.15 * math.sin(x * f2 + 3 * ph))
                path.lineTo(x, min(wl, y))
            path.lineTo(w, wl)
            path.closeSubpath()
            p.fillPath(path, QColor(col))
        # water
        water = QLinearGradient(0, wl, 0, h)
        water.setColorAt(0, QColor("#16213d"))
        water.setColorAt(1, QColor("#060a14"))
        p.fillRect(QRectF(0, wl, w, h - wl), QBrush(water))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1))
        p.drawLine(QPointF(0, wl), QPointF(w, wl))
        p.end()
        return pm

    def paintEvent(self, _):
        if self._bg is None or self._bg.size() != self.size():
            self._bg = self._background()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.drawPixmap(0, 0, self._bg)
        w, h = self.width(), self.height()
        wl = self._water()
        # reward stars
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(min(self.stars, len(self._star_pos))):
            x, y = self._star_pos[i]
            tw = 0.75 + 0.25 * math.sin(self.phase * 2.0 + i * 1.7)
            c = QPointF(w * (0.05 + 0.9 * x), wl * (0.05 + 0.4 * y))
            g = QRadialGradient(c, 9)
            g.setColorAt(0, QColor(255, 236, 170, int(200 * tw)))
            g.setColorAt(1, QColor(255, 236, 170, 0))
            p.setBrush(QBrush(g))
            p.drawEllipse(c, 9, 9)
            p.setBrush(QColor(255, 250, 225, int(255 * tw)))
            p.drawEllipse(c, 1.8, 1.8)
        # target line
        if self.thr is not None:
            yt = self._y_of(self.thr)
            pen = QPen(QColor(253, 230, 138, 120), 1.2, Qt.PenStyle.DashLine)
            p.setPen(pen)
            p.drawLine(QPointF(16, yt), QPointF(w - 16, yt))
            p.setFont(QFont(T.FONT, 9))
            p.setPen(QColor(253, 230, 138, 170))
            p.drawText(QRectF(18, yt - 20, 80, 18), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "目标线")
        # lantern colours
        cx, cy = self._lantern_xy()
        lw, lh = self._lantern_size()
        if self.dim:
            body0, body1, glow_c, ga = QColor("#64748b"), QColor("#334155"), QColor(148, 163, 184), 40
        elif self.above:
            body0, body1, glow_c, ga = QColor("#ffd27a"), QColor("#f97316"), QColor(255, 196, 92), 150
        else:
            body0, body1, glow_c, ga = QColor("#f4a261"), QColor("#c2410c"), QColor(255, 170, 80), 80
        # reflection on the water
        ry = min(wl + (wl - cy) * 0.35 + 6, h - lh * 1.6)
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(7):
            yy = ry - lh * 0.6 + i * lh * 0.22
            if yy <= wl + 2:
                continue
            wob = 5 * math.sin(self.phase * 2.2 + i * 1.3)
            c = QColor(glow_c)
            c.setAlpha(max(0, int(ga * 0.6 * (1 - i / 7))))
            p.setBrush(c)
            p.drawRoundedRect(QRectF(cx - lw * 0.45 + wob, yy, lw * 0.9, 2.5), 1.2, 1.2)
        # glow
        g = QRadialGradient(QPointF(cx, cy), lw * 2.6)
        gc = QColor(glow_c)
        gc.setAlpha(ga)
        g.setColorAt(0, gc)
        gc.setAlpha(0)
        g.setColorAt(1, gc)
        p.setBrush(QBrush(g))
        p.drawEllipse(QPointF(cx, cy), lw * 2.6, lw * 2.6)
        # body
        body = QLinearGradient(cx - lw / 2, 0, cx + lw / 2, 0)
        body.setColorAt(0, body1)
        body.setColorAt(0.45, body0)
        body.setColorAt(1, body1)
        path = QPainterPath()
        path.addRoundedRect(QRectF(cx - lw / 2, cy - lh / 2, lw, lh), lw * 0.38, lw * 0.38)
        p.fillPath(path, QBrush(body))
        p.setPen(QPen(QColor(0, 0, 0, 40), 1))
        for fx in (-0.22, 0.0, 0.22):                        # paper ribs
            p.drawLine(QPointF(cx + fx * lw, cy - lh * 0.44), QPointF(cx + fx * lw, cy + lh * 0.44))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#3b2416"))
        p.drawRoundedRect(QRectF(cx - lw * 0.3, cy - lh / 2 - 4, lw * 0.6, 6), 2, 2)
        p.drawRoundedRect(QRectF(cx - lw * 0.3, cy + lh / 2 - 2, lw * 0.6, 6), 2, 2)
        if not self.dim:                                     # flame core
            fl = QRadialGradient(QPointF(cx, cy + lh * 0.12), lw * 0.3)
            fl.setColorAt(0, QColor(255, 255, 230, 230))
            fl.setColorAt(1, QColor(255, 255, 230, 0))
            p.setBrush(QBrush(fl))
            p.drawEllipse(QPointF(cx, cy + lh * 0.12), lw * 0.3, lw * 0.3)
        # sparks
        for x, y, _, _, life in self.sparks:
            p.setBrush(QColor(255, 226, 150, int(230 * life)))
            p.drawEllipse(QPointF(x, y), 2.2 * life + 0.5, 2.2 * life + 0.5)
        # banner
        if self.banner:
            p.setFont(QFont(T.FONT, 11))
            fm = p.fontMetrics()
            bw = fm.horizontalAdvance(self.banner) + 28
            r = QRectF((w - bw) / 2, 12, bw, 28)
            p.setBrush(QColor(15, 23, 42, 200))
            p.setPen(QPen(QColor(T.BORDER), 1))
            p.drawRoundedRect(r, 14, 14)
            p.setPen(QColor(T.TEXT))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, self.banner)
        p.end()


# ----------------------------------------------------------------------------- the page
class TrainPage(QWidget):
    """Neurofeedback training. start_recording(name, protocol) -> bool and stop_recording() are provided
    by the main window (they start / stop a recording that sets hub.recorder)."""

    finished = pyqtSignal(str)          # session folder after a run ended with results

    def __init__(self, hub, analyzer, start_recording, stop_recording):
        super().__init__()
        self.hub, self.an = hub, analyzer
        self._start_rec, self._stop_rec = start_recording, stop_recording
        self.state = "idle"             # idle | calib | block | rest | done
        self.sound = None
        self.rec = None
        self.rec_dir = None
        self.summary = None
        root = QHBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        # ---------------- settings
        left = Card("神经反馈训练")
        left.setFixedWidth(320)
        left.add(label("练什么", "muted"))
        self.cb_proto = QComboBox()
        for k, d in PROTOCOLS.items():
            self.cb_proto.addItem(d["name"], k)
        left.add(self.cb_proto)
        self.l_eyes = label("眼睛", "muted")
        left.add(self.l_eyes)
        self.cb_eyes = QComboBox()
        for t, k in EYES:
            self.cb_eyes.addItem(t, k)
        left.add(self.cb_eyes)
        left.add(label("组数和时长（每组之间休息 30 秒）", "muted"))
        self.cb_plan = QComboBox()
        for t, v in PLANS:
            self.cb_plan.addItem(t, v)
        left.add(self.cb_plan)
        self.chk_reward = QCheckBox("奖励音（做对 2 秒“叮”一声）")
        self.chk_reward.setChecked(True)
        left.add(self.chk_reward)
        self.chk_rain = QCheckBox("背景雨声（越好雨越小）")
        left.add(self.chk_rain)
        self.chk_voice = QCheckBox("语音提示每一组开始和结束")
        self.chk_voice.setChecked(True)
        left.add(self.chk_voice)
        left.add(label("音量", "muted"))
        self.sl_vol = QSlider(Qt.Orientation.Horizontal)
        self.sl_vol.setRange(0, 100)
        self.sl_vol.setValue(70)
        self.sl_vol.valueChanged.connect(lambda v: self.sound and self.sound.set_volume(0.0 if _muted() else v / 100))
        left.add(self.sl_vol)
        self.l_help = label("", "faint", wrap=True)
        left.add(self.l_help)
        left.add(label(SMR_NOTE, "faint", wrap=True))
        left.add(label("这是练习工具，不是治疗。", "faint", wrap=True))
        left.lay.addStretch(1)
        self.b_start = QPushButton("开始训练")
        self.b_start.setObjectName("primary")
        self.b_start.clicked.connect(self.start)
        left.add(self.b_start)
        self.b_stop = QPushButton("提前结束")
        self.b_stop.setObjectName("danger")
        self.b_stop.clicked.connect(lambda: self.finish(early=True))
        self.b_stop.setVisible(False)
        left.add(self.b_stop)
        root.addWidget(left)
        self.cb_proto.currentIndexChanged.connect(self._proto_changed)
        self.cb_eyes.currentIndexChanged.connect(self._proto_changed)

        # ---------------- game + timeline
        mid = QVBoxLayout()
        mid.setSpacing(14)
        main = Card()
        self.l_phase = label("准备好后点「开始训练」", "h1")
        self.l_phase.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main.add(self.l_phase)
        self.game = LanternLake()
        main.add(self.game, 1)
        self.l_hint = label("先校准 1 分钟，程序记住你平时的水平；之后灯笼的高低都是和你自己比。", "muted", wrap=True)
        self.l_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main.add(self.l_hint)
        mid.addWidget(main, 3)
        tl = Card("过程", "青线=你的表现（0=校准时的平均）  黄虚线=目标线")
        self.p_tl = plot(bottom="分钟")
        self.p_tl.setYRange(-3, 3)
        self.p_tl.getPlotItem().getAxis("left").setTicks([[(-2, "低于平时"), (0, "平时"), (2, "高于平时")]])
        self.curve = self.p_tl.plot(pen=pg.mkPen(T.ACCENT, width=2), connect="finite")
        self.curve_thr = self.p_tl.plot(pen=pg.mkPen("#fde68a", width=1, style=Qt.PenStyle.DashLine), connect="finite")
        tl.add(self.p_tl, 1)
        mid.addWidget(tl, 2)
        mw = QWidget()
        mw.setLayout(mid)
        root.addWidget(mw, 1)

        # ---------------- tiles + history
        right = QVBoxLayout()
        right.setSpacing(12)
        self.t_now = StatTile("当前", "", T.ACCENT)
        self.t_rate = StatTile("本组达标", "%", T.GOOD)
        self.t_reward = StatTile("奖励", "次", "#fde68a")
        self.t_thr = StatTile("目标线", "", T.ACCENT2)
        for t in (self.t_now, self.t_rate, self.t_reward, self.t_thr):
            right.addWidget(t)
        hist = Card("以往训练", "")
        self.c_hist = hist
        self.p_hist = plot(left="平均表现")
        self.p_hist.setMinimumHeight(140)
        hist.add(self.p_hist, 1)
        self.l_hist = label("", "faint", wrap=True)
        hist.add(self.l_hist)
        right.addWidget(hist, 1)
        rw = QWidget()
        rw.setLayout(right)
        rw.setFixedWidth(270)
        root.addWidget(rw)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self._proto_changed()
        self._reset_tiles()

    # ------------------------------------------------------------------ small helpers
    def _proto_changed(self, *_):
        proto = self.cb_proto.currentData()
        alpha = proto == "alpha"
        self.l_eyes.setVisible(alpha)
        self.cb_eyes.setVisible(alpha)
        self.l_help.setText(PROTO_HELP[proto])
        if self.state in ("idle", "done"):
            self.chk_rain.setChecked(alpha and self.cb_eyes.currentData() == "closed")
            self.refresh_history()

    def _say(self, text):
        if self.chk_voice.isChecked() and not _muted():
            from .protocols import speak
            speak(text)

    def _reset_tiles(self):
        for t in (self.t_now, self.t_rate, self.t_reward, self.t_thr):
            t.set("—", "")

    def is_running(self) -> bool:
        return self.state in ("calib", "block", "rest")

    def abort(self):
        """Stop a running session (e.g. the app is closing); results so far are saved."""
        self.finish(early=True)

    @staticmethod
    def _current_pid():
        try:
            from .people import current
            return current()
        except Exception:  # noqa: BLE001
            return None

    def showEvent(self, e):
        super().showEvent(e)
        if not self.is_running():                      # the wearer may have changed while the page was hidden
            self.refresh_history()

    # ------------------------------------------------------------------ history
    def refresh_history(self, include_sim: bool | None = None):
        """Redraw the history card for the current person (also called by the main window on a person switch).

        While idle/done, results of a run by a different person are cleared from the page."""
        try:
            self._refresh_history(include_sim)
        except Exception:  # noqa: BLE001
            pass

    def _clear_previous_wearer(self):
        if self.state != "done" or getattr(self, "_run_pid", None) in (None, self._current_pid()):
            return
        self.state = "idle"
        self.summary = None
        self._reset_tiles()
        self.curve.setData([], [])
        self.curve_thr.setData([], [])
        self.game.stars = 0
        self.game.set_state(target=0.0, thr=False, above=False, dim=False, banner="")
        self.b_start.setText("开始训练")
        self.l_phase.setText("准备好后点「开始训练」")
        self.l_hint.setText("先校准 1 分钟，程序记住你平时的水平；之后灯笼的高低都是和你自己比。")

    def _refresh_history(self, include_sim):
        from .people import current, name_of
        if not self.is_running():
            self._clear_previous_wearer()
        proto = self.cb_proto.currentData()
        if include_sim is None:
            include_sim = bool(os.environ.get("NB_TRAIN_SHOW_SIM"))
        rows = [r for r in training_history(current(), proto, include_sim) if r["mean_z"] is not None][-20:]
        self.p_hist.clear()
        self.c_hist.sub_label.setText(f"{name_of(current())} · {PROTOCOLS[proto]['short']}")
        if not rows:
            self.l_hist.setText("还没有这一项的训练记录。练完一次后，这里会显示每次的平均表现。")
            return
        x = np.arange(len(rows))
        z = np.array([r["mean_z"] for r in rows], float)
        brushes = [pg.mkBrush(T.GOOD if v > 0 else T.FAINT) for v in z]
        self.p_hist.addItem(pg.BarGraphItem(x=x, height=z, width=0.6, brushes=brushes, pen=pg.mkPen(None)))
        self.p_hist.addItem(pg.InfiniteLine(pos=0, angle=0, pen=pg.mkPen(T.BORDER)))
        step = max(1, len(rows) // 5)
        self.p_hist.getPlotItem().getAxis("bottom").setTicks(
            [[(i, f"{rows[i]['date'].month}/{rows[i]['date'].day}") for i in range(0, len(rows), step)]])
        last = rows[-1]
        txt = (f"共 {len(rows)} 次。最近一次 {last['date']:%m/%d}：平均 {last['mean_z']:+.2f}，"
               f"达标 {last['success_pct'] or 0:.0f}%，练了 {last['minutes'] or 0:.1f} 分钟。")
        cal = [r["calib_mean"] for r in rows if r["calib_mean"] is not None]
        if len(cal) >= 2:
            txt += f"\n校准水平：第一次 {display_value(proto, cal[0])} → 最近 {display_value(proto, cal[-1])}。"
        txt += "\n柱子高于 0 = 训练时比当天校准时更好。"
        self.l_hist.setText(txt)

    # ------------------------------------------------------------------ flow
    def start(self):
        if self.is_running():
            return
        if not self.hub.is_live():
            self.l_hint.setText("还没有数据：先连接头环（或右上角「···」打开演示模式）。")
            return
        if self.hub.recorder is not None:
            self.l_hint.setText("正在录制别的内容，先停止那边的录制。")
            return
        self.proto = self.cb_proto.currentData()
        P = PROTOCOLS[self.proto]
        self.eyes = self.cb_eyes.currentData() if self.proto == "alpha" else "open"
        chans = [c for c in P["chans"] if self.an.quality.get(dsp.EEG_NAMES[c], (0, ""))[0] > 0]
        if len(chans) < P["min_ch"]:
            need = "耳后" if self.proto == "alpha" else "额头和耳后"
            self.l_hint.setText(f"{need}的电极接触不好（看「实时」页的电极图），调整好再开始。")
            return
        self.chans = chans
        self.n_blocks, self.block_s = self.cb_plan.currentData()
        self.calib_s, self.rest_s, self.adapt_s = CALIB_S, REST_S, ADAPT_S
        if _fast():                                     # automated tests only
            self.calib_s, self.block_s, self.rest_s, self.adapt_s = 10.0, 10.0, 4.0, 5.0
        name = f"神经反馈 {P['short']} {datetime.now():%m-%d %H%M}"
        try:
            ok = bool(self._start_rec(name, "神经反馈训练"))
        except Exception:  # noqa: BLE001
            ok = False
        rec = self.hub.recorder
        if not ok or rec is None:
            self.l_hint.setText("无法开始录制，训练没有开始。")
            if ok:
                self._safe_stop()
            return
        self.rec, self.rec_dir = rec, rec.dir
        self.rows, self.blocks, self.calib, self.calib_emg = [], [], [], []
        self.scored = []                                # (elapsed, above) over all blocks, for the adaptation
        self.z = None
        self.thr = 0.0
        self.thr_start = None
        self.mu = self.sd = None
        self.emg_limit = EMG_ABS
        self.block_i = 0
        self.above_run = 0.0
        self.rewards = 0
        self.summary = None
        self.calib_tries = 0
        self._run_pid = self._current_pid()
        t0 = getattr(rec, "t_start", None)                # the recording's own clock, so rows match markers
        self.t_begin = float(t0) if isinstance(t0, (int, float)) and t0 == t0 else self.hub.now()
        vol = 0.0 if _muted() else self.sl_vol.value() / 100
        self.sound = NfSound(self.chk_reward.isChecked(), self.chk_rain.isChecked(), vol)
        self.game.stars = 0
        self.game.set_state(target=0.0, thr=False, above=False, dim=False, banner="")
        self.game.run(True)
        self.curve.setData([], [])
        self.curve_thr.setData([], [])
        self._reset_tiles()
        for w in (self.cb_proto, self.cb_eyes, self.cb_plan, self.chk_reward, self.chk_rain):
            w.setEnabled(False)
        self.b_start.setVisible(False)
        self.b_stop.setVisible(True)
        self._enter("calib")
        self.timer.start(TICK_MS)

    def _safe_stop(self):
        try:
            self._stop_rec()
        except Exception:  # noqa: BLE001
            pass

    def _marker(self, text):
        try:
            if self.hub.recorder is self.rec and self.rec is not None:
                self.rec.add_marker(text, "segment")
        except Exception:  # noqa: BLE001
            pass

    def _enter(self, phase):
        self.state = phase
        self.t_phase0 = self.hub.now()
        closed = self.eyes == "closed"
        if phase == "calib":
            self.calib, self.calib_emg = [], []
            self._marker("校准")
            self.l_phase.setText("校准中")
            self.l_hint.setText(("闭上眼睛，放松地坐着，" if closed else "睁眼看着画面，放松地坐着，")
                                + "这一分钟不用刻意做什么，程序在认识你平时的样子。")
            self._say("开始校准。" + ("请闭上眼睛，" if closed else "") + "放松地坐一分钟。")
            self.game.set_state(target=0.0, thr=False, banner="校准中")
        elif phase == "block":
            self.block_i += 1
            self._marker(f"训练·第{self.block_i}组")
            self.cur = {"zs": [], "z": [], "above": 0, "n": 0, "skip": 0, "ticks": 0, "rewards": 0, "raw": []}
            self.z = None
            self.above_run = 0.0
            self.l_phase.setText(f"训练 · 第 {self.block_i}/{self.n_blocks} 组")
            self.l_hint.setText("让灯笼飘过目标线。" + ("闭着眼听：雨小了、听到“叮”就是做对了。" if closed else
                                                         "不用使劲，找到那种感觉后保持住。"))
            if self.sound:
                self.sound.bell()
                if self.block_i == 1:
                    self.sound.start()
            self._say(f"第{self.block_i}组开始。" + ("请闭上眼睛。" if closed else ""))
            self.game.set_state(thr=level_of(self.thr), banner="")
        elif phase == "rest":
            self._marker(f"休息·第{self.block_i}次")
            self.l_phase.setText("休息一下")
            self.l_hint.setText("可以睁眼、眨眨眼、动一动脖子。下一组马上开始。")
            if self.sound:
                self.sound.bell()
                self.sound.level(0.5)
            self._say("休息一下。")
            self.game.set_state(target=0.0, thr=False, above=False, dim=False, banner="休息")

    def tick(self):
        if not self.is_running():
            self.timer.stop()
            return
        if self.hub.recorder is not self.rec:            # recording stopped elsewhere (disconnect, battery)
            self.finish(early=True)
            return
        now = self.hub.now()
        el = now - self.t_phase0
        P = PROTOCOLS[self.proto]
        t_rec = round(now - self.t_begin, 2)
        if self.state == "rest":
            left = max(0.0, self.rest_s - el)
            self.t_now.set(f"{left:.0f}", "秒后开始下一组")
            if el >= self.rest_s:
                self._enter("block")
            return
        v, emg, why = nf_metric(self.hub, self.an, self.proto, self.chans, self.emg_limit)
        if self.state == "calib":
            if v is not None:
                self.calib.append(v)
                self.calib_emg.append(emg)
            left = max(0.0, self.calib_s - el)
            self.t_now.set(f"{left:.0f}", "秒（校准）")
            self.game.set_state(banner=f"校准中 · 还有 {left:.0f} 秒" + (f" · {why}" if why else ""))
            self.rows.append({"t": t_rec, "phase": "calib", "block": 0, "raw": v, "z": "", "zs": "", "thr": "",
                              "above": "", "skip": why})
            if el >= self.calib_s:
                need = 5 if _fast() else 30
                if len(self.calib) < need:
                    self.calib_tries += 1
                    if self.calib_tries >= CALIB_TRIES:
                        self.finish(early=True, reason=(
                            f"校准试了 {CALIB_TRIES} 次，有效数据都太少（电极没贴好、一直在动、咬牙或数据中断），"
                            "训练没有开始。调整好头环、看「实时」页的电极图都正常后再试。"))
                        return
                    self._enter("calib")         # sets its own hint, so the retry note goes after it
                    self.l_hint.setText(f"校准时有效数据太少（电极没贴好、一直在动或咬牙），再校准一次"
                                        f"（第 {self.calib_tries + 1}/{CALIB_TRIES} 次）。")
                    return
                c = np.array(self.calib)
                self.mu = float(np.mean(c))
                self.sd = max(float(np.std(c)), P["sd_floor"])
                self.emg_limit = float(np.clip(3.0 * np.median(self.calib_emg), 6.0, 15.0))
                zc = P["sign"] * (c - self.mu) / self.sd
                sm, s = [], zc[0]
                for q in zc:
                    s = (1 - SMOOTH) * s + SMOOTH * q
                    sm.append(s)
                self.thr = self.thr_start = float(np.clip(np.percentile(sm, 35), -1.0, 1.0))
                self._enter("block")
            return
        # ---------------- training block
        b = self.cur
        b["ticks"] += 1
        dt = TICK_MS / 1000.0
        if v is None:
            b["skip"] += 1
            self.above_run = 0.0
            self.game.set_state(dim=True, banner="干扰，暂停计分" + (f"（{why}）" if why else ""))
            self.t_now.set("—", why or "暂停计分")
            if self.sound:
                self.sound.level(0.5)
            self.rows.append({"t": t_rec, "phase": "block", "block": self.block_i, "raw": "", "z": "", "zs": "",
                              "thr": round(self.thr, 3), "above": "", "skip": why})
        else:
            zz = P["sign"] * (v - self.mu) / self.sd
            self.z = zz if self.z is None else (1 - SMOOTH) * self.z + SMOOTH * zz
            above = self.z > self.thr
            b["n"] += 1
            b["above"] += int(above)
            b["z"].append(zz)
            b["zs"].append(self.z)
            b["raw"].append(v)
            self.scored.append((now, above))
            # adapt the target so ~60-70 % of the recent scored time is above it
            recent = [a for t, a in self.scored if t >= now - self.adapt_s]
            if len(recent) >= (4 if _fast() else 10):
                rate = float(np.mean(recent))
                if rate > TARGET_HI:
                    self.thr += THR_STEP
                elif rate < TARGET_LO:
                    self.thr -= THR_STEP
                self.thr = float(np.clip(self.thr, -1.5, 2.5))
            if above:
                self.above_run += dt
                if self.above_run >= REWARD_S:
                    self.above_run = 0.0
                    self.rewards += 1
                    b["rewards"] += 1
                    self.game.reward()
                    if self.sound:
                        self.sound.reward()
            else:
                self.above_run = 0.0
            lv = level_of(self.z)
            self.game.set_state(target=lv, thr=level_of(self.thr), above=above, dim=False, banner="")
            if self.sound:
                self.sound.level(lv)
            self.t_now.set(f"{self.z:+.2f}", display_value(self.proto, v), T.GOOD if above else T.ACCENT)
            self.rows.append({"t": t_rec, "phase": "block", "block": self.block_i, "raw": round(v, 5),
                              "z": round(zz, 3), "zs": round(self.z, 3), "thr": round(self.thr, 3),
                              "above": int(above), "skip": ""})
        rate = b["above"] / b["n"] * 100 if b["n"] else 0.0
        self.t_rate.set(f"{rate:.0f}" if b["n"] else "—", f"第 {self.block_i} 组 · 目标 60–70%")
        self.t_reward.set(str(self.rewards), "高于目标线满 2 秒得一次")
        self.t_thr.set(f"{self.thr:+.2f}", "会自动调整，让你大约六成多的时间达标")
        if b["ticks"] % 2 == 0:
            self._plot_timeline()
        if el >= self.block_s:
            self._close_block()
            if self.block_i >= self.n_blocks:
                self.finish()
            else:
                self._enter("rest")

    def _plot_timeline(self):
        tt, zs, th = [], [], []
        last_b = None
        for r in self.rows:
            if r["phase"] != "block":
                continue
            if last_b is not None and r["block"] != last_b:
                tt.append(np.nan), zs.append(np.nan), th.append(np.nan)
            last_b = r["block"]
            tt.append(r["t"] / 60)
            zs.append(np.nan if r["zs"] == "" else float(np.clip(r["zs"], -3, 3)))
            th.append(float(r["thr"]))
        if tt:
            self.curve.setData(np.array(tt), np.array(zs))
            self.curve_thr.setData(np.array(tt), np.array(th))

    def _close_block(self):
        b = getattr(self, "cur", None)
        if not b or b.get("closed"):
            return
        b["closed"] = True
        if b["n"] == 0 and b["ticks"] < 4:
            return
        self.blocks.append({
            "label": f"训练·第{self.block_i}组",
            "mean_z": round(float(np.mean(b["z"])), 3) if b["z"] else None,
            "success_pct": round(b["above"] / b["n"] * 100, 1) if b["n"] else None,
            "mean_raw": round(float(np.mean(b["raw"])), 5) if b["raw"] else None,
            "scored_s": round(b["n"] * TICK_MS / 1000, 1),
            "skipped_pct": round(b["skip"] / max(1, b["ticks"]) * 100, 1),
            "rewards": b["rewards"],
            "threshold_end": round(self.thr, 3),
            "seconds": round(b["ticks"] * TICK_MS / 1000, 1),
        })

    def _build_summary(self, early: bool):
        good = [b for b in self.blocks if b["mean_z"] is not None]
        if not good:
            return None
        n_all = sum(b["scored_s"] for b in good)
        mean_z = sum(b["mean_z"] * b["scored_s"] for b in good) / n_all if n_all else None
        succ = sum((b["success_pct"] or 0) * b["scored_s"] for b in good) / n_all if n_all else None
        P = PROTOCOLS[self.proto]
        return {
            "protocol": self.proto, "protocol_name": P["name"], "metric": P["metric"],
            "eyes": self.eyes, "channels": [dsp.EEG_NAMES[c] for c in self.chans],
            "calibration": {"mean": round(self.mu, 5), "sd": round(self.sd, 5), "n": len(self.calib),
                            "seconds": self.calib_s},
            "blocks": self.blocks,
            "mean_z": None if mean_z is None else round(mean_z, 3),
            "success_pct": None if succ is None else round(succ, 1),
            "threshold": round(self.thr, 3), "threshold_start": round(self.thr_start, 3),
            "rewards": self.rewards,
            "minutes": round(sum(b["seconds"] for b in self.blocks) / 60, 2),
            "total_minutes": round((self.hub.now() - self.t_begin) / 60, 2),
            "planned_blocks": self.n_blocks, "block_seconds": self.block_s, "rest_seconds": self.rest_s,
            "done_blocks": len(self.blocks), "early": early, "fast_test": _fast(),
            "emg_limit_uv": round(self.emg_limit, 2),
            "how": "z = 当次值减去校准平均再除以校准标准差（θ/β 取反号）；达标 = 平滑后的 z 高于目标线",
        }

    def _write_results(self, summary):
        d = self.rec_dir
        if d is None:
            return False
        try:
            (d / "train_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
            with open(d / "neurofeedback.csv", "w", encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
                w.writeheader()
                w.writerows(self.rows)
            from .session import save_meta
            p = d / "session.json"
            meta = json.loads(p.read_text(encoding="utf-8"))
            meta["neurofeedback"] = summary
            save_meta(d, meta)
            return True
        except Exception:  # noqa: BLE001
            return False

    def finish(self, early: bool = False, reason: str | None = None) -> bool:
        """End the run. Safe to call from outside at any time (before a disconnect / battery stop, on close):
        does nothing when no run is going; otherwise stops the recording and writes train_summary.json,
        neurofeedback.csv and session.json['neurofeedback'] synchronously before returning.
        Returns True when results were written."""
        if not self.is_running():
            return False
        was_block = self.state == "block"
        self.state = "done"                              # first, so a re-entrant call (stop callback) is a no-op
        self.timer.stop()
        summary, saved = None, False
        try:
            if was_block:
                self._close_block()
            if self.hub.recorder is self.rec and self.rec is not None:
                self._safe_stop()
            summary = self._build_summary(early)
            saved = bool(summary) and self._write_results(summary)
        except Exception:  # noqa: BLE001
            pass
        self.summary = summary
        try:
            self._finish_ui(summary, saved, reason)
        except Exception:  # noqa: BLE001
            pass
        if summary and saved:
            self.finished.emit(str(self.rec_dir))
        return saved

    def _finish_ui(self, summary, saved, reason):
        self.game.run(False)
        if self.sound:
            self.sound.bell()
            self.sound.stop()
        self._say("训练结束。")
        self.b_start.setVisible(True)
        self.b_start.setText("再练一次")
        self.b_stop.setVisible(False)
        for w in (self.cb_proto, self.cb_eyes, self.cb_plan, self.chk_reward, self.chk_rain):
            w.setEnabled(True)
        self._plot_timeline()
        if summary:
            self.l_phase.setText("完成")
            per = " · ".join(f"第{i + 1}组 {b['mean_z']:+.2f}（{b['success_pct']:.0f}%）"
                             for i, b in enumerate(self.blocks) if b["mean_z"] is not None)
            self.l_hint.setText(f"{per}\n平均 {summary['mean_z']:+.2f} 表示比校准时好（正数）还是差（负数）。"
                                + ("结果已保存，「回看」里也能看到每一组。" if saved else "结果没能写进录制文件夹。"))
            self.t_now.set(f"{summary['mean_z']:+.2f}", "全部组的平均表现", T.GOOD if summary["mean_z"] > 0 else T.ACCENT)
            self.t_rate.set(f"{summary['success_pct']:.0f}", "全部组的达标时间")
            self.t_reward.set(str(self.rewards), "")
            self.t_thr.set(f"{self.thr:+.2f}", f"开始时 {self.thr_start:+.2f}")
            self.game.set_state(banner=f"完成 · 点亮了 {self.rewards} 颗星", thr=False, dim=False)
        else:
            self.l_phase.setText("已结束")
            self.l_hint.setText(reason or "还没练完一组就结束了，这次不计成绩（录制仍然保存了）。")
            self.game.set_state(target=0.0, thr=False, dim=False, banner="")
        self.refresh_history()
