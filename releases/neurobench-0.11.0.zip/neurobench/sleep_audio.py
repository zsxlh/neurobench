"""Optional, opt-in sound during an overnight recording.

Two independent parts, both off unless the caller enables them:

Sleep assist
    A soft rain / pink-noise bed that fades in over 15 s, then fades out over 60 s once sleep onset is
    detected live and stays off (marker "助眠声音停止"). Onset rule (conservative, evaluated every 5 s on
    5-s epochs of the ear channels TP9/TP10):
      * awake reference = median band shares of the valid epochs in the first 5 min (extended up to
        15 min if contact was poor),
      * over the last 5 min (>= 80 % valid epochs), all relative to that reference so the rule works
        whatever the headset's baseline (real Muse ear channels: awake alpha share ~0.02-0.06, delta+theta
        share ~0.86-0.96; synthetic data: alpha ~0.3):
          - median alpha share <= 0.6 x reference alpha,
          - logit(median delta+theta share) >= logit(reference) + ln 2, i.e. the fast-to-slow power
            ratio has at least halved,
          - little motion (median gyro <= 1.5 deg/s, <= 10 % of epochs above 2 deg/s, none above
            3 deg/s in the last minute),
      * all of the above holding continuously for 60 s.
    Safety cap: if onset is never detected the bed fades out after 90 min anyway.

Closed-loop slow-wave cue (research mode)
    The mean of the good ear channels is band-passed causally (0.5-2 Hz, Butterworth, filter state kept
    between polls). A negative half-wave whose estimated duration is 0.25-1.0 s and whose trough is
    below -thr (thr = max(40 uV, 0.75 x the 75th percentile of recent troughs), capped at 120 uV) is a
    slow oscillation. It is confirmed when the signal has risen half-way back from the trough, and a
    50 ms pink-noise burst is scheduled for trough + 0.5 s (the up-state), minus the expected audio
    output latency. A cue whose time has passed by more than 60 ms when it is due (UI stall) is skipped
    and counted as blocked_late, never played late. Cues only while the live stage looks like deep sleep
    (>= 22 of the last 24 epochs with high delta share -- logit(delta) >= logit(reference delta) + 1,
    at least 0.7 -- low muscle activity and little motion; no head movement for 2 min), never
    within 30 s of a motion or muscle (EMG) burst. Cues come in pairs at most (Ngo et al. 2013 style):
    the first SO of a train gets a cue, the next SO within 2 s gets the second, then a 2.5 s refractory
    period starts before a new train can begin. Every burst adds the marker "慢波提示音".

Audio: WAVs are generated in memory and written to a private temp folder (QSoundEffect only plays
URLs); the folder is removed on stop(). NB_MUTE=1: nothing is played, everything else runs.

Not validated against polysomnography; meant for self-experiments.
"""

from __future__ import annotations

import io
import os
import shutil
import tempfile
import wave
from collections import deque
from pathlib import Path
from typing import Callable, Optional

import numpy as np
from scipy.signal import butter, lfilter, sosfilt, sosfilt_zi, welch

from . import dsp

SR = 22050

# ---------------------------------------------------------------- parameters
EPOCH_S = 5.0                 # live feature epoch
REF_S = 300.0                 # awake reference period
REF_MAX_S = 900.0             # reference may be extended this far if contact is poor
REF_MIN_EPOCHS = 30
ONSET_WIN_S = 300.0           # onset rule window
ONSET_HOLD_S = 60.0           # rule must hold this long
ALPHA_FACTOR = 0.6            # onset: alpha share <= this x awake reference
SLOW_LOGIT_MARGIN = float(np.log(2.0))   # onset: fast/slow power ratio at most half the awake one
DEEP_DELTA_LOGIT = 1.0        # deep: delta odds >= e x awake reference odds
DEEP_DELTA_MIN = 0.7          # ... and delta share never below this
SHARE_EPS = 1e-3              # shares are clipped to [eps, 1 - eps] before the logit
MOTION_EPOCH_MED = 1.5        # deg/s
MOTION_EVENT = 2.0            # deg/s, 1-s window: "the head moved"
MOTION_BIG = 3.0
FADE_IN_S = 15.0
FADE_OUT_S = 60.0
ASSIST_MAX_S = 90 * 60.0

SO_BAND = (0.5, 2.0)
SO_THR_MIN = 40.0             # uV
SO_THR_MAX = 120.0
SO_ART = 300.0                # filtered trough beyond this = artefact
SO_HALF_MIN, SO_HALF_MAX = 0.25, 1.0
CUE_DELAY = 0.5               # s after the trough
TRAIN_GAP = 2.0               # next SO within this -> same train
REFRACTORY = 2.5              # s after a train's last cue
LOCKOUT_S = 30.0              # after motion / EMG burst / artefact
DEEP_QUIET_S = 120.0          # no head movement for this long before cueing
DEEP_EPOCHS, DEEP_MIN_OK = 24, 22
CUE_LEN_S = 0.05
CUE_LATE_S = 0.06             # a cue more than this late is skipped, not played


def _logit(p: float) -> float:
    p = float(np.clip(p, SHARE_EPS, 1 - SHARE_EPS))
    return float(np.log(p / (1 - p)))


def _expit(z: float) -> float:
    return float(1.0 / (1.0 + np.exp(-z)))


# ---------------------------------------------------------------- sound synthesis
def _pink(n: int, rng) -> np.ndarray:
    b = [0.049922035, -0.095993537, 0.050612699, -0.004408786]
    a = [1, -2.494956002, 2.017265875, -0.522189400]
    return lfilter(b, a, rng.normal(0, 1, n))


def _loopable(x: np.ndarray, fade_s: float = 1.5) -> np.ndarray:
    n = int(fade_s * SR)
    head, tail = x[:n].copy(), x[-n:].copy()
    ramp = np.linspace(0, 1, n)
    x = x[n:].copy()
    x[-n:] = tail * (1 - ramp) + head * ramp
    return x


def make_bed(seconds: int = 24, seed: int = 5) -> np.ndarray:
    """Soft rain over a low pink-noise bed; loopable, peak 0.5."""
    rng = np.random.default_rng(seed)
    n = seconds * SR
    bed = sosfilt(butter(2, [60, 1800], btype="band", fs=SR, output="sos"), _pink(n, rng))
    bed /= np.max(np.abs(bed))
    hiss = sosfilt(butter(2, [700, 4500], btype="band", fs=SR, output="sos"), rng.normal(0, 1, n))
    hiss /= np.max(np.abs(hiss))
    drops = np.zeros(n)
    k = np.arange(260)
    for i in rng.integers(0, n - 300, seconds * 40):
        drops[i:i + 260] += rng.uniform(0.1, 0.6) * np.exp(-k / 45.0) * np.sin(2 * np.pi * rng.uniform(1200, 3200) * k / SR)
    drops = sosfilt(butter(2, 4000, fs=SR, output="sos"), drops)
    t = np.arange(n) / SR
    swell = 0.85 + 0.15 * np.sin(2 * np.pi * t / 9.0) * np.sin(2 * np.pi * t / 14.0 + 1)
    x = (0.7 * bed + 0.25 * hiss + 0.15 * drops / (np.max(np.abs(drops)) or 1)) * swell
    x = _loopable(x)
    return 0.5 * x / np.max(np.abs(x))


def make_cue(seed: int = 9) -> np.ndarray:
    """50 ms pink-noise burst with 5 ms raised-cosine ramps; peak 0.5."""
    rng = np.random.default_rng(seed)
    n = int(CUE_LEN_S * SR)
    x = _pink(n + 2000, rng)[2000:]
    x -= x.mean()
    r = int(0.005 * SR)
    env = np.ones(n)
    ramp = 0.5 - 0.5 * np.cos(np.pi * np.arange(r) / r)
    env[:r], env[-r:] = ramp, ramp[::-1]
    x = x * env
    return 0.5 * x / np.max(np.abs(x))


def wav_bytes(x: np.ndarray) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((np.clip(x, -1, 1) * 32000).astype("<i2").tobytes())
    return buf.getvalue()


class TempWavs:
    """Writes in-memory WAVs to a private temp folder; remove() deletes it."""

    def __init__(self, blobs: dict):
        self.dir = Path(tempfile.mkdtemp(prefix="nb_sleepaudio_"))
        self.paths = {}
        for k, b in blobs.items():
            p = self.dir / f"{k}.wav"
            p.write_bytes(b)
            self.paths[k] = p

    def remove(self):
        if self.dir is not None:
            shutil.rmtree(self.dir, ignore_errors=True)
            self.dir = None


class QtAudio:
    """Bed + cue players on QSoundEffect. muted=True: no files, no playback, just bookkeeping."""

    def __init__(self, muted: bool):
        self.muted = muted
        self.tmp = None
        self.bed = self.cue_fx = None
        self.bed_volume = 0.0
        self.cues_played = 0
        if muted:
            return
        try:
            from PyQt6.QtCore import QUrl
            from PyQt6.QtMultimedia import QSoundEffect
            self.tmp = TempWavs({"bed": wav_bytes(make_bed()), "cue": wav_bytes(make_cue())})
            self.bed = QSoundEffect()
            self.bed.setSource(QUrl.fromLocalFile(str(self.tmp.paths["bed"])))
            self.bed.setLoopCount(QSoundEffect.Loop.Infinite.value)
            self.bed.setVolume(0.0)
            self.cue_fx = QSoundEffect()
            self.cue_fx.setSource(QUrl.fromLocalFile(str(self.tmp.paths["cue"])))
            self.cue_fx.setVolume(0.0)
        except Exception:  # noqa: BLE001  (no audio backend: behave as muted)
            self.close()
            self.muted = True

    def bed_start(self):
        if self.bed is not None:
            self.bed.setVolume(0.0)
            self.bed.play()

    def bed_set_volume(self, v: float):
        self.bed_volume = float(np.clip(v, 0, 1))
        if self.bed is not None:
            self.bed.setVolume(self.bed_volume)

    def bed_stop(self):
        self.bed_volume = 0.0
        if self.bed is not None:
            self.bed.stop()

    def cue(self, v: float):
        self.cues_played += 1
        if self.cue_fx is not None:
            self.cue_fx.setVolume(float(np.clip(v, 0, 1)))
            self.cue_fx.play()

    def close(self):
        for e in (self.bed, self.cue_fx):
            if e is not None:
                try:
                    e.stop()
                    e.setSource(__import__("PyQt6.QtCore", fromlist=["QUrl"]).QUrl())
                    e.deleteLater()
                except Exception:  # noqa: BLE001
                    pass
        self.bed = self.cue_fx = None
        if self.tmp is not None:
            self.tmp.remove()
            self.tmp = None


# ---------------------------------------------------------------- engine (no Qt; testable with a fake clock)
class SleepAudioEngine:
    """All detection and scheduling logic. The owner calls poll() periodically (100-250 ms) and
    fire_due() when a scheduled cue is due (poll() also fires due cues)."""

    def __init__(self, hub, recorder, audio, enable_assist: bool, enable_cue: bool, volume: float,
                 cue_volume: Optional[float] = None, clock: Optional[Callable[[], float]] = None,
                 output_latency: float = 0.04, on_schedule: Optional[Callable[[float], None]] = None):
        self.hub, self.rec, self.audio = hub, recorder, audio
        self.assist, self.cue_on = bool(enable_assist), bool(enable_cue)
        self.volume = float(np.clip(volume, 0, 1))
        self.cue_volume = float(np.clip(0.5 * self.volume if cue_volume is None else cue_volume, 0, 1))
        self.clock = clock or hub.now
        self.latency = output_latency
        self.on_schedule = on_schedule
        self.t0 = self.clock()
        self.events: list = []                    # (hub time, label) for every marker we add
        # epochs
        self.epochs: deque = deque(maxlen=int(3600 / EPOCH_S))
        self._next_epoch = self.t0 + EPOCH_S
        self.ref = None
        self.ear_ok = [True, True]
        self._onset_since = None
        self.onset_t = None
        # assist
        self.bed_state = "off"                    # off / fadein / playing / fading / stopped
        self._bed_t = self.t0
        self.stop_reason = ""
        # cue
        self._sos = butter(2, SO_BAND, btype="band", fs=dsp.FS_EEG, output="sos")
        # wide, low-order band-pass that barely rings: confirms the trough is in the EEG itself and not
        # ringing of the narrow filter after a train has ended
        self._sos_w = butter(1, (0.16, 4.0), btype="band", fs=dsp.FS_EEG, output="sos")
        self._zi = self._zi_w = None
        self._wmin = 0.0
        self._so_last_t = -1e18
        self._so_chsel = None
        self._prev_y = 0.0
        self._in_neg = False
        self._t_down = self._t_peak = 0.0
        self._ymin = 0.0
        self._so_fired = False
        self._warm_until = -1e18
        self._troughs: deque = deque(maxlen=400)
        self.thr = SO_THR_MIN
        self._next_fast = self.t0
        self._emg_hist: deque = deque(maxlen=600)
        self.lock_until = -1e18
        self.last_motion_t = self.t0              # treat the start as "just moved"
        self.imu_seen = False
        self.deep_open = False
        self._train_count = 0
        self._train_last_so = -1e18
        self._last_cue_t = -1e18
        self.pending: list = []                   # scheduled cue target times
        self.cue_times: list = []
        self.c = {"so_detected": 0, "so_in_deep": 0, "cues": 0, "blocked_stage": 0, "blocked_lockout": 0,
                  "blocked_refractory": 0, "blocked_train": 0, "blocked_late": 0, "cancelled": 0,
                  "lockouts_motion": 0, "lockouts_emg": 0, "lockouts_artifact": 0}

    # ------------------------------------------------------------ helpers
    def _mark(self, label: str, kind: str = "sound"):
        self.events.append((self.clock(), label))
        if self.rec is not None:
            try:
                self.rec.add_marker(label, kind)
            except Exception:  # noqa: BLE001
                pass

    def _cols(self, sensor, wanted):
        names = self.hub.names(sensor)
        return [names.index(n) + 1 if n in names else None for n in wanted]

    # ------------------------------------------------------------ lifecycle
    def begin(self):
        if self.assist:
            self.audio.bed_start()
            self.bed_state = "fadein"
            self._bed_t = self.clock()
            self._mark("助眠声音开始")

    def end(self, reason: str = "手动停止"):
        if self.bed_state in ("fadein", "playing", "fading"):
            self.audio.bed_stop()
            self.bed_state = "stopped"
            self.stop_reason = reason
            self._mark("助眠声音停止")
        self.pending.clear()

    # ------------------------------------------------------------ main tick
    def poll(self):
        now = self.clock()
        if self.cue_on:
            self._process_so(now)
            if now >= self._next_fast:
                self._next_fast = now + 0.5
                self._fast_checks(now)
        if now >= self._next_epoch:
            self._next_epoch = max(self._next_epoch + EPOCH_S, now - EPOCH_S / 2)
            self._epoch(now)
        self._bed(now)
        self.fire_due()

    def next_due(self):
        return min(self.pending) if self.pending else None

    def fire_due(self):
        now = self.clock()
        due = [t for t in self.pending if t <= now + 0.005]
        if not due:
            return
        self.pending = [t for t in self.pending if t > now + 0.005]
        for t in sorted(due):
            if now - t > CUE_LATE_S:                    # UI stall: a late cue would miss the up-state
                self.c["blocked_late"] += 1
                self._train_count = 0
                continue
            if now < self.lock_until or not self._deep_gate(now):
                self.c["cancelled"] += 1
                self._train_count = 0
                continue
            self.audio.cue(self.cue_volume)
            self.c["cues"] += 1
            self.cue_times.append(now)
            self._mark("慢波提示音")

    # ------------------------------------------------------------ epochs / staging
    def _epoch(self, now):
        eeg = self.hub.latest("EEG", EPOCH_S)
        cols = self._cols("EEG", dsp.EEG_NAMES)
        fs = dsp.FS_EEG
        ep = {"t": now, "valid": False, "motion": float("nan")}
        imu = self.hub.latest("ACCGYRO", EPOCH_S)
        g = self._cols("ACCGYRO", ["GYRO_X", "GYRO_Y", "GYRO_Z"])
        if len(imu) >= 20 and None not in g and imu[-1, 0] > now - 3:
            ep["motion"] = dsp.motion_level(imu[:, g])
            self.imu_seen = True
        if len(eeg) >= 0.8 * EPOCH_S * fs and eeg[-1, 0] > now - 3 and None not in cols:
            X = eeg[:, cols]
            ok = []
            for c in range(4):
                x = X[:, c]
                y = x - x.mean()
                s = float(np.std(y))
                ok.append(0.5 < s < 250 and x.min() > 5 and x.max() < dsp.EEG_RAW_MAX - 5)
            ears = [i for i in (0, 3) if ok[i]]
            self.ear_ok = [ok[0], ok[3]]
            if ears:
                f, p = welch(X[:, ears] - X[:, ears].mean(axis=0), fs=fs, nperseg=int(2 * fs), axis=0)
                p = p.mean(axis=1)
                band = lambda lo, hi: float(p[(f >= lo) & (f < hi)].sum())  # noqa: E731
                tot = band(0.5, 30) or 1e-9
                good = [i for i in range(4) if ok[i]]
                ep.update(valid=True, delta=band(0.5, 4) / tot, theta=band(4, 8) / tot, alpha=band(8, 12) / tot,
                          emg=float(np.mean(dsp.emg_rms(X[:, good], fs))))
                ep["slow"] = ep["delta"] + ep["theta"]
        self.epochs.append(ep)
        self._reference(now)
        self._onset(now)
        self.deep_open = self._deep_epochs_ok()

    def _reference(self, now):
        if self.ref is not None or now - self.t0 < REF_S:
            return
        v = [e for e in self.epochs if e["valid"]]
        if len(v) >= REF_MIN_EPOCHS or now - self.t0 >= REF_MAX_S:
            if len(v) < 10:
                return                                  # still nothing usable; keep waiting
            v = v[: max(REF_MIN_EPOCHS, sum(1 for e in v if e["t"] <= self.t0 + REF_S))]
            med = lambda k: float(np.median([e[k] for e in v]))  # noqa: E731
            self.ref = {k: med(k) for k in ("alpha", "slow", "delta", "theta", "emg")}
            self.ref["t"] = now

    def _onset(self, now):
        if self.ref is None or self.onset_t is not None:
            return
        win = [e for e in self.epochs if e["t"] > now - ONSET_WIN_S]
        need = int(ONSET_WIN_S / EPOCH_S)
        v = [e for e in win if e["valid"]]
        ok = len(win) >= 0.9 * need and len(v) >= 0.8 * need
        if ok:
            r = self.ref
            a = float(np.median([e["alpha"] for e in v]))
            s = float(np.median([e["slow"] for e in v]))
            mot = np.array([e["motion"] for e in win], float)
            if np.isnan(mot).mean() > 0.2:
                ok = False                              # no motion data: do not guess
            else:
                mot = mot[~np.isnan(mot)]
                recent = [e["motion"] for e in win if e["t"] > now - 60 and e["motion"] == e["motion"]]
                ok = (a <= ALPHA_FACTOR * r["alpha"]
                      and _logit(s) >= _logit(r["slow"]) + SLOW_LOGIT_MARGIN
                      and np.median(mot) <= MOTION_EPOCH_MED and (mot > MOTION_EVENT).mean() <= 0.10
                      and all(m <= MOTION_BIG for m in recent))
        if not ok:
            self._onset_since = None
            return
        if self._onset_since is None:
            self._onset_since = now
        if now - self._onset_since >= ONSET_HOLD_S:
            self.onset_t = now
            self._mark("检测到入睡（实时估计）", "event")
            if self.bed_state in ("fadein", "playing"):
                self._start_fade(now, "检测到入睡")

    def _deep_epochs_ok(self) -> bool:
        if self.ref is None or len(self.epochs) < DEEP_EPOCHS:
            return False
        last = list(self.epochs)[-DEEP_EPOCHS:]
        v = [e for e in self.epochs if e["valid"]]
        emgs = np.array([e["emg"] for e in v], float)
        low_emg = 1.5 * float(np.percentile(emgs, 20)) + 0.5 if len(emgs) else 0.0
        low_emg = min(low_emg, max(self.ref["emg"], 0.5))
        dthr = self.deep_delta_threshold()
        n_ok = sum(1 for e in last if e["valid"] and e["delta"] >= dthr and e["emg"] <= low_emg
                   and e["motion"] == e["motion"] and e["motion"] <= MOTION_EPOCH_MED)
        return n_ok >= DEEP_MIN_OK

    def deep_delta_threshold(self) -> Optional[float]:
        """Delta share an epoch needs to count as deep, relative to the awake reference."""
        if self.ref is None:
            return None
        return max(DEEP_DELTA_MIN, _expit(_logit(self.ref["delta"]) + DEEP_DELTA_LOGIT))

    def _deep_gate(self, now) -> bool:
        return (self.deep_open and self.imu_seen and now - self.last_motion_t >= DEEP_QUIET_S
                and now >= self.lock_until)

    # ------------------------------------------------------------ assist bed
    def _start_fade(self, now, reason):
        self.bed_state = "fading"
        self._bed_t = now
        self._fade_from = self.audio.bed_volume if hasattr(self.audio, "bed_volume") else self.volume
        self.stop_reason = reason

    def _bed(self, now):
        st = self.bed_state
        if st == "fadein":
            x = min(1.0, (now - self._bed_t) / FADE_IN_S)
            self.audio.bed_set_volume(self.volume * x * x)
            if x >= 1:
                self.bed_state = "playing"
        if self.bed_state in ("fadein", "playing") and now - self.t0 >= ASSIST_MAX_S:
            self._start_fade(now, "已播放 90 分钟")
        if self.bed_state == "fading":
            x = min(1.0, (now - self._bed_t) / FADE_OUT_S)
            self.audio.bed_set_volume(self._fade_from * (1 - x) ** 2)
            if x >= 1:
                self.audio.bed_stop()
                self.bed_state = "stopped"
                self._mark("助眠声音停止")

    # ------------------------------------------------------------ fast checks: motion, EMG bursts
    def _fast_checks(self, now):
        imu = self.hub.latest("ACCGYRO", 1.0)
        g = self._cols("ACCGYRO", ["GYRO_X", "GYRO_Y", "GYRO_Z"])
        if len(imu) >= 20 and None not in g and imu[-1, 0] > now - 2:
            self.imu_seen = True
            if dsp.motion_level(imu[:, g]) > MOTION_EVENT:
                if now >= self.lock_until:
                    self.c["lockouts_motion"] += 1
                self.last_motion_t = now
                self.lock_until = max(self.lock_until, now + LOCKOUT_S)
        eeg = self.hub.latest("EEG", 1.0)
        cols = self._cols("EEG", dsp.EEG_NAMES)
        if len(eeg) >= 200 and None not in cols and eeg[-1, 0] > now - 2:
            e = float(np.mean(dsp.emg_rms(eeg[:, cols], dsp.FS_EEG)))
            if len(self._emg_hist) >= 20:
                base = float(np.median(self._emg_hist))
                if e > max(3.0 * base, base + 8.0):
                    if now >= self.lock_until:
                        self.c["lockouts_emg"] += 1
                    self.lock_until = max(self.lock_until, now + LOCKOUT_S)
                    return                              # keep bursts out of the baseline
            self._emg_hist.append(e)

    # ------------------------------------------------------------ slow-oscillation detector
    def _process_so(self, now):
        eeg = self.hub.latest("EEG", 2.0)
        if len(eeg) == 0:
            return
        new = eeg[eeg[:, 0] > self._so_last_t]
        if len(new) == 0:
            return
        cols = self._cols("EEG", ["EEG_TP9", "EEG_TP10"])
        if None in cols:
            return
        sel = tuple(c for c, ok in zip(cols, self.ear_ok) if ok) or tuple(cols)
        gap = new[0, 0] - self._so_last_t > 0.5
        self._so_last_t = float(new[-1, 0])
        x = new[:, list(sel)].mean(axis=1)
        if self._zi is None or gap or sel != self._so_chsel:
            self._zi = sosfilt_zi(self._sos) * x[0]
            self._zi_w = sosfilt_zi(self._sos_w) * x[0]
            self._so_chsel = sel
            self._in_neg, self._prev_y = False, 0.0
            self._warm_until = float(new[0, 0]) + 3.0
        y, self._zi = sosfilt(self._sos, x, zi=self._zi)
        yw, self._zi_w = sosfilt(self._sos_w, x, zi=self._zi_w)
        ts = new[:, 0]
        for t, v, w in zip(ts.tolist(), y.tolist(), yw.tolist()):
            if t < self._warm_until:
                self._prev_y = v
                continue
            if v < -SO_ART:
                if now >= self.lock_until:
                    self.c["lockouts_artifact"] += 1
                self.lock_until = max(self.lock_until, now + LOCKOUT_S)
                self._so_fired = True                   # invalidate this half-wave
            if not self._in_neg:
                if self._prev_y >= 0 > v:
                    self._in_neg, self._t_down, self._t_peak, self._ymin, self._so_fired = True, t, t, 0.0, False
                    self._wmin = 0.0
            else:
                if v < self._ymin:
                    self._ymin, self._t_peak = v, t
                self._wmin = min(self._wmin, w)
                if (not self._so_fired and self._ymin < -self.thr and v > 0.5 * self._ymin
                        and self._wmin < -0.6 * self.thr and t - self._t_down <= SO_HALF_MAX):
                    half = 2.0 * (self._t_peak - self._t_down)
                    if SO_HALF_MIN <= half <= SO_HALF_MAX:
                        self._so_fired = True
                        self._on_so(self._t_peak, now)
                if v >= 0:
                    self._in_neg = False
                    d = t - self._t_down
                    if SO_HALF_MIN <= d <= SO_HALF_MAX and -self._ymin < SO_ART and now >= self.lock_until:
                        self._troughs.append(-self._ymin)
                        if len(self._troughs) >= 20:
                            self.thr = float(np.clip(0.75 * np.percentile(self._troughs, 75), SO_THR_MIN, SO_THR_MAX))
            self._prev_y = v

    def _on_so(self, t_peak, now):
        self.c["so_detected"] += 1
        if now < self.lock_until:
            self.c["blocked_lockout"] += 1
            return
        if not self._deep_gate(now):
            self.c["blocked_stage"] += 1
            return
        self.c["so_in_deep"] += 1
        target = t_peak + CUE_DELAY - self.latency
        same_train = t_peak - self._train_last_so <= TRAIN_GAP
        self._train_last_so = t_peak
        if self._train_count == 1 and not same_train:
            self._train_count = 0                       # train ended after one cue
        if self._train_count == 1:
            if target - self._last_cue_t < 0.8:
                self.c["blocked_train"] += 1
                return
        elif target - self._last_cue_t < REFRACTORY:
            self.c["blocked_refractory"] += 1
            return
        if target < now - CUE_LATE_S:
            self.c["blocked_late"] += 1
            return
        self._train_count = 0 if self._train_count == 1 else 1
        self._last_cue_t = target
        self.pending.append(target)
        if self.on_schedule is not None:
            self.on_schedule(target)

    # ------------------------------------------------------------ reporting
    def status_text(self) -> str:
        now = self.clock()
        parts = []
        if self.ref is None and now - self.t0 < REF_MAX_S:
            parts.append("正在记下清醒时的脑电参考（约 5 分钟）")
        if self.assist:
            parts.append({"fadein": "助眠声音渐渐响起", "playing": "助眠声音播放中，等你睡着后会慢慢停下",
                          "fading": "看起来你睡着了，助眠声音正在慢慢变小",
                          "stopped": "助眠声音已停止", "off": ""}[self.bed_state])
        if self.cue_on:
            if not self.imu_seen:
                parts.append("慢波提示：没有运动数据，暂不启用")
            elif now < self.lock_until:
                parts.append("慢波提示：刚有动作，暂停 30 秒")
            elif self._deep_gate(now):
                parts.append(f"慢波提示：深睡中，已提示 {self.c['cues']} 次")
            else:
                parts.append("慢波提示：等待深睡")
        return "；".join(p for p in parts if p)

    def summary(self) -> dict:
        rel = lambda t: None if t is None else round(t - self.t0, 1)  # noqa: E731
        return {"assist_enabled": self.assist, "cue_enabled": self.cue_on, "assist_state": self.bed_state,
                "assist_stop_reason": self.stop_reason, "onset_s": rel(self.onset_t),
                "reference": None if self.ref is None else {k: round(v, 3) for k, v in self.ref.items() if k != "t"},
                "deep_delta_threshold": None if self.ref is None else round(self.deep_delta_threshold(), 3),
                "so_threshold_uv": round(self.thr, 1), **self.c,
                "cue_count": len(self.cue_times), "cue_first_s": rel(self.cue_times[0]) if self.cue_times else None,
                "cue_last_s": rel(self.cue_times[-1]) if self.cue_times else None,
                "cue_times_s": [round(t - self.t0, 2) for t in self.cue_times]}


# ---------------------------------------------------------------- Qt wrapper
from PyQt6.QtCore import QObject, Qt, QTimer, pyqtSignal  # noqa: E402


class SleepAudio(QObject):
    """Opt-in sound for overnight recordings. Usage:
        sa = SleepAudio(parent); sa.status.connect(label.setText)
        sa.start(hub, hub.recorder, enable_assist=True, enable_cue=False, volume=0.3)
        ...  sa.stop()   # before the recorder is closed
    """

    status = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.engine: Optional[SleepAudioEngine] = None
        self.audio = None
        self._last_status = ""
        self._final: dict = {}
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)

    @property
    def running(self) -> bool:
        return self.engine is not None

    @property
    def summary(self) -> dict:
        return self.engine.summary() if self.engine is not None else dict(self._final)

    def start(self, hub, recorder, enable_assist: bool, enable_cue: bool, volume: float,
              cue_volume: Optional[float] = None):
        self.stop()
        if not (enable_assist or enable_cue):
            return
        self.audio = QtAudio(muted=bool(os.environ.get("NB_MUTE")))
        self.engine = SleepAudioEngine(hub, recorder if recorder is not None else getattr(hub, "recorder", None),
                                       self.audio, enable_assist, enable_cue, volume, cue_volume=cue_volume,
                                       on_schedule=self._schedule)
        self.engine.begin()
        self.timer.start(100 if enable_cue else 250)
        self._tick()

    def _schedule(self, target: float):
        if self.engine is None:
            return
        ms = max(0, int((target - self.engine.clock()) * 1000))
        QTimer.singleShot(ms, Qt.TimerType.PreciseTimer, self._fire)

    def _fire(self):
        if self.engine is not None:
            self.engine.fire_due()

    def _tick(self):
        if self.engine is None:
            return
        try:
            self.engine.poll()
        except Exception as e:  # noqa: BLE001
            self.stop()                                 # stop() clears the status; the error must come after
            self._emit(f"声音功能出错，已停止：{e}")
            return
        self._emit(self.engine.status_text())

    def _emit(self, s: str):
        if s != self._last_status:
            self._last_status = s
            self.status.emit(s)

    def stop(self):
        self.timer.stop()
        if self.engine is not None:
            self.engine.end()
            self._final = self.engine.summary()
            self.engine = None
            self._emit("")
        if self.audio is not None:
            self.audio.close()
            self.audio = None
