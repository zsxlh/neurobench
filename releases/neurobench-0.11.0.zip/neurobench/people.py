"""Who a recording belongs to (v0.10).

Several people can use one headband and one computer. Each recording stores meta["person"] (a short ASCII id,
also used in the cloud release tag) and meta["person_name"]. Recordings made before v0.10 have no person and
count as the default person "me". Baselines, trends, reports and the thought-switch model only use the
current person's recordings.
"""

from __future__ import annotations

import json
import re

from .paths import ROOT

FILE = ROOT / "people.json"
DEFAULT = {"people": [{"id": "me", "name": "我"}], "current": "me"}


def _load() -> dict:
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        if d.get("people"):
            return d
    except Exception:  # noqa: BLE001
        pass
    return json.loads(json.dumps(DEFAULT))


def _save(d: dict):
    tmp = FILE.with_name(FILE.name + ".part")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(FILE)


def people() -> list:
    return _load()["people"]


def current() -> str:
    d = _load()
    ids = [p["id"] for p in d["people"]]
    return d.get("current") if d.get("current") in ids else ids[0]


def name_of(pid: str) -> str:
    for p in people():
        if p["id"] == pid:
            return p["name"]
    return pid


def set_current(pid: str):
    d = _load()
    if any(p["id"] == pid for p in d["people"]):
        d["current"] = pid
        _save(d)


def valid_id(pid: str) -> bool:
    return bool(re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,19}", pid or ""))


def add(pid: str, name: str) -> str:
    """Add a person; returns an error text or ''."""
    pid = (pid or "").strip().lower()
    name = (name or "").strip() or pid
    if not valid_id(pid):
        return "代号只能用小写字母、数字、- 或 _（最多 20 个），比如 tutu"
    d = _load()
    if any(p["id"] == pid for p in d["people"]):
        return "这个代号已经有了"
    d["people"].append({"id": pid, "name": name})
    d["current"] = pid
    _save(d)
    return ""


def person_of(meta: dict) -> str:
    return (meta or {}).get("person") or "me"


def mine(meta: dict, pid: str | None = None) -> bool:
    """Does this recording belong to `pid` (default: the current person)?"""
    return person_of(meta) == (pid or current())


def compare_ok(pid: str) -> bool:
    """Has this person agreed that their recordings may be shown next to someone else's?"""
    return any(p["id"] == pid and p.get("compare_ok") for p in people())


def set_compare_ok(pid: str, ok: bool):
    d = _load()
    for p in d["people"]:
        if p["id"] == pid:
            p["compare_ok"] = bool(ok)
    _save(d)


def comparable_with(pid: str | None = None) -> list:
    """Other people whose data may be shown next to `pid`'s: both must have agreed."""
    pid = pid or current()
    if not compare_ok(pid):
        return []
    return [p for p in people() if p["id"] != pid and p.get("compare_ok")]
