"""Stream live NeuroBench data to Lab Streaming Layer (LSL).

LabRecorder (or any LSL tool) can then record NeuroBench next to other devices (eye tracker,
stimulus PC, another amplifier) on one shared clock.

Outlets (created on start):
  NeuroBench-EEG      4 ch  TP9 AF7 AF8 TP10, 256 Hz, microvolts, float32
  NeuroBench-Optics   whatever optics channels the hub has (4/8/16), 64 Hz, float32
  NeuroBench-IMU      6 ch  ACC_X..GYRO_Z, 52 Hz, float32
  NeuroBench-Markers  1 ch  string, irregular rate

Timing: hub timestamps (seconds on hub.now()'s clock) are mapped to LSL local_clock() with one
fixed offset taken at start: t_lsl = t_hub + (local_clock() - hub.now()). Both clocks are
QueryPerformanceCounter based on Windows, so the offset does not drift in practice.

Every stream's desc carries "source" (hub.info.source: "muse", "sim" or "replay"); "model" is
"Muse S Athena" only for real headband data. source_id = "neurobench_<stream>_pid<PID>[_<address>]"
so two NeuroBench instances on one network never share a source_id.

Markers: call push_marker(label, t_hub) with the event's exact hub time (e.g. from a Recorder
marker hook: t_hub = rec.t_start + m["t"]); without t_hub the marker is stamped hub.now().

Uses mne_lsl (the same library OpenMuse uses); falls back to pylsl if only that is installed.
"""

from __future__ import annotations

import math
import os
import re
from typing import Optional

import numpy as np
from PyQt6.QtCore import QObject, QTimer, pyqtSignal

from .hub import KEEP_SECONDS

EEG_CH = ["EEG_TP9", "EEG_AF7", "EEG_AF8", "EEG_TP10"]
IMU_CH = ["ACC_X", "ACC_Y", "ACC_Z", "GYRO_X", "GYRO_Y", "GYRO_Z"]
PUSH_MS = 100                 # poll interval for new hub samples


def max_catchup_s(sensor: str) -> float:
    """Longest span read from the ring in one tick: the whole ring minus 1 s (a stall longer than
    the ring loses samples anyway; reading all of it pushes everything still available)."""
    return float(KEEP_SECONDS.get(sensor, 61)) - 1.0


def source_label(source: str) -> str:
    return {"muse": "Muse S Athena", "sim": "simulated", "replay": "replay"}.get(source or "", "unknown")

STREAM_NAMES = {
    "EEG": "NeuroBench-EEG",
    "OPTICS": "NeuroBench-Optics",
    "ACCGYRO": "NeuroBench-IMU",
    "MARKERS": "NeuroBench-Markers",
}
_FS = {"EEG": 256.0, "OPTICS": 64.0, "ACCGYRO": 52.0}
_TYPES = {"EEG": "EEG", "OPTICS": "PPG", "ACCGYRO": "IMU"}

NO_LIB_MSG = ("没有找到 LSL 组件（mne_lsl 或 pylsl），无法向 LabRecorder 等软件发送数据。"
              "这个功能先关掉，其他功能照常使用。")

# ------------------------------------------------------------------ library shim
_LIB = None            # "mne_lsl" | "pylsl" | ""
_IMPORT_ERR = ""


def _load_lib():
    """Import an LSL binding once. Returns the binding name or "" if none works."""
    global _LIB, _IMPORT_ERR
    if _LIB is not None:
        return _LIB
    try:
        import mne_lsl.lsl  # noqa: F401
        _LIB = "mne_lsl"
        return _LIB
    except Exception as e:  # noqa: BLE001  (missing package or missing liblsl DLL)
        _IMPORT_ERR = f"mne_lsl: {type(e).__name__}: {e}"
    try:
        import pylsl  # noqa: F401
        _LIB = "pylsl"
        return _LIB
    except Exception as e:  # noqa: BLE001
        _IMPORT_ERR += f"; pylsl: {type(e).__name__}: {e}"
    _LIB = ""
    return _LIB


def lsl_available() -> tuple[bool, str]:
    """(True, "") if an LSL library loads, else (False, friendly Chinese message)."""
    return (True, "") if _load_lib() else (False, NO_LIB_MSG)


def local_clock() -> float:
    lib = _load_lib()
    if lib == "mne_lsl":
        from mne_lsl.lsl import local_clock as lc
        return float(lc())
    if lib == "pylsl":
        import pylsl
        return float(pylsl.local_clock())
    raise RuntimeError(NO_LIB_MSG)


def _make_outlet(name: str, stype: str, ch_names: list, sfreq: float, dtype: str, source_id: str,
                 units: Optional[list] = None, source: str = ""):
    lib = _load_lib()
    is_muse = source == "muse"
    manufacturer = "Interaxon (via NeuroBench)" if is_muse else "NeuroBench"
    if lib == "mne_lsl":
        from mne_lsl.lsl import StreamInfo, StreamOutlet
        info = StreamInfo(name=name, stype=stype, n_channels=len(ch_names), sfreq=sfreq,
                          dtype=dtype, source_id=source_id)
        info.set_channel_names(list(ch_names))
        if units:
            info.set_channel_units(list(units))
        desc = info.desc
        desc.append_child_value("manufacturer", manufacturer)
        desc.append_child_value("model", source_label(source))
        desc.append_child_value("source", source or "unknown")
        return StreamOutlet(info, chunk_size=1)
    import pylsl
    fmt = pylsl.cf_string if dtype == "string" else pylsl.cf_float32
    info = pylsl.StreamInfo(name, stype, len(ch_names), sfreq or pylsl.IRREGULAR_RATE, fmt, source_id)
    chans = info.desc().append_child("channels")
    for i, c in enumerate(ch_names):
        ch = chans.append_child("channel")
        ch.append_child_value("label", c)
        if units:
            ch.append_child_value("unit", str(units[i]))
    info.desc().append_child_value("manufacturer", manufacturer)
    info.desc().append_child_value("model", source_label(source))
    info.desc().append_child_value("source", source or "unknown")
    return pylsl.StreamOutlet(info)


def _close_outlet(outlet):
    try:
        if hasattr(outlet, "_del"):          # mne_lsl: release the C handle right away
            outlet._del()
    except Exception:  # noqa: BLE001
        pass


def _units_for(sensor: str, names: list) -> list:
    if sensor == "EEG":
        return ["microvolts"] * len(names)
    if sensor == "ACCGYRO":
        return ["g" if n.startswith("ACC") else "degrees/s" for n in names]
    return ["none"] * len(names)


class _SensorOut:
    """Outlet plus bookkeeping for one numeric sensor."""

    def __init__(self, sensor: str, outlet, names: list, cols: list):
        self.sensor = sensor
        self.outlet = outlet
        self.names = names          # channel names sent to LSL
        self.cols = cols            # column indices into hub rows (0 is time)
        self.last_t = -math.inf     # hub time of the last pushed sample
        self.pushed = 0
        self.source = ""            # hub.info.source when the outlet was made
        self.source_id = ""


class LSLOutlet(QObject):
    """Push NeuroBench hub data to LSL every 100 ms while running.

    Signals:
      started(list)      names of the outlets that were opened
      stopped()
      error(str)         friendly Chinese message (feature disabled or a push failed)
    """

    started = pyqtSignal(list)
    stopped = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, hub, parent=None):
        super().__init__(parent)
        self.hub = hub
        self.offset = 0.0                        # local_clock() - hub.now()
        self.outs: dict[str, _SensorOut] = {}
        self.marker_outlet = None
        self._marker_source = ""
        self.markers_sent = 0
        self._running = False
        self._timer = QTimer(self)
        self._timer.setInterval(PUSH_MS)
        self._timer.timeout.connect(self.tick)

    # ------------------------------------------------------------------ state
    @property
    def running(self) -> bool:
        return self._running

    def status_text(self) -> str:
        if not self._running:
            ok, msg = lsl_available()
            return "LSL 输出已关闭" if ok else msg
        parts = [STREAM_NAMES[s] for s in ("EEG", "OPTICS", "ACCGYRO") if s in self.outs]
        parts.append(STREAM_NAMES["MARKERS"])
        text = "正在通过 LSL 发送：" + "、".join(parts)
        if self._hub_source() != "muse":
            text += "（模拟/回放数据，不是头环实时数据）"
        return text

    def to_lsl_time(self, t_hub: float) -> float:
        return float(t_hub) + self.offset

    def _hub_source(self) -> str:
        info = getattr(self.hub, "info", None)
        return str(getattr(info, "source", "") or "")

    def _source_id(self, base: str) -> str:
        """base + process id (+ headband address when known): unique per NeuroBench instance."""
        sid = f"{base}_pid{os.getpid()}"
        info = getattr(self.hub, "info", None)
        addr = str(getattr(info, "address", "") or "")
        if addr:
            sid += "_" + re.sub(r"[^0-9A-Za-z]+", "", addr)
        return sid

    def _open_marker_outlet(self):
        if self.marker_outlet is not None:
            _close_outlet(self.marker_outlet)
            self.marker_outlet = None
        src = self._hub_source()
        self.marker_outlet = _make_outlet(STREAM_NAMES["MARKERS"], "Markers", ["Marker"], 0.0,
                                          "string", self._source_id("neurobench_markers"), source=src)
        self._marker_source = src

    # ------------------------------------------------------------------ start/stop
    def start(self) -> bool:
        """Open the outlets and begin pushing. Returns False (and emits error) if LSL is missing."""
        if self._running:
            return True
        ok, msg = lsl_available()
        if not ok:
            self.error.emit(msg)
            return False
        try:
            self.offset = local_clock() - self.hub.now()
            self._open_marker_outlet()
            self.markers_sent = 0
            self.outs = {}
            for s in ("EEG", "OPTICS", "ACCGYRO"):
                self._ensure(s)
        except Exception as e:  # noqa: BLE001
            self._drop_all()
            self.error.emit(f"打开 LSL 输出失败：{type(e).__name__}: {e}")
            return False
        self._running = True
        self._timer.start()
        self.started.emit([STREAM_NAMES[s] for s in ("EEG", "OPTICS", "ACCGYRO") if s in self.outs]
                          + [STREAM_NAMES["MARKERS"]])
        return True

    def stop(self):
        if not self._running:
            return
        self._timer.stop()
        self._running = False
        self._drop_all()
        self.stopped.emit()

    def _drop_all(self):
        for o in self.outs.values():
            _close_outlet(o.outlet)
        self.outs = {}
        if self.marker_outlet is not None:
            _close_outlet(self.marker_outlet)
        self.marker_outlet = None

    # ------------------------------------------------------------------ outlets
    def _wanted_channels(self, sensor: str) -> tuple[list, list]:
        """(LSL channel names, hub column indices) for a sensor given what the hub has now."""
        hub_names = self.hub.names(sensor)
        if not hub_names:
            return [], []
        if sensor == "EEG":
            want = [n for n in EEG_CH if n in hub_names]
        elif sensor == "ACCGYRO":
            want = [n for n in IMU_CH if n in hub_names]
        else:
            want = list(hub_names)
        return want, [1 + hub_names.index(n) for n in want]

    def _ensure(self, sensor: str) -> Optional[_SensorOut]:
        """Create (or recreate after a channel-layout change) the outlet for a sensor."""
        names, cols = self._wanted_channels(sensor)
        cur = self.outs.get(sensor)
        if not names:
            return cur
        src = self._hub_source()
        base = {"EEG": "neurobench_eeg", "OPTICS": "neurobench_optics", "ACCGYRO": "neurobench_imu"}[sensor]
        if sensor == "OPTICS":
            base += f"_{len(names)}"            # a different layout is a different stream
        sid = self._source_id(base)
        if cur is not None and cur.names == names and cur.source == src and cur.source_id == sid:
            cur.cols = cols
            return cur
        # New outlet: first time, channel layout changed, or the data source changed (sim -> muse ...)
        last_t = cur.last_t if cur is not None else None
        if cur is not None:
            _close_outlet(cur.outlet)
        outlet = _make_outlet(STREAM_NAMES[sensor], _TYPES[sensor], names, _FS[sensor], "float32", sid,
                              _units_for(sensor, names), source=src)
        so = _SensorOut(sensor, outlet, names, cols)
        so.source = src
        so.source_id = sid
        if last_t is not None:
            so.last_t = last_t
        else:
            # Only stream what arrives from now on, not the ring's history.
            rows = self.hub.latest(sensor, 1.0 / _FS[sensor])
            so.last_t = float(rows[-1, 0]) if rows.size else -math.inf
        self.outs[sensor] = so
        return so

    # ------------------------------------------------------------------ pushing
    def tick(self):
        """Push every hub sample newer than the last pushed one (called by the 100 ms timer)."""
        if not self._running:
            return
        try:
            if self._hub_source() != self._marker_source:
                self._open_marker_outlet()      # relabel the marker stream for the new source
            for s in ("EEG", "OPTICS", "ACCGYRO"):
                so = self._ensure(s)
                if so is not None:
                    self._push_new(so)
        except Exception as e:  # noqa: BLE001
            self.error.emit(f"LSL 发送出错，已停止：{type(e).__name__}: {e}")
            self.stop()

    def _push_new(self, so: _SensorOut):
        now = self.hub.now()
        span = now - so.last_t if math.isfinite(so.last_t) else 2.0
        span = min(max(span + 0.5, 0.5), max_catchup_s(so.sensor))
        rows = self.hub.latest(so.sensor, span)
        if rows.size == 0 or rows.shape[1] <= max(so.cols):
            return
        t = rows[:, 0]
        if t[-1] < so.last_t - 2.0:
            # The hub restarted its clock mapping (new source / cleared buffers): resynchronise.
            so.last_t = -math.inf
        new = t > so.last_t
        if not new.any():
            return
        rows = rows[new]
        data = np.ascontiguousarray(rows[:, so.cols], dtype=np.float32)
        stamps = rows[:, 0] + self.offset
        if len(data) == 1:          # mne_lsl warns on one-sample chunks
            if _LIB == "mne_lsl":
                so.outlet.push_sample(data[0], timestamp=float(stamps[0]))
            else:
                so.outlet.push_sample(data[0].tolist(), float(stamps[0]))
        elif _LIB == "mne_lsl":
            so.outlet.push_chunk(data, timestamp=stamps)
        else:
            so.outlet.push_chunk(data.tolist(), stamps.tolist())
        so.last_t = float(rows[-1, 0])
        so.pushed += len(rows)

    def push_marker(self, label: str, t_hub: Optional[float] = None) -> bool:
        """Send one marker string stamped at hub time t_hub (default: hub.now()). This is the way to
        send a marker with an exact event time, e.g. from a Recorder marker hook:
        push_marker(m["label"], rec.t_start + m["t"]). Returns False if not running or on failure."""
        if not self._running or self.marker_outlet is None:
            return False
        ts = self.to_lsl_time(self.hub.now() if t_hub is None else t_hub)
        try:
            if _LIB == "mne_lsl":
                self.marker_outlet.push_sample([str(label)], timestamp=ts)
            else:
                self.marker_outlet.push_sample([str(label)], ts)
        except Exception as e:  # noqa: BLE001
            self.error.emit(f"LSL 标记发送失败：{type(e).__name__}: {e}")
            return False
        self.markers_sent += 1
        return True
