"""Rough overnight sleep staging from the headband (unvalidated; clearly labelled as such).

v2 (plan item B7): thresholds are fixed for the person, not taken from the night's own percentiles, so nights
can be compared (a night with more deep sleep now shows more deep sleep).

Calibration: the first 5 minutes of the night are the awake reference (eyes-closed rest before sleep). Their
medians give the person's relaxed-wake muscle tone, alpha, eye-movement rate and slow-wave power with tonight's
headband fit. If that stretch is unusable (bad contact, or it already looks like deep sleep) the median reference
of the same person's earlier nights is used, and failing that generic values.

Per 30 s epoch, from the ear and forehead electrodes and the IMU:
  wake  : head movement; clear muscle activity; eyes-closed alpha near the awake level (no spindles); or
          awake muscle tone together with awake fast (beta) activity
  deep  : slow-wave (0.5-2 Hz) power >= 5x the awake reference (about +7 dB; N3 waves are >75 uV against
          10-20 uV awake) AND delta share >= max(0.55, awake + 0.2), with no movement and no extra muscle
  REM   : muscle tone well below relaxed wake (atonia), no movement, rapid eye movements clearly above the awake
          rate, little alpha and no sleep spindles (sigma 11-16 Hz bursts mean N2)
  light : everything else (N1/N2)
Slow-wave power and delta share use the in-phase part of each electrode pair (AF7+AF8, TP9+TP10): sideways eye
movements are opposite in sign on the two sides and cancel, true slow waves do not. Alpha/sigma/beta are shares
of 4-30 Hz power and muscle tone is 30-100 Hz log power (emg_p), because on the real recordings slow drift from
loose contact swamps shares of 0.5-30 Hz (an eyes-closed meditation read as "deep sleep" under v1).
A consumer 4-electrode band cannot do clinical staging; treat stage minutes as a rough guide and compare nights
with each other rather than with lab norms.
"""

from __future__ import annotations

import base64
import html
import io
import json
import math
from pathlib import Path

import numpy as np

from . import dsp
from .session import save_meta

EPOCH = 30.0
STAGES = ["清醒", "REM", "浅睡", "深睡"]          # plotting order, top to bottom
STAGE_COL = {"清醒": "#f59e0b", "REM": "#a78bfa", "浅睡": "#60a5fa", "深睡": "#1d4ed8"}
RULES_VERSION = 2
REF_MINUTES = 5.0
REF_KEYS = ("slow", "slow_c", "delta", "delta_c", "theta", "alpha", "sigma", "beta", "alpha_r", "sigma_r", "beta_r",
            "emg", "emg_p", "eye")
# generic values when there is no usable awake reference at all (typical relaxed eyes-closed wake on the band)
DEFAULT_REF = {"slow": float("nan"), "slow_c": float("nan"), "delta": 0.45, "delta_c": 0.45, "theta": 0.15,
               "alpha": 0.20, "sigma": 0.06, "beta": 0.12, "alpha_r": 0.25, "sigma_r": 0.12, "beta_r": 0.25,
               "emg": 0.10, "emg_p": float("nan"), "eye": 0.08}


def _band(f, p, lo, hi):
    m = (f >= lo) & (f < hi)
    return p[m].sum() * (f[1] - f[0])


def _common_psd(x, good, fs):
    """PSD of the in-phase part of each electrode pair (forehead AF7/AF8, ears TP9/TP10), averaged over pairs."""
    from scipy.signal import welch
    sigs = []
    for pair in ((1, 2), (0, 3)):
        use = [c for c in pair if c in good]
        if use:
            v = x[:, use].mean(axis=1)
            sigs.append(v - v.mean())
    if not sigs:
        v = x.mean(axis=1)
        sigs = [v - v.mean()]
    f, p = welch(np.column_stack(sigs), fs=fs, nperseg=int(4 * fs), axis=0)
    return f, p.mean(axis=1)


def epoch_features(s):
    if "EEG" not in (getattr(s, "data", None) or {}):
        return []                                  # recording without EEG: nothing to stage
    t, X, names = s.data["EEG"]
    X4 = X[:, [names.index(n) for n in dsp.EEG_NAMES]]
    fs = dsp.FS_EEG
    W = int(EPOCH * fs)
    n = len(X4) // W
    tg, G = (s.data["ACCGYRO"][0], s.data["ACCGYRO"][1]) if "ACCGYRO" in s.data else (None, None)
    from scipy.signal import welch
    rows = []
    for k in range(n):
        sl = slice(k * W, (k + 1) * W)
        x = X4[sl]
        q = dsp.window_quality(x)
        ok = [c for c, (lv, _) in enumerate(q) if lv > 0]
        good = ok or [0, 3]                        # features still computed, but the epoch is marked bad below
        xx = x[:, good] - x[:, good].mean(axis=0)
        f, p = welch(xx, fs=fs, nperseg=int(4 * fs), axis=0)
        p = p.mean(axis=1)
        tot = _band(f, p, 0.5, 30) or 1e-9
        keepf = ~dsp.line_bins(f)
        emg = _band(f[keepf], p[keepf], 30, 100) / (_band(f[keepf], p[keepf], 0.5, 100) or 1e-9)
        fc, pc = _common_psd(x, good, fs)
        totc = _band(fc, pc, 0.5, 30) or 1e-9
        fr = dsp.clean_eeg(x[:, [1, 2]], fs, 0.3, 5)
        okL, okR = q[1][0] > 0, q[2][0] > 0
        if okL and okR:
            heog, thr, src = fr[:, 0] - fr[:, 1], 8.0, "both"   # left minus right: sideways eye movements add up
        elif okL or okR:                                         # one forehead only: about half the swing
            heog, thr, src = fr[:, 0 if okL else 1], 4.0, ("AF7" if okL else "AF8")
        else:
            heog, thr, src = None, 0.0, "none"
        eye = float(np.mean(np.abs(np.diff(heog[:: int(fs / 8)])) > thr)) if heog is not None else float("nan")
        mot = float("nan")
        if G is not None:
            m = (tg >= t[sl][0]) & (tg < t[sl][-1])
            if m.sum() > 20:
                mot = dsp.motion_level(G[m, 3:6])
        fast = _band(f, p, 4, 30) or 1e-9          # shares of 4-30 Hz are not swamped by slow drift
        rows.append({"t": float(t[sl][0]), "slow": np.log(_band(f, p, 0.5, 2) + 1e-9),
                     "alpha_r": _band(f, p, 8, 12) / fast, "sigma_r": _band(f, p, 11, 16) / fast,
                     "beta_r": _band(f, p, 16, 30) / fast,
                     "emg_p": float(np.log(_band(f[keepf], p[keepf], 30, 100) + 1e-9)),
                     "slow_c": float(np.log(_band(fc, pc, 0.5, 2) + 1e-9)), "delta_c": _band(fc, pc, 0.5, 4) / totc,
                     "delta": _band(f, p, 0.5, 4) / tot, "theta": _band(f, p, 4, 8) / tot,
                     "alpha": _band(f, p, 8, 12) / tot, "sigma": _band(f, p, 11, 16) / tot,
                     "beta": _band(f, p, 16, 30) / tot, "emg": emg, "eye": eye, "eye_src": src, "motion": mot,
                     "bad": len(ok) < 2})
    return rows


# --------------------------------------------------------------------------- awake reference and thresholds
def _nanmed(v):
    v = np.asarray([x for x in v if isinstance(x, (int, float))], float)
    v = v[np.isfinite(v)]
    return float(np.median(v)) if len(v) else float("nan")


def awake_reference(rows, minutes: float = REF_MINUTES) -> dict | None:
    """Medians of the first `minutes` of the night (eyes-closed rest before sleep), or None if unusable."""
    if not rows:
        return None
    n_ref = min(int(round(minutes * 60 / EPOCH)), max(2, len(rows) // 4))
    use = [r for r in rows[:n_ref] if not r.get("bad")]
    if len(use) < 3:
        return None
    ref = {k: _nanmed([r.get(k) for r in use]) for k in REF_KEYS}
    ref.update(source="tonight", n=len(use), minutes=round(len(use) * EPOCH / 60, 1))
    return ref


def person_reference(earlier: list) -> dict | None:
    """Median awake reference of the same person's earlier nights (only references measured on those nights)."""
    refs = [e["ref"] for e in earlier if (e.get("ref") or {}).get("source") == "tonight"]
    if not refs:
        return None
    ref = {k: _nanmed([r.get(k) for r in refs]) for k in REF_KEYS}
    ref.update(source="earlier", n=len(refs))
    return ref


def choose_reference(rows, earlier: list | None = None) -> dict | None:
    """Tonight's first minutes; the person's earlier nights if tonight's start is unusable or already looks like
    deep sleep compared with those nights (slow waves 5x stronger and delta-dominated); else None (generic)."""
    tonight = awake_reference(rows)
    past = person_reference(earlier or [])
    if tonight and past and all(math.isfinite(x) for x in (tonight["slow_c"], past["slow_c"])):
        if tonight["slow_c"] > past["slow_c"] + math.log(5.0) and tonight["delta_c"] > 0.85:
            return past
    elif tonight and looks_deep_start(tonight):
        return past                                 # None without history: generic values, not tonight's deep sleep
    return tonight or past


def looks_deep_start(ref: dict) -> bool:
    """Without earlier nights: tonight's start is delta-dominated with no eyes-closed alpha, i.e. already deep sleep
    (relaxed wake has delta_c well below 0.85 and alpha above 0.15 of 4-30 Hz power)."""
    delta_c, alpha = ref.get("delta_c"), ref.get("alpha_r")
    return (isinstance(delta_c, float) and math.isfinite(delta_c) and delta_c > 0.85
            and isinstance(alpha, float) and math.isfinite(alpha) and alpha < 0.15)


def _fill(ref: dict | None) -> dict:
    out = dict(DEFAULT_REF)
    if ref:
        for k in REF_KEYS:
            v = ref.get(k)
            if isinstance(v, (int, float)) and math.isfinite(v):
                out[k] = float(v)
        out["source"] = ref.get("source", "generic")
        if out["source"] == "earlier":              # absolute powers depend on tonight's fit: do not carry them over
            out["slow_c"] = out["emg_p"] = float("nan")
    else:
        out["source"] = "generic"
    return out


def thresholds(ref: dict | None) -> dict:
    """Fixed per-person stage thresholds from the awake reference plus literature-based absolute bounds.

    Powers are natural-log uV^2, so +ln(5) is 5x (about +7 dB). alpha/sigma/beta use shares of 4-30 Hz power.
    """
    r = _fill(ref)
    has_slow, has_emg = math.isfinite(r["slow_c"]), math.isfinite(r["emg_p"])
    nan = float("nan")
    return {
        "mot_wake": 3.0, "mot_deep": 1.5, "mot_rem": 1.0,                 # deg/s RMS head rotation
        "emg_wake": max(0.30, 2.5 * r["emg"]),                             # clear muscle activity (share)
        "emg_p_wake": r["emg_p"] + math.log(4.0) if has_emg else nan,
        # relaxed-wake muscle tone; sleep lowers it, REM atonia lowers it by half or more
        "emg_p_awake": r["emg_p"] - math.log(1.25) if has_emg else nan,
        "emg_p_rem": r["emg_p"] - math.log(2.0) if has_emg else nan,
        "emg_awake": 0.8 * r["emg"], "emg_rem": 0.5 * r["emg"],          # share-based fallbacks
        "beta_awake": 0.9 * r["beta_r"],
        "alpha_wake": max(0.15, 0.6 * r["alpha_r"]),                       # alpha drops >40% at sleep onset
        "slow_deep": r["slow_c"] + math.log(5.0) if has_slow else nan,
        "delta_deep": min(0.85, max(0.55, r["delta_c"] + 0.20)) if has_slow else 0.75,
        "eye_rem": min(0.25, max(0.03, 1.25 * r["eye"])),                  # rapid eye movements above awake rate
        "sigma_spindle": max(0.12, 1.5 * r["sigma_r"]),                    # N2 spindles, not REM
    }


def _f(r, k, default=0.0):
    v = r.get(k)
    return default if not isinstance(v, (int, float)) or not math.isfinite(v) else float(v)


def stage(rows, ref: dict | None = None):
    """Label each epoch. `ref` is the awake reference (default: the first 5 minutes of these rows)."""
    if not rows:
        return []
    if ref is None:
        ref = awake_reference(rows)
    th = thresholds(ref)
    use_p = math.isfinite(th["emg_p_awake"])
    out = []
    for r in rows:
        mot = _f(r, "motion")
        if r.get("bad"):
            out.append("清醒" if mot > th["mot_wake"] else (out[-1] if out else "清醒"))
            continue
        emg, eye = _f(r, "emg"), _f(r, "eye")
        alpha, beta, sigma = _f(r, "alpha_r"), _f(r, "beta_r"), _f(r, "sigma_r")
        slow_c, delta_c = _f(r, "slow_c", _f(r, "slow")), _f(r, "delta_c", _f(r, "delta"))
        if use_p:
            emg_p = _f(r, "emg_p", -50.0)
            tense, awake_tone, atonia = emg_p > th["emg_p_wake"], emg_p >= th["emg_p_awake"], emg_p <= th["emg_p_rem"]
        else:
            tense, awake_tone, atonia = False, emg >= th["emg_awake"], emg <= th["emg_rem"]
        tense = tense or emg > th["emg_wake"]
        spindle = sigma >= th["sigma_spindle"] and alpha < th["alpha_wake"]
        deep_slow = not math.isfinite(th["slow_deep"]) or slow_c >= th["slow_deep"]
        if (mot > th["mot_wake"] or tense or (alpha >= th["alpha_wake"] and not spindle)
                or (awake_tone and beta >= th["beta_awake"] and delta_c < th["delta_deep"])):
            out.append("清醒")
        elif deep_slow and delta_c >= th["delta_deep"] and not tense and not awake_tone and mot < th["mot_deep"]:
            out.append("深睡")
        elif atonia and mot < th["mot_rem"] and eye >= th["eye_rem"] and not spindle:
            out.append("REM")
        else:
            out.append("浅睡")
    # smoothing: a single epoch that differs from both neighbours takes their stage
    sm = out[:]
    for i in range(1, len(out) - 1):
        if out[i - 1] == out[i + 1] != out[i]:
            sm[i] = out[i - 1]
    return sm


def summary(stages):
    n = len(stages)
    if n == 0:
        return {}
    mins = lambda k: sum(1 for x in stages if x == k) * EPOCH / 60  # noqa: E731
    asleep = [i for i, x in enumerate(stages) if x != "清醒"]
    onset = asleep[0] * EPOCH / 60 if asleep else None
    last = asleep[-1] if asleep else None
    waso = sum(1 for x in stages[asleep[0]:last + 1] if x == "清醒") * EPOCH / 60 if asleep else None
    awakenings = sum(1 for i in range(1, len(stages)) if stages[i] == "清醒" and stages[i - 1] != "清醒" and asleep and i > asleep[0])
    tst = sum(mins(k) for k in ("REM", "浅睡", "深睡"))
    return {"in_bed_min": n * EPOCH / 60, "sleep_min": tst, "onset_min": onset, "waso_min": waso,
            "awakenings": awakenings, "efficiency": tst / (n * EPOCH / 60) if n else None,
            **{f"{k}_min": mins(k) for k in STAGES}}


# --------------------------------------------------------------------------- the same person's earlier nights
def earlier_nights(d: Path, meta: dict, limit: int = 30):
    """Earlier overnight recordings of the same person staged with these rules.

    Returns (nights, n_old): nights newest first as {"dir", "started_at", "sleep", "ref"}; n_old counts the
    person's earlier nights that were staged with the old rules (not comparable until their report is rebuilt).
    """
    from . import people as P
    from . import session as S
    who, t0, sim = P.person_of(meta), meta.get("started_at", ""), meta.get("source") == "sim"
    try:
        me = Path(d).resolve()
    except Exception:  # noqa: BLE001
        me = Path(d)
    out, n_old = [], 0
    try:
        sessions = S.list_sessions()
    except Exception:  # noqa: BLE001
        sessions = []
    for dd, m in sessions:
        try:
            if Path(dd).resolve() == me:
                continue
        except Exception:  # noqa: BLE001
            pass
        if m.get("protocol") != "过夜睡眠" or P.person_of(m) != who or (m.get("source") == "sim") != sim:
            continue
        if not t0 or not (m.get("started_at", "") < t0):
            continue
        sl = m.get("sleep") or {}
        if not sl.get("in_bed_min"):
            continue
        if (m.get("sleep_ref") or {}).get("version") != RULES_VERSION:
            n_old += 1
            continue
        out.append({"dir": str(dd), "started_at": m.get("started_at", ""), "sleep": sl, "ref": m.get("sleep_ref") or {}})
    out.sort(key=lambda e: e["started_at"], reverse=True)
    return out[:limit], n_old


COMPARE_ROWS = (("估计睡着的时长", "sleep_min", "分钟"), ("入睡用时", "onset_min", "分钟"),
                ("睡着后醒着的时间", "waso_min", "分钟"), ("醒来次数", "awakenings", "次"),
                ("睡眠效率", "efficiency", "%"), ("浅睡", "浅睡_min", "分钟"), ("深睡", "深睡_min", "分钟"),
                ("REM（可能）", "REM_min", "分钟"))


def compare_rows(sm: dict, earlier: list) -> list:
    """Rows of (label, tonight, earlier mean, earlier min, earlier max, words) for the comparison table."""
    rows = []
    for label, key, unit in COMPARE_ROWS:
        scale = 100.0 if unit == "%" else 1.0
        now = sm.get(key)
        hist = [e["sleep"].get(key) for e in earlier]
        hist = [float(v) * scale for v in hist if isinstance(v, (int, float))]
        if now is None or not hist:
            continue
        now = float(now) * scale
        mean, lo, hi = float(np.mean(hist)), min(hist), max(hist)
        diff = now - mean
        tol = max(3.0 if unit == "分钟" else (1.0 if unit == "次" else 3.0), 0.05 * abs(mean))
        if abs(diff) < tol:
            words = "差不多"
        else:
            u = "个百分点" if unit == "%" else unit
            words = f"{'多' if diff > 0 else '少'} {abs(diff):.0f} {u}"
            if now > hi or now < lo:
                words += "（超出以往范围）"
        rows.append((label, now, mean, lo, hi, words, unit))
    return rows


def _compare_html(sm: dict, earlier: list, n_old: int) -> str:
    note_old = (f"<p style='color:#6b7280'>另外有 {n_old} 晚是用旧规则算的，不能直接比较；"
                "打开那几晚，在回看页点『重新生成睡眠报告』后就会算进来。</p>"
                if n_old else "")
    rows = compare_rows(sm, earlier) if len(earlier) >= 2 else []
    if not rows:
        if n_old:
            return "<h2>和你以往的夜晚比</h2>" + note_old
        return ""
    fmt = lambda v, unit: f"{v:.0f}{'%' if unit == '%' else (' ' + unit)}"  # noqa: E731
    body = "".join(f"<tr><td>{html.escape(lab)}</td><td><b>{fmt(now, u)}</b></td><td>{fmt(mean, u)}</td>"
                   f"<td>{fmt(lo, u)} ~ {fmt(hi, u)}</td><td>{html.escape(w)}</td></tr>"
                   for lab, now, mean, lo, hi, w, u in rows)
    return (f"<h2>和你以往的夜晚比</h2><p>和你之前的 {len(earlier)} 晚比较（都是同一套规则算的）。</p>"
            f"<table><tr><th></th><th>今晚</th><th>以往平均</th><th>以往范围</th><th>比较</th></tr>{body}</table>"
            + note_old)


def _clean(v):
    if isinstance(v, float):
        return round(v, 4) if math.isfinite(v) else None
    return v


_BUSY: set = set()
_BUSY_LOCK = __import__("threading").Lock()


def build_sleep_report(d: Path):
    """One night at a time per folder: a second call while the first still runs returns an error dict."""
    key = str(Path(d).resolve())
    with _BUSY_LOCK:
        if key in _BUSY:
            return {"error": "这一晚的睡眠报告正在生成，稍等一下。"}
        _BUSY.add(key)
    try:
        return _build_sleep_report(d)
    finally:
        with _BUSY_LOCK:
            _BUSY.discard(key)


def _build_sleep_report(d: Path):
    from .session import load_session
    d = Path(d)
    s = load_session(d)
    rows = epoch_features(s)
    meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
    if not rows:                                   # no EEG, or shorter than one 30 s epoch: nothing to stage
        why = ("这段录音里没有脑电数据" if "EEG" not in (getattr(s, "data", None) or {})
               else "这段录音的脑电不足 30 秒")
        msg = f"{why}，无法估算睡眠分期，没有生成睡眠报告。请确认头环连接正常、录满整晚后再试。"
        (d / "sleep_report.html").write_text(
            f"<!doctype html><html lang=zh><meta charset=utf-8><title>睡眠报告</title>"
            f"<body style='font-family:\"Microsoft YaHei\",sans-serif;max-width:860px;margin:24px auto;padding:0 16px'>"
            f"<h1>睡眠报告</h1><p>{html.escape(msg)}</p></body></html>", encoding="utf-8")
        return {"error": msg}
    earlier, n_old = earlier_nights(d, meta)
    ref = choose_reference(rows, earlier)
    # stage(rows, None) would re-derive tonight's reference; when choose_reference rejected it, stage generically
    st = stage(rows, ref if ref is not None else {"source": "generic"})
    sm = summary(st)
    th = thresholds(ref)
    meta["sleep"] = {k: (round(v, 1) if isinstance(v, float) else v) for k, v in sm.items()}
    used = _fill(ref)
    meta["sleep_ref"] = {"version": RULES_VERSION, "source": used["source"], "n": (ref or {}).get("n", 0),
                         **{k: _clean(used[k]) for k in REF_KEYS},
                         "thresholds": {k: _clean(v) for k, v in th.items()}}
    save_meta(d, meta)
    with open(d / "sleep_stages.csv", "w", encoding="utf-8-sig") as f:
        f.write("t_s,stage,delta,theta,alpha,sigma,emg,eye,motion,delta_c,slow_c\n")
        for r, x in zip(rows, st):
            f.write(f"{r['t']:.0f},{x},{r['delta']:.4f},{r['theta']:.4f},{r['alpha']:.4f},{r['sigma']:.4f},"
                    f"{r['emg']:.4f},{r['eye']:.3f},{r['motion']:.2f},{r['delta_c']:.4f},{r['slow_c']:.3f}\n")
    img = ""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
        fig, ax = plt.subplots(figsize=(10, 2.8))
        y = [STAGES.index(x) for x in st]
        tt = [r["t"] / 3600 for r in rows]
        ax.step(tt, y, where="post", color="#334155", lw=1)
        for k in STAGES:
            m = [i for i, x in enumerate(st) if x == k]
            ax.scatter([tt[i] for i in m], [STAGES.index(k)] * len(m), s=6, color=STAGE_COL[k])
        ax.set_yticks(range(len(STAGES)))
        ax.set_yticklabels(STAGES)
        ax.invert_yaxis()
        ax.set_xlabel("小时")
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=110)
        plt.close(fig)
        img = f"<img src='data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}' style='width:100%'>"
    except Exception:  # noqa: BLE001
        pass
    f = lambda v, unit="分钟": "—" if v is None else f"{v:.0f} {unit}"  # noqa: E731
    sm_rows = "".join(f"<tr><td>{a}</td><td>{b}</td></tr>" for a, b in (
        ("躺下时长", f(sm.get("in_bed_min"))), ("估计睡着的时长", f(sm.get("sleep_min"))),
        ("入睡用时", f(sm.get("onset_min"))), ("睡着后醒着的时间", f(sm.get("waso_min"))),
        ("醒来次数", f(sm.get("awakenings"), "次")),
        ("睡眠效率", "—" if sm.get("efficiency") is None else f"{sm['efficiency'] * 100:.0f}%"),
        ("浅睡", f(sm.get("浅睡_min"))), ("深睡", f(sm.get("深睡_min"))), ("REM（可能）", f(sm.get("REM_min")))))
    srcs = [r.get("eye_src", "both") for r in rows]
    eye_note = ""
    if srcs:
        single = sum(x in ("AF7", "AF8") for x in srcs) / len(srcs)
        none = srcs.count("none") / len(srcs)
        if single + none > 0.2:
            eye_note = (f"<p class=warn>这一晚有 {single * 100:.0f}% 的时间只有一侧前额电极贴合良好、{none * 100:.0f}% 的时间两侧都不好，"
                        "眼动（判断 REM 的主要依据）只能用单侧估计或估计不了，<b>REM 的时长可信度较低</b>。</p>")
    ref_note = {
        "tonight": f"判断标准以你今晚开头 {(ref or {}).get('minutes', REF_MINUTES):.0f} 分钟闭眼静躺时的脑电和肌肉活动为参照，"
                   "再加上睡眠研究里的固定界限，所以不同晚上可以直接比较。",
        "earlier": "今晚开头几分钟的信号用不了（电极没贴好，或者一开始就睡着了），改用你以往夜晚开头的清醒参照。"
                   "头环每晚戴得松紧不同，这一晚的深睡时长误差可能大一些。",
        "generic": "今晚开头几分钟的信号用不了，你也还没有以往的夜晚可参照，只能用通用数值判断，<b>这一晚的分期误差会比较大</b>。"
                   "下次睡前请先闭眼静躺 5 分钟再入睡。",
    }[used["source"]]
    page = f"""<!doctype html><html lang=zh><meta charset=utf-8><title>睡眠报告</title>
<style>body{{font-family:"Microsoft YaHei",sans-serif;max-width:860px;margin:24px auto;padding:0 16px;color:#1f2937}}
td,th{{border-bottom:1px solid #e5e7eb;padding:7px 8px;text-align:left}}table{{border-collapse:collapse;width:100%}}
h2{{font-size:18px;margin-top:28px}}
.warn{{background:#fffbeb;border-left:4px solid #f59e0b;padding:8px 14px}}</style>
<h1>睡眠报告（粗略估计）</h1><p>{html.escape(meta.get('started_at', '')[:16].replace('T', ' '))}</p>
<p class=warn>这是根据头环的 4 个电极、运动传感器按规则估算的结果，<b>没有经过和医院睡眠监测的对照验证</b>。
适合同一个人不同晚上互相比较，不适合判断有没有睡眠疾病。</p>
<p>{ref_note}</p>
{eye_note}{img}<table>{sm_rows}</table>
{_compare_html(sm, earlier, n_old)}
<p>每 30 秒的分期和用到的指标保存在 sleep_stages.csv。</p></html>"""
    (d / "sleep_report.html").write_text(page, encoding="utf-8")
    return sm
