"""回看 page: per-session segment analysis; 趋势 page: across sessions."""

from __future__ import annotations

import math
import os
from datetime import datetime
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QComboBox, QFileDialog, QHBoxLayout, QHeaderView, QListWidget, QListWidgetItem, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from . import dsp
from . import theme as T
from . import session as S
from .session import METRIC_LABELS, export_segments_csv, list_all_sessions, load_session
from .cloud import is_uploaded
from . import people as P


def _load_name(d: Path) -> str:
    import json
    try:
        return json.loads((d / "session.json").read_text(encoding="utf-8")).get("name", d.name)
    except Exception:  # noqa: BLE001
        return d.name


def _mark_imported(d: Path, sources):
    import json
    p = d / "session.json"
    try:
        meta = json.loads(p.read_text(encoding="utf-8"))
        meta.setdefault("imported_from", ", ".join(Path(x).name for x in sources))
        S.save_meta(d, meta)
    except Exception:  # noqa: BLE001
        pass
from .widgets import Card, label, legend_row, plot

PCT_KEYS = {"alpha", "theta", "beta", "delta", "emg", "clean_share"}
SEG_COLORS = ["#5eead4", "#a78bfa", "#fbbf24", "#f472b6", "#60a5fa", "#34d399", "#fb923c", "#c084fc"]


def f(v, nd=1, pct=False):
    if not isinstance(v, (int, float)) or (isinstance(v, float) and math.isnan(v)):
        return "—"
    return f"{v * 100:.{nd}f}%" if pct else f"{v:.{nd}f}"


def mmss(s):
    s = int(round(s))
    return f"{s // 60}:{s % 60:02d}"


class ReviewPage(QWidget):
    def __init__(self):
        super().__init__()
        self.session = None
        self.rows = []
        root = QHBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)

        # ---------------- session list
        lc = Card("录制记录")
        lc.setFixedWidth(290)
        self.lst = QListWidget()
        self.lst.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self.lst.currentItemChanged.connect(self._pick)
        lc.add(self.lst, 1)
        row = QHBoxLayout()
        b = QPushButton("刷新")
        b.setObjectName("ghost")
        b.clicked.connect(self.refresh)
        row.addWidget(b)
        b2 = QPushButton("打开文件夹")
        b2.setObjectName("ghost")
        b2.clicked.connect(self._open_folder)
        row.addWidget(b2)
        lc.add(row)
        row2 = QHBoxLayout()
        self.b_exp = QPushButton("导出选中")
        self.b_exp.setObjectName("ghost")
        self.b_exp.setToolTip("按住 Ctrl 或 Shift 可多选；导出成一个 .zip，拷到另一台电脑")
        self.b_exp.clicked.connect(self.export_selected)
        row2.addWidget(self.b_exp)
        self.b_imp = QPushButton("导入…")
        self.b_imp.setObjectName("ghost")
        self.b_imp.setToolTip("选另一台电脑导出的 .zip；也可以直接把 .zip 拖进窗口")
        self.b_imp.clicked.connect(self.import_dialog)
        row2.addWidget(self.b_imp)
        lc.add(row2)
        self.l_xfer = label("两台电脑之间互传：这边「导出选中」，那边「导入」或把 .zip 拖进窗口。", "faint", wrap=True)
        lc.add(self.l_xfer)
        row3 = QHBoxLayout()
        self.l_cloud = label("云端上传：未设置", "faint", wrap=True)
        row3.addWidget(self.l_cloud, 1)
        self.b_up = QPushButton("立即上传")
        self.b_up.setObjectName("ghost")
        self.b_up.setToolTip("把还没上传的录制传到私有仓库（「···」→「云端上传设置」）")
        self.b_up.clicked.connect(self._upload_now)
        row3.addWidget(self.b_up)
        lc.add(row3)
        self.cloud = None
        root.addWidget(lc)

        # ---------------- detail
        right = QVBoxLayout()
        right.setSpacing(14)
        head = QHBoxLayout()
        self.l_title = label("选择左边的一次录制", "h1")
        head.addWidget(self.l_title)
        head.addStretch(1)
        self.b_csv = QPushButton("导出表格")
        self.b_csv.clicked.connect(self._export_csv)
        self.b_png = QPushButton("保存截图")
        self.b_png.clicked.connect(self._export_png)
        self.b_resleep = QPushButton("重新生成睡眠报告")
        self.b_resleep.setToolTip("用最新的分期规则重新算这一晚（以后各晚才能互相比较）")
        self.b_resleep.clicked.connect(self._rebuild_sleep)
        self.b_resleep.setVisible(False)
        head.addWidget(self.b_resleep)
        self.b_research = QPushButton("研究导出…")
        self.b_research.setToolTip("导出 CSV + EDF + 事件表 + 分析笔记本（Jupyter），拿去自己分析或发给别人")
        self.b_research.clicked.connect(self._export_research)
        head.addWidget(self.b_research)
        self.b_owner = QPushButton("改归属…")
        self.b_owner.setToolTip("这条录制是谁的（录错人时改这里）")
        self.b_owner.clicked.connect(self._reassign)
        head.addWidget(self.b_owner)
        head.addWidget(self.b_csv)
        head.addWidget(self.b_png)
        self.b_report = QPushButton("查看报告")
        self.b_report.setObjectName("primary")
        self.b_report.clicked.connect(self._open_report)
        self.b_report.setVisible(False)
        head.addWidget(self.b_report)
        right.addLayout(head)
        self.l_meta = label("", "muted", wrap=True)
        right.addWidget(self.l_meta)

        top = QHBoxLayout()
        top.setSpacing(14)
        cbar = Card("各段对比", "相对功率，已剔除肌电过大的片段")
        self.p_bar = plot()
        cbar.add(self.p_bar, 1)
        cbar.add(legend_row([(dsp.BAND_LABELS[k], dsp.BAND_COLORS[k]) for k in ("theta", "alpha", "beta")]))
        top.addWidget(cbar, 3)
        cpsd = Card("频谱", "每段平均")
        self.p_psd = plot(left="功率 (对数)", bottom="Hz")
        self.p_psd.setLogMode(x=False, y=True)
        cpsd.add(self.p_psd, 1)
        top.addWidget(cpsd, 2)
        right.addLayout(top, 3)

        ctl = Card("全程 α 变化", "每 2 秒一点 · 灰点=肌电或贴合不良 · 竖线=标记")
        self.p_time = plot(bottom="分钟")
        ctl.add(self.p_time, 1)
        right.addWidget(ctl, 2)
        # ---------------- event-locked averages around the user's own markers (v0.10)
        self.c_ev = Card("事件前后", "把同一种标记前后 10 秒叠加平均：耳后 α、心率、头部晃动")
        evr = QHBoxLayout()
        self.cb_ev = QComboBox()
        self.cb_ev.currentTextChanged.connect(self._draw_event)
        evr.addWidget(self.cb_ev)
        self.l_ev = label("", "faint")
        evr.addWidget(self.l_ev, 1)
        self.c_ev.add(evr)
        self.p_ev = plot(bottom="相对标记的秒数")
        self.c_ev.add(self.p_ev, 1)
        self.c_ev.setVisible(False)
        self.c_ev.setMaximumHeight(240)                  # keep room for the α plot above
        right.addWidget(self.c_ev, 1)
        # ---------------- video / audio of this session, synced with the cursor on the α plot
        from .av_ui import AVPanel
        self.c_av = Card("录像 / 录音", "拖动上图的竖线跳到那一刻；播放时竖线跟着走")
        self.av_panel = AVPanel()
        self.c_av.add(self.av_panel, 1)
        avb = QHBoxLayout()
        self.l_av = label("", "faint")
        avb.addWidget(self.l_av, 1)
        self.b_avan = QPushButton("分析音视频")
        self.b_avan.setObjectName("ghost")
        self.b_avan.setToolTip("找出说话的时段、声音大小、画面里的动作，并用提示音校准对齐；结果画在上面的 α 图里")
        self.b_avan.clicked.connect(self._analyse_media)
        avb.addWidget(self.b_avan)
        b = QPushButton("删除这次的音视频")
        b.setObjectName("ghost")
        b.clicked.connect(self._delete_media)
        avb.addWidget(b)
        self.c_av.add(avb)
        self.c_av.setVisible(False)
        right.addWidget(self.c_av, 0)
        self._right = right
        self.cursor = None
        self.av_panel.moved.connect(self._media_moved)

        ct = Card("分段指标")
        self.tbl = QTableWidget()
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        ct.add(self.tbl, 1)
        right.addWidget(ct, 2)
        rw = QWidget()
        rw.setLayout(right)
        root.addWidget(rw, 1)
        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self, select: str | None = None):
        self.lst.blockSignals(True)
        self.lst.clear()
        self.rows = list_all_sessions()
        for r in self.rows:
            d, meta = r["dir"], r["meta"]
            started = meta.get("started_at", "")[:16].replace("T", " ")
            src = {"sim": " · 模拟", "replay": " · 回放"}.get(meta.get("source"), "")
            imp = "  ⇩" if meta.get("imported_from") else ""
            imp += "  · 已上传" if is_uploaded(d) else ""
            if len(P.people()) > 1 or P.person_of(meta) != "me":
                imp += f"  · {P.name_of(P.person_of(meta))}"
            it = QListWidgetItem(f"{meta.get('name', d.name)}{imp}\n{started} · {mmss(meta.get('duration', 0))}{src}")
            it.setData(Qt.ItemDataRole.UserRole, str(d))
            self.lst.addItem(it)
        self.lst.blockSignals(False)
        if self.lst.count():
            row = 0
            if select:
                for i in range(self.lst.count()):
                    if Path(self.lst.item(i).data(Qt.ItemDataRole.UserRole)).name == Path(select).name:
                        row = i
            self.lst.setCurrentRow(row)
            self._pick(self.lst.item(row), None)

    # ------------------------------------------------------------------ cloud
    def set_cloud_status(self, text: str):
        self.l_cloud.setText(text)

    def refresh_marks(self):
        """An upload finished: add the 已上传 mark without reloading the selected recording."""
        for i in range(self.lst.count()):
            it = self.lst.item(i)
            d = Path(it.data(Qt.ItemDataRole.UserRole))
            first, _, rest = it.text().partition("\n")
            if is_uploaded(d) and "已上传" not in first:
                it.setText(f"{first}  · 已上传\n{rest}")

    def _upload_now(self):
        if self.cloud is None:
            return
        from .cloud import load_token
        if not load_token():
            self.l_cloud.setText("还没设置：右上角「···」→「云端上传设置」，粘贴一次令牌。")
            return
        self.l_cloud.setText("云端上传：开始…")
        self.cloud.kick(manual=True)

    # ------------------------------------------------------------------ export / import
    def export_selected(self):
        items = self.lst.selectedItems() or ([self.lst.currentItem()] if self.lst.currentItem() else [])
        dirs = [Path(it.data(Qt.ItemDataRole.UserRole)) for it in items]
        if not dirs:
            self.l_xfer.setText("先在上面选中要导出的录制（Ctrl/Shift 可多选）。")
            return
        stamp = datetime.now().strftime("%Y%m%d_%H%M")
        tag = S.safe_name(_load_name(dirs[0])) if len(dirs) == 1 else f"{len(dirs)}条"
        default = Path.home() / "Desktop" / f"NeuroBench_{tag}_{stamp}.zip"
        if not default.parent.exists():
            default = Path.home() / default.name
        path, _ = QFileDialog.getSaveFileName(self, "导出录制", str(default), "压缩包 (*.zip)")
        if not path:
            return
        try:
            n, size = S.export_sessions(dirs, Path(path))
        except Exception as e:  # noqa: BLE001
            self.l_xfer.setText(f"导出失败：{e}")
            return
        self.l_xfer.setText(f"已导出 {n} 条（{size / 1e6:.1f} MB）：\n{path}")

    def import_dialog(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "导入录制", str(Path.home() / "Downloads"), "NeuroBench 导出 (*.zip)")
        if paths:
            self.import_paths(paths)

    def import_paths(self, paths):
        got, skipped, bad = [], [], []
        for p in paths:
            try:
                g, s_ = S.import_archive(Path(p), imported_from=Path(p).name)
                got += g
                skipped += s_
                if not g and not s_:
                    bad.append(Path(p).name)
            except Exception as e:  # noqa: BLE001
                bad.append(f"{Path(p).name}（{e}）")
        for name in got:
            _mark_imported(S.ROOT / name, paths)
        msg = [f"导入 {len(got)} 条"]
        if skipped:
            msg.append(f"{len(skipped)} 条本机已有，跳过")
        if bad:
            msg.append("没找到录制：" + "、".join(bad))
        self.l_xfer.setText("，".join(msg) + "。")
        self.refresh(str(S.ROOT / got[0]) if got else None)

    def _pick(self, item, _prev):
        if item is None:
            return
        try:
            self.session = load_session(Path(item.data(Qt.ItemDataRole.UserRole)))
        except Exception as e:  # noqa: BLE001
            self.l_title.setText("读取失败")
            self.l_meta.setText(str(e))
            return
        self._render()

    def _render(self):
        s = self.session
        m = s.meta
        self.l_title.setText(s.title)
        self.b_report.setVisible((s.dir / "report.html").exists() or (s.dir / "practice_report.html").exists()
                                 or (s.dir / "erp_report.html").exists()
                                 or m.get("protocol") in ("心理状态测评", "过夜睡眠", "练功前后对比"))
        self.b_resleep.setVisible(m.get("protocol") == "过夜睡眠")
        src = {"sim": "模拟数据", "replay": "回放数据", "muse": m.get("device", {}).get("name", "")}.get(m.get("source"), "")
        notes = m.get("notes", "").strip()
        med = m.get("meditation")
        if med:
            notes = (notes + "\n" if notes else "") + (
                f"冥想：平静 {med.get('calm_pct', 0):.0f}% · 中性 {med.get('neutral_pct', 0):.0f}% · 活跃 {med.get('active_pct', 0):.0f}% · "
                f"鸟叫 {med.get('birds', 0)} 次 · 回到平静 {med.get('recoveries', 0)} 次")
        try:
            from . import baseline as B
            table = B.baseline_table(B.session_rows())
            cmp_lines = []
            for g in s.segments:
                for k, name in (("alpha", "α"), ("hr", "心率"), ("blink_rate", "眨眼")):
                    c = B.versus_usual(g.metrics.get(k), g.label, k, table)
                    if c and abs(c["z"]) >= 1:
                        cmp_lines.append(f"{g.label} 的{name}{c['text']}")
            if cmp_lines:
                notes = (notes + "\n" if notes else "") + "和你平时比：" + "；".join(cmp_lines[:4])
        except Exception:  # noqa: BLE001
            pass
        sr = m.get("self_report") or {}
        if sr:
            notes = (notes + "\n" if notes else "") + (
                f"自评：{sr.get('activity', '')} · 平静 {sr.get('sr_calm', '—')} · 专注 {sr.get('sr_focus', '—')} · "
                f"困倦 {sr.get('sr_sleepy', '—')} · 心情 {sr.get('sr_mood', '—')} · 昨晚睡 {sr.get('sr_sleep_h', '—')} 小时"
                + (f" · {sr['note']}" if sr.get("note") else ""))
        self.l_meta.setText(f"{m.get('started_at', '')[:16].replace('T', ' ')}  ·  {m.get('protocol', '')}  ·  "
                            f"时长 {mmss(m.get('duration', 0))}  ·  {src}" + (f"\n备注：{notes}" if notes else ""))
        segs = [g for g in s.segments if g.metrics.get("epochs")]
        # ---------------- bars
        self.p_bar.clear()
        keys = ["theta", "alpha", "beta"]
        w = 0.26
        for j, k in enumerate(keys):
            x = np.arange(len(segs)) + (j - 1) * w
            y = [g.metrics.get(k, 0) or 0 for g in segs]
            self.p_bar.addItem(pg.BarGraphItem(x=x, height=y, width=w * 0.9, brush=dsp.BAND_COLORS[k], pen=None))
        ax = self.p_bar.getPlotItem().getAxis("bottom")
        ax.setTicks([[(i, _short(g.label)) for i, g in enumerate(segs)]])
        self.p_bar.setXRange(-0.6, max(0.6, len(segs) - 0.4))
        # ---------------- psd per segment
        self.p_psd.clear()
        if "EEG" in s.data:
            t, X, names = s.data["EEG"]
            idx = [names.index(n) for n in dsp.EEG_NAMES if n in names]
            for i, g in enumerate(segs[:8]):
                msk = (t >= g.t0) & (t < g.t1)
                if msk.sum() < dsp.FS_EEG * 4:
                    continue
                xx = dsp.notch_only(X[msk][:, idx])
                fr, p = dsp.psd(xx, seg_s=4.0)
                keep = (fr >= 1) & (fr <= 40)
                self.p_psd.plot(fr[keep], p[keep].mean(axis=1), pen=pg.mkPen(SEG_COLORS[i % len(SEG_COLORS)], width=1.6))
        # ---------------- time course
        self.p_time.clear()
        for g in s.segments:
            ser = g.metrics.get("alpha_series")
            if not ser or len(ser[0]) == 0:
                continue
            tt, a, keep = ser
            tm = tt / 60.0
            self.p_time.plot(tm[keep], a[keep], pen=None, symbol="o", symbolSize=4,
                             symbolBrush=dsp.BAND_COLORS["alpha"], symbolPen=None)
            if (~keep).any():
                self.p_time.plot(tm[~keep], a[~keep], pen=None, symbol="o", symbolSize=4,
                                 symbolBrush=T.FAINT, symbolPen=None)
        for i, g in enumerate(s.segments):
            col = QColor(SEG_COLORS[i % len(SEG_COLORS)])
            col.setAlpha(28)
            reg = pg.LinearRegionItem(values=(g.t0 / 60, g.t1 / 60), movable=False, brush=col, pen=pg.mkPen(None))
            self.p_time.addItem(reg)
            txt = pg.TextItem(_short(g.label), color=T.MUTED, anchor=(0, 0))
            txt.setPos(g.t0 / 60, 0.78)
            self.p_time.addItem(txt)
        for g in s.segments:                       # blinks: small ticks along the bottom
            bt = np.array(g.metrics.get("blink_times") or [])
            if len(bt):
                self.p_time.plot(bt / 60.0, np.full(len(bt), 0.02), pen=None, symbol="t1", symbolSize=7,
                                 symbolBrush="#7dd3fc", symbolPen=None)
        for mk in s.markers:
            if mk["kind"] in ("event", "system"):
                ln = pg.InfiniteLine(pos=mk["t"] / 60, angle=90, pen=pg.mkPen(T.ACCENT2, width=1, style=Qt.PenStyle.DotLine),
                                     label=mk["label"], labelOpts={"color": T.ACCENT2, "position": 0.1})
                self.p_time.addItem(ln)
        self.p_time.setYRange(0, 0.85)
        # ---------------- meditation: calm / neutral / active as a coloured strip along the top
        mf = s.dir / "meditation.csv"
        if mf.exists():
            try:
                import csv as _csv
                rows = list(_csv.DictReader(open(mf, encoding="utf-8-sig")))
                t0m = next((mk["t"] for mk in s.markers if mk["label"] in ("冥想", "冥想中", "呼吸引导")), 0.0)
                cols = {"calm": "#34d399", "neutral": "#64748b", "active": "#f87171"}
                for st_, col in cols.items():
                    tt = [(t0m + float(r["t"])) / 60 for r in rows if r.get("state") == st_]
                    if tt:
                        self.p_time.plot(tt, [0.82] * len(tt), pen=None, symbol="s", symbolSize=5,
                                         symbolBrush=col, symbolPen=None)
            except Exception:  # noqa: BLE001
                pass
        # ---------------- events
        from . import insights as I
        labs = I.marker_labels(s)
        self.cb_ev.blockSignals(True)
        self.cb_ev.clear()
        self.cb_ev.addItems(labs)
        self.cb_ev.blockSignals(False)
        self.c_ev.setVisible(bool(labs))
        if labs:
            self._draw_event(labs[0])
        # ---------------- media
        from . import av as AV
        info = AV.load_sync(s.dir) if AV.available() else None
        self.av_panel.load(info)
        self.c_av.setVisible(info is not None)
        self.cursor = None
        if info is not None:
            kind = "录像" if info.get("video") else "录音"
            res = info.get("residual_ms")
            self._right.setStretchFactor(self.c_av, 3 if info.get("video") else 0)
            size = info.get("size", 0)
            self.l_av.setText(f"{kind} · " + (f"{size / 1e6:.0f} MB" if size >= 1e6 else f"{size / 1e3:.0f} KB")
                              + (f" · 对齐误差约 {abs(res):.0f} 毫秒" if res == res and res is not None else ""))
            self._draw_av_features(s)
            self.cursor = pg.InfiniteLine(pos=0, angle=90, movable=True, pen=pg.mkPen(T.ACCENT, width=2))
            self.cursor.sigPositionChangeFinished.connect(lambda ln: self.av_panel.seek_eeg(ln.value() * 60.0))
            self.p_time.addItem(self.cursor)
        # ---------------- table
        cols = ["段落", "时长", "α", "耳后α", "θ", "β", "α峰频", "前额不对称", "心率", "心率变异", "眨眼/分", "肌电", "可用数据",
                "电极"]
        self.tbl.clear()
        self.tbl.setColumnCount(len(cols))
        self.tbl.setHorizontalHeaderLabels(cols)
        self.tbl.setRowCount(len(s.segments))
        for r, g in enumerate(s.segments):
            mt = g.metrics
            used = mt.get("channels_used")
            faa = mt.get("faa")
            vals = [g.label, mmss(mt.get("duration", 0)), f(mt.get("alpha"), 0, True), f(mt.get("alpha_ear"), 0, True),
                    f(mt.get("theta"), 0, True), f(mt.get("beta"), 0, True), f(mt.get("iaf"), 2),
                    (f"{faa:+.2f}" if isinstance(faa, float) and faa == faa else ("算不了" if mt.get("faa_note") else "—")),
                    f(mt.get("hr"), 0) + ("" if mt.get("hr_ok", True) else "?"),
                    f(mt.get("rmssd"), 0) if mt.get("hrv_ok", True) else "—",
                    f(mt.get("blink_rate"), 0), f(mt.get("emg"), 0, True), f(mt.get("clean_share"), 0, True),
                    ("4 个" if used and len(used) == 4 else ("缺 " + "、".join(x for x in ("TP9", "AF7", "AF8", "TP10") if x not in used))
                     if used is not None else "—")]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignmentFlag.AlignCenter if c else Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
                if c == 0:
                    it.setForeground(QColor(SEG_COLORS[r % len(SEG_COLORS)]))
                if c == 12 and isinstance(mt.get("clean_share"), float) and mt["clean_share"] < 0.6:
                    it.setForeground(QColor(T.WARN))
                if c == 7 and mt.get("faa_note"):
                    it.setToolTip(mt["faa_note"])
                if c == 13 and used is not None and len(used) < 4:
                    it.setForeground(QColor(T.WARN))
                    it.setToolTip("这些电极在这段里大部分时间贴合不好，数值只用了其余电极")
                self.tbl.setItem(r, c, it)
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)

    # ------------------------------------------------------------------
    def _reassign(self):
        from PyQt6.QtWidgets import QInputDialog, QMessageBox
        s = self.session
        if s is None:
            return
        if self.cloud is not None and getattr(self.cloud, "busy", False):
            QMessageBox.information(self, "改归属", "云端正在上传，等上传结束再改。")
            return
        people = P.people()
        names = [f"{p['name']}（{p['id']}）" for p in people]
        cur = P.person_of(s.meta)
        idx = next((i for i, p in enumerate(people) if p["id"] == cur), 0)
        name, ok = QInputDialog.getItem(self, "改归属", "这条录制是谁的：", names, idx, False)
        if not ok:
            return
        pid = people[names.index(name)]["id"]
        if pid == cur:
            return
        import json
        meta = json.loads((s.dir / "session.json").read_text(encoding="utf-8"))
        meta["person"], meta["person_name"] = pid, P.name_of(pid)
        meta.setdefault("person_changed", []).append({"from": cur, "to": pid})
        S.save_meta(s.dir, meta)
        from .cloud import MARK, upload_mark
        old = upload_mark(s.dir)
        if old.get("status") == "done":
            (s.dir / MARK).unlink(missing_ok=True)       # upload again under the new person
            QMessageBox.information(self, "改归属", f"已改成「{P.name_of(pid)}」，会按新归属重新上传。云端旧副本还在 {old.get('tag')} 里，"
                                                    "需要的话在 GitHub 上把它删掉。")
        from . import baseline as B
        try:
            B.session_rows()                             # the cache key changes with session.json
        except Exception:  # noqa: BLE001
            pass
        self.refresh(str(s.dir))

    def _draw_event(self, lab):
        from . import insights as I
        self.p_ev.clear()
        if not lab or self.session is None:
            return
        e = I.event_locked(self.session, lab)
        parts = [f"「{lab}」共 {e['n']} 次"]
        t = e["t"]
        if "alpha" in e:
            a = np.asarray(e["alpha"], float)
            self.p_ev.plot(t, a / max(1e-9, np.nanmax(a)), pen=pg.mkPen(dsp.BAND_COLORS["alpha"], width=2), name="α")
            parts.append("α（青）")
        if "hr" in e:
            h = np.asarray(e["hr"], float)
            if np.isfinite(h).any():
                hn = (h - np.nanmin(h)) / max(1e-9, np.nanmax(h) - np.nanmin(h))
                self.p_ev.plot(t, hn, pen=pg.mkPen("#fb7185", width=2))
                parts.append(f"心率（红，{np.nanmin(h):.0f}–{np.nanmax(h):.0f} 次/分）")
        if "motion" in e:
            m = np.asarray(e["motion"], float)
            if np.isfinite(m).any():
                self.p_ev.plot(t, m / max(1e-9, np.nanmax(m)), pen=pg.mkPen(T.FAINT, width=1, style=Qt.PenStyle.DashLine))
                parts.append("晃动（灰虚线）")
        self.p_ev.addItem(pg.InfiniteLine(pos=0, angle=90, pen=pg.mkPen(T.ACCENT2, width=1)))
        self.l_ev.setText(" · ".join(parts) + "；各条线已各自缩放到 0–1，看形状和先后")

    def _export_research(self):
        if self.session is None:
            return
        import subprocess
        from .export_data import export_research
        start = str(Path.home() / "Desktop") if (Path.home() / "Desktop").exists() else str(Path.home())
        root = QFileDialog.getExistingDirectory(self, "导出到哪个文件夹", start)
        if not root:
            return
        try:
            out = export_research(self.session.dir, Path(root))
        except Exception as e:  # noqa: BLE001
            self.l_meta.setText(self.l_meta.text() + f"\n研究导出失败：{e}")
            return
        if not os.environ.get("NB_NO_REVEAL"):
            subprocess.Popen(["explorer", str(out)])

    def _analyse_media(self):
        from PyQt6.QtWidgets import QApplication
        from . import av_analysis as AA
        if self.session is None:
            return
        self.b_avan.setEnabled(False)
        try:
            r = AA.analyse(self.session.dir, progress=lambda m: (self.l_av.setText(m), QApplication.processEvents()))
            if r is None:
                self.l_av.setText("这次没有音视频")
                return
        except Exception as e:  # noqa: BLE001
            self.l_av.setText(f"分析失败：{e}")
            return
        finally:
            self.b_avan.setEnabled(True)
        self._render()

    def _draw_av_features(self, s):
        """Talking spans (yellow), loudness and picture movement (thin lines, bottom) on the α plot."""
        from . import av_analysis as AA
        f = AA.load(s.dir)
        if not f:
            return
        notes = []
        au = f.get("audio")
        if au:
            t = np.asarray(au["t"]) / 60.0
            db = np.asarray(au["db"], float)
            lo, hi = np.percentile(db, 5), np.percentile(db, 99.5)
            self.p_time.plot(t, 0.02 + 0.18 * np.clip((db - lo) / max(1e-9, hi - lo), 0, 1),
                             pen=pg.mkPen("#fbbf24", width=1))
            talk = np.asarray(au["talk"], bool)
            edges = np.flatnonzero(np.diff(np.r_[0, talk.astype(int), 0]))
            for a_, b_ in zip(edges[::2], edges[1::2]):
                col = QColor("#fbbf24")
                col.setAlpha(40)
                self.p_time.addItem(pg.LinearRegionItem(values=(t[a_], t[min(b_, len(t) - 1)]), movable=False,
                                                        brush=col, pen=pg.mkPen(None)))
            notes.append(f"说话约 {100 * f.get('talk_share', 0):.0f}% 的时间（黄底）")
        vi = f.get("video")
        if vi and vi.get("motion"):
            m = np.asarray(vi["motion"], float)
            self.p_time.plot(np.asarray(vi["t"]) / 60.0, 0.02 + 0.18 * m / max(1e-9, np.percentile(m, 99.5)),
                             pen=pg.mkPen("#e879f9", width=1))
            notes.append("画面动作（紫线）")
        if f.get("a_refined") is not None:
            notes.append(f"已用提示音校准对齐（找到 {f.get('cues_found')} 个）")
        self.l_av.setText(self.l_av.text() + " · " + " · ".join(notes))

    def _media_moved(self, t_eeg: float):
        if self.cursor is not None:
            self.cursor.blockSignals(True)
            self.cursor.setValue(t_eeg / 60.0)
            self.cursor.blockSignals(False)

    def _delete_media(self):
        from PyQt6.QtWidgets import QMessageBox
        from . import av as AV
        s = self.session
        if s is None:
            return
        files = [s.dir / f for f in AV.MEDIA_FILES if (s.dir / f).exists()]
        if not files:
            return
        if QMessageBox.question(self, "删除音视频", "删除这次录制的录像/录音文件？脑电数据保留。删除后不能恢复。") \
                != QMessageBox.StandardButton.Yes:
            return
        self.av_panel.load(None)                        # releases the player's hold on the file
        failed = []
        for f in files:
            try:
                f.unlink()
            except OSError:
                failed.append(f.name)
        if failed:                                      # keep the sync file so the video stays visible here
            QMessageBox.warning(self, "没删掉", "文件正被其他程序占用，没删掉：" + "、".join(failed) + "。关掉播放器后再试。")
        else:
            try:
                (s.dir / AV.SYNC_FILE).unlink()
            except OSError:
                pass
        self._render()

    def _export_csv(self):
        if not self.session:
            return
        p = self.session.dir / "分段指标.csv"
        export_segments_csv(self.session, p)
        self.l_meta.setText(self.l_meta.text().split("\n已导出")[0] + f"\n已导出：{p}")

    def _rebuild_sleep(self):
        if self.session is None:
            return
        from PyQt6.QtWidgets import QApplication
        from .sleep import build_sleep_report
        self.l_meta.setText(self.l_meta.text() + "\n正在重新分期，整夜录制可能要一分钟…")
        QApplication.processEvents()
        try:
            build_sleep_report(self.session.dir)
        except Exception as e:  # noqa: BLE001
            self.l_meta.setText(self.l_meta.text() + f"\n重新生成失败：{e}")
            return
        self.refresh(str(self.session.dir))
        if not os.environ.get("NB_NO_REVEAL"):
            os.startfile(str(self.session.dir / "sleep_report.html"))

    def _open_report(self):
        if not self.session:
            return
        erp_html = self.session.dir / "erp_report.html"
        if erp_html.exists():
            os.startfile(str(erp_html))
            return
        if self.session.meta.get("protocol") == "过夜睡眠":
            p = self.session.dir / "sleep_report.html"
            if not p.exists():
                from .sleep import build_sleep_report
                build_sleep_report(self.session.dir)
            os.startfile(str(p))
            return
        if self.session.meta.get("protocol") == "练功前后对比":
            from .insights import build_practice_report
            p = build_practice_report(self.session.dir)     # always fresh: it compares with your latest history
            if p is not None:
                os.startfile(str(p))
            else:
                self.l_meta.setText(self.l_meta.text() + "\n（练前或练后的闭眼静坐段缺失，出不了对比报告）")
            return
        p = self.session.dir / "report.html"
        if not p.exists() and self.session.meta.get("protocol") == "心理状态测评":
            from .report import build_report
            build_report(self.session.dir)
        if p.exists():
            os.startfile(str(p))

    def _export_png(self):
        if not self.session:
            return
        p = self.session.dir / "回看截图.png"
        self.grab().save(str(p))
        self.l_meta.setText(self.l_meta.text().split("\n已导出")[0] + f"\n已导出：{p}")

    def _open_folder(self):
        from .session import ROOT
        target = self.session.dir if self.session else ROOT
        target.mkdir(parents=True, exist_ok=True)
        os.startfile(str(target))


def _short(s, n=7):
    return s if len(s) <= n else s[: n - 1] + "…"


# ============================================================================ trends
class TrendsPage(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)
        head = QHBoxLayout()
        head.addWidget(label("长期趋势", "h1"))
        head.addStretch(1)
        head.addWidget(label("段落", "muted"))
        self.cb_seg = QComboBox()
        self.cb_seg.setMinimumWidth(200)
        head.addWidget(self.cb_seg)
        head.addWidget(label("指标", "muted"))
        self.cb_metric = QComboBox()
        from .survey import SELF_REPORT_LABELS
        extra = {"med_calm_pct": "冥想平静占比（%）", "med_birds": "冥想鸟叫次数", "med_hr_swing": "呼吸引导心率起伏",
                 "med_sync": "呼吸引导同步度", "as_relax_ratio": "测评·放松反应", "as_task_hr_delta": "测评·心算心率变化",
                 "as_recovery_score": "测评·恢复分数"}
        for k, v in {**METRIC_LABELS, **SELF_REPORT_LABELS, **extra}.items():
            self.cb_metric.addItem(v, k)
        head.addWidget(self.cb_metric)
        head.addWidget(label("对比", "muted"))
        self.cb_other = QComboBox()
        self.cb_other.setToolTip("两个人都在「佩戴者设置」里同意之后，才能并排对比")
        self.cb_other.currentIndexChanged.connect(self._other_changed)
        head.addWidget(self.cb_other)
        b = QPushButton("刷新")
        b.clicked.connect(self.refresh)
        head.addWidget(b)
        root.addLayout(head)
        root.addWidget(label("同一名称的段落放在一起比。比如每天都做「练功前后对比」，就能看「练后·闭眼静坐」的 α 一天天怎么变。"
                             "模拟数据不计入。", "muted", wrap=True))
        c = Card("", "")
        self.p = plot()
        ax = pg.DateAxisItem(orientation="bottom")
        ax.setPen(pg.mkPen(T.BORDER))
        ax.setTextPen(pg.mkPen(T.MUTED))
        self.p.setAxisItems({"bottom": ax})
        c.add(self.p, 1)
        root.addWidget(c, 3)
        ct = Card("明细")
        self.tbl = QTableWidget()
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        ct.add(self.tbl, 1)
        root.addWidget(ct, 2)
        self.cb_seg.currentIndexChanged.connect(self.draw)
        self.cb_metric.currentIndexChanged.connect(self.draw)
        self.rows = []
        self.include_sim = False

    def _rows_for(self, pid):
        rows = []
        for r in list_all_sessions():
            d, meta = r["dir"], r["meta"]
            if meta.get("source") == "sim" and not self.include_sim:
                continue
            if not P.mine(meta, pid):
                continue
            try:
                segs = S.segments_cached(d, meta)          # cached: the page opens at once
            except Exception:  # noqa: BLE001
                continue
            try:
                started = datetime.fromisoformat(meta["started_at"])
            except Exception:  # noqa: BLE001
                started = datetime.fromtimestamp(d.stat().st_mtime)
            # one row per (session, segment label): average repeated segments, weighted by duration
            groups: dict = {}
            for g in segs:
                groups.setdefault(g["label"], []).append(g["metrics"])
            for lab, ms in groups.items():
                row = {"date": started, "session": meta.get("name") or d.name, "segment": lab, "n": len(ms),
                       **{k: v for k, v in (meta.get("self_report") or {}).items() if k.startswith("sr_")},
                       **{f"med_{k}": v for k, v in (meta.get("meditation") or {}).items()
                          if k in ("calm_pct", "birds", "hr_swing", "sync") and isinstance(v, (int, float))},
                       **{f"as_{k}": v for k, v in (meta.get("assessment") or {}).items() if isinstance(v, (int, float))}}
                for k in METRIC_LABELS:
                    vals = [(m.get(k), m.get("duration", 1.0)) for m in ms
                            if isinstance(m.get(k), (int, float)) and m.get(k) == m.get(k)]
                    if vals:
                        wsum = sum(w for _, w in vals) or 1.0
                        row[k] = sum(v * w for v, w in vals) / wsum
                rows.append(row)
        return sorted(rows, key=lambda r: r["date"])

    def refresh(self):
        rows = self._rows_for(P.current())
        # who may be compared with the current person (both agreed)
        cur_other = self.cb_other.currentData() if self.cb_other.count() else None
        self.cb_other.blockSignals(True)
        self.cb_other.clear()
        self.cb_other.addItem("不对比", None)
        for p in P.comparable_with():
            self.cb_other.addItem(p["name"], p["id"])
        k = self.cb_other.findData(cur_other)
        self.cb_other.setCurrentIndex(k if k >= 0 else 0)
        self.cb_other.blockSignals(False)
        self.rows_other = self._rows_for(self.cb_other.currentData()) if self.cb_other.currentData() else []
        self.rows = sorted(rows, key=lambda r: r["date"])
        labels = sorted({r["segment"] for r in self.rows})
        cur = self.cb_seg.currentText()
        self.cb_seg.blockSignals(True)
        self.cb_seg.clear()
        self.cb_seg.addItems(labels)
        if cur in labels:
            self.cb_seg.setCurrentText(cur)
        self.cb_seg.blockSignals(False)
        self.draw()

    def _other_changed(self, _i):
        pid = self.cb_other.currentData()
        self.rows_other = self._rows_for(pid) if pid else []
        self.draw()

    def draw(self):
        seg = self.cb_seg.currentText()
        key = self.cb_metric.currentData()
        rows = [r for r in self.rows if r["segment"] == seg and isinstance(r.get(key), (int, float)) and r[key] == r[key]]
        self.p.clear()
        other = [r for r in getattr(self, "rows_other", []) if r["segment"] == seg
                 and isinstance(r.get(key), (int, float)) and r[key] == r[key]]
        if getattr(self, "_legend", None) is None:
            self._legend = self.p.addLegend(offset=(10, 10))
        self._legend.clear()
        xs, ys = [], []
        if rows:
            x = np.array([r["date"].timestamp() for r in rows])
            y = np.array([r[key] for r in rows], float)
            self.p.plot(x, y, pen=pg.mkPen(T.ACCENT, width=2), symbol="o", symbolSize=9,
                        symbolBrush=T.ACCENT, symbolPen=pg.mkPen(T.BG, width=2), name=P.name_of(P.current()))
            xs.append(x)
            ys.append(y)
        if other:
            xo = np.array([r["date"].timestamp() for r in other])
            yo = np.array([r[key] for r in other], float)
            self.p.plot(xo, yo, pen=pg.mkPen("#f472b6", width=2, style=Qt.PenStyle.DashLine), symbol="t",
                        symbolSize=9, symbolBrush="#f472b6", symbolPen=None, name=self.cb_other.currentText())
            xs.append(xo)
            ys.append(yo)
        if xs:                                        # ranges cover both people
            x, y = np.concatenate(xs), np.concatenate(ys)
            span = x.max() - x.min()
            pad = max(86400.0, span * 0.08)
            self.p.setXRange(x.min() - pad, x.max() + pad, padding=0)
            lo, hi = float(y.min()), float(y.max())
            ypad = max(abs(hi - lo) * 0.25, abs(hi) * 0.1, 1e-3)
            self.p.setYRange(min(0.0, lo - ypad) if key in PCT_KEYS else lo - ypad, hi + ypad, padding=0)
            self.p.getPlotItem().setLabel("left", self.cb_metric.currentText(), color=T.MUTED)
        cols = ["日期", "录制", "段落", self.cb_metric.currentText(), "可用数据"]
        self.tbl.clear()
        self.tbl.setColumnCount(len(cols))
        self.tbl.setHorizontalHeaderLabels(cols)
        self.tbl.setRowCount(len(rows))
        for i, r in enumerate(reversed(rows)):
            vals = [r["date"].strftime("%Y-%m-%d %H:%M"), r["session"], r["segment"],
                    f(r[key], 1, True) if key in PCT_KEYS else f(r[key], 2),
                    f(r.get("clean_share"), 0, True)]
            for c, v in enumerate(vals):
                self.tbl.setItem(i, c, QTableWidgetItem(v))
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
