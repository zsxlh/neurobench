"""Built-in ERP mini-experiments (auditory and visual oddball P300): stimulus schedule, tones, and analysis.

No Qt here, so the analysis can run headless (tests, batch re-analysis). The page that runs the
experiment lives in page_erp.py.

Timing notes (measured on the development laptop, Windows 11, Qt 6.12):
- The next stimulus is fired by a Qt PreciseTimer; it fires 0-2 ms late (one outlier ~9 ms on the first
  shot). The lateness of every trial is logged in erp_trials.csv.
- QSoundEffect.play() on a preloaded 60 ms WAV returns in 0.25-0.55 ms; the marker is written right after.
  The sound itself leaves the speaker later by the Windows audio buffer (WASAPI shared mode, typically
  10-40 ms). That delay is mostly constant within one run; the trial-to-trial jitter is a few ms.
  A silent looping effect keeps the audio device awake so the first tones are not later than the rest.
- A visual stimulus is painted synchronously (repaint()) and the marker is written right after; the
  pixels reach the screen at the next compositor refresh: 0-1 frame later (0-17 ms at 60 Hz) plus a
  fixed display lag.
- EEG sample times are mapped to the computer clock at the minimum Bluetooth latency, so EEG looks a
  little late, which partly cancels the output delays. Net: a constant offset of roughly +-30 ms and a
  jitter of ~5-15 ms. Both are small against the 250-500 ms window used for the P300 amplitude.
"""

from __future__ import annotations

import base64
import csv
import html
import io
import json
import wave
from pathlib import Path

import numpy as np

from . import dsp

STD_LABEL = "P300·标准"
TGT_LABEL = "P300·目标"
STIM_KIND = "stim"

EXPERIMENTS = {
    "auditory": {
        "title": "听觉 P300",
        "short": "听觉",
        "std_freq": 1000.0, "tgt_freq": 1500.0, "dur": 0.060,
        "std_name": "低音（1000 Hz）", "tgt_name": "高音（1500 Hz）",
        "instructions": (
            "闭上眼睛，放松坐好，尽量别动、别咬牙。\n"
            "你会听到一连串短促的“嘀”声：大多数是低音，偶尔夹一个高一点的音。\n"
            "请在心里默数高音出现了几次，结束后告诉程序。不用按键，也不用出声。\n"
            "戴耳机或把音量调到听得清就行，别太响。"),
    },
    "visual": {
        "title": "视觉 P300",
        "short": "视觉",
        "std_color": "#2563eb", "tgt_color": "#ea580c", "dur": 0.100,
        "std_name": "蓝色圆", "tgt_name": "橙色圆",
        "instructions": (
            "睁眼盯住屏幕中间的小十字，头别动。\n"
            "中间会一闪而过一个圆：大多数是蓝色，偶尔是橙色。\n"
            "请在心里默数橙色圆出现了几次，结束后告诉程序。\n"
            "想眨眼就在圆闪过之后眨，尽量别在圆出现的一瞬间眨。"),
    },
}

N170_NOTE = ("为什么没有 N170（看人脸时的脑电反应）？它需要成百上千张标准化的人脸和物体照片，"
             "而且主要出现在后脑勺两侧（P7/P8 位置），这个头环没有那里的电极，测出来也不可靠，所以没有放进来。")

LENGTHS = {"standard": (250, "标准：250 次，约 5 分钟"), "quick": (150, "快速：150 次，约 3 分钟")}

ISI_RANGE = (1.0, 1.4)        # onset-to-onset, uniform jitter
P_TARGET = 0.2

# analysis parameters
EPOCH = (-0.2, 0.8)
BASELINE = (-0.2, 0.0)
P300_WIN = (0.25, 0.50)
BAND = (0.5, 20.0)
REJECT_UV = 100.0
MAX_GAP_S = 0.05             # a hole in the EEG longer than this inside an epoch rejects it
ROI = ("EEG_TP9", "EEG_TP10")
MIN_TGT, MIN_STD = 15, 30
N_BOOT, N_PERM = 2000, 5000


# ============================================================================ schedule
def make_sequence(n_trials: int = 250, p_target: float = P_TARGET, rng=None, lead: int = 3) -> list:
    """Oddball order: exactly round(n*p) targets, never two in a row, the first `lead` trials standard.
    Returns a list of bools (True = target)."""
    rng = np.random.default_rng(rng)
    n_t = int(round(n_trials * p_target))
    n_free = n_trials - lead
    if n_t * 2 > n_free + 1:
        raise ValueError("too many targets for the no-repeat rule")
    # place n_t targets among n_free slots with at least one standard between them:
    # choose positions from n_free - n_t + 1 gaps (stars and bars)
    pos = np.sort(rng.choice(n_free - n_t + 1, n_t, replace=False)) + np.arange(n_t)
    seq = [False] * n_trials
    for p in pos:
        seq[lead + int(p)] = True
    return seq


def make_isis(n: int, lo: float = ISI_RANGE[0], hi: float = ISI_RANGE[1], rng=None) -> np.ndarray:
    return np.random.default_rng(rng).uniform(lo, hi, n)


# ============================================================================ tones
SR = 44100


def tone(freq: float, dur: float = 0.060, sr: int = SR, ramp: float = 0.005, amp: float = 0.5) -> np.ndarray:
    """Pure tone with raised-cosine on/off ramps (no click)."""
    n = int(round(dur * sr))
    t = np.arange(n) / sr
    x = amp * np.sin(2 * np.pi * freq * t)
    r = int(ramp * sr)
    if r:
        w = 0.5 - 0.5 * np.cos(np.pi * np.arange(r) / r)
        x[:r] *= w
        x[-r:] *= w[::-1]
    return x


def wav_bytes(x: np.ndarray, sr: int = SR) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((np.clip(x, -1, 1) * 32000).astype("<i2").tobytes())
    return buf.getvalue()


def ensure_tones(folder: Path | None = None) -> dict:
    """Write the stimulus WAVs once (QSoundEffect needs a file URL; generation is in memory).
    Returns {"standard": path, "target": path, "silence": path}."""
    if folder is None:
        from .paths import ROOT
        folder = ROOT / "cache" / "sounds"
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    cfg = EXPERIMENTS["auditory"]
    want = {"standard": wav_bytes(tone(cfg["std_freq"], cfg["dur"])),
            "target": wav_bytes(tone(cfg["tgt_freq"], cfg["dur"])),
            "silence": wav_bytes(np.zeros(int(0.5 * SR)))}
    out = {}
    for k, b in want.items():
        p = folder / f"erp_{k}_v1.wav"
        if not p.exists() or p.stat().st_size != len(b):
            p.write_bytes(b)
        out[k] = p
    return out


# ============================================================================ loading
def _load_light(d: Path):
    """EEG + markers + meta of a session folder without computing the segment metrics."""
    from .session import Session
    d = Path(d)
    meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
    data = {}
    cols = meta.get("channels", {}).get("EEG")
    p = d / "eeg.f64"
    if cols and p.exists():
        arr = np.fromfile(p, dtype="<f8")
        n = len(cols)
        arr = arr[: (len(arr) // n) * n].reshape(-1, n)
        arr = arr[np.argsort(arr[:, 0], kind="stable")]
        data["EEG"] = (arr[:, 0], arr[:, 1:], cols[1:])
    markers = []
    mp = d / "markers.csv"
    if mp.exists():
        with open(mp, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                try:
                    markers.append({"t": float(r["t"]), "label": r["label"], "kind": r.get("kind", "event")})
                except (ValueError, KeyError):
                    pass
    return Session(dir=d, meta=meta, data=data, markers=markers)


def is_erp_session(meta: dict, markers: list | None = None) -> bool:
    if isinstance(meta.get("erp"), dict):
        return True
    return bool(markers) and any(m.get("label") in (STD_LABEL, TGT_LABEL) for m in markers)


# ============================================================================ analysis
def _stats(tgt: np.ndarray, std: np.ndarray, rng) -> dict:
    """Difference of means of per-epoch window amplitudes, bootstrap 95% CI, two-sided permutation p."""
    out = {"n_tgt": int(len(tgt)), "n_std": int(len(std)), "amp": float("nan"),
           "ci": (float("nan"), float("nan")), "p": float("nan")}
    if len(tgt) < 3 or len(std) < 3:
        return out
    d = float(tgt.mean() - std.mean())
    bt = tgt[rng.integers(0, len(tgt), (N_BOOT, len(tgt)))].mean(axis=1)
    bs = std[rng.integers(0, len(std), (N_BOOT, len(std)))].mean(axis=1)
    lo, hi = np.percentile(bt - bs, [2.5, 97.5])
    pool = np.concatenate([tgt, std])
    nt = len(tgt)
    perm = rng.permuted(np.broadcast_to(pool, (N_PERM, len(pool))), axis=1)
    dp = perm[:, :nt].mean(axis=1) - perm[:, nt:].mean(axis=1)
    p = (1 + int(np.sum(np.abs(dp) >= abs(d) - 1e-12))) / (N_PERM + 1)
    out.update(amp=d, ci=(float(lo), float(hi)), p=float(p))
    return out


def erp_filter(X: np.ndarray, fs: float = dsp.FS_EEG) -> np.ndarray:
    """0.5-20 Hz zero-phase band-pass (same design as dsp.clean_eeg; in a noise-free simulation it shrinks a
    350 ms Gaussian P300 by ~13 %, the usual cost of a 0.5 Hz high-pass), after the 50/60 Hz notches."""
    x = np.asarray(X, float)
    x = np.nan_to_num(x - np.nanmean(x, axis=0, keepdims=True))
    for f0 in (50.0, 60.0):
        x = dsp._safe_filtfilt(dsp._sos("notch", fs, f0, 25.0), x)
    return dsp._safe_filtfilt(dsp._sos("band", fs, BAND[0], BAND[1], 4), x)


def analyse(session, write: bool = True, experiment: str | None = None, seed: int = 0) -> dict:
    """P300 analysis of one ERP recording.

    session: a session.Session (or any object with .dir, .meta, .data['EEG']=(t, X, names), .markers)
             or a session folder path.
    Returns a result dict (see keys below). With write=True also writes erp_figure.png, erp_report.html
    and a summary under session.json["erp"]["result"] in the session folder.
    """
    s = _load_light(session) if isinstance(session, (str, Path)) else session
    meta = s.meta or {}
    exp = experiment or (meta.get("erp") or {}).get("experiment") or "auditory"
    cfg = EXPERIMENTS.get(exp, EXPERIMENTS["auditory"])
    res = {"experiment": exp, "title": cfg["title"], "ok": False, "message": "", "dir": str(getattr(s, "dir", "")),
           "started_at": meta.get("started_at", ""), "counted": (meta.get("erp") or {}).get("counted"),
           "n_targets_shown": None, "channels": {}, "roi": {}}
    stims = [m for m in s.markers if m.get("label") in (STD_LABEL, TGT_LABEL)]
    res["n_targets_shown"] = sum(m["label"] == TGT_LABEL for m in stims)
    res["n_standards_shown"] = sum(m["label"] == STD_LABEL for m in stims)
    if "EEG" not in s.data or not stims:
        res["message"] = "这份录制里没有脑电数据或刺激标记，没法分析。"
        return _finish(res, s, write)
    t, X, names = s.data["EEG"]
    if not all(n in names for n in dsp.EEG_NAMES) or len(t) < dsp.FS_EEG * 10:
        res["message"] = "脑电数据太短或缺少电极，没法分析。"
        return _finish(res, s, write)
    X = np.asarray(X, float)[:, [names.index(n) for n in dsp.EEG_NAMES]]
    t = np.asarray(t, float)
    fs = dsp.FS_EEG

    # blinks on the raw signal; filtered copy for the ERPs (0.5-20 Hz zero-phase, mains notches)
    pk, _ = dsp.detect_blinks(X, fs)
    blink_t = t[pk] if len(pk) else np.array([])
    xf = erp_filter(X, fs)

    lags = np.arange(int(round(EPOCH[0] * fs)), int(round(EPOCH[1] * fs)) + 1) / fs
    base = (lags >= BASELINE[0]) & (lags < BASELINE[1])
    win = (lags >= P300_WIN[0]) & (lags <= P300_WIN[1])
    n_ep = len(stims)
    E = np.full((n_ep, len(lags), 4), np.nan)
    is_tgt = np.array([m["label"] == TGT_LABEL for m in stims], bool)
    reason = np.array([""] * n_ep, dtype=object)
    for i, m in enumerate(stims):
        tt = m["t"] + lags
        a, b = np.searchsorted(t, [tt[0] - 0.01, tt[-1] + 0.01])
        if a == 0 or b >= len(t) or b - a < len(lags) * 0.9:
            reason[i] = "edge"
            continue
        if np.max(np.diff(t[a - 1:b + 1])) > MAX_GAP_S:
            reason[i] = "gap"
            continue
        if len(blink_t) and np.any((blink_t >= tt[0]) & (blink_t <= tt[-1])):
            reason[i] = "blink"
        for c in range(4):
            E[i, :, c] = np.interp(tt, t[a - 1:b + 1], xf[a - 1:b + 1, c])
    E -= np.nanmean(E[:, base, :], axis=1, keepdims=True)
    # per-channel amplitude rejection (a single badly seated forehead electrode must not cost every epoch)
    over = np.nanmax(np.abs(E), axis=1) > REJECT_UV                      # (n_ep, 4)
    valid = (reason == "")[:, None] & ~np.isnan(E).any(axis=1) & ~over   # (n_ep, 4)
    res["rejected"] = {"blink": int(np.sum(reason == "blink")), "gap": int(np.sum(reason == "gap")),
                       "edge": int(np.sum(reason == "edge")),
                       "amplitude": {n.replace("EEG_", ""): int(np.sum((reason == "") & over[:, c]))
                                     for c, n in enumerate(dsp.EEG_NAMES)}}
    res["n_epochs"] = int(n_ep)

    rng = np.random.default_rng(seed)
    wave_t = lags
    res["lags"] = wave_t
    for c, n in enumerate(dsp.EEG_NAMES):
        k = valid[:, c]
        amp = np.nanmean(E[:, win, c], axis=1)
        st = _stats(amp[k & is_tgt], amp[k & ~is_tgt], rng)
        st["tgt_wave"] = E[k & is_tgt, :, c].mean(axis=0) if np.any(k & is_tgt) else np.full(len(lags), np.nan)
        st["std_wave"] = E[k & ~is_tgt, :, c].mean(axis=0) if np.any(k & ~is_tgt) else np.full(len(lags), np.nan)
        st["diff_wave"] = st["tgt_wave"] - st["std_wave"]
        res["channels"][n.replace("EEG_", "")] = st

    # ROI: mean of the ear electrodes that survived in each epoch
    ri = [dsp.EEG_NAMES.index(n) for n in ROI]
    vr = valid[:, ri]
    keep = vr.any(axis=1)
    with np.errstate(invalid="ignore"):
        roi = np.where(vr[:, None, :], E[:, :, ri], np.nan)
        roi = np.nanmean(roi[keep], axis=2) if keep.any() else np.empty((0, len(lags)))
    tg = is_tgt[keep]
    amp = roi[:, win].mean(axis=1) if len(roi) else np.array([])
    st = _stats(amp[tg], amp[~tg], rng)
    st["tgt_wave"] = roi[tg].mean(axis=0) if tg.any() else np.full(len(lags), np.nan)
    st["std_wave"] = roi[~tg].mean(axis=0) if (~tg).any() else np.full(len(lags), np.nan)
    st["diff_wave"] = st["tgt_wave"] - st["std_wave"]
    if tg.sum() >= 2:
        sem_t = roi[tg].std(axis=0, ddof=1) / np.sqrt(tg.sum())
        sem_s = roi[~tg].std(axis=0, ddof=1) / np.sqrt(max(1, (~tg).sum()))
        st["diff_sem"] = np.sqrt(sem_t ** 2 + sem_s ** 2)
    dw = st["diff_wave"]
    if np.isfinite(dw[win]).any():
        st["peak_ms"] = float(lags[win][int(np.nanargmax(dw[win]))] * 1000)
    res["roi"] = st
    res["kept_tgt"], res["kept_std"] = st["n_tgt"], st["n_std"]

    res["ok"] = True
    p, a = st["p"], st["amp"]
    if st["n_tgt"] < MIN_TGT or st["n_std"] < MIN_STD:
        res["verdict"] = "too_few"
        res["message"] = (f"能用的试次太少（目标 {st['n_tgt']} 个、标准 {st['n_std']} 个，至少要 {MIN_TGT} 和 {MIN_STD}），"
                          "这次的结果不作数。多半是眨眼或耳后电极接触不好，调整后再做一次。")
    elif p < 0.05 and a > 0:
        res["verdict"] = "found"
        res["message"] = (f"看到了 P300：{cfg['tgt_name']}出现后约 {st.get('peak_ms', 0):.0f} 毫秒，耳后电极比"
                          f"{cfg['std_name']}之后高 {a:.1f} µV（95% 区间 {st['ci'][0]:.1f} 到 {st['ci'][1]:.1f}），"
                          f"p = {p:.3g}。说明你的大脑确实在“留意”那些少见的目标。")
    elif p < 0.05 and a < 0:
        res["verdict"] = "reversed"
        res["message"] = (f"目标之后的脑电和标准之后差别明显，但方向是负的（{a:.1f} µV，p = {p:.3g}），"
                          "不像典型的 P300。可能是电极接触或参考位置的问题，换个时间再做一次看看。")
    else:
        res["verdict"] = "none"
        res["message"] = (f"这次没有看到可靠的 P300（差值 {a:.1f} µV，95% 区间 {st['ci'][0]:.1f} 到 {st['ci'][1]:.1f}，"
                          f"p = {p:.2g}）。常见原因：走神没在数、电极没贴紧、头动或眨眼多。不代表大脑有问题。")
    return _finish(res, s, write)


def _finish(res: dict, s, write: bool) -> dict:
    if write and getattr(s, "dir", None):
        try:
            write_outputs(res, Path(s.dir))
        except Exception as e:  # noqa: BLE001
            res["write_error"] = f"{type(e).__name__}: {e}"
    return res


def summary(res: dict) -> dict:
    """JSON-safe compact result (stored in session.json)."""
    r = res.get("roi") or {}
    f = lambda v: None if v is None or not np.isfinite(v) else round(float(v), 3)  # noqa: E731
    out = {"verdict": res.get("verdict", ""), "experiment": res.get("experiment"),
           "p300_uv": f(r.get("amp")), "ci95": [f(x) for x in r.get("ci", (None, None))], "p": f(r.get("p")),
           "peak_ms": f(r.get("peak_ms")), "kept_target": r.get("n_tgt"), "kept_standard": r.get("n_std"),
           "epochs": res.get("n_epochs"), "rejected": res.get("rejected"),
           "per_channel": {k: {"p300_uv": f(v["amp"]), "ci95": [f(x) for x in v["ci"]], "p": f(v["p"]),
                               "kept_target": v["n_tgt"], "kept_standard": v["n_std"]}
                           for k, v in (res.get("channels") or {}).items()}}
    return out


# ============================================================================ outputs
STD_COLOR, TGT_COLOR, DIFF_COLOR = "#2563eb", "#ea580c", "#1f2937"


def figure_png(res: dict, path: Path | None = None) -> bytes:
    """ROI panel on top, the four electrodes below. Positive is up. Uses the OO API (safe off the GUI thread)."""
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib.figure import Figure
    import matplotlib as mpl
    mpl.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    mpl.rcParams["axes.unicode_minus"] = False
    cfg = EXPERIMENTS.get(res.get("experiment"), EXPERIMENTS["auditory"])
    fig = Figure(figsize=(9, 7.4), dpi=110)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.35, 1, 1], hspace=0.55, wspace=0.18)
    lags = res.get("lags")
    if lags is None or len(lags) < 2:                     # no data: empty axes over the epoch window
        lags = np.array(EPOCH, float)
    lags = np.asarray(lags, float) * 1000

    def panel(ax, st, title, big=False):
        ax.axvspan(P300_WIN[0] * 1000, P300_WIN[1] * 1000, color="#f3f4f6", zorder=0)
        ax.axhline(0, color="#9ca3af", lw=0.8, zorder=1)
        ax.axvline(0, color="#9ca3af", lw=0.8, zorder=1)
        if st and len(lags) > 1:
            if big and "diff_sem" in st:
                d, e = st["diff_wave"], 1.96 * st["diff_sem"]
                ax.fill_between(lags, d - e, d + e, color=DIFF_COLOR, alpha=0.12, lw=0)
            ax.plot(lags, st["std_wave"], color=STD_COLOR, lw=1.6, label=f"标准（{cfg['std_name']}）")
            ax.plot(lags, st["tgt_wave"], color=TGT_COLOR, lw=1.6, label=f"目标（{cfg['tgt_name']}）")
            ax.plot(lags, st["diff_wave"], color=DIFF_COLOR, lw=2.0 if big else 1.4, ls="-", label="差值（目标 − 标准）")
            a, p = st.get("amp"), st.get("p")
            if a is not None and np.isfinite(a):
                # stats sit in the right-hand title slot, above the plot, so they never cover a curve
                ax.set_title(f"P300 {a:+.1f} µV · p={p:.2g} · 目标 {st['n_tgt']} / 标准 {st['n_std']}",
                             loc="right", fontsize=9 if big else 8, color="#374151")
        ax.set_title(title, fontsize=11 if big else 10, loc="left", color="#111827")
        ax.set_xlim(lags[0], lags[-1])
        ax.tick_params(labelsize=8, colors="#4b5563")
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
        ax.set_ylabel("µV", fontsize=8, color="#4b5563")

    ax = fig.add_subplot(gs[0, :])
    panel(ax, res.get("roi"), "耳后两电极平均（TP9 + TP10）", big=True)
    if ax.get_legend_handles_labels()[0]:
        ax.legend(loc="upper left", fontsize=8.5, frameon=False)
    ax.set_xlabel("刺激后时间（毫秒）· 阴影是差值的 95% 范围 · 灰底是算 P300 的 250–500 ms", fontsize=8, color="#4b5563")
    names = {"TP9": "左耳后 TP9", "AF7": "左前额 AF7", "AF8": "右前额 AF8", "TP10": "右耳后 TP10"}
    for i, ch in enumerate(("TP9", "TP10", "AF7", "AF8")):
        a2 = fig.add_subplot(gs[1 + i // 2, i % 2])
        panel(a2, (res.get("channels") or {}).get(ch), names[ch])
        if i >= 2:
            a2.set_xlabel("刺激后时间（毫秒）", fontsize=8, color="#4b5563")
    fig.suptitle(f"{res.get('title', 'P300')} · 平均脑电反应（正值朝上）", fontsize=12, x=0.02, ha="left", color="#111827")
    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor="white")
    b = buf.getvalue()
    if path is not None:
        Path(path).write_bytes(b)
    return b


def html_report(res: dict, img_name: str = "erp_figure.png") -> str:
    cfg = EXPERIMENTS.get(res.get("experiment"), EXPERIMENTS["auditory"])
    r = res.get("roi") or {}
    rej = res.get("rejected") or {}
    fmt = lambda v, nd=1: "—" if v is None or not np.isfinite(v) else f"{v:.{nd}f}"  # noqa: E731
    rows = []
    for ch, lab in (("TP9", "左耳后 TP9"), ("TP10", "右耳后 TP10"), ("AF7", "左前额 AF7"), ("AF8", "右前额 AF8")):
        v = (res.get("channels") or {}).get(ch)
        if not v:
            continue
        rows.append(f"<tr><td>{lab}</td><td class=v>{fmt(v['amp'])}</td><td>{fmt(v['ci'][0])} 到 {fmt(v['ci'][1])}</td>"
                    f"<td>{fmt(v['p'], 3)}</td><td>{v['n_tgt']}</td><td>{v['n_std']}</td>"
                    f"<td>{(rej.get('amplitude') or {}).get(ch, 0)}</td></tr>")
    counted = res.get("counted")
    shown = res.get("n_targets_shown")
    cnt = ""
    if counted is not None and shown:
        diff = int(counted) - int(shown)
        judge = "数得很准" if abs(diff) <= 2 else ("差得有点多，可能中途走神了" if abs(diff) > 5 else "大致对得上")
        cnt = f"<p>你数到 <b>{int(counted)}</b> 个目标，实际出现 <b>{shown}</b> 个：{judge}。</p>"
    box_cls = "box" if res.get("verdict") == "found" else "warn"
    when = html.escape(str(res.get("started_at", ""))[:16].replace("T", " "))
    return f"""<!doctype html><html lang=zh><meta charset=utf-8><title>{html.escape(cfg['title'])} 报告</title>
<style>body{{font-family:"Microsoft YaHei",sans-serif;max-width:880px;margin:24px auto;padding:0 16px;color:#1f2937;background:#fff}}
h1{{font-size:22px}}h2{{font-size:17px;margin-top:26px}}table{{border-collapse:collapse;width:100%;margin:10px 0 18px}}
td,th{{border-bottom:1px solid #e5e7eb;padding:7px 8px;text-align:left;font-size:14px}}.v{{font-weight:600}}
.m{{color:#6b7280;font-size:13px}}.box{{background:#f0fdfa;border-left:4px solid #14b8a6;padding:10px 14px;margin:12px 0}}
.warn{{background:#fffbeb;border-left:4px solid #f59e0b;padding:10px 14px;margin:12px 0}}img{{width:100%;border:1px solid #e5e7eb}}</style>
<h1>{html.escape(cfg['title'])} 小实验报告</h1>
<p class=m>{when} · 共 {res.get('n_epochs', 0)} 次刺激（目标 {shown or 0} 次）</p>
<div class={box_cls}>{html.escape(res.get('message', ''))}</div>
{cnt}
<h2>平均波形</h2>
<img src="{html.escape(img_name)}" alt="平均脑电波形">
<p class=m>蓝线是{html.escape(cfg['std_name'])}之后的平均脑电，橙线是{html.escape(cfg['tgt_name'])}之后的，黑线是两者之差。
P300 指差值在刺激后 250–500 毫秒的平均高度，正值说明大脑对少见的目标反应更大。</p>
<h2>各电极结果</h2>
<table><tr><th>电极</th><th>P300（µV）</th><th>95% 区间</th><th>p 值</th><th>用到的目标</th><th>用到的标准</th><th>幅度超限剔除</th></tr>
<tr><td><b>耳后平均（主要看这个）</b></td><td class=v>{fmt(r.get('amp'))}</td><td>{fmt((r.get('ci') or (None, None))[0])} 到 {fmt((r.get('ci') or (None, None))[1])}</td>
<td>{fmt(r.get('p'), 3)}</td><td>{r.get('n_tgt', 0)}</td><td>{r.get('n_std', 0)}</td><td>—</td></tr>
{''.join(rows)}</table>
<p class=m>剔除：眨眼 {rej.get('blink', 0)} 次、数据缺口 {rej.get('gap', 0)} 次、录制首尾 {rej.get('edge', 0)} 次；
某个电极超过 ±{REJECT_UV:.0f} µV 时只在那个电极上剔除。</p>
<h2>怎么算的</h2>
<p class=m>每次刺激前 0.2 秒到后 0.8 秒截一段，滤波 0.5–20 Hz，减去刺激前 0.2 秒的平均作基线。
95% 区间用自助法（重抽 {N_BOOT} 次），p 值用置换检验（把“目标/标准”标签随机打乱 {N_PERM} 次，双侧）。
这个头环的参考电极在额头正中，所以耳后的 TP9/TP10 最能看到 P300，前额两个电极离参考太近，信号通常小。
标记时间和实际出声/出图之间有约 10–40 毫秒的固定延迟和几毫秒的抖动，对 250–500 毫秒的平均影响很小。</p>
<p class=m>说明：这是消费级 4 电极头环做的小实验，适合体验和自己前后比较，不能用于诊断。</p>
</html>"""


def write_outputs(res: dict, d: Path) -> dict:
    """Write erp_figure.png + erp_report.html and store the summary in session.json. Returns paths.

    The figure is always written (empty axes when there was nothing to analyse), so a finished ERP folder
    always holds all three outputs."""
    from .session import save_meta
    d = Path(d)
    out = {}
    figure_png(res, d / "erp_figure.png")
    out["figure"] = d / "erp_figure.png"
    (d / "erp_report.html").write_text(html_report(res), encoding="utf-8")
    out["report"] = d / "erp_report.html"
    mp = d / "session.json"
    if mp.exists():
        meta = json.loads(mp.read_text(encoding="utf-8"))
        e = meta.get("erp") if isinstance(meta.get("erp"), dict) else {}
        e["result"] = summary(res)
        meta["erp"] = e
        save_meta(d, meta)
    res["files"] = {k: str(v) for k, v in out.items()}
    return out


def outputs_ready(d: Path) -> bool:
    """True when erp_report.html, erp_figure.png and session.json["erp"]["result"] are all in folder d."""
    d = Path(d)
    try:
        if not ((d / "erp_report.html").is_file() and (d / "erp_figure.png").is_file()):
            return False
        meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
        return isinstance((meta.get("erp") or {}).get("result"), dict)
    except Exception:  # noqa: BLE001
        return False


def save_count(d: Path, counted: int, res: dict | None = None):
    """Store the user's own target count in session.json; rewrite the HTML report if a result is given."""
    from .session import save_meta
    d = Path(d)
    mp = d / "session.json"
    meta = json.loads(mp.read_text(encoding="utf-8"))
    e = meta.get("erp") if isinstance(meta.get("erp"), dict) else {}
    e["counted"] = int(counted)
    meta["erp"] = e
    save_meta(d, meta)
    if res is not None:
        res["counted"] = int(counted)
        (d / "erp_report.html").write_text(html_report(res), encoding="utf-8")


def figure_b64(res: dict) -> str:
    return base64.b64encode(figure_png(res)).decode()
