"""Main window: sidebar navigation, device bar, pages."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from PyQt6.QtCore import QSettings, Qt, QTimer
from PyQt6.QtGui import QFont, QIcon, QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QApplication, QButtonGroup, QDialog, QFileDialog, QFrame, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QMainWindow, QMenu, QPushButton, QStackedWidget, QVBoxLayout, QWidget,
)

from . import APP_NAME, APP_VERSION
from . import theme as T
from .analyzer import LiveAnalyzer
from .hub import DataHub
from .page_live import LivePage
from .page_record import RecordPage
from .page_review import ReviewPage, TrendsPage
from .page_switch import SwitchPage
from .sources import MuseSource, ReplaySource, SimSource, SourceSignals, scan_devices
from .widgets import label

from .paths import ICON, RECORDINGS

APP_DIR = Path(__file__).resolve().parents[1]


# ============================================================================ scan dialog
POWER_MODES = [
    ("全功能：脑电 + 16 路光学（心率、血氧），LED 高亮；实测约 1 小时", "p1041"),
    ("均衡：脑电 + 8 路光学，LED 调暗；有心率、血氧，更省电", "p1044"),
    ("省电：只有脑电，没有心率和血氧；适合长时间、睡眠", "p21"),
]


class ScanDialog(QDialog):
    def __init__(self, parent, signals: SourceSignals, last: dict | None, preset_last: str = ""):
        super().__init__(parent)
        self.setWindowTitle("连接头环")
        self.setMinimumSize(440, 380)
        self.signals = signals
        self.choice = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 20)
        lay.setSpacing(12)
        lay.addWidget(label("连接 Muse S Athena", "h2"))
        lay.addWidget(label("1. 打开电脑蓝牙。不用在 Windows 设置里配对。\n"
                            "2. 关掉手机上的 Muse App / Mind Monitor（头环一次只能连一个设备）。\n"
                            "3. 短按头环电源键开机，额头处亮灯后点「搜索」。", "muted", wrap=True))
        self.lst = QListWidget()
        lay.addWidget(self.lst, 1)
        if last and last.get("address"):
            it = QListWidgetItem(f"上次使用：{last.get('name') or 'Muse'}   {last['address']}")
            it.setData(Qt.ItemDataRole.UserRole, last)
            self.lst.addItem(it)
            self.lst.setCurrentRow(0)
        self.status = label("", "faint")
        lay.addWidget(self.status)
        from PyQt6.QtWidgets import QComboBox
        mrow = QHBoxLayout()
        mrow.addWidget(label("采集模式", ""))
        self.cb_preset = QComboBox()
        for text, preset in POWER_MODES:
            self.cb_preset.addItem(text, preset)
        i = self.cb_preset.findData(preset_last or "p1041")
        self.cb_preset.setCurrentIndex(max(0, i))
        mrow.addWidget(self.cb_preset, 1)
        lay.addLayout(mrow)
        row = QHBoxLayout()
        self.b_scan = QPushButton("搜索")
        self.b_scan.clicked.connect(self.scan)
        self.b_ok = QPushButton("连接")
        self.b_ok.setObjectName("primary")
        self.b_ok.clicked.connect(self.accept_choice)
        cancel = QPushButton("取消")
        cancel.setObjectName("ghost")
        cancel.clicked.connect(self.reject)
        row.addWidget(self.b_scan)
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(self.b_ok)
        lay.addLayout(row)
        self.lst.itemDoubleClicked.connect(lambda *_: self.accept_choice())
        signals.scan_done.connect(self.on_scan)

    def scan(self):
        self.b_scan.setEnabled(False)
        self.status.setText("正在搜索（约 8 秒）…")
        scan_devices(self.signals)

    def on_scan(self, devices, err):
        self.b_scan.setEnabled(True)
        if err:
            self.status.setText(f"搜索出错：{err}。请确认蓝牙已打开。")
            return
        for d in devices:
            it = QListWidgetItem(f"{d['name']}   {d['address']}")
            it.setData(Qt.ItemDataRole.UserRole, d)
            self.lst.addItem(it)
        if devices:
            self.lst.setCurrentRow(self.lst.count() - 1)
            self.status.setText(f"找到 {len(devices)} 个头环。")
        else:
            self.status.setText("没找到。确认头环已开机、没被手机连着，再搜一次。")

    def accept_choice(self):
        it = self.lst.currentItem()
        if it is None:
            self.status.setText("先搜索并选中一个头环。")
            return
        self.choice = it.data(Qt.ItemDataRole.UserRole)
        self.accept()


# ============================================================================ main window
class MainWindow(QMainWindow):
    PAGES = [("实时", "live"), ("冥想", "meditate"), ("录制", "record"), ("意念开关", "switch"), ("回看", "review"), ("趋势", "trends")]

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} · 脑电实验台")
        self.setMinimumSize(960, 600)
        icon = ICON
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))
        self.settings = QSettings("NeuroBench", "NeuroBench")
        self.setAcceptDrops(True)   # drop an exported .zip onto the window to import it
        self.hub = DataHub()
        self.signals = SourceSignals()
        self.signals.status.connect(self.on_status)
        self.source = None
        self.state = "idle"
        self.analyzer = LiveAnalyzer(self.hub)

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        h = QHBoxLayout(root)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)

        # ---------------- sidebar
        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(196)
        sv = QVBoxLayout(side)
        sv.setContentsMargins(16, 26, 16, 18)
        sv.setSpacing(4)
        sv.addWidget(label("NeuroBench", "brand"))
        sv.addWidget(label("脑电实验台 · Muse S", "brandSub"))
        sv.addSpacing(26)
        self.nav = QButtonGroup(self)
        self.nav.setExclusive(True)
        for i, (text, _) in enumerate(self.PAGES):
            b = QPushButton(text)
            b.setObjectName("nav")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            self.nav.addButton(b, i)
            sv.addWidget(b)
        sv.addStretch(1)
        sv.addWidget(label(f"v{APP_VERSION} · 基于 OpenMuse", "faint"))
        h.addWidget(side)

        # ---------------- main column
        col = QVBoxLayout()
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)
        bar = QFrame()
        bar.setObjectName("topbar")
        bar.setFixedHeight(64)
        bh = QHBoxLayout(bar)
        bh.setContentsMargins(24, 0, 24, 0)
        self.l_page = label("实时", "h2")
        bh.addWidget(self.l_page)
        bh.addStretch(1)
        self.l_rec = label("", "")
        self.l_rec.setStyleSheet(f"color: {T.BAD}; font-weight: 600;")
        bh.addWidget(self.l_rec)
        bh.addSpacing(16)
        self.dot = QLabel("●")
        bh.addWidget(self.dot)
        self.l_dev = label("未连接", "muted")
        bh.addWidget(self.l_dev)
        bh.addSpacing(12)
        self.b_conn = QPushButton("连接头环")
        self.b_conn.setObjectName("primary")
        self.b_conn.clicked.connect(self.connect_dialog)
        bh.addWidget(self.b_conn)
        self.b_more = QPushButton("···")
        self.b_more.setFixedWidth(46)
        menu = QMenu(self)
        menu.setStyleSheet(f"QMenu {{ background: {T.SURFACE2}; border: 1px solid {T.BORDER}; padding: 6px; }}"
                           f"QMenu::item {{ padding: 8px 20px; border-radius: 6px; }}"
                           f"QMenu::item:selected {{ background: {T.BORDER}; }}")
        menu.addAction("演示模式（模拟数据）", self.start_sim)
        menu.addAction("回放录音文件…", self.start_replay)
        menu.addSeparator()
        menu.addAction("导入录制（.zip）…", self.import_dialog)
        menu.addSeparator()
        menu.addAction("检查更新", lambda: self.updater.check(manual=True))
        self.act_rollback = menu.addAction("回退到上一版本", self.rollback)
        menu.addSeparator()
        menu.addAction("断开", self.disconnect)
        self.b_more.setMenu(menu)
        bh.addWidget(self.b_more)
        col.addWidget(bar)

        # ---------------- update banner (hidden until there is something to say)
        self.banner = QFrame()
        self.banner.setStyleSheet(f"QFrame {{ background: #12302b; border-bottom: 1px solid {T.BORDER}; }}")
        bb = QHBoxLayout(self.banner)
        bb.setContentsMargins(24, 8, 24, 8)
        self.l_banner = QLabel("")
        self.l_banner.setWordWrap(True)
        bb.addWidget(self.l_banner, 1)
        self.b_banner = QPushButton("立即更新")
        self.b_banner.setObjectName("primary")
        self.b_banner.clicked.connect(self._banner_action)
        bb.addWidget(self.b_banner)
        self.b_banner_later = QPushButton("稍后")
        self.b_banner_later.setObjectName("ghost")
        self.b_banner_later.clicked.connect(self._dismiss_banner)
        bb.addWidget(self.b_banner_later)
        self.banner.setVisible(False)
        col.addWidget(self.banner)

        self.stack = QStackedWidget()
        self.p_live = LivePage(self.hub, self.analyzer)
        self.p_record = RecordPage(self.hub, self.analyzer)
        from .page_meditate import MeditatePage
        self.p_meditate = MeditatePage(self.hub, self.analyzer, self.p_record)
        self.p_switch = SwitchPage(self.hub, self.analyzer)
        self.p_review = ReviewPage()
        self.p_trends = TrendsPage()
        for p in (self.p_live, self.p_meditate, self.p_record, self.p_switch, self.p_review, self.p_trends):
            self.stack.addWidget(p)
        col.addWidget(self.stack, 1)
        cw = QWidget()
        cw.setLayout(col)
        h.addWidget(cw, 1)

        self.nav.idClicked.connect(self.go)
        self.p_record.saved.connect(self._saved)
        self.p_live.record_toggle.connect(self.quick_record)
        self.p_live.mark.connect(self._mark)
        # marker hotkeys 1-6 work on every page while a recording runs
        from .protocols import EVENT_MARKERS
        for lab, key in EVENT_MARKERS:
            QShortcut(QKeySequence(key), self, activated=lambda l=lab: self._mark(l))
        self._rec_shown = False
        self._gap = False
        self.nav.button(0).setChecked(True)
        self.go(0)
        self.set_dev_state("idle", "未连接")

        self.clock = QTimer(self)
        self.clock.timeout.connect(self._tick)
        self.clock.start(500)

        # ---------------- updates: check shortly after start, then every 6 hours
        from .updater import CHECK_EVERY_S, Updater
        self.updater = Updater()
        self._pending_update = None
        self._banner_mode = ""
        self.updater.available.connect(self._update_available)
        self.updater.ready.connect(self._update_ready)
        self.updater.progress.connect(lambda m: self._show_banner(m, "", ""))
        self.updater.failed.connect(lambda m: self._show_banner(m, "", "关闭"))
        self.updater.up_to_date.connect(lambda m: self._show_banner(m, "", "关闭"))
        if not os.environ.get("NB_NO_UPDATE"):
            QTimer.singleShot(8000, self.updater.check)
            self.update_timer = QTimer(self)
            self.update_timer.timeout.connect(self.updater.check)
            self.update_timer.start(CHECK_EVERY_S * 1000)
        self._refresh_rollback()

    # ------------------------------------------------------------------ updates
    def _show_banner(self, text, action="", later="稍后"):
        self.l_banner.setText(text)
        self.b_banner.setVisible(bool(action))
        if action:
            self.b_banner.setText(action)
        self.b_banner_later.setVisible(bool(later))
        if later:
            self.b_banner_later.setText(later)
        self.banner.setVisible(True)

    def _dismiss_banner(self):
        if self._banner_mode == "install":
            self._banner_mode = "dismissed"   # ask again at the next periodic check
        self.banner.setVisible(False)

    def _update_available(self, m):
        self._pending_update = m
        if self.p_record.rec is not None:
            return                      # do not interrupt a recording; _tick shows it afterwards
        notes = (m.get("notes") or "").strip().replace("\n", "；")
        self._banner_mode = "install"
        self._show_banner(f"有新版本 v{m['version']}（当前 v{APP_VERSION}）：{notes}", "立即更新", "稍后")

    def _update_ready(self, ver):
        self._pending_update = None
        self._banner_mode = "restart"
        self._refresh_rollback()
        if self.p_record.rec is None:
            self._show_banner(f"v{ver} 已安装好，重启 NeuroBench 后生效。", "立即重启", "稍后")

    def _banner_action(self):
        if self._banner_mode == "install" and self._pending_update:
            if self.p_record.rec is not None:
                self._show_banner("正在录制，录完再更新。", "", "关闭")
                return
            self.updater.install(self._pending_update)
        elif self._banner_mode == "restart":
            if self.p_record.rec is not None:
                self._show_banner("正在录制，录完再重启。", "", "关闭")
                return
            from .updater import restart_app
            self.disconnect()
            restart_app()
            QApplication.quit()

    def rollback(self):
        from .updater import previous_version, set_current
        prev = previous_version()
        if not prev:
            self._show_banner("没有可以回退的版本。", "", "关闭")
            return
        set_current(prev)
        self._banner_mode = "restart"
        self._show_banner(f"已切回{'安装时的版本' if prev == 'bundled' else ' v' + prev}，重启后生效。", "立即重启", "稍后")
        self._refresh_rollback()

    def _refresh_rollback(self):
        from .updater import previous_version
        prev = previous_version()
        self.act_rollback.setEnabled(bool(prev))
        self.act_rollback.setText("回退到上一版本" + (f"（{'安装时的版本' if prev == 'bundled' else 'v' + prev}）" if prev else ""))

    # ------------------------------------------------------------------ navigation
    def go(self, i):
        if isinstance(i, str):
            i = [k for _, k in self.PAGES].index(i)
        self.stack.setCurrentIndex(i)
        self.l_page.setText(self.PAGES[i][0])
        self.nav.button(i).setChecked(True)
        if self.PAGES[i][1] == "review":
            self.p_review.refresh(self.p_review.session and str(self.p_review.session.dir))
        if self.PAGES[i][1] == "trends":
            self.p_trends.refresh()

    def _saved(self, path):
        """After any recording: keep a screenshot of the window in the folder; quick recordings
        are also packed into one .zip on the Desktop, ready to send."""
        import json
        import os
        import subprocess
        from datetime import datetime

        from PyQt6.QtCore import QStandardPaths

        from . import session as S
        d = Path(path)
        try:
            self.grab().save(str(d / "snapshot.png"))
        except Exception:  # noqa: BLE001
            pass
        try:
            meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            meta = {}
        # 10-second self-report, stored with the recording (becomes training data for personal baselines)
        if not os.environ.get("NB_NO_SURVEY") and meta:
            from .survey import SurveyDialog
            guess = {"睁眼闭眼测试": "闭眼静坐", "冥想 / 打坐": "冥想 / 打坐", "练功前后对比": "站桩 / 练功"}.get(meta.get("protocol"), "")
            if meta.get("mode") == "冥想":
                guess = "冥想 / 打坐"
            dlg = SurveyDialog(self, guess)
            if dlg.exec() and dlg.result_data:
                meta["self_report"] = dlg.result_data
                (d / "session.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        if meta.get("protocol") == "心理状态测评":
            try:
                from .report import build_report
                build_report(d)
                if not os.environ.get("NB_NO_REVEAL"):
                    os.startfile(str(d / "report.html"))
            except Exception as e:  # noqa: BLE001
                self._show_banner(f"测评报告生成失败：{e}", "", "关闭")
        self.p_review.refresh(path)
        if meta.get("mode") != "实时页一键录制":
            self.p_live.set_recording(None, f"已保存：{d.name}（在「回看」页可以导出）")
            return
        out_dir = Path(os.environ.get("NB_EXPORT_DIR") or
                       QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DesktopLocation) or Path.home())
        z = out_dir / f"NeuroBench_{d.name}.zip"
        try:
            n, size = S.export_sessions([d], z)
        except Exception as e:  # noqa: BLE001
            self.p_live.set_recording(None, f"已保存，但打包失败：{e}。可以在「回看」页手动导出。")
            return
        dur = meta.get("duration") or 0
        self.p_live.set_recording(None, f"已保存并打包（{int(dur) // 60} 分 {int(dur) % 60} 秒，{size / 1e6:.1f} MB）："
                                        f"桌面\\{z.name}  → 直接发给 Claude")
        if not os.environ.get("NB_NO_REVEAL"):
            try:
                subprocess.Popen(["explorer", f"/select,{z}"])
            except OSError:
                pass

    # ------------------------------------------------------------------ one-click recording (实时 page)
    def quick_record(self):
        from datetime import datetime
        if self.p_record.rec is not None:
            self.p_record.stop()
            return
        if not self.p_record.start_free(f"实时 {datetime.now():%m-%d %H%M}"):
            self.p_live.set_recording(None, "还没有数据：先连接头环（或右上角「···」打开演示模式），再点录制。")
            return
        self._rec_shown = True
        self.p_live.set_recording(0.0)

    def _mark(self, lab):
        if self.p_record.rec is not None:
            self.p_record.mark(lab)
            s = int(self.p_record.rec.elapsed())
            self.p_live.l_rec.setText(f"录制中 · 已标记「{lab}」@ {s // 60:02d}:{s % 60:02d} · 打标记：")

    def _system_marker(self, text):
        rec = self.p_record.rec
        if rec is not None:
            rec.add_marker(f"系统：{text}", "system")

    # ------------------------------------------------------------------ transfer between computers
    def import_dialog(self):
        self.go("review")
        self.p_review.import_dialog()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.go("review")
            self.p_review.import_paths(paths)

    # ------------------------------------------------------------------ sources
    def _start(self, src):
        self.disconnect()
        self.hub.clear()
        self.analyzer.reset()
        self.source = src
        self.set_dev_state("connecting", "连接中…")
        src.start()

    def connect_dialog(self):
        if self.state in ("connected", "connecting") and self.source and self.source.kind == "muse":
            self.disconnect()
            return
        last = {"address": self.settings.value("last_address", ""), "name": self.settings.value("last_name", "")}
        dlg = ScanDialog(self, self.signals, last, self.settings.value("preset", "p1041"))
        if dlg.exec() and dlg.choice:
            d = dlg.choice
            self.settings.setValue("last_address", d["address"])
            self.settings.setValue("last_name", d.get("name") or "")
            preset = dlg.cb_preset.currentData()
            self.settings.setValue("preset", preset)
            self._start(MuseSource(self.hub, self.signals, d["address"], d.get("name") or "", preset=preset))

    def start_sim(self):
        self._start(SimSource(self.hub, self.signals))

    def start_replay(self):
        start = str(RECORDINGS)
        path, _ = QFileDialog.getOpenFileName(self, "选择 OpenMuse 原始录音", start, "OpenMuse 原始数据 (*.txt)")
        if path:
            self._start(ReplaySource(self.hub, self.signals, path))

    def disconnect(self):
        if self.p_record.rec is not None:
            self._system_marker("手动断开")
            self.p_record.stop()
        if self.source is not None:
            self.source.stop()
            self.source = None
        self.set_dev_state("idle", "未连接")

    def on_status(self, state, msg):
        if state == "connected":
            self.set_dev_state("connected", msg)
        elif state == "connecting":
            self.set_dev_state("connecting", msg)
        elif state == "error":
            if self.p_record.rec is not None:
                bat = self.hub.info.battery
                self._system_marker(f"连接中断（{msg[:80]}；电量 {bat:.0f}%）" if bat == bat else f"连接中断（{msg[:80]}）")
                self.p_record.stop()
            self.source = None
            self.set_dev_state("error", f"连接失败：{msg[:60]}")
        elif state == "stopped" and self.state != "idle":
            self.set_dev_state("idle", "已断开")

    def set_dev_state(self, state, text):
        self.state = state
        col = {"idle": T.FAINT, "connecting": T.WARN, "connected": T.GOOD, "error": T.BAD}[state]
        self.dot.setStyleSheet(f"color: {col}; font-size: 14px;")
        self.l_dev.setText(text)
        kind = self.source.kind if self.source else ""
        self.b_conn.setText("断开" if (state in ("connected", "connecting") and kind == "muse") else "连接头环")

    def _tick(self):
        info = self.hub.info
        if self.state == "connected":
            parts = [info.name or "Muse"]
            if info.source == "sim":
                parts = ["演示 · 模拟数据"]
            elif info.source == "replay":
                parts = ["回放中"]
            if info.battery == info.battery:
                mins = self.analyzer.batt_minutes
                parts.append(f"电量 {info.battery:.0f}%" + (f"（约 {mins:.0f} 分钟）" if mins == mins else ""))
                self._battery_guard(info.battery)
            gap = not self.hub.is_live(3.0)
            if gap:
                parts.append("数据中断")
            if gap != self._gap:
                self._system_marker("数据中断（3 秒没收到数据）" if gap else "数据恢复")
                self._gap = gap
            self.l_dev.setText("  ·  ".join(parts))
        rec = self.p_record.rec
        if rec is not None:
            s = int(rec.elapsed())
            self.l_rec.setText(f"● 录制中 {s // 60:02d}:{s % 60:02d}")
            self._rec_shown = True
            self.p_live.set_recording(rec.elapsed())
        else:
            self.l_rec.setText("")
            if self._pending_update and not self.banner.isVisible() and self._banner_mode != "dismissed":
                self._update_available(self._pending_update)
            if self._rec_shown:
                self._rec_shown = False
                if "录制中" in self.p_live.l_rec.text() or "停止" in self.p_live.b_rec.text():
                    self.p_live.set_recording(None)

    def _battery_guard(self, b):
        """Warn once below 15 %; below 5 % stop and save the recording before the headband dies."""
        if b < 15 and not getattr(self, "_warned_low", False):
            self._warned_low = True
            self._show_banner(f"头环电量只剩 {b:.0f}%，录制会在 5% 时自动保存。请尽快充电。", "", "知道了")
        if b < 5 and self.p_record.rec is not None and not getattr(self, "_low_saved", False):
            self._low_saved = True
            self._system_marker(f"电量 {b:.0f}%，自动保存")
            if self.p_meditate.state in ("calibrate", "session"):
                self.p_meditate.finish(early=True)
            else:
                self.p_record.stop()
        if b > 20:
            self._warned_low = self._low_saved = False

    def closeEvent(self, e):
        self.disconnect()
        super().closeEvent(e)


def main(argv=None):
    argv = argv if argv is not None else sys.argv
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(argv)
    app.setApplicationName(APP_NAME)
    app.setFont(QFont(T.FONT, 10))
    app.setStyleSheet(T.QSS)
    w = MainWindow()
    if "--demo" in argv:
        QTimer.singleShot(300, w.start_sim)
    # fit the window to the screen (small laptop screens, high-DPI scaling)
    import os
    scr = app.primaryScreen().availableGeometry()
    test_size = os.environ.get("NB_TEST_SIZE")       # e.g. "1300x740", used by the screenshot self-test
    if test_size:
        tw, th = (int(v) for v in test_size.lower().split("x"))
        w.resize(tw, th)
        w.show()
    elif scr.width() < 1400 or scr.height() < 860:
        w.showMaximized()
    else:
        W, H = min(1480, int(scr.width() * 0.94)), min(920, int(scr.height() * 0.92))
        w.resize(W, H)
        w.move(scr.x() + (scr.width() - W) // 2, scr.y() + (scr.height() - H) // 2)
        w.show()
    if "--exit-after" in argv:        # used by automated tests
        QTimer.singleShot(int(float(argv[argv.index("--exit-after") + 1]) * 1000), QApplication.quit)
    if "--print-version" in argv:
        print(f"NeuroBench {APP_VERSION} from {Path(__file__).resolve().parent}", flush=True)
    if "--shots" in argv:
        from .selftest import run_shots
        run_shots(w, argv[argv.index("--shots") + 1], fast="--quick" in argv)
    return app.exec()
