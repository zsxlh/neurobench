"""Upload finished recordings to the user's PRIVATE GitHub repository as release assets.

* The access token lives in Windows Credential Manager (never in a file, never in logs).
* Before every batch the repository is checked to be private; a public repository is refused.
* One release per person per month (tag "<person>-YYYY-MM"); one .zip asset per recording.
* A recording counts as uploaded once <session>/cloud_upload.json says so; failures retry with backoff.
* Only real headband recordings are uploaded (no demo / replay / imported sessions).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

from PyQt6.QtCore import QObject, pyqtSignal

from . import session as S
from .paths import ROOT as INSTALL_ROOT

API = "https://api.github.com"
UPLOADS = "https://uploads.github.com"
DEFAULT_REPO = "zsxlh/neurobench-data"
CRED_TARGET = "NeuroBench:github-data-token"
CONFIG = INSTALL_ROOT / "cloud.json"
MARK = "cloud_upload.json"
MAX_ASSET = 1_900_000_000          # GitHub release assets must be < 2 GiB
TOKEN_PAGE = "https://github.com/settings/personal-access-tokens/new"


# ------------------------------------------------------------------ token: Windows Credential Manager
def _wincred():
    import ctypes
    from ctypes import wintypes

    class CREDENTIAL(ctypes.Structure):
        _fields_ = [("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
                    ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
                    ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.POINTER(ctypes.c_char)),
                    ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD),
                    ("Attributes", ctypes.c_void_p), ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR)]

    adv = ctypes.WinDLL("advapi32", use_last_error=True)
    adv.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.POINTER(CREDENTIAL))]
    adv.CredWriteW.argtypes = [ctypes.POINTER(CREDENTIAL), wintypes.DWORD]
    adv.CredDeleteW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD]
    adv.CredFree.argtypes = [ctypes.c_void_p]
    return ctypes, CREDENTIAL, adv


def save_token(token: str) -> None:
    if sys.platform != "win32":
        raise RuntimeError("只支持 Windows 凭据管理器")
    ctypes, CREDENTIAL, adv = _wincred()
    blob = token.strip().encode("utf-8")
    buf = ctypes.create_string_buffer(blob, len(blob))
    c = CREDENTIAL()
    c.Type = 1                       # CRED_TYPE_GENERIC
    c.TargetName = CRED_TARGET
    c.UserName = "neurobench"
    c.Comment = "NeuroBench 上传录制用的 GitHub 访问令牌"
    c.CredentialBlobSize = len(blob)
    c.CredentialBlob = ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))
    c.Persist = 2                    # CRED_PERSIST_LOCAL_MACHINE: survives logoff, stays on this computer
    if not adv.CredWriteW(ctypes.byref(c), 0):
        raise OSError(ctypes.get_last_error(), "保存到 Windows 凭据管理器失败")


def load_token() -> str:
    if sys.platform != "win32":
        return ""
    ctypes, CREDENTIAL, adv = _wincred()
    p = ctypes.POINTER(CREDENTIAL)()
    if not adv.CredReadW(CRED_TARGET, 1, 0, ctypes.byref(p)):
        return ""
    try:
        return ctypes.string_at(p.contents.CredentialBlob, p.contents.CredentialBlobSize).decode("utf-8")
    finally:
        adv.CredFree(p)


def delete_token() -> None:
    if sys.platform == "win32":
        ctypes, _, adv = _wincred()
        adv.CredDeleteW(CRED_TARGET, 1, 0)


# ------------------------------------------------------------------ settings
def load_config() -> dict:
    cfg = {"repo": DEFAULT_REPO, "person": "me", "auto": True}
    try:
        cfg.update(json.loads(CONFIG.read_text(encoding="utf-8")))
    except Exception:  # noqa: BLE001
        pass
    return cfg


def save_config(cfg: dict) -> None:
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def valid_person(p: str) -> bool:
    return bool(re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,19}", p or ""))


def valid_repo(r: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9-]+/[A-Za-z0-9._-]+", r or ""))


# ------------------------------------------------------------------ GitHub REST
class GitHubError(RuntimeError):
    def __init__(self, status: int, msg: str):
        super().__init__(msg)
        self.status = status


def _req(method: str, url: str, token: str, body=None, headers=None, timeout: float = 30.0):
    h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
         "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "NeuroBench"}
    if isinstance(body, (dict, list)):
        body = json.dumps(body).encode("utf-8")
        h["Content-Type"] = "application/json"
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read() or b"{}").get("message", "")
        except Exception:  # noqa: BLE001
            detail = ""
        raise GitHubError(e.code, f"HTTP {e.code} {detail}".strip()) from None


class Paused(Exception):
    """A recording started while uploading; the upload is abandoned and retried later."""


class _TooBig(RuntimeError):
    pass


def explain(e: Exception) -> str:
    """Short Chinese explanation for the status line. Never echoes request headers (the token)."""
    if isinstance(e, Paused):
        return "开始录制了，上传先暂停"
    if isinstance(e, GitHubError):
        msg = str(e).lower()
        if e.status == 401:
            return "令牌无效或已过期，请在「云端上传设置」里换一个"
        if e.status == 403 and "rate limit" in msg:
            return "GitHub 暂时限流，稍后自动重试"
        if e.status == 403:
            return "令牌没有写入权限（建令牌时 Contents 要选 Read and write）"
        if e.status == 404:
            return "令牌看不到这个仓库（建令牌时要选中 neurobench-data）"
        if 300 <= e.status < 400:
            return "仓库改过名或换了地方，请在「云端上传设置」里填新的仓库名"
        if e.status == 422:
            return "GitHub 拒绝了这个请求（仓库是空的，或同名文件冲突）"
        return str(e)
    if isinstance(e, (urllib.error.URLError, TimeoutError, ConnectionError)):
        return "连不上 GitHub（网络问题），稍后自动重试"
    if isinstance(e, OSError):
        return f"本机文件读写出错（{e.strerror or type(e).__name__}）"
    if isinstance(e, RuntimeError):
        return str(e)                   # our own messages
    return type(e).__name__             # anything else: no message text, it could quote a header


def _affects_all(e: Exception) -> bool:
    """Errors that would hit every session (network, token, repository): back off as a whole."""
    if isinstance(e, GitHubError):
        return e.status in (0, 401, 403, 404, 429) or 300 <= e.status < 400 or e.status >= 500
    return isinstance(e, (urllib.error.URLError, TimeoutError, ConnectionError))


def check_repo(repo: str, token: str) -> dict:
    """Raise unless the token can see the repository and the repository is private."""
    info = _req("GET", f"{API}/repos/{repo}", token)
    if not info.get("private") or info.get("visibility", "private") != "private":
        raise GitHubError(0, f"{repo} 不是私有仓库，脑电数据不能放进去，已停止上传")
    return info


def _get_or_create_release(repo: str, token: str, tag: str) -> dict:
    try:
        return _req("GET", f"{API}/repos/{repo}/releases/tags/{urllib.parse.quote(tag)}", token)
    except GitHubError as e:
        if e.status != 404:
            raise
    return _req("POST", f"{API}/repos/{repo}/releases", token,
                {"tag_name": tag, "name": tag, "body": "NeuroBench 自动上传的录制（私有）。",
                 "draft": False, "prerelease": False, "make_latest": "false"})


def _list_assets(repo: str, token: str, release_id: int) -> list:
    out, page = [], 1
    while True:
        got = _req("GET", f"{API}/repos/{repo}/releases/{release_id}/assets?per_page=100&page={page}", token)
        out += got or []
        if not got or len(got) < 100:
            return out
        page += 1


class _Progress:
    """File wrapper that reports how much http.client has read."""

    def __init__(self, f, size, cb, abort=None):
        self.f, self.size, self.cb, self.abort, self.done, self._last = f, size, cb, abort, 0, 0.0

    def read(self, n=-1):
        if self.abort is not None and self.abort():
            raise Paused()
        b = self.f.read(65536 if n is None or n < 0 else min(n, 65536))
        self.done += len(b)
        if self.cb and time.monotonic() - self._last > 0.5:
            self._last = time.monotonic()
            self.cb(self.done / max(1, self.size))
        return b


def _upload_asset(upload_url_base: str, token: str, path: Path, name: str, label: str, cb=None, abort=None) -> dict:
    size = path.stat().st_size
    q = urllib.parse.urlencode({"name": name, "label": label})
    with open(path, "rb") as f:          # the timeout applies per socket operation, not to the whole upload
        return _req("POST", f"{upload_url_base}?{q}", token, body=_Progress(f, size, cb, abort),
                    headers={"Content-Type": "application/zip", "Content-Length": str(size)}, timeout=120.0)


# ------------------------------------------------------------------ which sessions
def asset_name(d: Path, person: str) -> str:
    m = re.match(r"(\d{8}_\d{6})", d.name)
    stamp = m.group(1) if m else "x"
    return f"{stamp}_{person}_{hashlib.sha1(d.name.encode('utf-8')).hexdigest()[:6]}.zip"


def release_tag(meta: dict, d: Path, person: str) -> str:
    try:
        when = datetime.fromisoformat(meta["started_at"])
    except Exception:  # noqa: BLE001
        when = datetime.fromtimestamp(d.stat().st_mtime)
    return f"{person}-{when:%Y-%m}"


def upload_mark(d: Path) -> dict:
    try:
        return json.loads((Path(d) / MARK).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def is_uploaded(d: Path, repo: str | None = None) -> bool:
    m = upload_mark(d)
    return m.get("status") == "done" and (repo is None or m.get("repo") == repo)


def _write_mark(d: Path, rec: dict):
    tmp = Path(d) / (MARK + ".part")
    tmp.write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, Path(d) / MARK)


def eligible(d: Path, meta: dict, skip=()) -> bool:
    """A finished recording from a real headband, made on this computer, that nobody is still writing to.

    Finished = the app marked it cloud_ready after the survey and reports were written, or (older versions,
    crashes) nothing in the folder has changed for 15 minutes.
    """
    if meta.get("source") != "muse" or meta.get("imported_from"):
        return False
    if str(Path(d).resolve()) in skip:
        return False
    if meta.get("cloud_ready"):
        return True
    try:
        newest = max(p.stat().st_mtime for p in Path(d).iterdir() if p.is_file() and not p.name.startswith(MARK))
    except (OSError, ValueError):
        return False
    return time.time() - newest > 900


MAX_ATTEMPTS = 5


def pending_sessions(repo: str, skip=(), manual: bool = False) -> list:
    out = []
    for d, meta in S.list_sessions():
        if not eligible(d, meta, skip):
            continue
        m = upload_mark(d)
        if m.get("repo") == repo:
            if m.get("status") == "done":
                continue
            if not manual and (m.get("status") == "too_big" or m.get("attempts", 0) >= MAX_ATTEMPTS):
                continue                 # gave up on this one; 「立即上传」 tries again
        out.append(d)
    return out


# ------------------------------------------------------------------ worker
class CloudUploader(QObject):
    status = pyqtSignal(str)          # one line for the 回看 page
    uploaded = pyqtSignal(str)        # session folder name

    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        self._wake = threading.Event()
        self._lock = threading.Lock()
        self._manual = False
        self._held: set = set()
        self._thread = None
        self._fails = 0
        self.last = "云端上传：未设置"
        self.busy = False

    # -- called from the GUI thread
    def start(self):
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, name="cloud-upload", daemon=True)
            self._thread.start()
        self.kick()

    def kick(self, manual: bool = False):
        with self._lock:
            self._manual = self._manual or manual
        self._wake.set()

    def hold(self, d):
        """Keep a just-saved session back while the survey and reports are still being written."""
        with self._lock:
            self._held.add(str(Path(d).resolve()))

    def release(self, d):
        with self._lock:
            self._held.discard(str(Path(d).resolve()))

    def summary(self) -> str:
        return self.last

    # -- worker thread
    def _say(self, text):
        self.last = text
        self.status.emit(text)

    def _keep_manual(self, manual: bool):
        """A 「立即上传」 request that could not run yet stays pending for the next pass."""
        if manual:
            with self._lock:
                self._manual = True

    def _recording(self) -> bool:
        return self.hub.recorder is not None

    def _skip(self) -> set:
        with self._lock:
            skip = set(self._held)
        rec = self.hub.recorder
        if rec is not None and getattr(rec, "dir", None) is not None:
            skip.add(str(Path(rec.dir).resolve()))
        return skip

    def _loop(self):
        wait = 20.0                                    # first pass shortly after start
        while True:
            self._wake.wait(timeout=wait)
            self._wake.clear()
            with self._lock:
                manual, self._manual = self._manual, False
            try:
                wait = self._pass(manual)
            except Exception as e:  # noqa: BLE001     # never let the thread die
                wait = 600
                self._say(f"云端上传出错：{explain(e)}（10 分钟后重试）")
            finally:
                self.busy = False

    def _pass(self, manual: bool) -> float:
        cfg = load_config()
        token = load_token()
        if not token:
            self._say("云端上传：未设置（「···」→「云端上传设置」）")
            return 3600
        repo = cfg.get("repo", DEFAULT_REPO)
        if not cfg.get("auto") and not manual:
            n = len(pending_sessions(repo, self._skip()))
            self._say(f"云端上传：自动上传已关闭 · {n} 条未上传")
            return 3600
        if self._recording():
            self._keep_manual(manual)
            self._say("云端上传：录制结束后再上传")
            return 60
        try:
            self.busy = True
            done, failed = self._run_once(cfg, token, manual)
        except Paused:
            self._keep_manual(manual)
            self._say("云端上传：开始录制了，上传先暂停，录完继续")
            return 60
        except Exception as e:  # noqa: BLE001
            self._fails += 1
            wait = min(3600.0, 60.0 * 2 ** min(self._fails - 1, 6))
            self._say(f"云端上传失败：{explain(e)}（{max(1, int(wait // 60))} 分钟后重试）")
            return wait
        self._fails = 0
        n = len(pending_sessions(repo, self._skip()))
        parts = [f"云端上传：{datetime.now():%H:%M} 完成"]
        if done:
            parts.append(f"本次 {done} 条")
        if failed:
            parts.append(f"{len(failed)} 条失败（{failed[0]}）")
        parts.append(f"还有 {n} 条" if n else "全部已上传")
        self._say(" · ".join(parts))
        return 1800

    def _run_once(self, cfg: dict, token: str, manual: bool = False):
        repo, person = cfg.get("repo", DEFAULT_REPO), cfg.get("person") or "me"
        if not valid_repo(repo) or not valid_person(person):
            raise RuntimeError("设置里的仓库名或人员代号不对")
        todo = pending_sessions(repo, self._skip(), manual)
        if not todo:
            return 0, []
        check_repo(repo, token)                        # private, visible, token valid
        releases, assets, n, failed = {}, {}, 0, []
        cache = INSTALL_ROOT / "cache" / "upload"
        cache.mkdir(parents=True, exist_ok=True)
        for leftover in cache.iterdir():               # from an interrupted run
            try:
                leftover.unlink()
            except OSError:
                pass
        for d in todo:
            if self._recording():
                raise Paused()
            try:
                if self._upload_one(d, repo, person, token, releases, assets, cache):
                    n += 1
            except Paused:
                raise
            except Exception as e:  # noqa: BLE001
                if _affects_all(e):
                    raise
                m = upload_mark(d)
                attempts = (m.get("attempts", 0) if m.get("repo") == repo else 0) + 1
                _write_mark(d, {"status": "too_big" if isinstance(e, _TooBig) else "error", "repo": repo,
                                "attempts": attempts, "error": explain(e),
                                "at": datetime.now().isoformat(timespec="seconds")})
                failed.append(f"{d.name[:15]}：{explain(e)}")
        return n, failed

    def _upload_one(self, d, repo, person, token, releases, assets, cache) -> bool:
        meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
        tag = release_tag(meta, d, person)
        if tag not in releases:
            releases[tag] = _get_or_create_release(repo, token, tag)
            assets[tag] = {a["name"]: a for a in _list_assets(repo, token, releases[tag]["id"])}
        rel = releases[tag]
        name = asset_name(d, person)
        old = assets[tag].get(name)
        if old is not None and old.get("state") == "uploaded":
            self._mark(d, repo, tag, old, already=True)
            return True
        if old is not None:                            # a broken earlier attempt: remove it first
            _req("DELETE", f"{API}/repos/{repo}/releases/assets/{old['id']}", token)
            assets[tag].pop(name, None)
        title = str(meta.get("name", d.name))
        z = cache / name
        self._say(f"云端上传：正在打包 {title} …")
        S.export_sessions([d], z)
        try:
            size = z.stat().st_size
            if size > MAX_ASSET:
                raise _TooBig(f"打包后 {size / 1e9:.1f} GB，超过 GitHub 单文件 2 GB 上限")
            h = hashlib.sha256()
            with open(z, "rb") as fz:
                for chunk in iter(lambda: fz.read(1 << 20), b""):
                    h.update(chunk)
            base = rel["upload_url"].split("{", 1)[0]

            def cb(frac, title=title, size=size):
                self._say(f"云端上传：{title} {frac:.0%}（{size / 1e6:.1f} MB）")

            got = _upload_asset(base, token, z, name, title[:200], cb, abort=self._recording)
            if got.get("size") != size:
                raise RuntimeError(f"上传后大小不一致（{got.get('size')} ≠ {size}）")
            got["sha256"] = h.hexdigest()
            self._mark(d, repo, tag, got)
            return True
        finally:
            try:
                z.unlink()
            except OSError:
                pass

    def _mark(self, d: Path, repo: str, tag: str, asset: dict, already: bool = False):
        _write_mark(d, {"status": "done", "repo": repo, "tag": tag, "asset_id": asset.get("id"),
                        "name": asset.get("name"), "size": asset.get("size"), "sha256": asset.get("sha256", ""),
                        "uploaded_at": datetime.now().isoformat(timespec="seconds"), "found_existing": already})
        self.uploaded.emit(d.name)


def test_connection(repo: str, token: str) -> str:
    """Human-readable result of a read-only check (no data is sent)."""
    try:
        info = check_repo(repo, token)
        _req("GET", f"{API}/repos/{repo}/releases?per_page=1", token)
        _req("GET", f"{API}/repos/{repo}/commits?per_page=1", token)    # an empty repo cannot hold releases
    except Exception as e:  # noqa: BLE001
        if isinstance(e, GitHubError) and e.status == 409:
            return "✗ 仓库是空的：在 GitHub 上给它加一个 README 再试"
        return "✗ " + explain(e)
    return f"✓ 连接正常：{info.get('full_name')}（私有）"
