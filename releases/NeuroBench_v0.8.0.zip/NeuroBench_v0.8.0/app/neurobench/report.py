"""Assessment report (心理状态测评): indicators, plain-language reading, comparison with your own history.

Every indicator compares you with yourself: task segments against your eyes-closed rest in the same
session, and (from the third assessment on) against your earlier assessments. Nothing is compared with
population norms, because a 4-electrode consumer headband has none that are trustworthy.
"""

from __future__ import annotations

import base64
import html
import io
import json
from pathlib import Path

import numpy as np

from . import dsp
from .session import list_sessions, load_session, save_meta, session_hb_series

PROTOCOL = "心理状态测评"
LABELS = {
    "relax_ratio": ("放松反应", "闭眼时 α ÷ 睁眼时 α", "{:.2f} 倍"),
    "task_hr_delta": ("心算时心率变化", "心算 − 闭眼静坐", "{:+.1f} 次/分"),
    "task_rmssd_change": ("心算时心率变异变化", "相对闭眼静坐", "{:+.0f}%"),
    "task_theta_delta": ("心算时 θ 变化", "占比变化（百分点）", "{:+.1f}"),
    "task_hbo_delta": ("心算时前额含氧血红蛋白", "相对闭眼静坐，估算值", "{:+.2f} μM"),
    "recovery_score": ("恢复分数", "心率回到静坐水平的程度，100 = 完全回去", "{:.0f}"),
    "music_hr_delta": ("听音乐时心率变化", "听音乐 − 闭眼静坐", "{:+.1f} 次/分"),
    "music_alpha_ratio": ("听音乐时 α", "听音乐 ÷ 闭眼静坐", "{:.2f} 倍"),
}


def _seg(s, label):
    for g in s.segments:
        if g.label == label:
            return g
    return None


def _hbo_mean(s, t0, t1):
    vals = []
    for side in ("L", "R"):
        r = session_hb_series(s, side)
        if r is None:
            continue
        t, hbo, _ = r
        m = (t >= t0) & (t < t1)
        if m.any():
            vals.append(float(np.mean(hbo[m])))
    return float(np.mean(vals)) if vals else float("nan")


def indicators(s) -> dict:
    base, closed, task, rec, music = (_seg(s, k) for k in ("睁眼静坐", "闭眼静坐", "心算", "闭眼恢复", "听音乐"))
    ind = {}
    g = lambda seg, k: (seg.metrics.get(k) if seg else None)  # noqa: E731
    def ok(v):
        return isinstance(v, (int, float)) and v == v
    if ok(g(closed, "alpha")) and ok(g(base, "alpha")) and g(base, "alpha") > 0:
        ind["relax_ratio"] = g(closed, "alpha") / g(base, "alpha")
    if ok(g(task, "hr")) and ok(g(closed, "hr")):
        ind["task_hr_delta"] = g(task, "hr") - g(closed, "hr")
    if ok(g(task, "rmssd")) and ok(g(closed, "rmssd")) and g(closed, "rmssd") > 0 and g(task, "hrv_ok") and g(closed, "hrv_ok"):
        ind["task_rmssd_change"] = (g(task, "rmssd") / g(closed, "rmssd") - 1) * 100
    if ok(g(task, "theta")) and ok(g(closed, "theta")):
        ind["task_theta_delta"] = (g(task, "theta") - g(closed, "theta")) * 100
    if task and closed:
        h1, h0 = _hbo_mean(s, task.t0, task.t1), _hbo_mean(s, closed.t0, closed.t1)
        if ok(h1) and ok(h0):
            ind["task_hbo_delta"] = h1 - h0
    if ok(g(rec, "hr")) and ok(g(closed, "hr")) and ok(g(task, "hr")) and g(task, "hr") - g(closed, "hr") >= 2:
        rise = g(task, "hr") - g(closed, "hr")          # only meaningful when the task raised the heart rate
        ind["recovery_score"] = float(np.clip(100 * (1 - abs(g(rec, "hr") - g(closed, "hr")) / rise), 0, 100))
    if ok(g(music, "hr")) and ok(g(closed, "hr")):
        ind["music_hr_delta"] = g(music, "hr") - g(closed, "hr")
    if ok(g(music, "alpha")) and ok(g(closed, "alpha")) and g(closed, "alpha") > 0:
        ind["music_alpha_ratio"] = g(music, "alpha") / g(closed, "alpha")
    return ind


def reading(ind: dict) -> list[str]:
    out = []
    r = ind.get("relax_ratio")
    if r is not None:
        out.append("闭眼后 α 明显升高，放松反应明显。" if r >= 1.5 else
                   "闭眼后 α 有所升高，有一定的放松反应。" if r >= 1.1 else
                   "闭眼后 α 几乎没升高：可能比较紧张、犯困，或者电极接触影响了结果。")
    d = ind.get("task_hr_delta")
    if d is not None:
        out.append(f"心算时心率{'明显上升' if d > 5 else '略有上升' if d > 2 else '变化不大'}（{d:+.1f} 次/分）："
                   + ("投入了不少脑力，或者有一些压力感。" if d > 5 else "有一定投入。" if d > 2 else "身体对这项脑力任务反应平稳。"))
    c = ind.get("task_rmssd_change")
    if c is not None and c < -15:
        out.append("心算时心率变异下降，这是常见的压力反应。")
    sc = ind.get("recovery_score")
    if sc is not None:
        out.append("停下来后，心率很快回到了静坐水平。" if sc >= 80 else
                   "停下来后，心率回落了一部分。" if sc >= 50 else "停下来后，心率回落得比较慢。")
    m = ind.get("music_hr_delta")
    if m is not None:
        out.append(f"听音乐时心率{'上升' if m > 2 else '下降' if m < -2 else '基本不变'}（{m:+.1f} 次/分）。")
    return out


def history(exclude_dir: Path | None = None):
    """Indicators of earlier real (not simulated) assessments, oldest first."""
    rows = []
    for d, meta in list_sessions():
        if meta.get("protocol") != PROTOCOL or meta.get("source") == "sim" or (exclude_dir and d == exclude_dir):
            continue
        a = meta.get("assessment")
        if a:
            rows.append((meta.get("started_at", ""), a))
    return sorted(rows)


def compare(ind: dict, hist) -> dict:
    out = {}
    for k, v in ind.items():
        vals = [a[k] for _, a in hist if k in a]
        if len(vals) >= 3:
            mu, sd = float(np.mean(vals)), float(np.std(vals)) or 1e-9
            z = (v - mu) / sd
            out[k] = {"n": len(vals), "mean": mu, "z": z,
                      "text": "和你平时差不多" if abs(z) < 1 else ("比你平时高" if z > 0 else "比你平时低")}
    return out


def _chart_png(s) -> str:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, axes = plt.subplots(2, 1, figsize=(9, 5.2), sharex=True)
    cols = ["#5eead4", "#a78bfa", "#fbbf24", "#60a5fa", "#f472b6", "#34d399"]
    if "OPTICS" in s.data:
        t, O, names = s.data["OPTICS"]
        h = dsp.robust_heart(O, names)
        if h["ch"] is not None:
            pt, ibi = dsp.ppg_beats(O[:, h["ch"]], t=t)
            ok = (ibi > 0.33) & (ibi < 1.6)
            axes[0].plot(pt[1:][ok] / 60, 60 / ibi[ok], ".", ms=3, color="#fb7185")
    axes[0].set_ylabel("心率")
    for g in s.segments:
        ser = g.metrics.get("alpha_series")
        if ser and len(ser[0]):
            tt, a, keep = ser
            axes[1].plot(tt[keep] / 60, a[keep] * 100, ".", ms=4, color="#34d399")
    axes[1].set_ylabel("α 占比 %")
    axes[1].set_xlabel("分钟")
    for i, g in enumerate(s.segments):
        for ax in axes:
            ax.axvspan(g.t0 / 60, g.t1 / 60, color=cols[i % len(cols)], alpha=0.12)
        axes[0].text(g.t0 / 60, axes[0].get_ylim()[1], g.label, fontsize=8, va="top")
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def build_report(d: Path) -> dict:
    """Compute indicators, store them in session.json, write report.html. Returns the indicators."""
    d = Path(d)
    s = load_session(d)
    ind = indicators(s)
    hist = history(exclude_dir=d)
    cmp_ = compare(ind, hist)
    meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
    meta["assessment"] = ind
    save_meta(d, meta)

    rows = []
    for k, (name, how, fmt) in LABELS.items():
        if k not in ind:
            continue
        c = cmp_.get(k)
        if c:
            versus = html.escape(f"{c['text']}（之前 {c['n']} 次，平均 {fmt.format(c['mean'])}）")
        else:
            versus = "<span class=m>满 3 次测评后开始比较</span>"
        rows.append(f"<tr><td>{name}</td><td class=v>{fmt.format(ind[k])}</td><td class=m>{how}</td><td>{versus}</td></tr>")
    segs = []
    for g in s.segments:
        m = g.metrics
        f = lambda v, p=False, nd=0: "—" if not isinstance(v, (int, float)) or v != v else (f"{v*100:.{nd}f}%" if p else f"{v:.{nd}f}")  # noqa: E731
        segs.append(f"<tr><td>{html.escape(g.label)}</td><td>{f(m.get('alpha'), True)}</td><td>{f(m.get('theta'), True)}</td>"
                    f"<td>{f(m.get('beta'), True)}</td><td>{f(m.get('hr'))}</td><td>{f(m.get('rmssd')) if m.get('hrv_ok') else '—'}</td>"
                    f"<td>{f(m.get('blink_rate'))}</td><td>{f(m.get('clean_share'), True)}</td></tr>")
    sr = meta.get("self_report") or {}
    srs = (f"自评：平静 {sr.get('sr_calm')} · 专注 {sr.get('sr_focus')} · 困倦 {sr.get('sr_sleepy')} · "
           f"心情 {sr.get('sr_mood')} · 昨晚睡 {sr.get('sr_sleep_h')} 小时") if sr else ""
    low = [g.label for g in s.segments if isinstance(g.metrics.get("clean_share"), float) and g.metrics["clean_share"] < 0.5]
    try:
        img = f"<img src='data:image/png;base64,{_chart_png(s)}' style='width:100%'>"
    except Exception:  # noqa: BLE001
        img = ""
    page = f"""<!doctype html><html lang=zh><meta charset=utf-8><title>心理状态测评报告</title>
<style>body{{font-family:"Microsoft YaHei",sans-serif;max-width:860px;margin:24px auto;padding:0 16px;color:#1f2937}}
h1{{font-size:22px}}table{{border-collapse:collapse;width:100%;margin:10px 0 20px}}td,th{{border-bottom:1px solid #e5e7eb;padding:7px 8px;text-align:left;font-size:14px}}
.v{{font-weight:600}}.m{{color:#6b7280;font-size:13px}}.box{{background:#f0fdfa;border-left:4px solid #14b8a6;padding:10px 14px;margin:12px 0}}
.warn{{background:#fffbeb;border-left:4px solid #f59e0b;padding:8px 14px}}</style>
<h1>心理状态测评报告</h1>
<p class=m>{html.escape(meta.get('started_at', '')[:16].replace('T', ' '))} · NeuroBench v{html.escape(str(meta.get('software', {}).get('neurobench', '')))} · {html.escape(srs)}</p>
<div class=box>{'<br>'.join(html.escape(x) for x in reading(ind)) or '数据不足，无法给出解读。'}</div>
{f"<p class=warn>这几段干净数据不到一半，相关结论要打折扣：{'、'.join(map(html.escape, low))}</p>" if low else ''}
<h2>指标</h2><table><tr><th>指标</th><th>本次</th><th>怎么算</th><th>和你自己比</th></tr>{''.join(rows)}</table>
<h2>过程</h2>{img}
<h2>分段数据</h2><table><tr><th>段落</th><th>α</th><th>θ</th><th>β</th><th>心率</th><th>心率变异</th><th>眨眼/分</th><th>可用数据</th></tr>{''.join(segs)}</table>
<p class=m>说明：这是消费级 4 电极头环，结果只适合和你自己比较、看长期变化，不能用于诊断。各频段占比只用剔除了眨眼、肌电、晃动后的片段计算。</p>
</html>"""
    (d / "report.html").write_text(page, encoding="utf-8")
    return ind
