"""Synthesized soundscape for meditation feedback (no audio files shipped; generated on first use).

calm  : soft wind bed, always on
rain  : rain layer whose volume follows how "busy" the mind is
bird  : short chirp, played after a stretch of calm
bell  : start / end chime
"""

from __future__ import annotations

import wave
from pathlib import Path

import numpy as np
from scipy.signal import butter, sosfilt

from .paths import ROOT

SR = 22050
CACHE = ROOT / "cache" / "sounds"
VERSION = 1


def _write(path: Path, x: np.ndarray):
    x = np.clip(x, -1, 1)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32000).astype("<i2").tobytes())


def _loopable(x: np.ndarray, fade_s: float = 1.5):
    """Crossfade the end into the start so the loop has no click."""
    n = int(fade_s * SR)
    head, tail = x[:n].copy(), x[-n:].copy()
    ramp = np.linspace(0, 1, n)
    x = x[n:].copy()
    x[-n:] = tail * (1 - ramp) + head * ramp
    return x


def _pink(n, rng):
    w = rng.normal(0, 1, n)
    b = [0.049922035, -0.095993537, 0.050612699, -0.004408786]
    a = [1, -2.494956002, 2.017265875, -0.522189400]
    from scipy.signal import lfilter
    return lfilter(b, a, w)


def _wind(rng, seconds=24):
    n = seconds * SR
    x = _pink(n, rng)
    x = sosfilt(butter(2, [80, 700], btype="band", fs=SR, output="sos"), x)
    t = np.arange(n) / SR
    env = 0.6 + 0.4 * np.sin(2 * np.pi * t / 8.0) * np.sin(2 * np.pi * t / 13.0 + 1)
    x = x * env
    return 0.5 * x / np.max(np.abs(x))


def _rain(rng, seconds=20):
    n = seconds * SR
    x = rng.normal(0, 1, n)
    x = sosfilt(butter(2, [900, 7000], btype="band", fs=SR, output="sos"), x) * 0.35
    drops = np.zeros(n)
    for i in rng.integers(0, n - 400, seconds * 90):
        k = np.arange(300)
        drops[i:i + 300] += rng.uniform(0.2, 1.0) * np.exp(-k / 40.0) * np.sin(2 * np.pi * rng.uniform(1500, 4500) * k / SR)
    x = x + 0.25 * drops
    return 0.6 * x / np.max(np.abs(x))


def _bird(rng):
    out = []
    for _ in range(rng.integers(2, 5)):
        d = rng.uniform(0.07, 0.14)
        t = np.arange(int(d * SR)) / SR
        f0, f1 = rng.uniform(2600, 3600), rng.uniform(3800, 5200)
        f = np.linspace(f0, f1, len(t)) if rng.random() < 0.6 else np.linspace(f1, f0, len(t))
        ph = 2 * np.pi * np.cumsum(f) / SR
        env = np.sin(np.pi * np.linspace(0, 1, len(t))) ** 2
        out += [0.5 * env * np.sin(ph), np.zeros(int(rng.uniform(0.04, 0.09) * SR))]
    x = np.concatenate(out)
    return x / np.max(np.abs(x)) * 0.5


def _bell():
    t = np.arange(int(3.0 * SR)) / SR
    x = sum(a * np.sin(2 * np.pi * f * t) * np.exp(-t * d) for f, a, d in ((528, 1.0, 1.3), (1056, 0.4, 2.0), (1584, 0.2, 3.0)))
    return 0.45 * x / np.max(np.abs(x))


def ensure_sounds() -> dict:
    """Generate the sound files once; return {name: path}."""
    CACHE.mkdir(parents=True, exist_ok=True)
    stamp = CACHE / f"v{VERSION}"
    files = {k: CACHE / f"{k}.wav" for k in ("calm", "rain", "bird1", "bird2", "bird3", "bell")}
    if stamp.exists() and all(p.exists() for p in files.values()):
        return files
    rng = np.random.default_rng(11)
    _write(files["calm"], _loopable(_wind(rng)))
    _write(files["rain"], _loopable(_rain(rng)))
    for k in ("bird1", "bird2", "bird3"):
        _write(files[k], _bird(rng))
    _write(files["bell"], _bell())
    stamp.write_text("ok", encoding="utf-8")
    return files


class Soundscape:
    """Two looping layers plus one-shot birds and bells; volumes follow set_level()."""

    def __init__(self):
        from PyQt6.QtCore import QUrl
        from PyQt6.QtMultimedia import QSoundEffect
        self._ok = True
        try:
            files = ensure_sounds()
        except Exception:  # noqa: BLE001
            self._ok = False
            return
        def eff(name, loop=False):
            e = QSoundEffect()
            e.setSource(QUrl.fromLocalFile(str(files[name])))
            if loop:
                e.setLoopCount(QSoundEffect.Loop.Infinite.value)
            e.setVolume(0.0)
            return e
        self.calm = eff("calm", True)
        self.rain = eff("rain", True)
        self.birds = [eff(k) for k in ("bird1", "bird2", "bird3")]
        self.bell = eff("bell")
        self._bird_i = 0
        self.master = 0.8
        self.level = 0.5

    def start(self):
        if not self._ok:
            return
        self.calm.setVolume(0.35 * self.master)
        self.rain.setVolume(0.2 * self.master)
        self.calm.play()
        self.rain.play()

    def set_level(self, busy: float):
        """busy: 0 = calm, 1 = very active. Rain gets louder with busyness."""
        if not self._ok:
            return
        self.level = 0.85 * self.level + 0.15 * float(np.clip(busy, 0, 1))
        self.rain.setVolume(float((0.03 + 0.75 * self.level ** 1.5) * self.master))
        self.calm.setVolume(float((0.40 - 0.15 * self.level) * self.master))

    def chirp(self):
        if not self._ok:
            return
        e = self.birds[self._bird_i % len(self.birds)]
        self._bird_i += 1
        e.setVolume(0.55 * self.master)
        e.play()

    def ring(self):
        if not self._ok:
            return
        self.bell.setVolume(0.7 * self.master)
        self.bell.play()

    def stop(self):
        if not self._ok:
            return
        for e in (self.calm, self.rain):
            e.stop()
