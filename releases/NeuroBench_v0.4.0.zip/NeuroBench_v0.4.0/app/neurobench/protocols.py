"""Recording protocols (step sequences) and audio prompts."""

from __future__ import annotations

import subprocess
import sys
import threading
from dataclasses import dataclass


@dataclass
class Step:
    label: str
    seconds: float | None      # None = until the user presses 下一步
    tip: str
    voice: str = ""


PROTOCOLS: dict[str, list[Step]] = {
    "自由录制": [],
    "练功前后对比": [
        Step("练前·睁眼静坐", 120, "目视前方一点，自然呼吸，尽量不眨眼太频繁。", "开始练前测量。请睁眼静坐，目视前方。"),
        Step("练前·闭眼静坐", 180, "闭上眼睛，放松面部和下巴，不要刻意做什么。", "请闭上眼睛，放松下巴，安静坐好。"),
        Step("练功", None, "开始你的练习（站桩、打坐等）。结束时点「下一步」。", "请睁开眼睛，开始练功。结束时按下一步。"),
        Step("练后·闭眼静坐", 300, "回到坐姿，闭眼放松，和练前一样的姿势。", "练功结束。请坐好，闭上眼睛，放松。"),
        Step("休息", 600, "可以睁眼活动，但别摘头环。也可以点「下一步」跳过。", "请睁开眼睛，自由休息十分钟。"),
        Step("十分钟后·闭眼静坐", 180, "再闭眼静坐三分钟，看效果还在不在。", "请再次闭上眼睛，安静坐好。"),
    ],
    "睁眼闭眼测试": [
        Step("睁眼", 30, "目视前方。", "请睁眼，目视前方。"),
        Step("闭眼", 30, "闭眼放松。", "请闭上眼睛。"),
        Step("睁眼", 30, "目视前方。", "请睁开眼睛。"),
        Step("闭眼", 30, "闭眼放松。", "请闭上眼睛。"),
    ],
    "冥想 / 打坐": [
        Step("基线·闭眼静坐", 120, "闭眼，自然呼吸，先不进入冥想。", "请闭上眼睛，自然呼吸，先不要开始冥想。"),
        Step("冥想", 900, "开始冥想。十五分钟后提示，也可以随时点「下一步」。", "现在开始冥想。"),
        Step("收功·闭眼静坐", 120, "停止用功，闭眼自然放松。", "请停止用功，自然放松，保持闭眼。"),
    ],
    "肌电样本": [
        Step("放松", 20, "放松面部。", "请放松面部。"),
        Step("咬牙", 10, "用力咬牙。", "请用力咬牙。"),
        Step("放松", 20, "放松。", "放松。"),
        Step("绷脖子", 10, "绷紧脖子和肩膀。", "请绷紧脖子和肩膀。"),
        Step("放松", 20, "放松。", "放松。"),
        Step("皱眉", 10, "用力皱眉。", "请皱眉。"),
        Step("放松", 20, "放松。", "放松。"),
    ],
}

PROTOCOL_DESC = {
    "自由录制": "不分步骤，随时打标记。",
    "练功前后对比": "练前睁眼 2 分 · 闭眼 3 分 → 练功 → 练后闭眼 5 分 → 休息 10 分 → 再闭眼 3 分。",
    "睁眼闭眼测试": "4 × 30 秒，检查设备和 α 波，约 2 分钟。",
    "冥想 / 打坐": "基线 2 分 → 冥想 15 分 → 收功 2 分。",
    "肌电样本": "录咬牙、绷脖子、皱眉的干扰样子，约 2 分钟。",
}

EVENT_MARKERS = [
    ("眨眼", "1"),
    ("动了一下", "2"),
    ("咬牙/用力", "3"),
    ("走神", "4"),
    ("入静", "5"),
    ("有感觉", "6"),
]


# ---------------------------------------------------------------------------- audio
_CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def speak(text: str):
    """Speak Chinese text with the Windows voice, without blocking."""
    if not text or sys.platform != "win32":
        return
    safe = text.replace("'", "''")
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "try{$s.SelectVoiceByHints('Female',0,0,[Globalization.CultureInfo]'zh-CN')}catch{};"
        "$s.Rate=-1;"
        f"$s.Speak('{safe}')"
    )
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
                         creationflags=_CREATE_NO_WINDOW,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        chime()


def chime(times: int = 1):
    if sys.platform != "win32":
        return

    def run():
        import winsound
        for i in range(times):
            winsound.Beep(880 if i % 2 == 0 else 660, 180)

    threading.Thread(target=run, daemon=True).start()
