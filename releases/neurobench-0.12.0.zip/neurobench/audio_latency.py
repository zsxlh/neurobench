"""Sound output latency calibration: speaker -> microphone delay of the ERP tones.

The program plays the auditory-P300 standard tone exactly the way page_erp does (a preloaded QSoundEffect,
time stamp taken right after play() returns) about a dozen times at jittered intervals, while a QAudioSource
captures the default (or a chosen) microphone at 16 kHz mono. Audio stays in memory only, it is never
written to disk.

Clock model: every captured buffer is stamped with time.perf_counter() when it is read. A buffer is never
read before its last sample was recorded, so sample k was recorded at t0 + k/sr with
t0 = min_i(t_read_i - K_i/sr) (lower envelope, K_i = samples received up to and including buffer i).
Delivery jitter therefore only makes t0 later by the *minimum* input delay of the microphone path; that
minimum still adds to the result. The number is thus an UPPER BOUND of the speaker latency (output delay
+ microphone input delay), unless the output is wired back into the input (loopback cable).

Onsets: matched filter with the tone's own envelope at the tone frequency (complex demodulation), onset
taken on the leading edge (half of the peak, corrected by the template's own response) so room echoes
after the direct sound do not pull it late.

Pure functions (sample_clock, detect_tones, analyse_capture, store helpers) need no Qt; the Qt classes
(QtMicSource, SoundEffectPlayer, LatencyCalibrator) take injected sources/players so tests never open a
real microphone.
"""

from __future__ import annotations

import json
import os
import time
from datetime import datetime
from pathlib import Path

import numpy as np

CAP_SR = 16000
N_TONES = 12
MIN_DETECTED = 8
ISI = (1.2, 1.8)             # jittered onset-to-onset interval, s
WARMUP_S = 1.2               # capture runs this long before the first tone
TAIL_S = 0.9                 # and this long after the last
MAX_LATENCY_S = 0.5          # search window after each play() call (Bluetooth can be 200-300 ms)
EARLY_S = 0.02               # a little before play() too (clock rounding)
SNR_MIN = 6.0                # peak of the matched filter / its median over the whole capture
ONSET_FRAC = 0.5             # leading-edge level (fraction of the peak) that marks the onset
MAX_IQR_MS = 20.0            # above this the result is called unstable and not saved
STORE_NAME = "audio_latency.json"
MAX_CLOCK_SPLIT_MS = 3.0     # t0 of the first vs the second half of the reads: more = samples were lost
MIN_RECEIVED_RATIO = 0.95    # samples received / (elapsed time x rate): less = samples were lost
APPLY_RANGE_MS = (0.0, 500.0)  # only latencies in this range are ever applied to recordings

UPPER_BOUND_NOTE = ("这是“扬声器延迟的上限”：麦克风自己的录音延迟也算在里面了（通常 5–20 毫秒），"
                    "除非用回环线把输出直接接到输入，真实的出声延迟只会等于或短于这个数。")


# ============================================================================ tone parameters
def tone_params() -> tuple[float, float]:
    """(frequency Hz, duration s) of the ERP standard tone that is calibrated."""
    from .erp import EXPERIMENTS
    cfg = EXPERIMENTS["auditory"]
    return float(cfg["std_freq"]), float(cfg["dur"])


def tone_envelope(dur: float, sr: int, ramp: float = 0.005) -> np.ndarray:
    """Amplitude envelope of erp.tone (raised-cosine ramps), used as the matched-filter template."""
    n = int(round(dur * sr))
    w = np.ones(n)
    r = int(ramp * sr)
    if r:
        rr = 0.5 - 0.5 * np.cos(np.pi * np.arange(r) / r)
        w[:r] *= rr
        w[-r:] *= rr[::-1]
    return w


# ============================================================================ pure analysis
def to_float(raw: bytes, sample_format: str = "int16", channels: int = 1) -> np.ndarray:
    """Raw interleaved PCM -> float mono (first channel). Trailing partial frames must be cut by the caller."""
    dt = {"int16": "<i2", "int32": "<i4", "float32": "<f4", "uint8": "u1"}[sample_format]
    a = np.frombuffer(raw, dtype=dt).astype(np.float64)
    if sample_format == "int16":
        a /= 32768.0
    elif sample_format == "int32":
        a /= 2147483648.0
    elif sample_format == "uint8":
        a = (a - 128.0) / 128.0
    if channels > 1:
        a = a[: (len(a) // channels) * channels].reshape(-1, channels)[:, 0]
    return a


def sample_clock(chunks, sr: float) -> tuple[np.ndarray, float]:
    """chunks: [(t_read_perf, samples)] in arrival order -> (signal, t0) with sample k at t0 + k/sr.

    t0 is the lower envelope of t_read - (samples so far)/sr: the read that came soonest after its last
    sample defines the clock (later reads only arrived later, they do not move it)."""
    chunks = [(float(t), np.asarray(x, float)) for t, x in chunks if len(x)]
    if not chunks:
        return np.zeros(0), float("nan")
    x = np.concatenate([c[1] for c in chunks])
    k = np.cumsum([len(c[1]) for c in chunks])
    t_read = np.array([c[0] for c in chunks])
    t0 = float(np.min(t_read - k / sr))
    return x, t0


def clock_check(chunks, sr: float, max_split_ms: float = MAX_CLOCK_SPLIT_MS,
                min_ratio: float = MIN_RECEIVED_RATIO) -> dict:
    """Detect lost microphone samples, which make the lower-envelope clock (and so the latency) too early.

    1. t0 estimated separately from the first and the second half of the reads (same cumulative sample
       count): a sample gap between them makes the second estimate later by the lost duration.
    2. Samples received vs. elapsed time from the start of the first buffer to the last read.
    Returns {"ok", "t0_first", "t0_second", "split_ms", "received", "expected", "ratio", "n_reads"}."""
    chunks = [(float(t), len(x)) for t, x in chunks if len(x)]
    out = {"ok": True, "t0_first": None, "t0_second": None, "split_ms": None, "received": 0, "expected": 0,
           "ratio": None, "n_reads": len(chunks)}
    if len(chunks) < 4 or not sr:
        return out
    t_read = np.array([c[0] for c in chunks])
    n = np.array([c[1] for c in chunks], float)
    k = np.cumsum(n)
    off = t_read - k / sr
    h = len(chunks) // 2
    t1, t2 = float(np.min(off[:h])), float(np.min(off[h:]))
    split = abs(t2 - t1) * 1000.0
    received = int(k[-1])
    elapsed = float(t_read[-1] - (t_read[0] - n[0] / sr))
    expected = int(round(elapsed * sr))
    ratio = received / expected if expected > 0 else 1.0
    out.update(t0_first=t1, t0_second=t2, split_ms=round(split, 3), received=received, expected=expected,
               ratio=round(float(ratio), 4))
    out["ok"] = bool(split <= max_split_ms and ratio >= min_ratio)
    return out


def _envelope(x: np.ndarray, sr: float, freq: float, dur: float, frac: float = 0.5):
    """|matched filter| for a tone starting at each sample, and the template's half-rise lag (samples)."""
    from scipy.signal import fftconvolve
    w = tone_envelope(dur, int(round(sr)))
    n = np.arange(len(x))
    z = (x - np.mean(x)) * np.exp(-2j * np.pi * freq * n / sr)
    env = np.abs(fftconvolve(z, w[::-1], mode="valid"))       # env[n]: template starting at sample n
    ac = np.correlate(w, w, mode="full")                        # template response vs lag
    ac /= ac.max()
    mid = len(w) - 1
    rise = ac[: mid + 1]                                        # lags -(L-1)..0
    j = int(np.argmax(rise >= frac))
    # sub-sample lag where the response crosses one half on the rising side (negative)
    if j > 0:
        u = (frac - rise[j - 1]) / (rise[j] - rise[j - 1])
        half_lag = (j - 1 + u) - mid
    else:
        half_lag = float(-mid)
    return env, float(half_lag)


def detect_tones(x: np.ndarray, sr: float, t0: float, play_times, freq: float, dur: float,
                 max_latency: float = MAX_LATENCY_S, snr_min: float = SNR_MIN) -> list:
    """For each play() time find the tone onset in the capture. Returns
    [{"play_t", "onset_t" | None, "latency_ms" | None, "snr"}]."""
    out = []
    if len(x) < int(dur * sr) + 10 or not np.isfinite(t0):
        return [{"play_t": float(p), "onset_t": None, "latency_ms": None, "snr": 0.0} for p in play_times]
    env, half_lag = _envelope(x, sr, freq, dur, ONSET_FRAC)
    floor = float(np.median(env)) + 1e-12
    for p in play_times:
        a = int(np.floor((p - EARLY_S - t0) * sr))
        b = int(np.ceil((p + max_latency - t0) * sr))
        a, b = max(a, 1), min(b, len(env) - 1)
        rec = {"play_t": float(p), "onset_t": None, "latency_ms": None, "snr": 0.0}
        if b - a < 5:
            out.append(rec)
            continue
        pk = a + int(np.argmax(env[a:b]))
        snr = float(env[pk] / floor)
        rec["snr"] = round(snr, 1)
        if snr >= snr_min:
            half = ONSET_FRAC * env[pk]
            i = pk
            lo = max(0, pk - int(2 * dur * sr))
            while i > lo and env[i] >= half:
                i -= 1
            # linear interpolation between i (below half) and i+1 (at/above half)
            d = env[i + 1] - env[i]
            cross = i + ((half - env[i]) / d if d > 0 else 0.0)
            onset_sample = cross - half_lag
            onset_t = t0 + onset_sample / sr
            rec["onset_t"] = float(onset_t)
            rec["latency_ms"] = float((onset_t - p) * 1000.0)
        out.append(rec)
    return out


def summarise(tones: list, n_played: int, min_detected: int = MIN_DETECTED) -> dict:
    """Median and spread of the per-tone latencies, robust outlier removal, Chinese verdict."""
    lat = np.array([r["latency_ms"] for r in tones if r.get("latency_ms") is not None], float)
    res = {"ok": False, "n_played": int(n_played), "n_detected": int(len(lat)), "n_used": 0,
           "median_ms": None, "iqr_ms": None, "q25_ms": None, "q75_ms": None, "latencies_ms": [],
           "message": "", "note": UPPER_BOUND_NOTE, "kind": "upper_bound"}
    if len(lat):
        med = float(np.median(lat))
        mad = float(np.median(np.abs(lat - med))) * 1.4826
        keep = np.abs(lat - med) <= max(25.0, 5.0 * mad)
        lat = lat[keep]
        res["n_outliers"] = int((~keep).sum())
    res["n_used"] = int(len(lat))
    res["latencies_ms"] = [round(float(v), 2) for v in lat]
    if len(lat) < min_detected:
        res["reason"] = "too_few"
        res["message"] = (f"只测到 {len(lat)} 声（一共播放了 {n_played} 声，至少要测到 {min_detected} 声）。"
                          "常见原因：扬声器静音或音量太小、麦克风被关掉或选错了、戴着耳机（麦克风听不到）、"
                          "周围太吵。把音量调大、摘下耳机、选对麦克风后再测一次。这次的结果没有保存。")
        return res
    q25, med, q75 = (float(v) for v in np.percentile(lat, [25, 50, 75]))
    res.update(median_ms=round(med, 2), q25_ms=round(q25, 2), q75_ms=round(q75, 2), iqr_ms=round(q75 - q25, 2),
               min_ms=round(float(lat.min()), 2), max_ms=round(float(lat.max()), 2))
    if med < -5.0:
        res["reason"] = "negative"
        res["message"] = ("测出来声音比程序发出还早，说明计时出了问题（可能是电脑太忙）。这次的结果没有保存，"
                          "关掉别的程序后再测一次。")
        return res
    if q75 - q25 > MAX_IQR_MS:
        res["reason"] = "unstable"
        res["message"] = (f"延迟忽快忽慢（中间一半相差 {q75 - q25:.0f} 毫秒，超过 {MAX_IQR_MS:.0f} 毫秒），"
                          "可能是环境里有别的声音或电脑太忙。这次的结果没有保存，安静下来再测一次。")
        return res
    res["ok"] = True
    res["reason"] = ""
    res["message"] = (f"声音从程序发出到麦克风收到约 {med:.0f} 毫秒（中间一半在 {q25:.0f}–{q75:.0f} 毫秒之间，"
                      f"{len(lat)}/{n_played} 声测到）。以后做听觉 P300 时，分析会按这个数校正刺激时间。")
    return res


def analyse_capture(chunks, play_times, sr: float = CAP_SR, freq: float | None = None, dur: float | None = None,
                    min_detected: int = MIN_DETECTED) -> dict:
    """Whole pipeline on captured buffers: clock -> onsets -> summary. chunks = [(t_read_perf, samples)]."""
    if freq is None or dur is None:
        f0, d0 = tone_params()
        freq = f0 if freq is None else freq
        dur = d0 if dur is None else dur
    x, t0 = sample_clock(chunks, sr)
    tones = detect_tones(x, sr, t0, list(play_times), freq, dur)
    res = summarise(tones, len(play_times), min_detected)
    res["tones"] = [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items() if k != "onset_t"}
                    for r in tones]
    res["sr"] = float(sr)
    res["capture_s"] = round(len(x) / sr, 2) if sr else 0.0
    res["freq_hz"] = float(freq)
    ck = clock_check(chunks, sr)
    res["clock"] = ck
    if not ck["ok"]:
        res["ok"] = False
        res["reason"] = "clock"
        if ck["split_ms"] is not None and ck["split_ms"] > MAX_CLOCK_SPLIT_MS:
            why = f"前后两半的录音时钟差了 {ck['split_ms']:.1f} 毫秒（最多允许 {MAX_CLOCK_SPLIT_MS:.0f} 毫秒）"
        else:
            why = (f"只收到应有声音样本的 {100 * (ck['ratio'] or 0):.0f}%"
                   f"（至少要 {100 * MIN_RECEIVED_RATIO:.0f}%）")
        res["message"] = (f"录音中途丢了一些声音样本：{why}。丢样本会让测出的延迟偏小，这次的结果没有保存。"
                          "常见原因是电脑太忙或麦克风驱动卡顿，关掉别的程序后再测一次。")
    return res


# ============================================================================ store
def store_path(root: Path | None = None) -> Path:
    if root is None:
        from .paths import ROOT
        root = ROOT
    return Path(root) / "models" / STORE_NAME


def device_key(output: str, inp: str) -> str:
    return f"{output or '默认输出'} | {inp or '默认输入'}"


def entry_ms(entry) -> float | None:
    """The entry's median_ms as a finite float, or None (entry not a dict, value missing, bool, text, NaN...)."""
    if not isinstance(entry, dict):
        return None
    v = entry.get("median_ms")
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    v = float(v)
    return v if np.isfinite(v) else None


def in_apply_range(ms) -> bool:
    return ms is not None and APPLY_RANGE_MS[0] <= float(ms) <= APPLY_RANGE_MS[1]


def _valid_entry(d) -> bool:
    return isinstance(d, dict) and entry_ms(d) is not None


def load_store(root: Path | None = None) -> dict:
    """The store dict. Corrupt files read as empty; corrupt entries stay in "devices" (lookup skips them)."""
    p = store_path(root)
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(d, dict) and isinstance(d.get("devices"), dict):
            return d
    except (OSError, ValueError):
        pass
    return {"version": 1, "devices": {}}


def save_result(output: str, inp: str, res: dict, root: Path | None = None) -> dict:
    """Store a successful calibration under 'output | input' (latest wins, 5 past results kept). Returns the entry."""
    if not res.get("ok"):
        raise ValueError("only successful calibrations are stored")
    st = load_store(root)
    key = device_key(output, inp)
    old = st["devices"].get(key)
    old = old if isinstance(old, dict) else {}
    hist = old.get("history")
    hist = [h for h in hist if isinstance(h, dict)] if isinstance(hist, list) else []
    if entry_ms(old) is not None:
        hist.append({k: old.get(k) for k in ("date", "median_ms", "iqr_ms", "n_used")})
    entry = {"output": output, "input": inp, "date": datetime.now().isoformat(timespec="seconds"),
             "median_ms": res["median_ms"], "iqr_ms": res["iqr_ms"], "q25_ms": res["q25_ms"], "q75_ms": res["q75_ms"],
             "n_used": res["n_used"], "n_played": res["n_played"], "kind": res.get("kind", "upper_bound"),
             "note": res.get("note", UPPER_BOUND_NOTE), "history": hist[-5:]}
    st["devices"][key] = entry
    p = store_path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, p)
    return entry


def lookup(output: str | None = None, inp: str | None = None, root: Path | None = None) -> dict | None:
    """Latest stored calibration for this output device (any microphone unless inp is given).
    output=None: only when exactly one output device was ever calibrated, its latest entry
    (with "guessed": True; for display only, erp.analyse never applies a guess), else None.
    Corrupt entries (not a dict, median_ms not a finite number) are skipped."""
    devs = [d for d in load_store(root)["devices"].values() if _valid_entry(d)]
    if output is not None:
        devs = [d for d in devs if d.get("output") == output]
        if inp is not None:
            devs = [d for d in devs if d.get("input") == inp]
    else:
        if len({str(d.get("output")) for d in devs}) != 1:
            return None
    if not devs:
        return None
    best = dict(max(devs, key=lambda d: str(d.get("date", ""))))
    best.pop("history", None)
    if output is None:
        best["guessed"] = True
    return best


def describe(entry: dict | None) -> str:
    """One Chinese line for the ERP page (corrupt or out-of-range entries read as not calibrated)."""
    ms = entry_ms(entry)
    if ms is None:
        return "声音延迟：未校准（分析时不做校正）。"
    if not in_apply_range(ms):
        return (f"声音延迟：存的数 {ms:.0f} 毫秒不在 {APPLY_RANGE_MS[0]:.0f}–{APPLY_RANGE_MS[1]:.0f} 毫秒之内，"
                "分析时不会用它，请重新测一次。")
    return (f"声音延迟：{ms:.0f} 毫秒（{str(entry.get('date', ''))[:10]} 测，"
            f"扬声器「{entry.get('output', '')}」→ 麦克风「{entry.get('input', '')}」，上限值）。")


# ============================================================================ Qt side
def default_output_name() -> str:
    try:
        from PyQt6.QtMultimedia import QMediaDevices
        return QMediaDevices.defaultAudioOutput().description()
    except Exception:  # noqa: BLE001
        return ""


def input_devices() -> list:
    """[(QAudioDevice, name)] microphones; listing does not open any of them."""
    try:
        from PyQt6.QtMultimedia import QMediaDevices
        return [(d, d.description()) for d in QMediaDevices.audioInputs()]
    except Exception:  # noqa: BLE001
        return []


def unique_labels(names) -> list:
    """Chooser labels for device names: a name shared by several inputs gets （2）, （3）… on its later copies
    (labels never collide with another device's real name), so a label maps back to exactly one index."""
    names = [str(n or "麦克风") for n in names]
    out, used = [], set(names)
    seen = {}
    for n in names:
        k = seen.get(n, 0) + 1
        seen[n] = k
        if k == 1:
            out.append(n)
            continue
        lab = f"{n}（{k}）"
        while lab in used:
            k += 1
            lab = f"{n}（{k}）"
        used.add(lab)
        out.append(lab)
    return out


def default_input_index(mics, default=None) -> int:
    """Index of the system default microphone in input_devices() (matched by device id, then by name); 0 if absent."""
    if default is None:
        try:
            from PyQt6.QtMultimedia import QMediaDevices
            default = QMediaDevices.defaultAudioInput()
        except Exception:  # noqa: BLE001
            return 0
    try:
        did = bytes(default.id())
        if did:
            for i, (dev, _n) in enumerate(mics):
                try:
                    if bytes(dev.id()) == did:
                        return i
                except Exception:  # noqa: BLE001
                    pass
    except Exception:  # noqa: BLE001
        pass
    try:
        dn = default.description()
    except Exception:  # noqa: BLE001
        return 0
    for i, (_dev, n) in enumerate(mics):
        if n == dn:
            return i
    return 0


class QtMicSource:
    """QAudioSource on one input device, pull mode. Interface used by LatencyCalibrator:
    start() -> QIODevice-like (readyRead signal, readAll()), stop(), name, sample_rate, sample_format, channels."""

    def __init__(self, device=None):
        from PyQt6.QtMultimedia import QAudioFormat, QMediaDevices
        self.device = device if device is not None else QMediaDevices.defaultAudioInput()
        self.name = self.device.description()
        fmt = QAudioFormat()
        fmt.setSampleRate(CAP_SR)
        fmt.setChannelCount(1)
        fmt.setSampleFormat(QAudioFormat.SampleFormat.Int16)
        if not self.device.isFormatSupported(fmt):
            fmt = self.device.preferredFormat()
        self.fmt = fmt
        self.sample_rate = float(fmt.sampleRate())
        self.channels = int(fmt.channelCount())
        sf = fmt.sampleFormat()
        S = QAudioFormat.SampleFormat
        self.sample_format = {S.Int16: "int16", S.Int32: "int32", S.Float: "float32", S.UInt8: "uint8"}.get(sf, "int16")
        self.src = None

    def start(self):
        from PyQt6.QtMultimedia import QAudioSource
        self.src = QAudioSource(self.device, self.fmt)
        bps = {"int16": 2, "int32": 4, "float32": 4, "uint8": 1}[self.sample_format] * self.channels
        self.src.setBufferSize(int(self.sample_rate * 0.04) * bps)       # ~40 ms buffers: tight time stamps
        return self.src.start()

    def stop(self):
        if self.src is not None:
            self.src.stop()
            self.src = None


class SoundEffectPlayer:
    """Plays the ERP standard tone like page_erp: preloaded QSoundEffect + a silent loop keeping the device awake."""

    def __init__(self, parent=None, volume: float = 0.6):
        self.parent, self.volume = parent, volume
        self.fx = {}
        self.output_name = default_output_name()

    def prepare(self):
        from PyQt6.QtCore import QUrl
        from PyQt6.QtMultimedia import QSoundEffect
        from .erp import ensure_tones
        files = ensure_tones()
        muted = bool(os.environ.get("NB_MUTE"))
        for k in ("standard", "silence"):
            e = QSoundEffect(self.parent)
            e.setSource(QUrl.fromLocalFile(str(files[k])))
            e.setVolume(0.0 if muted else (self.volume if k == "standard" else 0.01))
            self.fx[k] = e
        self.fx["silence"].setLoopCount(QSoundEffect.Loop.Infinite.value)
        self.fx["silence"].play()

    def ready(self) -> bool:
        from PyQt6.QtMultimedia import QSoundEffect
        e = self.fx.get("standard")
        return e is not None and e.status() == QSoundEffect.Status.Ready

    def play(self):
        self.fx["standard"].play()

    def stop(self):
        for e in self.fx.values():
            try:
                e.stop()
            except Exception:  # noqa: BLE001
                pass
        self.fx = {}


try:
    from PyQt6.QtCore import QObject, Qt, QTimer, pyqtSignal
except Exception:  # noqa: BLE001  (headless use without PyQt6: pure functions still work)
    QObject = object
    Qt = QTimer = pyqtSignal = None


if QTimer is not None:
    class LatencyCalibrator(QObject):
        """One calibration run (~20 s). Emits progress(played, total) and done(result dict).

        source: QtMicSource-like (default: QtMicSource(input_device)); player: SoundEffectPlayer-like.
        The result has the summarise() keys plus output, input, date, saved (bool), cancelled (bool)."""

        progress = pyqtSignal(int, int)
        done = pyqtSignal(dict)

        def __init__(self, parent=None, input_device=None, source=None, player=None, n_tones: int = N_TONES,
                     seed=None, save: bool = True, root: Path | None = None, isi=ISI, warmup_s: float = WARMUP_S):
            super().__init__(parent)
            self._input_device = input_device
            self.source, self.player = source, player
            self.n_tones, self.save, self.root = int(n_tones), save, root
            self.isi, self.warmup_s = isi, warmup_s
            self.rng = np.random.default_rng(seed)
            self.chunks, self.play_times = [], []
            self.dev = None
            self._left = b""
            self._wait = 0
            self.running = False
            self.result = None
            self.t_next = QTimer(self)
            self.t_next.setSingleShot(True)
            self.t_next.setTimerType(Qt.TimerType.PreciseTimer)
            self.t_next.timeout.connect(self._next)
            self.t_poll = QTimer(self)                   # fallback drain if readyRead is sparse
            self.t_poll.setInterval(100)
            self.t_poll.timeout.connect(self._drain)

        def start(self) -> bool:
            if self.running:
                return False
            try:
                if self.source is None:
                    self.source = QtMicSource(self._input_device)
                if self.player is None:
                    self.player = SoundEffectPlayer(self)
                self.player.prepare()
                self.dev = self.source.start()
            except Exception as e:  # noqa: BLE001
                self._emit({"ok": False, "reason": "device", "n_played": 0, "n_detected": 0,
                            "message": f"打不开麦克风或扬声器：{type(e).__name__}: {e}"})
                return False
            if self.dev is None:
                self._emit({"ok": False, "reason": "device", "n_played": 0, "n_detected": 0,
                            "message": "麦克风没能开始录音（可能被别的程序占用，或系统隐私设置不允许）。"})
                return False
            self.running = True
            self.dev.readyRead.connect(self._drain)
            self.t_poll.start()
            self.t_next.start(int(self.warmup_s * 1000))
            return True

        def cancel(self):
            if self.running:
                self._stop_all()
                self._emit({"ok": False, "reason": "cancelled", "cancelled": True, "n_played": len(self.play_times),
                            "n_detected": 0, "message": "测量已取消。"})

        # ---------------------------------------------------------------- internals
        def _drain(self):
            if self.dev is None:
                return
            data = self.dev.readAll()
            t = time.perf_counter()
            raw = self._left + bytes(data)
            if not raw:
                return
            bps = {"int16": 2, "int32": 4, "float32": 4, "uint8": 1}[self.source.sample_format] * self.source.channels
            n = (len(raw) // bps) * bps
            self._left = raw[n:]
            if n:
                self.chunks.append((t, to_float(raw[:n], self.source.sample_format, self.source.channels)))

        def _next(self):
            if not self.running:
                return
            if len(self.play_times) >= self.n_tones:
                self._finish()
                return
            if not self.player.ready():
                self._wait += 1
                if self._wait > 30:                       # 3 s and the tone still is not loaded
                    self._stop_all()
                    self._emit({"ok": False, "reason": "device", "n_played": 0, "n_detected": 0,
                                "message": "提示音没能加载，无法测量。"})
                    return
                self.t_next.start(100)
                return
            self.player.play()
            self.play_times.append(time.perf_counter())   # same moment page_erp writes its marker
            self.progress.emit(len(self.play_times), self.n_tones)
            if len(self.play_times) >= self.n_tones:
                self.t_next.start(int(TAIL_S * 1000))
            else:
                self.t_next.start(int(round(self.rng.uniform(*self.isi) * 1000)))

        def _stop_all(self):
            self.running = False
            self.t_next.stop()
            self.t_poll.stop()
            try:
                self._drain()
            except Exception:  # noqa: BLE001
                pass
            for f in (self.source.stop, self.player.stop):
                try:
                    f()
                except Exception:  # noqa: BLE001
                    pass
            self.dev = None

        def _finish(self):
            self._stop_all()
            res = analyse_capture(self.chunks, self.play_times, self.source.sample_rate)
            self.chunks = []                              # audio only ever lived in memory; drop it now
            self._emit(res)

        def _emit(self, res: dict):
            res.setdefault("cancelled", False)
            res["output"] = getattr(self.player, "output_name", "") if self.player is not None else ""
            res["input"] = getattr(self.source, "name", "") if self.source is not None else ""
            res["date"] = datetime.now().isoformat(timespec="seconds")
            res["saved"] = False
            if res.get("ok") and self.save:
                try:
                    save_result(res["output"], res["input"], res, self.root)
                    res["saved"] = True
                except OSError as e:
                    res["save_error"] = str(e)
            self.result = res
            self.done.emit(res)
