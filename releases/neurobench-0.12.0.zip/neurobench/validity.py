"""Metric validity check (round 4): does each number the app shows actually follow what it claims to, on you?

Works on a recording made with the protocol 「指标校验」 (eyes open, eyes closed, mental arithmetic, jaw clench,
frown, left-right eye movement, fast blinking, eyes closed again). Every metric is computed on 2 s epochs the
way the app computes it (the training metrics exactly as page_train.nf_metric does), and checked in three steps:

  manipulation  did the person actually do the artifact steps? Jaw clench must raise EMG (dsp.emg_rms) on every
                sensor, frowning the forehead EMG (AF7/AF8), looking left-right the horizontal-EOG slow power
                (AF7 - AF8, 0.3-4 Hz), each by Cohen's d >= 1 against eyes open. A step that was not done cannot
                test anything: metrics whose robustness depends on it are "unknown".
  robustness    what the app would still show during those steps: the mean of the epochs the app's own skip rule
                does NOT flag, minus the eyes-open mean (unflagged epochs), in units of the robust eyes-open SD
                (1.4826 x MAD). It must stay <= lim + 1.28 se (one-sided 90 %), lim = 0.5 robust SD, or half the
                sensitivity d when the required sensitivity test passed and d < 1. se^2 = 1/max(n_kept, 8) + 1/n_ref
                + tau^2: tau^2 is the slow drift between blocks of the same condition, estimated per recording from
                闭眼 vs 再闭眼 (minutes apart), 0.5 when it cannot be estimated, at most 1. RMSSD windows overlap
                (15 s every 4 s), so its n counts as n x 4/15. The skip rule is the trainer's live rule
                (page_train.nf_metric) for alpha_ear / theta_beta / theta_beta_ear (EMG of the last 1 s above the
                calibrated 6-15 uV limit, motion > 12 deg/s, blink cover > 50 %, a channel at quality level 0; the
                'artifact' class is level 1 and is scored) and the review page's epoch tags (or the calm score's
                own rule) otherwise.
  sensitivity   where an effect is expected (alpha rises with closed eyes, blink rate with blinking, the calm
                score is lower with closed eyes than open): Cohen's d over unflagged epochs, bootstrap 95 % CI.

Verdict "ok" = the manipulations were done, the metric is robust AND its required sensitivity test passed.
Metrics without a required sensitivity test (theta_beta, theta_beta_ear, faa, rmssd) are at best "warn"
("只验证了抗干扰", robust=True). A run without all artifact steps and the final 再闭眼 is "incomplete": every
metric "unknown" and nothing is kept in the history. Results are kept per person in
<ROOT>/models/validity_<pid>.json (latest first; only for a valid person id, and never for simulated or replayed
recordings); status(metric) is what the other pages read.
"""

from __future__ import annotations

import html
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from . import dsp

PROTOCOL = "指标校验"
PREFIX = "校验·"
SEG_OPEN, SEG_CLOSED, SEG_MATH = "校验·睁眼", "校验·闭眼", "校验·心算"
SEG_CLENCH, SEG_FROWN, SEG_LOOK = "校验·咬牙", "校验·皱眉", "校验·左右看"
SEG_BLINK, SEG_CLOSED2 = "校验·眨眼", "校验·再闭眼"
ARTIFACT_SEGS = (SEG_CLENCH, SEG_FROWN, SEG_LOOK)
REST_SEGS = (SEG_OPEN, SEG_CLOSED, SEG_MATH, SEG_CLOSED2)
REQUIRED_SEGS = (SEG_CLENCH, SEG_FROWN, SEG_LOOK, SEG_CLOSED2)   # missing one -> the run is incomplete
MIN_STEP_EPOCHS = 3

EPOCH_S = 2.0
SETTLE_S = 3.0          # skip the first seconds of every step: voice prompt, closing / opening the eyes
MIN_EPOCHS = 5
SHIFT_MAX = 0.5         # unflagged shift / robust eyes-open SD must stay at or below this
Z_ONE = 1.28            # one-sided 90 % sampling allowance (in standard errors)
N_KEPT_MIN = 8          # 1/n_kept term of the standard error never uses fewer epochs than this
TAU2_DEFAULT = 0.5      # block-to-block drift (in SD^2) when 闭眼 vs 再闭眼 cannot estimate it
TAU2_MAX = 1.0
NOT_REAL = ("sim", "replay")    # checklist.NOT_REAL: simulated / replayed recordings are never kept
D_MIN = 0.5             # minimum effect size for "sensitive"
MANIP_D = 1.0           # minimum effect size of a manipulation check
N_BOOT = 2000
STALE_DAYS = 30
STALE_NOTE = "（校验已超过 30 天，建议重做）"
EMG_LIMIT = 0.30        # session.EMG_LIMIT (offline epoch tag)
CALM_EMG_SKIP = 0.35    # page_meditate.busy_raw skip rule
MOTION_LIMIT = 5.0      # session.MOTION_LIMIT
# page_train live skip rule
NF_EMG_ABS = 10.0       # page_train.EMG_ABS (before calibration)
NF_EMG_LO, NF_EMG_HI = 6.0, 15.0    # calibrated limit = 3 x eyes-open median, clipped
NF_MOTION = 12.0        # page_train.MOTION_LIMIT
NF_BLINK_COVER = 0.5    # skip when more than half of the 2 s window is blink samples
NF_BUF_S = 3.0          # page_train.nf_metric filters and blink-detects hub.latest("EEG", 3.0)
FLAT_RSD = 0.05         # uV; an electrode this quiet is not measuring anything
HRV_WIN, HRV_STEP = 15.0, 4.0   # s; 2 s epochs are too short for RMSSD

METRICS = {
    "alpha": "α 相对功率（全部电极）",
    "alpha_ear": "耳后 α 相对功率",
    "theta_beta": "θ/β 专注指标（全部电极）",
    "theta_beta_ear": "耳后 θ/β",
    "calm": "冥想平静度（脑电）",
    "faa": "前额 α 不对称",
    "blink_rate": "眨眼频率",
    "rmssd": "心率变异 RMSSD",
}
TRAIN_CHANS = {"alpha_ear": (0, 3), "theta_beta": (0, 1, 2, 3), "theta_beta_ear": (0, 3)}   # page_train.PROTOCOLS
# floor for the robust eyes-open SD, so a near-constant baseline does not turn tiny moves into huge "shifts"
# (blink rate per 2 s epoch is 0 or 30 /min most of the time, so its MAD is often 0)
SD_FLOOR = {"alpha": 0.01, "alpha_ear": 0.01, "theta_beta": 0.05, "theta_beta_ear": 0.05, "calm": 0.05,
            "faa": 0.05, "blink_rate": 15.0, "rmssd": 4.0}
# effective number of independent values per row (RMSSD windows overlap: 15 s every 4 s)
N_EFF = {k: 1.0 for k in ("alpha", "alpha_ear", "theta_beta", "theta_beta_ear", "calm", "faa", "blink_rate")}
N_EFF["rmssd"] = HRV_STEP / HRV_WIN
CALM_OK = "能反映闭眼放松时的变化（还没验证冥想时的平静程度）"
# (condition, reference, expected sign of condition - reference or None = report only, Chinese description)
SENS_TESTS = {
    "alpha": [((SEG_CLOSED, SEG_CLOSED2), (SEG_OPEN,), +1, "闭眼比睁眼高")],
    "alpha_ear": [((SEG_CLOSED, SEG_CLOSED2), (SEG_OPEN,), +1, "闭眼比睁眼高")],
    "theta_beta": [((SEG_MATH,), (SEG_CLOSED,), None, "心算对比闭眼")],
    "theta_beta_ear": [((SEG_MATH,), (SEG_CLOSED,), None, "心算对比闭眼")],
    "calm": [((SEG_CLOSED, SEG_CLOSED2), (SEG_OPEN,), -1, "闭眼时比睁眼更平静")],
    "faa": [],
    "blink_rate": [((SEG_BLINK,), (SEG_OPEN,), +1, "快速眨眼时比睁眼高")],
    "rmssd": [],
}
# what a metric without a required sensitivity test still has no evidence for
CLAIM = {"theta_beta": "专注程度", "theta_beta_ear": "专注程度", "faa": "情绪或动机倾向",
         "rmssd": "放松程度（副交感神经活动）"}
# artifact steps each metric's robustness is tested on (PPG does not see eye movements)
ROB_STEPS = {k: ARTIFACT_SEGS for k in METRICS}
ROB_STEPS["rmssd"] = (SEG_CLENCH, SEG_FROWN)
SHORT = {s: s.replace(PREFIX, "") for s in (SEG_OPEN, SEG_CLOSED, SEG_MATH, SEG_CLENCH, SEG_FROWN, SEG_LOOK,
                                           SEG_BLINK, SEG_CLOSED2)}
MANIP_DESC = {SEG_CLENCH: "咬牙时所有电极的肌电升高", SEG_FROWN: "皱眉时前额（AF7/AF8）肌电升高",
              SEG_LOOK: "左右看时水平眼动信号（AF7−AF8，0.3–4 Hz）升高"}
MANIP_FAIL = {SEG_CLENCH: "咬牙时肌电没有明显升高", SEG_FROWN: "皱眉时前额肌电没有明显升高",
              SEG_LOOK: "左右看时没有明显的水平眼动"}


# ============================================================================ storage
def _models_dir() -> Path:
    from .paths import ROOT
    return ROOT / "models"


def _file(pid: str) -> Path:
    return _models_dir() / f"validity_{pid}.json"


def _pid(pid=None) -> str:
    if pid:
        return pid
    from . import people as P
    return P.current()


def _parse_date(v) -> datetime | None:
    """ISO date -> naive local datetime (timezone-aware ones are converted); None when unreadable."""
    if not isinstance(v, str) or not v:
        return None
    try:
        dt = datetime.fromisoformat(v.strip().replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if dt.tzinfo is not None:
        try:
            dt = dt.astimezone().replace(tzinfo=None)
        except (OverflowError, OSError, ValueError):
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


def _sort_key(e: dict) -> float:
    dt = _parse_date(e.get("date"))
    try:
        return dt.timestamp() if dt else float("-inf")
    except (OverflowError, OSError, ValueError):
        return float("-inf")


def _valid_pid(pid) -> bool:
    from . import people as P
    return isinstance(pid, str) and P.valid_id(pid)


def history(pid=None) -> list:
    """All saved checks of a person, latest first. A corrupt file or malformed entries count as no history;
    an id that is not a valid person id (people.valid_id) has none (it never names a file)."""
    try:
        p = _pid(pid)
        if not _valid_pid(p):
            return []
        d = json.loads(_file(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []
    h = d.get("history") if isinstance(d, dict) else None
    if not isinstance(h, list):
        return []
    h = [e for e in h if isinstance(e, dict) and isinstance(e.get("metrics", {}), dict)]
    return sorted(h, key=_sort_key, reverse=True)


def latest(pid=None) -> dict | None:
    """The most recent check of a person: {date, session, metrics: {key: {state, why, ...}}, ...} or None."""
    h = history(pid)
    return h[0] if h else None


def age_days(entry: dict | None) -> float | None:
    if not isinstance(entry, dict):
        return None
    dt = _parse_date(entry.get("date"))
    if dt is None:
        return None
    return (datetime.now() - dt).total_seconds() / 86400.0


def status(metric: str, pid=None) -> dict:
    """{"state": "ok"|"warn"|"unknown", "why": str, "date": str, "stale": bool, "robust": bool|None,
    "sens_required": bool|None} from the latest check. An "ok" older than 30 days comes back as "warn" (with a note appended)."""
    try:
        e = latest(pid)
    except Exception:  # noqa: BLE001
        e = None
    if not e:
        return {"state": "unknown", "why": "还没做过指标校验", "date": "", "stale": False, "robust": None,
                "sens_required": None}
    date = str(e.get("date") or "")
    m = (e.get("metrics") or {}).get(metric)
    if not isinstance(m, dict):
        return {"state": "unknown", "why": "上次校验没有这个指标", "date": date, "stale": False, "robust": None,
                "sens_required": None}
    a = age_days(e)
    stale = a is not None and a > STALE_DAYS
    st = m.get("state") if m.get("state") in ("ok", "warn", "unknown") else "unknown"
    why = str(m.get("why") or "")
    if st == "ok" and stale:
        st, why = "warn", why + STALE_NOTE
    rob, sr = m.get("robust"), m.get("sens_required")
    lab = m.get("label") if isinstance(m.get("label"), str) else ""
    return {"state": st, "why": why, "date": date, "stale": stale, "robust": rob if isinstance(rob, bool) else None,
            "sens_required": sr if isinstance(sr, bool) else None, "label": lab if st == "ok" else ""}


def _persist(res: dict, pid: str) -> bool:
    """Add the result to the person's history; False (nothing written) for an id that is not a valid person id."""
    if not _valid_pid(pid):
        return False
    f = _file(pid)
    f.parent.mkdir(parents=True, exist_ok=True)
    h = [e for e in history(pid) if e.get("session") != res["session"]]
    entry = {"date": res["date"], "session": res["session"], "saved_at": datetime.now().isoformat(timespec="seconds"),
             "metrics": {k: {"state": m["state"], "why": m["why"], "d": m.get("d"), "worst_shift": m.get("worst_shift"),
                             "robust": m.get("robust"), "sens_required": m.get("sens_required"),
                             **({"label": m["label"]} if m.get("label") else {})}
                         for k, m in res["metrics"].items()},
             "manipulation": {SHORT[k]: v.get("ok") for k, v in res.get("manipulation", {}).items()},
             "contact": {c: v["text"] for c, v in res.get("contact", {}).items()}}
    h.insert(0, entry)
    h.sort(key=_sort_key, reverse=True)
    tmp = f.with_name(f.name + ".part")
    tmp.write_text(json.dumps({"person": pid, "history": h[:50]}, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)
    return True


# ============================================================================ statistics
def cohen_d(a, b) -> float:
    """Effect size of b relative to a: (mean b - mean a) / pooled sd."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    sp = math.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
    return float((b.mean() - a.mean()) / sp) if sp > 0 else float("nan")


def boot_d(a, b, n_boot: int = N_BOOT, seed: int = 0):
    """Bootstrap 95 % CI of cohen_d(a, b) (each group resampled independently)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    A = a[rng.integers(0, na, (n_boot, na))]
    B = b[rng.integers(0, nb, (n_boot, nb))]
    sp = np.sqrt(((na - 1) * A.var(axis=1, ddof=1) + (nb - 1) * B.var(axis=1, ddof=1)) / (na + nb - 2))
    with np.errstate(divide="ignore", invalid="ignore"):
        d = (B.mean(axis=1) - A.mean(axis=1)) / sp
    d = d[np.isfinite(d)]
    if len(d) < n_boot // 2:
        return float("nan"), float("nan")
    return float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))


def robust_sd(v) -> float:
    """1.4826 x median absolute deviation (0 for fewer than 2 values)."""
    v = np.asarray(v, float)
    if len(v) < 2:
        return 0.0
    return 1.4826 * float(np.median(np.abs(v - np.median(v))))


# ============================================================================ loading
def _load(d: Path):
    """Light loader: meta, markers, segments and raw arrays, without session.load_session's per-segment metrics."""
    from . import session as S
    meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
    if not isinstance(meta, dict):
        raise ValueError("session.json is not an object")
    tmp = S.Session(dir=d, meta=meta, data={}, markers=[])
    import csv
    mp = d / "markers.csv"
    if mp.exists():
        with open(mp, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                try:
                    tmp.markers.append({"t": float(r["t"]), "label": r["label"], "kind": r.get("kind", "event")})
                except (ValueError, KeyError, TypeError):
                    pass
    tmp.markers.sort(key=lambda m: m["t"])
    return tmp


def _read_sensor(s, sensor: str):
    from .session import SENSOR_FILES
    p = s.dir / SENSOR_FILES[sensor]
    cols = s.meta.get("channels", {}).get(sensor)
    if not p.exists() or not cols:
        return None
    arr = np.fromfile(p, dtype="<f8")
    n = len(cols)
    arr = arr[: (len(arr) // n) * n].reshape(-1, n)
    if not len(arr):
        return None
    arr = arr[np.argsort(arr[:, 0], kind="stable")]
    return arr[:, 0], arr[:, 1:], cols[1:]


def is_validation(meta: dict, markers: list) -> bool:
    labels = {m["label"] for m in markers if m.get("kind") == "segment"}
    return meta.get("protocol") == PROTOCOL or sum(lab.startswith(PREFIX) for lab in labels) >= 3


def _not_validation(d: Path, why: str) -> dict:
    return {"is_validation": False, "session": d.name, "message": why, "metrics": {}}


# ============================================================================ per-epoch metrics
def _trainer_value(xe, keep, key):
    """page_train.nf_metric on one 2 s epoch (already on the protocol's channels): blink samples dropped."""
    xs = xe[keep] if keep.sum() >= dsp.FS_EEG * 0.25 else xe
    _, absp, _ = dsp.band_powers(xs)
    a = absp.mean(axis=0)                     # delta theta alpha beta gamma
    if key == "alpha_ear":
        return float(a[2] / (a[1] + a[2] + a[3] + 1e-12))
    return float(math.log((a[1] + 1e-12) / (a[3] + 1e-12)))


def _epochs(s, eeg, opt, imu):
    """One row per 2 s epoch of every 校验 step: metric values, the app's own flags and the manipulation
    measures. Returns (rows, contact, n_blinks, emg_limits)."""
    t, X, names = eeg
    X = X[:, [names.index(n) for n in dsp.EEG_NAMES]]
    x = dsp.notch_only(X)
    pk, _ = dsp.detect_blinks(X)
    bm = dsp.blink_mask(len(X), pk)
    heog = dsp.clean_eeg((X[:, 1] - X[:, 2])[:, None], dsp.FS_EEG, 0.3, 4.0)[:, 0]
    W = int(EPOCH_S * dsp.FS_EEG)
    H = W // 2
    from .session import build_segments
    rows, contact = [], []
    ai, ti, bi = dsp.BAND_KEYS.index("alpha"), dsp.BAND_KEYS.index("theta"), dsp.BAND_KEYS.index("beta")
    for seg in build_segments(s):
        if not seg.label.startswith(PREFIX):
            continue
        i0 = int(np.searchsorted(t, seg.t0 + SETTLE_S))
        i1 = int(np.searchsorted(t, seg.t1))
        for k in range((i1 - i0) // W):
            sl = slice(i0 + k * W, i0 + (k + 1) * W)
            if t[sl][-1] - t[sl][0] > EPOCH_S * 1.5:       # a gap in the data inside this epoch
                continue
            xe = x[sl]
            rel, absp, emg = dsp.band_powers(xe)
            feats = dsp.window_features(X[sl], dsp.FS_EEG, bm[sl], span=None)
            cls = [dsp.classify_window(f) for f in feats]
            app_ok = [c != "artifact" and dsp.CLASS_LEVEL[c] > 0 for c in cls]       # dsp.window_quality level > 0
            contact_ok = [c not in ("none", "float") and f["rail"] <= 0.25 for c, f in zip(cls, feats)]
            flat = [bool(f["flat"]) or f["rsd"] < FLAT_RSD for f in feats]
            good = [c for c in range(4) if app_ok[c]]
            use = good or list(range(4))
            mot = float("nan")
            if imu is not None:
                tg, G, _ = imu
                m = (tg >= t[sl][0]) & (tg < t[sl][-1])
                if m.sum() > 10:
                    mot = dsp.motion_level(G[m, 3:6])
            # the offline epoch tag of session.segment_metrics
            tag = ""
            if len(good) < 3:
                tag = "contact"
            elif bm[sl].mean() > 0.05:
                tag = "blink"
            elif float(emg[use].mean()) >= EMG_LIMIT:
                tag = "emg"
            elif mot == mot and mot > MOTION_LIMIT:
                tag = "motion"
            # manipulation measures: absolute EMG per sensor over the 2 s; the trainer's skip rule looks only at
            # the LAST 1 s of its 2 s window (page_train.nf_metric: dsp.emg_rms(x[-FS:]))
            erms = dsp.emg_rms(xe)
            # the trainer's own view of this moment: its 3 s buffer ending here, notch-filtered and blink-detected
            # on that buffer, scored on the last 2 s (page_train.nf_metric)
            j0 = max(0, sl.stop - int(NF_BUF_S * dsp.FS_EEG))
            X3 = X[j0:sl.stop]
            pk3, _ = dsp.detect_blinks(X3)
            keep3 = ~dsp.blink_mask(len(X3), pk3)[-W:]
            x3 = dsp.notch_only(X3)[-W:]
            fs1 = int(dsp.FS_EEG)
            elast = np.maximum(dsp.emg_rms(x3[:fs1]), dsp.emg_rms(x3[-fs1:]))   # = page_train.nf_metric
            r = {"seg": seg.label, "t": float(t[sl][0]), "tag": tag, "cls": cls, "flat": flat,
                 "clean": tag == "" and not any(flat),
                 "emg_rms": [float(v) for v in erms], "heog": float(math.log10(np.mean(heog[sl] ** 2) + 1e-6))}

            def chans(cands):
                """App channels among cands; else channels still on the skin (then the app would not use it)."""
                a = [c for c in cands if app_ok[c] and contact_ok[c]]
                if a:
                    return a, False
                return [c for c in cands if contact_ok[c]], True

            # review-page all-channel alpha
            ch, fb = chans((0, 1, 2, 3))
            r["alpha"] = float(rel[ch, ai].mean()) if ch else float("nan")
            r["alpha_flag"] = bool(tag) or fb or any(flat[c] for c in ch)
            # training metrics: page_train.nf_metric on the protocol's fixed channels. It skips a moment only for a
            # channel at quality level 0 (none / float / poor; 'artifact' is level 1 and still scored), motion,
            # blink cover > 50 % or EMG of the last 1 s; the EMG part needs the calibrated limit, so it is applied
            # after all epochs are known
            keep = ~bm[sl]
            for key, cc in TRAIN_CHANS.items():
                cc = list(cc)
                r[key] = _trainer_value(x3[:, cc], keep3, key)
                r[key + "_emg"] = float(np.max(elast[cc]))
                r[key + "_base_flag"] = bool(any(dsp.CLASS_LEVEL[cls[c]] == 0 for c in cc)
                                             or (mot == mot and mot > NF_MOTION)
                                             or keep3.mean() < 1.0 - NF_BLINK_COVER
                                             or len(X3) < dsp.FS_EEG * 2.5)
            # calm: page_meditate.busy_raw (ear first, blink samples dropped, skip when EMG > 0.35)
            ear = [c for c in (0, 3) if app_ok[c]]
            cu = ear or good or [c for c in range(4) if contact_ok[c]] or [0, 3]
            xs = xe[keep] if keep.mean() >= 0.5 else xe
            _, ab2, emg2 = dsp.band_powers(xs[:, cu])
            a2 = ab2.mean(axis=0)
            r["calm"] = float(math.log((a2[bi] + 1e-9) / (a2[ti] + a2[ai] + 1e-9)))
            r["calm_flag"] = bool(keep.mean() < 0.5 or float(np.mean(emg2)) > CALM_EMG_SKIP or not (ear or good)
                                  or any(flat[c] for c in cu))
            # frontal alpha asymmetry ln AF8 - ln AF7
            if contact_ok[1] and contact_ok[2]:
                r["faa"] = float(np.log(absp[2, ai] + 1e-9) - np.log(absp[1, ai] + 1e-9))
                r["faa_flag"] = bool(tag) or not (app_ok[1] and app_ok[2]) or flat[1] or flat[2]
            else:
                r["faa"], r["faa_flag"] = float("nan"), True
            # blink rate (per minute) of this epoch; blinks themselves are the signal, so no "blink" flag
            nbk = int(np.sum((pk >= sl.start) & (pk < sl.stop)))
            r["blink_rate"] = nbk * 60.0 / EPOCH_S
            r["blink_rate_flag"] = tag in ("contact", "emg", "motion") or flat[0] or flat[3]
            rows.append(r)
            if seg.label in REST_SEGS:
                contact.append((cls, feats))
    # trainer EMG limit: 3 x the eyes-open median (epochs the trainer would score before calibration), 6-15 uV
    limits = {}
    for key in TRAIN_CHANS:
        cal = [r[key + "_emg"] for r in rows if r["seg"] == SEG_OPEN and not r[key + "_base_flag"]
               and r[key + "_emg"] <= NF_EMG_ABS]
        lim = float(np.clip(3.0 * np.median(cal), NF_EMG_LO, NF_EMG_HI)) if cal else NF_EMG_ABS
        limits[key] = lim
        for r in rows:
            r[key + "_flag"] = bool(r[key + "_base_flag"] or r[key + "_emg"] > lim)
    rows += _rmssd_rows(s, opt)
    return rows, contact, len(pk), limits


def _rmssd_rows(s, opt):
    """RMSSD on 15 s windows (4 s step) inside every 校验 step: 2 s is too short for heart-rate variability."""
    if opt is None:
        return []
    t, O, names = opt
    if len(O) < dsp.FS_OPT * 30:
        return []
    ch, _ = dsp.pick_ppg_channel(O, names)
    if ch is None:
        return []
    from .session import build_segments
    out = []
    for seg in build_segments(s):
        if not seg.label.startswith(PREFIX):
            continue
        a = seg.t0 + SETTLE_S
        while a + HRV_WIN <= seg.t1 + 1e-6:
            m = (t >= a) & (t < a + HRV_WIN)
            if m.sum() > dsp.FS_OPT * HRV_WIN * 0.8:
                _, rm = dsp.heart_metrics(O[m, ch], dsp.FS_OPT, min_beats=10)
                if rm == rm:
                    out.append({"seg": seg.label, "t": float(a), "rmssd": float(rm), "rmssd_flag": False})
            a += HRV_STEP
    return out


# ============================================================================ manipulation checks
MANIP_LOG_RISE = {SEG_CLENCH: 0.30, SEG_FROWN: 0.30, SEG_LOOK: 0.60}


def _manipulations(rows: list) -> dict:
    """{step: {"ok": bool, "d": float|None, "desc": str, "fail": str}} for the three artifact steps."""
    eeg = [r for r in rows if "emg_rms" in r]
    ref = [r for r in eeg if r["seg"] == SEG_OPEN]
    out = {}

    def vals(rs, f):
        return np.array([f(r) for r in rs], float)

    measures = {
        SEG_CLENCH: [lambda r, c=c: math.log10(r["emg_rms"][c] + 1e-3) for c in range(4)],
        SEG_FROWN: [lambda r: math.log10((r["emg_rms"][1] + r["emg_rms"][2]) / 2 + 1e-3)],
        SEG_LOOK: [lambda r: r["heog"]],
    }
    for seg, fs in measures.items():
        cond = [r for r in eeg if r["seg"] == seg]
        if len(cond) < MIN_STEP_EPOCHS or len(ref) < MIN_STEP_EPOCHS:
            out[seg] = {"ok": False, "d": None, "desc": MANIP_DESC[seg], "fail": MANIP_FAIL[seg] + "（数据不够）"}
            continue
        ds = [cohen_d(vals(ref, f), vals(cond, f)) for f in fs]
        ds = [d if d == d else -math.inf for d in ds]
        dmin = min(ds)
        # absolute rise of the medians (all measures are log10): EMG amplitude x2 (0.30), HEOG power x4 (0.60)
        need = MANIP_LOG_RISE.get(seg, 0.30)
        # the actions are intermittent (2 s clench / frown every few seconds), so the step's upper quartile is
        # compared with the eyes-open median
        rises = [float(np.percentile(vals(cond, f), 75) - np.median(vals(ref, f))) for f in fs]
        rise = min(rises) if rises else -math.inf
        ok = bool(dmin >= MANIP_D and rise >= need)
        dtxt = (f"d={dmin:.1f}" if math.isfinite(dmin) else "d 算不出") + f"，比睁眼高 {10 ** rise:.1f} 倍" if math.isfinite(rise) else ""
        out[seg] = {"ok": ok, "d": dmin if math.isfinite(dmin) else None, "desc": MANIP_DESC[seg],
                    "fail": "" if ok else f"{MANIP_FAIL[seg]}，{dtxt}"}
    return out


# ============================================================================ verdicts
def _vals(rows, key, segs, unflagged_only=True):
    v = [r[key] for r in rows if key in r and r["seg"] in segs and r[key] == r[key]
         and not (unflagged_only and r.get(key + "_flag"))]
    return np.array(v, float)


def _blank(key: str) -> dict:
    return {"name": METRICS[key], "sensitivity": [], "robustness": [], "state": "unknown", "why": "", "d": None,
            "worst_shift": None, "robust": None, "sens_required": any(t[2] is not None for t in SENS_TESTS[key])}


def _ref_sd(key: str, rows: list, ref) -> float:
    """Robust eyes-open SD (floored). RMSSD windows overlap, so the SD of every 4th window (non-overlapping) is
    also estimated and the larger one used."""
    sd = robust_sd(ref)
    if key == "rmssd":
        step = int(math.ceil(HRV_WIN / HRV_STEP))
        sub = [r[key] for r in rows if r["seg"] == SEG_OPEN and key in r and r[key] == r[key]
               and not r.get(key + "_flag")][::step]
        if len(sub) >= 3:
            sd = max(sd, float(np.std(sub, ddof=1)))
    return max(sd, SD_FLOOR[key])


def _tau2(key: str, rows: list) -> tuple:
    """Block-to-block drift of the metric in SD^2 units: 闭眼 vs 再闭眼 are the same condition minutes apart, so
    their difference beyond sampling noise is slow drift the artifact-step comparison also suffers from.
    tau^2 = max(0, diff^2 - (1/n1 + 1/n2)) / 2 (diff in units of their pooled robust SD), capped at TAU2_MAX.
    Returns (tau2, estimated: bool)."""
    a, b = _vals(rows, key, (SEG_CLOSED,)), _vals(rows, key, (SEG_CLOSED2,))
    if len(a) < MIN_EPOCHS or len(b) < MIN_EPOCHS:
        return TAU2_DEFAULT, False
    sd = max(robust_sd(np.concatenate([a - np.median(a), b - np.median(b)])), SD_FLOOR[key])
    f = N_EFF[key]
    diff = (float(a.mean()) - float(b.mean())) / sd
    t2 = max(0.0, diff * diff - (1.0 / (f * len(a)) + 1.0 / (f * len(b)))) / 2.0
    return float(min(t2, TAU2_MAX)), True


def _metric_result(key: str, rows: list, manip: dict | None = None) -> dict:
    out = _blank(key)
    manip = manip or {}
    # eyes-open reference: unflagged epochs only (what the app would show)
    ref = _vals(rows, key, (SEG_OPEN,))
    if len(ref) < MIN_EPOCHS:
        out["why"] = ("这次录制没有光学心率数据" if key == "rmssd" and not any("rmssd" in r for r in rows)
                      else f"睁眼段干净数据太少（{len(ref)} 段），算不了")
        return out
    mu = float(ref.mean())
    rsd_raw = robust_sd(ref)
    sd = _ref_sd(key, rows, ref)
    out.update(open_mean=mu, open_sd=sd, open_rsd_raw=rsd_raw, open_n=int(len(ref)))
    # ---- sensitivity (unflagged epochs only)
    sens_ok = None
    for cond, base, sign, desc in SENS_TESTS[key]:
        a, b = _vals(rows, key, base), _vals(rows, key, cond)
        if len(a) < MIN_EPOCHS or len(b) < MIN_EPOCHS:
            out["sensitivity"].append({"desc": desc, "cond": [SHORT[c] for c in cond], "ref": [SHORT[c] for c in base],
                                       "d": None, "ci": None, "n": [int(len(b)), int(len(a))], "expect": sign,
                                       "passed": None if sign is None else False})
            if sign is not None:
                sens_ok = False
            continue
        dd = cohen_d(a, b)
        lo, hi = boot_d(a, b, seed=sum(map(ord, key)))
        passed = None
        if sign is not None:
            passed = bool(dd == dd and sign * dd >= D_MIN and ((sign > 0 and lo > 0) or (sign < 0 and hi < 0)))
            sens_ok = passed if sens_ok is None else (sens_ok and passed)
            if out["d"] is None:
                out["d"] = round(dd, 2) if dd == dd else None
        out["sensitivity"].append({"desc": desc, "cond": [SHORT[c] for c in cond], "ref": [SHORT[c] for c in base],
                                   "d": dd, "ci": [lo, hi], "n": [int(len(b)), int(len(a))], "expect": sign,
                                   "mean_cond": float(b.mean()), "mean_ref": float(a.mean()), "passed": passed})
    out["sens_ok"] = sens_ok
    # ---- robustness: what the app would still show during the artifact steps
    # the limit only tightens to half the sensitivity d when that test passed (a failed d says nothing)
    lim = SHIFT_MAX
    if sens_ok and out["d"] is not None and out["d"] == out["d"]:
        lim = min(SHIFT_MAX, abs(out["d"]) / 2.0)
    out["shift_limit"] = lim
    tau2, tau_est = _tau2(key, rows)
    out["tau2"], out["tau2_estimated"] = tau2, tau_est
    f = N_EFF[key]
    rob, nodata = [], []
    for seg in ROB_STEPS[key]:
        sel = [r for r in rows if r["seg"] == seg and key in r and r[key] == r[key]]
        if len(sel) < MIN_STEP_EPOCHS:
            nodata.append(SHORT[seg])
            continue
        v = np.array([r[key] for r in sel])
        fl = np.array([bool(r.get(key + "_flag")) for r in sel])
        shift = abs(float(v.mean()) - mu) / sd
        kept = v[~fl]
        shift_kept = abs(float(kept.mean()) - mu) / sd if len(kept) else 0.0
        # sampling error of the difference of two means in SD units, plus the slow drift between blocks
        # (tau^2): with ~20 epochs per step and minutes between the steps, a perfectly clean metric still
        # moves by ~0.3-0.6 SD; the shift only fails when it is beyond the limit by more than that
        se = (1.0 / (f * max(len(kept), N_KEPT_MIN)) + 1.0 / (f * len(ref)) + tau2) ** 0.5
        thr = lim + Z_ONE * se
        passed = bool(len(kept) == 0 or shift_kept <= thr)
        rob.append({"seg": SHORT[seg], "n": int(len(v)), "shift": shift, "flagged": float(fl.mean()),
                    "shift_kept": shift_kept, "n_kept": int(len(kept)), "limit": lim, "se": se, "threshold": thr,
                    "passed": passed, "manip_ok": bool((manip.get(seg) or {}).get("ok", True))})
    out["robustness"] = rob
    if rob:
        out["worst_shift"] = round(max(r["shift_kept"] for r in rob), 2)
    # ---- verdict and a one-line reason (no trailing full stop: other pages append their own text)
    failed = [manip[s]["fail"] for s in ROB_STEPS[key] if s in manip and not manip[s].get("ok")]
    if failed:
        out["why"] = f"校验时没做出要求的动作（{'；'.join(failed)}）"
        return out
    if nodata:
        out["why"] = f"{'、'.join(nodata)}段没有可用数据，没法检验抗干扰"
        return out
    info = [x for x in out["sensitivity"] if x["expect"] is None and x["d"] is not None and x["d"] == x["d"]]
    note = ""
    if info:
        x = info[0]
        sig = x["ci"][0] > 0 or x["ci"][1] < 0
        note = f"；{x['desc']}{'有' if sig else '没有明显'}变化（d={x['d']:.1f}）"
    bad = [r for r in rob if not r["passed"]]
    rob_fail = ""
    if bad:
        w = max(bad, key=lambda r: r["shift_kept"] - r["threshold"])
        rob_fail = f"{w['seg']}时程序没认出的片段偏移 {w['shift_kept']:.1f} 个波动单位（上限 {w['threshold']:.2f}）"
    sens_fail = ""
    if out["sens_required"] and not sens_ok:
        x = next(s for s in out["sensitivity"] if s["expect"] is not None and not s["passed"])
        sens_fail = (f"{x['desc']}这一点没有看到（d={x['d']:.1f}），在你身上可能反映不出变化" if x["d"] is not None
                     else f"{'、'.join(x['cond'])}段干净数据不够，没法检验灵敏度")
    if bad:
        out["state"], out["robust"] = "warn", False
        if sens_fail:
            # the required effect was not seen: the shift cannot be read as "mostly muscle or eye movement"
            out["why"] = f"{sens_fail}；另外{rob_fail}{note}"
        else:
            out["why"] = (rob_fail + ("，可能主要反映肌肉或眼动" if key in ("theta_beta", "theta_beta_ear", "alpha",
                                                                    "alpha_ear", "calm", "faa") else "") + note)
        return out
    out["robust"] = True
    if all(r["shift"] <= r["threshold"] for r in rob):
        rob_txt = "咬牙、皱眉、左右看时基本不动" if key != "rmssd" else "咬牙、皱眉时基本不动"
    else:
        rob_txt = "咬牙、皱眉、左右看造成的偏移能被识别并跳过" if key != "rmssd" else "咬牙、皱眉造成的偏移能被识别并跳过"
    if not out["sens_required"]:
        out["state"] = "warn"
        out["why"] = f"只验证了抗干扰，还没有证据说明它反映{CLAIM.get(key, '要测的状态')}（{rob_txt}）{note}"
        return out
    if not sens_ok:
        out["state"] = "warn"
        out["why"] = sens_fail
        return out
    x = next(s for s in out["sensitivity"] if s["expect"] is not None)
    if key == "calm":
        # closed vs open eyes is not meditation: say what was shown, and what was not
        out["label"] = CALM_OK
        out["why"] = f"{CALM_OK}；{x['desc']}（d={x['d']:.1f}），{rob_txt}"
    else:
        out["why"] = f"{x['desc']}（d={x['d']:.1f}），{rob_txt}"
    out["state"] = "ok"
    return out


def _contact_summary(contact: list) -> dict:
    out = {}
    if not contact:
        return out
    for c, nm in enumerate(dsp.EEG_NAMES):
        cls = [cl[c] for cl, _ in contact]
        rsd = float(np.median([f[c]["rsd"] for _, f in contact]))
        line = float(np.median([f[c]["line"] for _, f in contact]))
        good = float(np.mean([k == "good" for k in cls]))
        usable = float(np.mean([dsp.CLASS_LEVEL[k] > 0 and k != "artifact" for k in cls]))
        txt = "良好" if good >= 0.7 else ("一般" if usable >= 0.7 else "差")
        out[nm.replace("EEG_", "")] = {"label": dsp.EEG_LABELS[nm], "good_share": good, "usable_share": usable,
                                       "rsd_uv": rsd, "mains_uv": line, "text": txt}
    return out


def _message(res: dict) -> str:
    ms = list(res["metrics"].values())
    n_ok = sum(m["state"] == "ok" for m in ms)
    n_rob = sum(m["state"] == "warn" and m.get("robust") and not m.get("sens_required") for m in ms)
    n_warn = sum(m["state"] == "warn" for m in ms) - n_rob
    n_unk = sum(m["state"] == "unknown" for m in ms)
    head = ""
    if not res.get("complete", True):
        head = f"校验不完整（{res.get('incomplete_why', '')}），结果没有保存，请完整重做；"
    return (head + f"{n_ok} 个指标可信，{n_rob} 个只验证了抗干扰，{n_warn} 个需要小心，{n_unk} 个没法检验")


# ============================================================================ entry point
def analyse_validation(session_dir, write: bool = True, persist: bool | None = None) -> dict:
    """Analyse a 「指标校验」 recording. Returns a result dict (see module doc); for any other recording
    {"is_validation": False, "message": ...}. write=True puts validity_report.html (and a short summary in
    session.json) into the session folder; persist (default = write) adds the result to the person's history,
    except for an incomplete run (res["complete"] False), which is never kept.
    Nothing is written for a recording that is not a validation recording."""
    d = Path(session_dir)
    if not (d / "session.json").exists():
        return _not_validation(d, "找不到这次录制（没有 session.json）")
    try:
        s = _load(d)
    except Exception as e:  # noqa: BLE001
        return _not_validation(d, f"录制文件读不了：{type(e).__name__}")
    if not is_validation(s.meta, s.markers):
        return _not_validation(d, "这不是指标校验录制：请在「录制」页选「指标校验」录约 7 分钟，再来看各指标靠不靠得住")
    eeg = _read_sensor(s, "EEG")
    if eeg is None or not all(n in eeg[2] for n in dsp.EEG_NAMES) or len(eeg[0]) < dsp.FS_EEG * 20:
        res = _not_validation(d, "这次指标校验没有足够的脑电数据")
        res["is_validation"] = True
        return res
    # a crashed recording has duration 0: the last segment would end before it starts
    try:
        dur = float(s.meta.get("duration") or 0)
    except (TypeError, ValueError):
        dur = 0.0
    if not dur == dur or dur < float(eeg[0][-1]):
        s.meta["duration"] = float(eeg[0][-1])
    opt, imu = _read_sensor(s, "OPTICS"), _read_sensor(s, "ACCGYRO")
    rows, contact, n_blinks, limits = _epochs(s, eeg, opt, imu)
    dt0 = _parse_date(s.meta.get("started_at"))
    dt = (dt0 or datetime.fromtimestamp((d / "session.json").stat().st_mtime)).isoformat(timespec="seconds")
    from . import people as P
    counts = {k: sum(1 for r in rows if r["seg"] == k and "alpha" in r) for k in SHORT}
    res = {"is_validation": True, "session": d.name, "date": dt, "person": P.person_of(s.meta),
           "segments": {SHORT[k]: v for k, v in counts.items()},
           "blinks": int(n_blinks), "contact": _contact_summary(contact), "emg_limit_uv": limits, "metrics": {}}
    missing = [SHORT[k] for k in REQUIRED_SEGS if counts.get(k, 0) < MIN_STEP_EPOCHS]
    n_clean_open = sum(1 for r in rows if r["seg"] == SEG_OPEN and r.get("clean"))
    res["clean_open_epochs"] = n_clean_open
    res["complete"] = not missing
    if missing:
        res["incomplete_why"] = "缺少或太短：" + "、".join(missing)
        res["manipulation"] = {}
        for key in METRICS:
            m = _blank(key)
            m["why"] = f"校验不完整（{res['incomplete_why']}），没法检验"
            res["metrics"][key] = m
    elif n_clean_open < MIN_EPOCHS:
        res["manipulation"] = _manipulations(rows)
        for key in METRICS:
            m = _blank(key)
            m["why"] = f"睁眼段干净数据太少（{n_clean_open} 段），没法检验"
            res["metrics"][key] = m
    else:
        res["manipulation"] = _manipulations(rows)
        for key in METRICS:
            res["metrics"][key] = _metric_result(key, rows, res["manipulation"])
    res["message"] = _message(res)
    res["persisted"] = False
    keep = (write if persist is None else persist) and res["complete"]
    if res["complete"] and s.meta.get("source") in NOT_REAL:
        res["persist_note"] = "模拟或回放的录制，结果不保存到校验记录"
        keep = False
    elif res["complete"] and not _valid_pid(res["person"]):
        res["persist_note"] = f"录制里的使用者编号「{res['person']}」不合规，结果没有保存到校验记录"
        keep = False
    if res.get("persist_note"):
        res["message"] += "（" + res["persist_note"] + "）"
    if write:
        try:
            (d / "validity_report.html").write_text(report_html(res), encoding="utf-8")
        except OSError:
            pass
        try:
            from .session import save_meta
            meta = json.loads((d / "session.json").read_text(encoding="utf-8"))
            meta["validity"] = {**{k: m["state"] for k, m in res["metrics"].items()}, "complete": res["complete"]}
            save_meta(d, meta)
        except Exception:  # noqa: BLE001
            pass
    if keep:
        res["persisted"] = _persist(res, res["person"])
    return res


# ============================================================================ report
STATE_TXT = {"ok": "可信", "warn": "要小心", "unknown": "没法检验", "robust_only": "只验证了抗干扰"}
STATE_COL = {"ok": "#15803d", "warn": "#b45309", "unknown": "#64748b", "robust_only": "#4f46e5"}


def display_state(m: dict) -> str:
    """"ok" | "robust_only" | "warn" | "unknown" for showing a metric result (robust_only = warn, robust, but
    no required sensitivity test)."""
    st = m.get("state", "unknown")
    if st == "warn" and m.get("robust") is True and m.get("sens_required") is False:
        return "robust_only"
    return st if st in ("ok", "warn", "unknown") else "unknown"


def _f(v, nd=2):
    return "—" if v is None or v != v else f"{v:.{nd}f}"


def report_html(res: dict) -> str:
    e = html.escape
    rows = []
    for key, m in res["metrics"].items():
        sens = "；".join(
            f"{e(x['desc'])}：d={_f(x['d'], 1)} [{_f(x['ci'][0], 1)}, {_f(x['ci'][1], 1)}]"
            + ("（只作参考）" if x.get("expect") is None else "") if x.get("ci")
            else f"{e(x['desc'])}：干净数据不够" for x in m["sensitivity"]) or "没有要求的灵敏度检验"
        rob = "<br>".join(
            f"{e(r['seg'])}：没认出的片段偏移 {r['shift_kept']:.2f}（{r['n_kept']} 段，上限 {r.get('threshold', r['limit']):.2f}"
            f" = {r['limit']:.2f} + {Z_ONE} × {r.get('se', 0):.2f}），"
            f"全部片段偏移 {r['shift']:.1f}，识别 {r['flagged'] * 100:.0f}%" for r in m["robustness"]) or "—"
        ds = display_state(m)
        rows.append(f"<tr><td>{e(m['name'])}</td><td><span class='b' style='background:{STATE_COL[ds]}'>"
                    f"{STATE_TXT[ds]}</span></td><td>{sens}</td><td>{rob}</td><td>{e(m['why'])}</td></tr>")
    mrows = "".join(
        f"<tr><td>{e(SHORT[k])}</td><td>{e(v['desc'])}</td><td>{_f(v.get('d'), 1)}</td>"
        f"<td><span class='b' style='background:{'#15803d' if v.get('ok') else '#b91c1c'}'>"
        f"{'做到了' if v.get('ok') else '没做出来'}</span></td></tr>"
        for k, v in (res.get("manipulation") or {}).items())
    mtab = (f"<div class='wrap'><table><tr><th>步骤</th><th>要求</th><th>效应量 d（对比睁眼）</th><th>结果</th></tr>"
            f"{mrows}</table></div>") if mrows else "<p class='m'>校验不完整，没有检查。</p>"
    crow = "".join(f"<tr><td>{e(v['label'])}</td><td>{e(v['text'])}</td><td>{v['good_share'] * 100:.0f}%</td>"
                   f"<td>{v['usable_share'] * 100:.0f}%</td><td>{v['rsd_uv']:.1f}</td><td>{v['mains_uv']:.1f}</td></tr>"
                   for v in res.get("contact", {}).values())
    seg = "、".join(f"{k} {v}" for k, v in res.get("segments", {}).items())
    banner = ""
    if not res.get("complete", True):
        banner = (f"<div class='inc'><b>这次校验不完整</b>：{e(res.get('incomplete_why', ''))}。"
                  "所有指标都算“没法检验”，结果<b>没有保存</b>到你的校验记录里，请在「录制」页完整重做一次「指标校验」。</div>")
    lims = res.get("emg_limit_uv") or {}
    lim_txt = "、".join(f"{METRICS[k]} {v:.1f} µV" for k, v in lims.items())
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>指标可信度报告</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{{font-family:"Microsoft YaHei UI","PingFang SC",sans-serif;background:#f8fafc;color:#0f172a;margin:0;padding:24px;line-height:1.6}}
main{{max-width:1080px;margin:0 auto}} h1{{font-size:22px;margin:0 0 4px}} h2{{font-size:17px;margin:28px 0 8px}}
.m{{color:#475569;font-size:14px}} table{{border-collapse:collapse;width:100%;background:#fff;font-size:14px}}
th,td{{border-bottom:1px solid #e2e8f0;padding:8px 10px;text-align:left;vertical-align:top}} th{{background:#f1f5f9}}
.b{{color:#fff;border-radius:10px;padding:1px 9px;font-size:13px;white-space:nowrap}}
.wrap{{overflow-x:auto}} .inc{{background:#fee2e2;border:1px solid #fca5a5;color:#7f1d1d;padding:10px 14px;border-radius:8px;margin:12px 0}}
</style></head><body><main>
<h1>指标可信度报告{'（不完整）' if not res.get('complete', True) else ''}</h1>
<div class="m">{e(res['date'][:16].replace('T', ' '))} · {e(res['session'])} · {e(res['message'])}</div>
{banner}
<h2>干扰动作有没有做到</h2>
{mtab}
<p class="m">咬牙、皱眉、左右看是用来考验指标的。只有确实做出了这些动作（相对睁眼，效应量 d ≥ {MANIP_D:.0f}），
抗干扰检验才有意义；没做出来时，依赖这一步的指标一律算“没法检验”。</p>
<h2>每个指标靠不靠得住</h2>
<div class="wrap"><table><tr><th>指标</th><th>结论</th><th>灵敏度（效应量 d 与 95% 区间）</th>
<th>抗干扰（相对睁眼的稳健波动）</th><th>说明</th></tr>{''.join(rows)}</table></div>
<h2>这些数字是什么意思</h2>
<p class="m">每个指标都按程序平时的算法，在每 2 秒一段的数据上算一遍（每一步开头 {SETTLE_S:.0f} 秒跳过）；
训练页的指标（耳后 α、θ/β）按训练时的跳过规则判断哪些片段会被丢掉（贴合差、头动超过 {NF_MOTION:.0f}°/秒、
眨眼盖住一半以上、最后 1 秒的肌电超过按睁眼段校准的上限：{e(lim_txt) or '—'}），其他指标按回看页的规则。<br>
<b>抗干扰</b>：咬牙、皱眉、左右看时，程序<b>没认出、仍会显示</b>的片段离睁眼平均值偏了多少，单位是睁眼时的稳健波动
（1.4826 × 中位绝对偏差，只用睁眼的干净片段）。上限＝{SHIFT_MAX} 个单位（灵敏度检验通过且效应量小于 1 时取它的一半）再加 {Z_ONE} 倍标准误；标准误包括片段数带来的抽样误差（片段数按至少 {N_KEPT_MIN} 段算），和同一状态隔几分钟后的自然漂移（由两段闭眼的差估计，估不出时按 {TAU2_DEFAULT} 算）。每一步的实际上限写在表里。
被认出并跳过的片段不算。<br>
<b>灵敏度</b>：该变的时候有没有变（只用干净片段），比如闭眼时 α 应该升高、闭眼时平静度应该比睁眼高、
快速眨眼时眨眼频率应该升高。|d| ≥ {D_MIN} 且区间不跨 0 算看到了；“心算对比闭眼”只作参考，不要求方向。<br>
<b>可信</b>＝动作做到了、不被肌肉和眼动带着走、而且该变时会变。<b>只验证了抗干扰</b>＝不受这些干扰，
但这次校验里没有能证明它反映所说状态（专注、情绪倾向、放松）的步骤，只能当参考。<b>要小心</b>＝它会跟着咬牙、
皱眉或眼动变而程序又认不出来，或者该变的时候没变。<b>没法检验</b>＝动作没做出来、数据不够或校验不完整。
结论只针对这次佩戴，超过 {STALE_DAYS} 天建议重做。</p>
<h2>这次的电极贴合（睁眼、闭眼、心算、再闭眼段）</h2>
<div class="wrap"><table><tr><th>电极</th><th>评价</th><th>“良好”比例</th><th>可用比例</th><th>噪声（µV，稳健标准差）</th>
<th>市电干扰（µV）</th></tr>{crow}</table></div>
<p class="m">用到的 2 秒片段数：{e(seg)}。睁眼段干净片段 {res.get('clean_open_epochs', 0)} 段。检测到眨眼 {res.get('blinks', 0)} 次。</p>
</main></body></html>"""
