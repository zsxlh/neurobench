"""「今天」 page (v0.10): one day at a glance, every number next to your own usual value."""

from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (QGridLayout, QHBoxLayout, QHeaderView, QPushButton, QTableWidget, QTableWidgetItem,
                             QVBoxLayout, QWidget)

from . import insights as I
from . import people as P
from . import theme as T
from .widgets import Card, label, plot

COLS = [("iaf", "α峰频"), ("alpha_ear", "耳后α"), ("hr", "心率"), ("rmssd", "心率变异"), ("calm_pct", "平静占比"),
        ("blink_rate", "眨眼/分")]
PERIOD_COL = {"夜里": "#a78bfa", "早上": "#fbbf24", "下午": "#34d399", "晚上": "#60a5fa"}


class TodayPage(QWidget):
    def __init__(self):
        super().__init__()
        self.day = date.today()
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)
        head = QHBoxLayout()
        self.b_prev = QPushButton("‹ 前一天")
        self.b_prev.setObjectName("ghost")
        self.b_prev.clicked.connect(lambda: self.shift(-1))
        self.l_day = label("", "h1")
        self.l_day.setMinimumWidth(300)
        self.b_next = QPushButton("后一天 ›")
        self.b_next.setObjectName("ghost")
        self.b_next.clicked.connect(lambda: self.shift(1))
        self.b_today = QPushButton("回到今天")
        self.b_today.setObjectName("ghost")
        self.b_today.clicked.connect(self.go_today)
        for w in (self.b_prev, self.l_day, self.b_next):
            head.addWidget(w)
        head.addStretch(1)
        head.addWidget(self.b_today)
        root.addLayout(head)
        self.l_lead = label("", "muted", wrap=True)
        root.addWidget(self.l_lead)

        # real-device acceptance checklist (round 4, R2): ticks itself once a qualifying recording exists
        self.c_check = Card("真机验收清单", "录过一项自动打勾；只看当前使用者的录制")
        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(6)
        self.l_checks = []
        for i in range(6):
            lb = label("", wrap=True)
            lb.setTextFormat(Qt.TextFormat.RichText)
            lb.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
            grid.addWidget(lb, i // 3, i % 3)
            self.l_checks.append(lb)
        for c in range(3):
            grid.setColumnStretch(c, 1)
        self.c_check.add(grid)
        root.addWidget(self.c_check)

        top = QHBoxLayout()
        top.setSpacing(14)
        self.c_sleep = Card("昨晚睡眠", "来自「过夜睡眠」录制（粗略估计）")
        self.l_sleep = label("", "muted", wrap=True)
        self.c_sleep.add(self.l_sleep)
        top.addWidget(self.c_sleep, 1)
        self.c_iaf = Card("α 峰值频率", "按时段和你平时比：刚起床通常偏低，清醒、精力好时偏高")
        self.l_iaf = label("", "muted", wrap=True)
        self.c_iaf.add(self.l_iaf)
        top.addWidget(self.c_iaf, 1)
        root.addLayout(top)

        cr = Card("这一天的录制", "颜色：绿 = 和平时差不多，橙 = 偏高，蓝 = 偏低（满 3 次以前的录制后才比较）")
        self.tbl = QTableWidget()
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        cr.add(self.tbl, 1)
        root.addWidget(cr, 2)

        ct = Card("α 峰值频率的变化", "每点一次录制；颜色 = 时段")
        self.p = plot(left="Hz", bottom="日期")
        ct.add(self.p, 1)
        root.addWidget(ct, 2)

    # ------------------------------------------------------------------
    def go_today(self):
        self.day = date.today()
        self.refresh()

    def shift(self, n):
        self.day = self.day + timedelta(days=n)
        self.refresh()

    def refresh_checklist(self, who: str | None = None):
        import html
        try:
            from . import checklist as CL
            items = CL.status(who or P.current())
        except Exception as e:  # noqa: BLE001
            items = []
            self.c_check.sub_label.setText(f"清单读取失败：{e}")
        else:
            self.c_check.sub_label.setText(CL.summary_text(items) + "；录过一项自动打勾，只看当前使用者的录制")
        self.checklist_items = items
        for i, lb in enumerate(self.l_checks):
            if i >= len(items):
                lb.setText("")
                continue
            it = items[i]
            if it["done"]:
                when = (it.get("when") or "")[:16].replace("T", " ")
                note = it.get("note") or ""
                lb.setText(f"<span style='color:{T.GOOD}'>✔</span> <b>{html.escape(it['title'])}</b>"
                           f"<br><span style='color:{T.MUTED}'>已完成 {html.escape(when)}</span>"
                           + (f"<br><span style='color:{T.WARN}'>{html.escape(note)}</span>" if note else ""))
                lb.setToolTip(it.get("dir") or "")
            else:
                lb.setText(f"<span style='color:{T.FAINT}'>○</span> <b>{html.escape(it['title'])}</b>"
                           f"<br><span style='color:{T.MUTED}'>{html.escape(it.get('hint') or '')}</span>")
                lb.setToolTip("")

    def refresh(self):
        who = P.current()
        self.refresh_checklist(who)
        self.l_day.setText(f"{self.day:%Y-%m-%d}" + ("（今天）" if self.day == date.today() else ""))
        self.b_next.setEnabled(self.day < date.today())
        ds = I.day_summary(self.day, who)
        items = ds["items"]
        if not items:
            self.l_lead.setText(f"{P.name_of(who)}这一天没有录制。")
        else:
            mins = sum(r["duration"] or 0 for r in items) / 60
            self.l_lead.setText(f"{P.name_of(who)}这一天录了 {len(items)} 次，共 {mins:.0f} 分钟。"
                                f"比较用的是你此前 {ds['n_days']} 天的录制。")
        # sleep
        sl = ds["sleep"]
        if sl and sl.get("sleep"):
            z = sl["sleep"]
            f = lambda k, u="分钟": "—" if z.get(k) is None else f"{z[k]:.0f} {u}"  # noqa: E731
            eff = "—" if z.get("efficiency") is None else f"{z['efficiency'] * 100:.0f}%"
            self.l_sleep.setText(f"睡着 {f('sleep_min')} · 入睡用时 {f('onset_min')} · 醒来 {f('awakenings', '次')} · 效率 {eff}\n"
                                 f"深睡 {f('深睡_min')} · 浅睡 {f('浅睡_min')} · 可能的 REM {f('REM_min')}")
        else:
            self.l_sleep.setText("这一天没有过夜睡眠录制。睡前在「录制」选「过夜睡眠」，用省电模式连接。")
        # alpha peak by period
        lines = []
        rows_all = I.all_rows(who)
        before = [r for r in rows_all if r["day"] < self.day and r.get("iaf")]
        for per, v in ds["iaf_by_period"].items():
            same = [r["iaf"] for r in before if r["period"] == per]
            allp = [r["iaf"] for r in before]
            c = I.versus(v, same)
            if c:
                lines.append(f"{per} {v:.2f} Hz：{c['text']}（你{per}平均 {c['mean']:.2f}，{c['n']} 次）")
            elif len(allp) >= I.MIN_BASE:
                lines.append(f"{per} {v:.2f} Hz：你{per}的录制还不够 3 次；和全部录制平均 {np.mean(allp):.2f} Hz 比"
                             f"{'低' if v < np.mean(allp) else '高'} {abs(v - np.mean(allp)):.2f} Hz")
            else:
                lines.append(f"{per} {v:.2f} Hz（录满 3 次后开始和平时比较）")
        self.l_iaf.setText("\n".join(lines) or "这一天没有可用的 α 峰频（需要耳后电极贴好、闭眼或安静的片段）。")
        # table
        heads = ["时间", "录制", "时长"] + [n for _, n in COLS]
        self.tbl.clear()
        self.tbl.setColumnCount(len(heads))
        self.tbl.setHorizontalHeaderLabels(heads)
        self.tbl.setRowCount(len(items))
        for r_i, r in enumerate(items):
            vals = [r["when"].strftime("%H:%M") + f" {r['period']}", r["name"], f"{(r['duration'] or 0) / 60:.0f} 分"]
            for c_i, v in enumerate(vals):
                self.tbl.setItem(r_i, c_i, QTableWidgetItem(v))
            for j, (k, _) in enumerate(COLS):
                v = r.get(k)
                it = QTableWidgetItem("—" if v is None else I.fmt_value(k, v))
                it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                c = r["cmp"].get(k)
                if c:
                    it.setForeground(QColor(T.GOOD if abs(c["z"]) < 1 else ("#fb923c" if c["z"] > 0 else "#60a5fa")))
                    it.setToolTip(f"{c['text']}：平时 {I.fmt_value(k, c['mean'])}（{c['n']} 次）")
                self.tbl.setItem(r_i, 3 + j, it)
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        # trend of alpha peak frequency by period
        self.p.clear()
        pts = [r for r in rows_all if r.get("iaf")]
        if pts:
            from datetime import datetime as _dt
            d0 = _dt.combine(min(r["day"] for r in pts), _dt.min.time())   # midnight of the first day
            for per, col in PERIOD_COL.items():
                xs = [(r["when"] - d0).total_seconds() / 86400 for r in pts if r["period"] == per]
                ys = [r["iaf"] for r in pts if r["period"] == per]
                if xs:
                    self.p.plot(xs, ys, pen=None, symbol="o", symbolSize=8, symbolBrush=col, symbolPen=None, name=per)
            ax = self.p.getPlotItem().getAxis("bottom")
            days = sorted({r["day"] for r in pts})
            ax.setTicks([[((d - d0.date()).days + 0.5, f"{d:%m-%d}") for d in days]])     # tick at midday
