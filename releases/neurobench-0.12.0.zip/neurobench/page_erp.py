"""脑电小实验 page: auditory / visual oddball P300 with its own recording and an automatic report."""

from __future__ import annotations

import csv
import json
import os
import threading
import time
from datetime import datetime
from pathlib import Path

import numpy as np
from PyQt6.QtCore import QRectF, Qt, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QColor, QDesktopServices, QFont, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import (QComboBox, QHBoxLayout, QInputDialog, QLabel, QMessageBox, QProgressBar, QPushButton,
                             QSpinBox, QStackedWidget, QVBoxLayout, QWidget)

from . import audio_latency as AL
from . import erp as E
from . import theme as T
from .widgets import Card, label

COUNTDOWN_S = 3
RESYNC_S = 0.1          # a stimulus later than this restarts the schedule instead of catching up

LATENCY_EXPLAIN = ("测一下“程序发出提示音”到“声音真正响起”之间晚了多少毫秒，听觉 P300 的分析会按这个数校正刺激时间。\n\n"
                   "请这样准备：\n"
                   "· 打开扬声器（不要戴耳机，麦克风要能听到声音），音量调到平时做实验的大小；\n"
                   "· 打开麦克风（笔记本自带的就行）；\n"
                   "· 房间安静一些，测量时别说话。\n\n"
                   "会响 12 声“嘀”，大约 20 秒。录到的声音只在内存里用来对时间，不会保存。\n"
                   "换了扬声器（比如改用蓝牙音箱）要重新测，结果按扬声器和麦克风分别记下。\n"
                   "测出来的是上限：麦克风自己的录音延迟（通常 5–20 毫秒）也算在里面。")


class StimCanvas(QWidget):
    """Dark full-page canvas: fixation cross, the oddball circle, a countdown, and a quiet progress line."""

    abort_clicked = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAutoFillBackground(False)
        self.circle = None          # colour string while a circle is shown
        self.big_text = ""          # countdown / instruction in the middle
        self.small_text = ""        # progress line at the bottom
        self.show_cross = True
        self.b_abort = QPushButton("中止（Esc）", self)
        self.b_abort.setObjectName("ghost")
        self.b_abort.clicked.connect(self.abort_clicked.emit)

    def resizeEvent(self, e):
        self.b_abort.adjustSize()
        self.b_abort.move(self.width() - self.b_abort.width() - 16, 16)
        super().resizeEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.abort_clicked.emit()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), QColor("#0b0d12"))
        cx, cy = w / 2, h / 2
        if self.circle:
            r = min(w, h) * 0.22
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(self.circle))
            p.drawEllipse(QRectF(cx - r, cy - r, 2 * r, 2 * r))
        if self.show_cross:
            p.setPen(QPen(QColor("#e5e7eb"), 2))
            p.drawLine(int(cx - 10), int(cy), int(cx + 10), int(cy))
            p.drawLine(int(cx), int(cy - 10), int(cx), int(cy + 10))
        if self.big_text:
            p.setPen(QColor(T.TEXT))
            f = QFont(T.FONT, 20)
            p.setFont(f)
            p.drawText(QRectF(0, cy - 140, w, 100), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap,
                       self.big_text)
        if self.small_text:
            p.setPen(QColor(T.FAINT))
            p.setFont(QFont(T.FONT, 10))
            p.drawText(QRectF(0, h - 40, w, 30), Qt.AlignmentFlag.AlignCenter, self.small_text)
        p.end()


class ErpPage(QWidget):
    """Built-in P300 mini-experiments.

    start_recording(name) -> bool and stop_recording() are passed by the main window (normally
    RecordPage.start_free / RecordPage.stop). Without them the page records by itself with session.Recorder.
    """

    finished = pyqtSignal(str)          # session folder, only once erp_report.html, erp_figure.png and
    #                                     session.json["erp"]["result"] are written (folder is then cloud-ready)
    message = pyqtSignal(str)           # short status for a status bar
    ended = pyqtSignal(str)             # aborted / report not written: the folder is final as it is (v0.11)
    _analysed = pyqtSignal(object)      # result dict from the analysis thread

    def __init__(self, hub, analyzer=None, start_recording=None, stop_recording=None):
        super().__init__()
        self.hub, self.an = hub, analyzer
        self._start_cb, self._stop_cb = start_recording, stop_recording
        self.state = "idle"             # idle / countdown / running / analysing / done
        self.rec = None
        self.own_rec = False
        self.dir: Path | None = None
        self.result = None
        self.pending_count = None
        self.effects = {}
        self.log = []
        self._analysed.connect(self._on_analysed)

        self.t_stim = QTimer(self)
        self.t_stim.setSingleShot(True)
        self.t_stim.setTimerType(Qt.TimerType.PreciseTimer)
        self.t_stim.timeout.connect(self._fire)
        self.t_off = QTimer(self)
        self.t_off.setSingleShot(True)
        self.t_off.setTimerType(Qt.TimerType.PreciseTimer)
        self.t_off.timeout.connect(self._stim_off)
        self.t_count = QTimer(self)
        self.t_count.setInterval(1000)
        self.t_count.timeout.connect(self._countdown_tick)
        self.t_end = QTimer(self)
        self.t_end.setSingleShot(True)
        self.t_end.timeout.connect(self._complete)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget()
        outer.addWidget(self.stack)

        # ---------------- setup / results view
        setup = QWidget()
        root = QHBoxLayout(setup)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(14)
        left = Card("脑电小实验", "P300：大脑对“少见目标”的反应")
        left.add(label("实验", "muted"))
        self.cb_exp = QComboBox()
        self.cb_exp.addItem("听觉 P300（可以闭眼，推荐）", "auditory")
        self.cb_exp.addItem("视觉 P300（看屏幕上的圆）", "visual")
        self.cb_exp.currentIndexChanged.connect(self._show_instructions)
        left.add(self.cb_exp)
        left.add(label("长度", "muted"))
        self.cb_len = QComboBox()
        for k, (_, txt) in E.LENGTHS.items():
            self.cb_len.addItem(txt, k)
        left.add(self.cb_len)
        self.l_instr = label("", "", wrap=True)
        left.add(self.l_instr)
        left.add(label(E.N170_NOTE, "faint", wrap=True))
        # sound output latency calibration (auditory P300 timing)
        self.l_latency = label("", "muted", wrap=True)
        left.add(self.l_latency)
        lrow = QHBoxLayout()
        self.b_latency = QPushButton("测声音延迟")
        self.b_latency.setToolTip(LATENCY_EXPLAIN)
        self.b_latency.clicked.connect(self._ask_latency)
        lrow.addWidget(self.b_latency)
        lrow.addStretch(1)
        lw = QWidget()
        lw.setLayout(lrow)
        left.add(lw)
        self.calib = None
        left.lay.addStretch(1)
        self.l_hint = label("", "muted", wrap=True)
        left.add(self.l_hint)
        self.b_start = QPushButton("开始实验")
        self.b_start.setObjectName("primary")
        self.b_start.clicked.connect(self.start)
        left.add(self.b_start)
        root.addWidget(left, 2)

        right = Card("结果")
        self.l_status = label("做完一次实验后，结果会显示在这里。", "muted", wrap=True)
        right.add(self.l_status)
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(6)
        self.bar.setVisible(False)
        right.add(self.bar)
        crow = QHBoxLayout()
        self.l_count = label("你一共数到几个目标？", "")
        crow.addWidget(self.l_count)
        self.sp_count = QSpinBox()
        self.sp_count.setRange(0, 999)
        crow.addWidget(self.sp_count)
        self.b_count = QPushButton("记下")
        self.b_count.clicked.connect(self._save_count)
        crow.addWidget(self.b_count)
        crow.addStretch(1)
        self.count_row = QWidget()
        self.count_row.setLayout(crow)
        self.count_row.setVisible(False)
        right.add(self.count_row)
        self.img = QLabel()
        self.img.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.img.setMinimumHeight(200)
        right.add(self.img, 1)
        self.b_report = QPushButton("打开完整报告")
        self.b_report.setVisible(False)
        self.b_report.clicked.connect(self._open_report)
        right.add(self.b_report)
        root.addWidget(right, 3)
        self.stack.addWidget(setup)

        # ---------------- stimulus view
        self.canvas = StimCanvas()
        self.canvas.abort_clicked.connect(lambda: self.abort("你中止了实验。"))
        self.stack.addWidget(self.canvas)
        self._pix = None
        self._show_instructions()
        self._refresh_latency_label()

    # ------------------------------------------------------------------ public
    def set_recording_callbacks(self, start_recording, stop_recording):
        self._start_cb, self._stop_cb = start_recording, stop_recording

    def is_running(self) -> bool:
        return self.state in ("countdown", "running")

    def shutdown(self):
        """Call when the window closes: ends a run cleanly (the recording is kept, marked as aborted)."""
        if self.calib is not None:
            self.calib.cancel()
        if self.is_running():
            self.abort("程序关闭，实验中止。")

    # ------------------------------------------------------------------ sound latency calibration
    def _refresh_latency_label(self):
        try:
            out = AL.default_output_name()
            if not out:
                self.l_latency.setText("声音延迟：未校准（读不到当前扬声器的名字，不能套用存下的校准）。只影响听觉实验。")
                return
            self.l_latency.setText(AL.describe(AL.lookup(out)) + " 只影响听觉实验。")
        except Exception:  # noqa: BLE001
            self.l_latency.setText("声音延迟：未校准。")

    def _ask_latency(self):
        """Button: explain, pick a microphone when there are several, then run the ~20 s calibration."""
        if self.is_running() or self.state == "analysing" or self.calib is not None:
            return
        box = QMessageBox(QMessageBox.Icon.Information, "测声音延迟", LATENCY_EXPLAIN,
                          QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel, self)
        box.button(QMessageBox.StandardButton.Ok).setText("开始测量")
        box.button(QMessageBox.StandardButton.Cancel).setText("取消")
        if box.exec() != QMessageBox.StandardButton.Ok:
            return
        mics = AL.input_devices()
        if not mics:
            self.l_latency.setText("没找到麦克风，无法测量声音延迟。请在系统设置里打开麦克风后再试。")
            return
        dev = None
        if len(mics) > 1:
            labels = AL.unique_labels([n for _, n in mics])     # two inputs may share a name: （2）… keeps them apart
            cur = AL.default_input_index(mics)
            name, ok = QInputDialog.getItem(self, "选择麦克风", "用哪个麦克风听扬声器的声音？", labels, cur, False)
            if not ok:
                return
            dev = mics[labels.index(name) if name in labels else cur][0]
        else:
            dev = mics[0][0]
        self.start_latency(dev)

    def start_latency(self, input_device=None, source=None, player=None, **kw) -> bool:
        """Run a calibration (tests inject a fake source and player; extra kw go to AL.LatencyCalibrator)."""
        if self.is_running() or self.state == "analysing" or self.calib is not None:
            return False
        self.calib = AL.LatencyCalibrator(self, input_device=input_device, source=source, player=player, **kw)
        self.calib.progress.connect(self._latency_progress)
        self.calib.done.connect(self._latency_done)
        self.b_latency.setEnabled(False)
        self.b_start.setEnabled(False)
        self.l_latency.setText("正在测声音延迟，请保持安静……")
        self._say("正在测声音延迟，大约 20 秒。")
        if not self.calib.start():                   # done was emitted with the reason
            return False
        return True

    def _latency_progress(self, i: int, n: int):
        self.l_latency.setText(f"正在测声音延迟，请保持安静……第 {i} / {n} 声")

    def _latency_done(self, res: dict):
        cal, self.calib = self.calib, None
        if cal is not None:
            cal.deleteLater()                        # finished calibrator: free its timers and player
        self.latency_result = res
        self.b_latency.setEnabled(True)
        self.b_start.setEnabled(True)
        msg = res.get("message", "")
        if res.get("ok"):
            msg += "\n" + res.get("note", AL.UPPER_BOUND_NOTE)
            if not res.get("saved") and res.get("save_error"):
                msg += f"\n（结果没存下来：{res['save_error']}）"
            self._refresh_latency_label()
            self.l_latency.setText(msg + "\n" + self.l_latency.text())
        else:
            self.l_latency.setText(msg)
        self._say("声音延迟测完了。" if res.get("ok") else "声音延迟没测成。")

    # ------------------------------------------------------------------ ui helpers
    def _exp(self) -> str:
        return self.cb_exp.currentData()

    def _show_instructions(self, *_):
        cfg = E.EXPERIMENTS[self._exp()]
        self.l_instr.setText(cfg["instructions"])

    def _say(self, txt: str):
        self.l_hint.setText(txt)
        self.message.emit(txt)

    # ------------------------------------------------------------------ flow
    def start(self):
        if self.is_running() or self.state == "analysing":
            return
        if self.calib is not None:
            self._say("正在测声音延迟，等它测完再开始实验。")
            return
        if not self.hub.is_live():
            self._say("还没有数据：先连接头环（或右上角「···」打开演示模式）。")
            return
        if getattr(self.hub, "recorder", None) is not None:
            self._say("正在录制别的内容，先停止那边的录制。")
            return
        if self.an is not None:
            q = getattr(self.an, "quality", {}) or {}
            if all(q.get(n, (1, ""))[0] == 0 for n in E.ROI):
                self._say("两个耳后电极（TP9、TP10）都没贴好，P300 主要靠它们。先把耳后的电极贴紧皮肤，再开始。")
                return
        exp = self._exp()
        cfg = E.EXPERIMENTS[exp]
        n = E.LENGTHS[self.cb_len.currentData()][0]
        lo, hi = E.ISI_RANGE
        if os.environ.get("NB_ERP_FAST"):           # automated tests only
            n, lo, hi = int(os.environ.get("NB_ERP_FAST_N", "40")), 0.30, 0.40
        seed = int(time.time() * 1000) % (2 ** 31)
        self.seq = E.make_sequence(n, E.P_TARGET, rng=seed)
        self.isis = E.make_isis(n, lo, hi, rng=seed + 1)
        name = f"{cfg['title']} {datetime.now():%m-%d %H%M}"
        if not self._begin_recording(name):
            self._say("无法开始录制。")
            return
        self.exp, self.cfg, self.n, self.i = exp, cfg, n, 0
        self.log = []
        self.n_resync = 0
        self.result, self.pending_count, self.dir = None, None, Path(self.rec.dir)
        self._clear_results()
        info = {"experiment": exp, "title": cfg["title"], "n_trials": n, "n_targets": int(sum(self.seq)),
                "p_target": E.P_TARGET, "isi_s": [lo, hi], "stim_ms": int(cfg["dur"] * 1000), "seed": seed,
                "labels": {"standard": E.STD_LABEL, "target": E.TGT_LABEL}, "completed": False}
        if exp == "auditory":
            info["tones_hz"] = [cfg["std_freq"], cfg["tgt_freq"]]
            # snapshot of the speaker calibration in force now (erp.analyse adds it to the stimulus times)
            # (no output name -> no snapshot: erp.analyse never applies a calibration of a guessed device)
            out = AL.default_output_name()
            info["audio_output"] = out
            try:
                info["audio_latency"] = AL.lookup(out) if out else None
            except Exception:  # noqa: BLE001
                info["audio_latency"] = None
        else:
            info["colors"] = [cfg["std_color"], cfg["tgt_color"]]
        self.rec.meta["erp"] = info
        self._save_rec_meta()
        self.audio = None
        if exp == "auditory":
            self._load_audio()
        self.state = "countdown"
        self._cd = COUNTDOWN_S
        self.canvas.circle = None
        self.canvas.show_cross = exp == "visual"
        self.canvas.big_text = f"{cfg['title']}：{COUNTDOWN_S} 秒后开始"
        self.canvas.small_text = ("闭上眼睛，默数高音" if exp == "auditory" else "盯住十字，默数橙色圆")
        self.stack.setCurrentIndex(1)
        self.canvas.setFocus()
        self.t_count.start()
        self._say(f"{cfg['title']}开始了，共 {n} 次。")

    def _clear_results(self):
        """Forget the previous run's figure, report button and count row (a new run is starting)."""
        self._pix = None
        self.img.clear()
        self.b_report.setVisible(False)
        self.count_row.setVisible(False)
        self.bar.setVisible(False)
        self.l_status.setText("实验进行中……")

    def _begin_recording(self, name: str) -> bool:
        """Start the run's recording. With a start_recording callback (the main window passes one that starts
        a plain EEG recording without camera or microphone) it must return True and leave the new Recorder
        in hub.recorder; otherwise the page makes its own session.Recorder."""
        self.rec, self.own_rec = None, False
        if self._start_cb is not None:
            try:
                ok = bool(self._start_cb(name))
            except Exception:  # noqa: BLE001
                ok = False
            self.rec = getattr(self.hub, "recorder", None) if ok else None
            return self.rec is not None
        from .session import Recorder
        try:
            self.rec = Recorder(self.hub, name, "自由录制")
        except Exception:  # noqa: BLE001
            return False
        self.rec.meta["mode"] = "脑电小实验"
        with self.hub.lock:
            self.hub.recorder = self.rec
        self.own_rec = True
        return True

    def _end_recording(self):
        rec, self.rec = self.rec, None
        if rec is None:
            return
        if not self.own_rec and self._stop_cb is not None and getattr(self.hub, "recorder", None) is rec:
            try:
                self._stop_cb()
            except Exception:  # noqa: BLE001
                pass
        # own recorder, or the callback did not stop it: close it ourselves (not again if it was closed elsewhere)
        if getattr(self.hub, "recorder", None) is rec:
            rec.close()
        # make sure the experiment description reached session.json (in case the stopper rewrote it)
        try:
            mp = Path(rec.dir) / "session.json"
            meta = json.loads(mp.read_text(encoding="utf-8"))
            if meta.get("erp") != rec.meta.get("erp"):
                meta["erp"] = rec.meta.get("erp")
                from .session import save_meta
                save_meta(rec.dir, meta)
        except Exception:  # noqa: BLE001
            pass

    def _save_rec_meta(self):
        """While the recording runs, the recorder's dict is the truth. Once it was closed (stopped from another
        page), others (the survey) may have written session.json: then only the "erp" entry is merged in."""
        import json
        from .session import save_meta
        try:
            if getattr(self.hub, "recorder", None) is self.rec:
                save_meta(self.rec.dir, self.rec.meta)
            else:
                p = self.rec.dir / "session.json"
                meta = json.loads(p.read_text(encoding="utf-8"))
                meta["erp"] = self.rec.meta.get("erp", {})
                save_meta(self.rec.dir, meta)
        except Exception:  # noqa: BLE001
            pass

    def _load_audio(self):
        """Preload both tones plus a silent loop that keeps the audio device awake (no wake-up delay)."""
        files = E.ensure_tones()
        vol = 0.0 if os.environ.get("NB_MUTE") else 0.6
        try:
            from PyQt6.QtMultimedia import QSoundEffect
            fx = {}
            for k in ("standard", "target", "silence"):
                e = QSoundEffect(self)
                e.setSource(QUrl.fromLocalFile(str(files[k])))
                e.setVolume(vol if k != "silence" else 0.01)
                fx[k] = e
            fx["silence"].setLoopCount(QSoundEffect.Loop.Infinite.value)
            fx["silence"].play()
            self.effects = fx
            self.audio = "qsoundeffect"
        except Exception:  # noqa: BLE001
            self.effects = {}
            self.audio = "winsound"
        self._files = files

    def _play(self, target: bool):
        k = "target" if target else "standard"
        e = self.effects.get(k)
        if e is not None:
            from PyQt6.QtMultimedia import QSoundEffect
            if e.status() == QSoundEffect.Status.Ready:
                e.play()
                return "qsoundeffect"
        if os.environ.get("NB_MUTE"):
            return "muted"
        try:
            import winsound
            winsound.PlaySound(str(self._files[k]), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
            return "winsound"
        except Exception:  # noqa: BLE001
            return "none"

    def _countdown_tick(self):
        if self.state != "countdown":
            self.t_count.stop()
            return
        if self.rec is None or getattr(self.hub, "recorder", None) is not self.rec:
            self.abort("录制被停止了（可能是头环断开或电量不足），实验中止。")
            return
        self._cd -= 1
        if self._cd > 0:
            self.canvas.big_text = f"{self.cfg['title']}：{self._cd} 秒后开始"
            self.canvas.update()
            return
        self.t_count.stop()
        self.state = "running"
        self.canvas.big_text = "闭上眼睛，默数高音" if self.exp == "auditory" else ""
        self.canvas.update()
        self.rec.add_marker(self.cfg["title"], "segment")
        self._due = self.hub.now() + 0.8
        self.t_stim.start(800)

    def _fire(self):
        if self.state != "running":
            return
        rec = self.rec
        if rec is None or getattr(self.hub, "recorder", None) is not rec:
            self.abort("录制被停止了（可能是头环断开或电量不足），实验中止。")
            return
        if not self.hub.is_live(5.0):
            self.abort("头环 5 秒没有数据，实验中止。录下的部分已保存。")
            return
        tgt = bool(self.seq[self.i])
        now = self.hub.now()
        late = now - self._due
        c0 = time.perf_counter()
        if self.exp == "auditory":
            how = self._play(tgt)
        else:
            self.canvas.circle = self.cfg["tgt_color"] if tgt else self.cfg["std_color"]
            self.canvas.repaint()                    # synchronous paint, so the marker follows the paint call
            how = "paint"
        call_ms = (time.perf_counter() - c0) * 1000
        m = rec.add_marker(E.TGT_LABEL if tgt else E.STD_LABEL, E.STIM_KIND)
        if self.exp == "visual":
            self.t_off.start(int(round(self.cfg["dur"] * 1000)))
        # after a GUI stall do not catch up (that would fire the missed stimuli a few ms apart):
        # restart the schedule from now, so the next stimulus still gets its full ISI
        resync = late > RESYNC_S
        self.log.append({"i": self.i + 1, "type": "目标" if tgt else "标准", "marker_t": m["t"],
                         "due_t": round(self._due - rec.t_start, 4), "late_ms": round(late * 1000, 2),
                         "call_ms": round(call_ms, 3), "output": how,
                         "resync_ms": round(late * 1000, 1) if resync else 0})
        if resync:
            self.n_resync += 1
            self._due = now
        self.i += 1
        self.canvas.small_text = f"{self.i} / {self.n}"
        if self.exp == "auditory":
            self.canvas.update()
        if self.i >= self.n:
            self.t_end.start(1500)                   # let the last epoch finish
            return
        self._due += float(self.isis[self.i])
        self.t_stim.start(max(0, int(round((self._due - self.hub.now()) * 1000))))

    def _stim_off(self):
        self.canvas.circle = None
        self.canvas.repaint()

    def _stop_timers(self):
        for t in (self.t_stim, self.t_off, self.t_count, self.t_end):
            t.stop()
        for e in self.effects.values():
            try:
                e.stop()
            except Exception:  # noqa: BLE001
                pass
        self.effects = {}

    def _timing_summary(self) -> dict:
        if not self.log:
            return {}
        late = np.array([r["late_ms"] for r in self.log])
        call = np.array([r["call_ms"] for r in self.log])
        outs = sorted({r["output"] for r in self.log})
        return {"timer_late_ms": {"median": round(float(np.median(late)), 2), "p95": round(float(np.percentile(late, 95)), 2),
                                  "max": round(float(late.max()), 2)},
                "call_ms": {"median": round(float(np.median(call)), 3), "max": round(float(call.max()), 3)},
                "output": outs,
                "resyncs": int(sum(1 for r in self.log if r.get("resync_ms"))),
                "note": ("声音/画面实际出现比标记晚约 10-40 ms（固定）且有几毫秒抖动；标记在调用播放/绘制后立刻记下")}

    def _write_log(self):
        if not self.log or self.dir is None:
            return
        try:
            with open(self.dir / "erp_trials.csv", "w", encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=list(self.log[0].keys()))
                w.writeheader()
                w.writerows(self.log)
        except OSError:
            pass

    def _complete(self):
        if self.state != "running":
            return
        self._stop_timers()
        self.rec.meta["erp"].update(completed=True, trials_done=self.i, timing=self._timing_summary(),
                                    audio=self.audio if self.exp == "auditory" else "")
        self._save_rec_meta()
        self._write_log()
        self._end_recording()
        self.state = "analysing"
        self.stack.setCurrentIndex(0)
        self.canvas.big_text = ""
        tn = "高音" if self.exp == "auditory" else "橙色圆"
        self.l_count.setText(f"你一共数到几个{tn}？")
        self.sp_count.setValue(0)
        self.count_row.setVisible(True)
        self.b_count.setEnabled(True)
        self.b_report.setVisible(False)
        self._pix = None
        self.img.clear()
        self.bar.setRange(0, 0)
        self.bar.setVisible(True)
        self.l_status.setText("实验完成，正在分析……趁这会儿填一下你数到的个数。")
        self._say("实验完成，正在分析。")
        d = self.dir
        self._th = threading.Thread(target=self._analyse_thread, args=(d,), daemon=True, name="erp-analyse")
        self._th.start()

    def _analyse_thread(self, d: Path):
        try:
            res = E.analyse(d, write=True)
        except Exception as e:  # noqa: BLE001
            res = {"ok": False, "message": f"分析出错：{type(e).__name__}: {e}", "dir": str(d)}
        self._analysed.emit(res)

    def _on_analysed(self, res: dict):
        self.result = res
        self.state = "done"
        self.bar.setVisible(False)
        self.l_status.setText(res.get("message", ""))
        d = self.dir
        ready = d is not None and E.outputs_ready(d)
        if d is not None and not ready:              # analysis crashed or a write failed: try once more here
            try:
                E.write_outputs(res, d)
            except Exception as e:  # noqa: BLE001
                res["write_error"] = f"{type(e).__name__}: {e}"
            ready = E.outputs_ready(d)
        fig = d / "erp_figure.png" if d else None
        if res.get("ok") and fig is not None and fig.exists():
            self._pix = QPixmap(str(fig))
            self._fit_pix()
        self.b_report.setVisible(bool(d and (d / "erp_report.html").exists()))
        if self.pending_count is not None:
            self._write_count(self.pending_count)
        if not ready:
            self.l_status.setText(res.get("message", "") + f"\n（报告文件没写成：{res.get('write_error', '未知原因')}）")
            self._say("分析完成，但报告没写成。")
            if d is not None:
                self.ended.emit(str(d))
            return
        self._say("分析完成。")
        if self.b_count.isEnabled():
            # the target count is still to come: wait for it (or 2 minutes) so the upload includes it
            self._finish_pending = str(d)
            import os
            QTimer.singleShot(2_000 if os.environ.get("NB_ERP_FAST") else 120_000, self._emit_finished)
        else:
            self.finished.emit(str(d))       # report, figure and session.json["erp"]["result"] are on disk

    def _emit_finished(self):
        d, self._finish_pending = getattr(self, "_finish_pending", None), None
        if d:
            self.finished.emit(d)

    def wait_analysis(self, timeout_s: float = 60.0):
        """Closing the app: let a running analysis finish so its report is not lost."""
        import time
        from PyQt6.QtWidgets import QApplication
        th = getattr(self, "_th", None)
        t0 = time.monotonic()
        while th is not None and th.is_alive() and time.monotonic() - t0 < timeout_s:
            QApplication.processEvents()
            th.join(0.05)
        QApplication.processEvents()                 # deliver the result (writes the count, emits finished)
        self._emit_finished()

    def on_person_changed(self):
        if self.state in ("idle", "done"):
            self._clear_results()
            self.l_status.setText("做完一次实验后，结果会显示在这里。")
            self.dir, self.result = None, None

    def _fit_pix(self):
        if self._pix is not None and not self._pix.isNull():
            w = max(200, self.img.width())
            self.img.setPixmap(self._pix.scaledToWidth(w, Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._fit_pix()

    def _save_count(self):
        v = int(self.sp_count.value())
        self.b_count.setEnabled(False)
        if self.state == "analysing":
            self.pending_count = v                   # applied when the analysis has written session.json
            self.l_count.setText(f"记下了：{v} 个。")
            return
        self._write_count(v)

    def _write_count(self, v: int):
        if self.dir is None:
            return
        try:
            E.save_count(self.dir, v, self.result if (self.result or {}).get("ok") else None)
        except Exception:  # noqa: BLE001
            pass
        self.pending_count = None
        if getattr(self, "_finish_pending", None):
            self._emit_finished()                    # the count is in: now the folder is complete
        shown = (self.result or {}).get("n_targets_shown")
        self.l_count.setText(f"记下了：你数到 {v} 个" + (f"，实际出现 {shown} 个。" if shown is not None else "。"))

    def _open_report(self):
        if self.dir is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.dir / "erp_report.html")))

    def abort(self, why: str = "实验中止。"):
        if not self.is_running():
            return
        self._stop_timers()
        self.state = "idle"
        ended_dir = str(self.rec.dir) if self.rec is not None else None
        if self.rec is not None:
            try:
                self.rec.meta["erp"].update(completed=False, aborted=why, trials_done=self.i if hasattr(self, "i") else 0,
                                            timing=self._timing_summary())
                if getattr(self.hub, "recorder", None) is self.rec:
                    self.rec.add_marker("实验中止", "event")
                self._save_rec_meta()
            except Exception:  # noqa: BLE001
                pass
            self._write_log()
            self._end_recording()
        self.canvas.circle, self.canvas.big_text = None, ""
        self.stack.setCurrentIndex(0)
        self.count_row.setVisible(False)
        self.l_status.setText(why + " 这次不做分析，录下的部分在「回看」里还能看到。")
        self._say(why)
        if ended_dir:
            self.ended.emit(ended_dir)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape and self.is_running():
            self.abort("你中止了实验。")
        else:
            super().keyPressEvent(e)
