"""Real-device acceptance checklist (round 4, R2).

A short list of recordings that the lab needs from the real headband to check and tune the metrics. Each item
is ticked automatically once a qualifying recording of the person exists. Demo ("sim") and replayed recordings
never count. Reading only: nothing here writes to the recordings.

    status(pid=None) -> [{key, title, done, when, dir, hint, note}]

`note` is an extra remark on a done item (e.g. the person's last 指标校验 is older than 30 days), else "".
"""

from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path

from . import people as P
from .paths import ROOT

SLEEP_MIN_S = 4 * 3600
NF_BLOCK_SHARE = 0.8                       # a training block counts when it lasted >= 80 % of its planned length
VALIDATION_PROTOCOL = "指标校验"
VALIDATION_LAST = "校验·再闭眼"           # the protocol's last step: reaching it means the run was not cut short
NOT_REAL = ("sim", "replay")

ITEMS = [
    ("validation", "指标校验",
     "「录制」页选「指标校验」，跟着语音录约 6 分钟（睁眼、闭眼、心算、咬牙、皱眉、左右看、眨眼、再闭眼）。"),
    ("neurofeedback", "神经反馈训练", "「训练」页选一个方案，至少完整练完一组（中途停下的组不算）。"),
    ("p300", "听觉 P300", "「小实验」页做一次「听觉 P300」，全程数高音，尽量少眨眼。"),
    ("sleep", "一整晚睡眠", "睡前在「录制」页选「过夜睡眠」，用省电模式连接，至少睡满 4 小时，早上点结束。"),
    ("video", "带录像的录制", "「录制」页打开「录像/录音…」勾上摄像头录一段，录完在「回看」页点「分析音视频」。"),
    ("latency", "声音延迟校准", "在「小实验」页点「测声音延迟」做一次校准（用麦克风听程序的提示音，约半分钟）。"),
]


def latency_file() -> Path:
    return ROOT / "models" / "audio_latency.json"


def _when(meta: dict) -> str:
    return str(meta.get("started_at") or "")


def _real(meta: dict) -> bool:
    return meta.get("source") not in NOT_REAL


def _segment_labels(d: Path) -> set:
    try:
        with open(d / "markers.csv", encoding="utf-8-sig") as f:
            return {r.get("label", "") for r in csv.DictReader(f) if r.get("kind") == "segment"}
    except OSError:
        return set()


def latency_date(info) -> str:
    """Date of the newest calibrated device in models/audio_latency.json ({"devices": {key: {..., "date"}}}),
    "" when nothing was calibrated."""
    devs = info.get("devices") if isinstance(info, dict) else None
    if not isinstance(devs, dict):
        return ""
    dates = [str(e.get("date") or "") for e in devs.values() if isinstance(e, dict)]
    return max(dates, default="")


def validity_incomplete(v) -> bool:
    """meta["validity"] marked as coming from a run that was cut short (any of the spellings a writer may use)."""
    if isinstance(v, str):
        return v == "incomplete"
    if not isinstance(v, dict):
        return False
    if v.get("incomplete") or v.get("complete") is False or v.get("completed") is False:
        return True
    return any(v.get(k) == "incomplete" for k in ("status", "state", "_status", "_state"))


def nf_full_block(nf: dict) -> bool:
    """At least one training block lasted >= NF_BLOCK_SHARE of its planned length (meta neurofeedback.blocks
    [{seconds}] against neurofeedback.block_seconds)."""
    try:
        plan = float(nf.get("block_seconds") or 0)
    except (TypeError, ValueError):
        return False
    blocks = nf.get("blocks")
    if plan <= 0 or not isinstance(blocks, list):
        return False
    for b in blocks:
        try:
            if isinstance(b, dict) and float(b.get("seconds") or 0) >= NF_BLOCK_SHARE * plan:
                return True
        except (TypeError, ValueError):
            continue
    return False


def validity_note(pid: str) -> str:
    """Remark on the person's stored 指标校验 result: too old / unreadable. Guarded: validity may change."""
    try:
        from . import validity as V
        st = V.status("alpha_ear", pid=pid)
    except Exception:  # noqa: BLE001
        return ""
    if not isinstance(st, dict):
        return ""
    if st.get("stale"):
        d = str(st.get("date") or "")[:10]
        return f"上次校验{('（' + d + '）') if d else ''}超过 30 天，结果仅供参考，建议再录一次"
    return ""


def _json(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


# Each check returns (state, note): state "done", "partial" (tried, not good enough) or None (not a candidate).
def _check_validation(d: Path, meta: dict):
    if meta.get("protocol") != VALIDATION_PROTOCOL:
        return None, ""
    if VALIDATION_LAST not in _segment_labels(d):
        return "partial", "上次没录完最后一段「再闭眼」，请完整再录一次"
    if validity_incomplete(meta.get("validity")):
        return "partial", "上次的校验结果标为不完整，请完整再录一次"
    return "done", ""


def _check_nf(d: Path, meta: dict):
    nf = meta.get("neurofeedback")
    if not isinstance(nf, dict):
        return None, ""
    if nf.get("fast_test"):
        return None, ""
    if nf_full_block(nf):
        return "done", ""
    return "partial", "上次训练没有一组练满计划时长的 80%"


def _check_p300(d: Path, meta: dict):
    e = meta.get("erp")
    if not isinstance(e, dict) or e.get("experiment") != "auditory":
        return None, ""
    res = e.get("result")
    if isinstance(res, dict) and res.get("verdict") in ("found", "none", "reversed"):
        return "done", ""
    if isinstance(res, dict) and res.get("verdict") == "too_few":
        return "partial", "上次能用的试次太少（多半是眨眼或耳后电极），请再做一次"
    return "partial", "上次中途停了，没有结果"


def _check_sleep(d: Path, meta: dict):
    if meta.get("protocol") != "过夜睡眠":
        return None, ""
    dur = float(meta.get("duration") or 0)
    if dur >= SLEEP_MIN_S and isinstance(meta.get("sleep"), dict):
        return "done", ""
    if dur < SLEEP_MIN_S:
        return "partial", f"上次只录了 {dur / 3600:.1f} 小时，需要至少 4 小时"
    return "partial", "录够了时长，但睡眠报告还没生成：在「回看」页打开这条录制点「重新生成睡眠报告」"


def _check_video(d: Path, meta: dict):
    sync = _json(d / "av_sync.json") if (d / "av_sync.json").exists() else None
    if not isinstance(sync, dict) or not sync.get("video"):
        return None, ""
    if (d / "av_features.json").exists():
        return "done", ""
    return "partial", "录像已录好，还没分析：在「回看」页打开这条录制点「分析音视频」"


CHECKS = {"validation": _check_validation, "neurofeedback": _check_nf, "p300": _check_p300,
          "sleep": _check_sleep, "video": _check_video}


def status(pid: str | None = None, sessions: list | None = None) -> list:
    """Checklist of one person (default: the current person). `sessions` may pass a preloaded
    session.list_sessions() result. Returns [{key, title, done, when, dir, hint, note}] in display order;
    `hint` says what to do while an item is open (empty when done); `note` is a remark on a done item."""
    if sessions is None:
        from .session import list_sessions
        sessions = list_sessions()
    pid = pid or P.current()
    best = {k: None for k in CHECKS}          # key -> (state, when, dir, note); latest done wins over partial
    for d, meta in sessions:                  # list_sessions is newest first
        if not isinstance(meta, dict) or not P.mine(meta, pid) or not _real(meta):
            continue
        d = Path(d)
        for k, fn in CHECKS.items():
            cur = best[k]
            if cur is not None and cur[0] == "done":
                continue
            try:
                st, note = fn(d, meta)
            except Exception:  # noqa: BLE001
                continue
            if st is None:
                continue
            if cur is None or st == "done":
                best[k] = (st, _when(meta), str(d), note)
    out = []
    for key, title, todo in ITEMS:
        if key == "latency":
            lf = latency_file()
            info = _json(lf) if lf.exists() else None
            devs = info.get("devices") if isinstance(info, dict) else None
            done = isinstance(devs, dict) and any(isinstance(e, dict) for e in devs.values())
            when = latency_date(info) if done else ""
            if done and not when:
                try:
                    when = datetime.fromtimestamp(lf.stat().st_mtime).isoformat(timespec="seconds")
                except OSError:
                    when = ""
            out.append({"key": key, "title": title, "done": done, "when": when, "dir": "",
                        "hint": "" if done else todo, "note": ""})
            continue
        b = best.get(key)
        done = bool(b and b[0] == "done")
        hint = "" if done else ((b[3] + "。" + todo) if b and b[3] else todo)
        note = validity_note(pid) if key == "validation" and done else ""
        out.append({"key": key, "title": title, "done": done, "when": b[1] if b else "", "dir": b[2] if b else "",
                    "hint": hint, "note": note})
    return out


def summary_text(items: list) -> str:
    n = sum(1 for it in items if it["done"])
    return f"已完成 {n} / {len(items)} 项"
