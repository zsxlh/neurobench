"""Install-root aware paths.

Code may run from <root>/app/neurobench (bundled) or <root>/versions/<ver>/neurobench (updated).
The launcher sets NEUROBENCH_ROOT; otherwise walk up until a folder with recordings/ or .venv/ is found.
"""

from __future__ import annotations

import os
from pathlib import Path

HERE = Path(__file__).resolve().parent


def install_root() -> Path:
    env = os.environ.get("NEUROBENCH_ROOT")
    if env:
        # an explicit root is always used (created if needed): falling back to the real install root would let
        # tests and scratch runs write into the user's recordings
        Path(env).mkdir(parents=True, exist_ok=True)
        return Path(env)
    for p in [HERE, *HERE.parents]:
        if (p / "recordings").is_dir() or (p / ".venv").is_dir():
            return p
    return HERE.parents[1]


ROOT = install_root()
RECORDINGS = ROOT / "recordings"
SESSIONS = RECORDINGS / "sessions"
VERSIONS = ROOT / "versions"
ICON = HERE.parent / "neurobench.ico"
